#!/usr/bin/env python3
"""Post-hoc pair-acceptance diagnostics from verified R54 saved predictions."""
import argparse
from collections import Counter
import hashlib
import importlib.util
import json
import math
from pathlib import Path

REFS = ('frozen666', 'historical663', 'r38', 'r50')
SETTINGS = (('reference', .13), ('candidate', .13), ('candidate', .20))
KPT_CUTOFFS = (.5, .7, .8, .9, .95, .99)
INPUTS_SHA256 = 'b6059a3810e29ba3afb245f1585704521c2633d8caca6fddd908be015e249125'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fraction(numerator, denominator):
    return numerator / denominator if denominator else None


def usable_point(point, cutoff):
    return (all(isinstance(v, (int, float)) and math.isfinite(v) for v in point)
            and 0 <= point[0] < 1280 and 0 <= point[1] < 720
            and point[2] >= cutoff)


def analyze(gold, predictions, scorer, box_cutoff, keypoint_cutoff):
    total = Counter()
    images = {}
    failures = []
    supported_sets = {5: set(), 10: set()}
    for image, targets in gold.items():
        retained = [p for p in predictions[image] if p['confidence'] > box_cutoff]
        accepted = [p for p in retained if all(usable_point(k, keypoint_cutoff)
                                             for k in p['keypoints'])]
        score = scorer.score_image(targets, accepted, 1280, 720, .5, keypoint_cutoff)
        counts = Counter({
            'all_reference_fronts': len(targets),
            'eligible_two_corner_fronts': sum(all(p[2] == 2 for p in g['keypoints']) for g in targets),
            'retained_front_outputs': len(retained),
            'accepted_pair_outputs': len(accepted),
            'withheld_pair_outputs': len(retained) - len(accepted),
            'unmatched_accepted_outputs': score['fp'],
            'duplicate_subset': score['duplicate_fp'],
            'other_unmatched': score['other_fp'],
            'accepted_matches_to_unavailable_pair': 0,
            'accepted_matches_to_two_corner_front': 0,
            'correct_pair_within5': 0,
            'correct_pair_within10': 0,
            'matched_pair_error_over5': 0,
            'matched_pair_error_over10': 0,
        })
        duplicate_indices = set(score['duplicate_prediction_indices'])
        for idx in score['unmatched_prediction_indices']:
            p = accepted[idx]
            failures.append({'image': image, 'category': 'duplicate' if idx in duplicate_indices else 'other_unmatched',
                             'primary_prediction_id': p.get('primary_prediction_id'),
                             'box_confidence': p['confidence'],
                             'min_keypoint_confidence': min(k[2] for k in p['keypoints'])})
        for pair in score['matches']:
            g, p = targets[pair['gold_index']], accepted[pair['prediction_index']]
            identity = {'image': image, 'reference_row_1based': pair['gold_index'] + 1,
                        'primary_prediction_id': p.get('primary_prediction_id'),
                        'box_confidence': p['confidence'],
                        'min_keypoint_confidence': min(k[2] for k in p['keypoints'])}
            if not all(k[2] == 2 for k in g['keypoints']):
                counts['accepted_matches_to_unavailable_pair'] += 1
                failures.append(dict(identity, category='reference_pair_unavailable',
                                     locatable_reference_corners=sum(k[2] == 2 for k in g['keypoints'])))
                continue
            counts['accepted_matches_to_two_corner_front'] += 1
            errors = [math.hypot(a[0] - b[0], a[1] - b[1])
                      for a, b in zip(g['keypoints'], p['keypoints'])]
            worst = max(errors)
            counts['correct_pair_within5'] += worst <= 5
            counts['correct_pair_within10'] += worst <= 10
            counts['matched_pair_error_over5'] += worst > 5
            counts['matched_pair_error_over10'] += worst > 10
            for tolerance in (5, 10):
                if worst <= tolerance:
                    supported_sets[tolerance].add(f"{image}/R{pair['gold_index']+1:03d}")
            if worst > 5:
                failures.append(dict(identity, category='matched_pair_error_over5',
                                     corner_errors_px=errors, worst_corner_error_px=worst))
        for tolerance in (5, 10):
            accounted = (counts['correct_pair_within' + str(tolerance)]
                         + counts['matched_pair_error_over' + str(tolerance)]
                         + counts['accepted_matches_to_unavailable_pair']
                         + counts['unmatched_accepted_outputs'])
            assert accounted == len(accepted), 'Accepted-output categories do not partition outputs'
        total.update(counts)
        images[image] = dict(counts)
    result = dict(total)
    result.update({
        'box_cutoff_strict': box_cutoff, 'keypoint_cutoff_inclusive': keypoint_cutoff,
        'pair_acceptance_fraction': fraction(total['accepted_pair_outputs'], total['retained_front_outputs']),
        'correct_pair_fraction_within5': fraction(total['correct_pair_within5'], total['accepted_pair_outputs']),
        'correct_pair_fraction_within10': fraction(total['correct_pair_within10'], total['accepted_pair_outputs']),
        'all_eligible_pair_recall_within5': fraction(total['correct_pair_within5'], total['eligible_two_corner_fronts']),
        'all_eligible_pair_recall_within10': fraction(total['correct_pair_within10'], total['eligible_two_corner_fronts']),
        'per_image': images,
        '_supported_sets': supported_sets,
    })
    if keypoint_cutoff in (.5, .9):
        result['acceptance_review_ledger'] = failures
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', type=Path, required=True)
    parser.add_argument('--scorer', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    data = json.loads(args.inputs.read_text())
    assert digest(args.inputs) == INPUTS_SHA256, 'Inputs differ from verified R54 snapshot'
    assert digest(args.scorer) == data['provenance']['scorer_sha256'], 'Scorer differs from verified original'
    spec = importlib.util.spec_from_file_location('original_pose_scoring', args.scorer)
    scorer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scorer)
    baseline_checks = []
    for name in REFS:
        gold = data['references'][name]['gold']
        for role in ('reference', 'candidate'):
            scores = {image: scorer.score_image(targets, data['predictions'][role][image], 1280, 720, .5, .5)
                      for image, targets in gold.items()}
            expected = data['expected_baseline'][name][role]
            assert scores == expected['per_image'], f'Baseline image scoring differs: {name}/{role}'
            assert scorer.aggregate_scores(list(scores.values())) == expected['detection'], f'Baseline totals differ: {name}/{role}'
            baseline_checks.append(name + '/' + role)
    results = {}
    for name in REFS:
        results[name] = {}
        for role, box_cutoff in SETTINGS:
            key = role + '_box' + str(box_cutoff)
            results[name][key] = [analyze(data['references'][name]['gold'], data['predictions'][role],
                                         scorer, box_cutoff, q) for q in KPT_CUTOFFS]
            base_sets = results[name][key][0]['_supported_sets']
            for row in results[name][key]:
                these_sets = row.pop('_supported_sets')
                row['paired_supported_targets_vs_keypoint05'] = {
                    str(tolerance): {
                        'lost_reference_supported_targets': sorted(base_sets[tolerance] - these_sets[tolerance]),
                        'new_reference_supported_targets': sorted(these_sets[tolerance] - base_sets[tolerance]),
                    } for tolerance in (5, 10)
                }
    report = {
        'schema': 'r55-automatic-pair-probe-v1',
        'purpose': 'Post-hoc output-contract diagnostic, not an approved automatic-use gate',
        'fresh_inference': False, 'fresh_training': False, 'automatic_promotion': False,
        'provenance': {'inputs_sha256': digest(args.inputs), 'scorer_sha256': digest(args.scorer),
                       'script_sha256': digest(Path(__file__)), 'input_provenance': data['provenance']},
        'protocol': {
            'pair_rule': 'Both keypoints finite and inside original 1280x720 image, each confidence >= keypoint cutoff',
            'matching': 'Recompute original confidence-ordered same-class IoU>=.5 matcher using ONLY accepted predictions against ALL reference fronts',
            'pair_success': 'Reference-supported usable-pair success: assigned reference has both slots v=2, and both original-pixel distances <= tolerance',
            'success_fraction_denominator': 'All accepted pair outputs, including unmatched and unavailable-reference pairs',
            'recall_denominator': 'All reference fronts with two v=2 slots, including missed or withheld fronts',
            'unavailable_interpretation': 'Unsupported relative to reference; no physical localization-error claim for absent coordinates',
            'box_cutoffs': [0.13, 0.20], 'keypoint_cutoffs': list(KPT_CUTOFFS),
            'pixel_tolerances': [5, 10],
            'limits': ['Repeated development photographs; post-hoc threshold comparison',
                       'Saved postclip cache is censored below box confidence .13',
                       'No robot or physical-operation accuracy measured',
                       '5/10 pixel tolerances are diagnostic, not user-approved requirements',
                       'No conclusion that confidence is a calibrated probability',
                       'Unmatched and reference-unavailable pairs are unverified for this supported-pair criterion, not proven physical errors',
                       'All four references annotate the same photographs'],
        },
        'verification': {'original_baseline_tables_exact': baseline_checks,
                         'accepted_categories_partition_each_image': True},
        'results': results,
    }
    (args.output / 'automatic-pair-results.json').write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + '\n')
    lines = ['# R55 automatic pair-output diagnostic', '',
             'Automatic consumption makes the quality of each emitted coordinate pair important. This analysis asks whether the existing endpoint-score screen alone establishes a well-supported two-corner output. It is not a new model, deployed gate or independent evaluation.', '',
             'Only saved postclip predictions are filtered. Matching is recomputed among accepted predictions against every reference front. A reference-supported usable pair must match a reference with both corners locatable and have both errors within the stated original-pixel tolerance. Unmatched accepted predictions and matches to unavailable pairs stay in the acceptance denominator; their lack of support is not a claim of proven physical error.', '',
             'The original eight model/reference baseline tables reproduce exactly before this new diagnostic.', '']
    for name in ('frozen666', 'r50'):
        lines.extend(['## ' + name, '',
                      '| Model / box cutoff | Corner cutoff | Accepted pairs | Reference-supported ≤5px | Reference-supported ≤10px | Unmatched accepted | Unavailable reference pair | Matched localization >5px | Supported-pair fraction ≤5px | Eligible-pair recall ≤5px |',
                      '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |'])
        for model, rows in results[name].items():
            for row in rows:
                precision = row['correct_pair_fraction_within5']
                recall = row['all_eligible_pair_recall_within5']
                lines.append(f"| {model} | {row['keypoint_cutoff_inclusive']:.2f} | {row['accepted_pair_outputs']} | {row['correct_pair_within5']} | {row['correct_pair_within10']} | {row['unmatched_accepted_outputs']} | {row['accepted_matches_to_unavailable_pair']} | {row['matched_pair_error_over5']} | {'N/A' if precision is None else f'{100*precision:.2f}%'} | {100*recall:.2f}% |")
        lines.append('')
    lines.extend(['## Interpretation limits', '',
                  '- Endpoint confidence is being tested as an acceptance signal, not assumed to encode physical visibility or error.',
                  '- A reference-unavailable pair has no two-point ground truth for localization; it is unsupported by the chosen reference, not proven physically wrong.',
                  '- Supported-pair fractions combine reference-unverified outputs and measured localization failures in their complement. They are not calibrated precision or true automated-use accuracy.',
                  '- The four reference versions reuse the same 20 development photographs. The 5/10px tolerances are diagnostic, not a downstream acceptance requirement.',
                  '- A cutoff accepting zero pairs has no defined accepted-pair precision. It must not be described as 100% reliable.',
                  '- The candidate .20 box cutoff is inherited from the R54 exploratory analysis, not newly validated for automatic consumption.',
                  '- No runtime, label, model or deployment setting changes in this analysis.', '',
                  '## Reproduce', '',
                  'Use the existing R54 verified inputs and scorer:', '',
                  '    python -B analyze_automatic_pairs.py --inputs ../r54-analysis/inputs.json --scorer ../r54-analysis/pose_scoring.py --output replay', ''])
    (args.output / 'automatic-pair-results.md').write_text('\n'.join(lines))
    print(json.dumps({'baseline_checks': len(baseline_checks), 'output': str(args.output),
                      'rows': len(REFS)*len(SETTINGS)*len(KPT_CUTOFFS)}))


if __name__ == '__main__':
    main()
