# R55 automatic output audit and thesis blueprint

27 November 2026 · Asia/Hong_Kong

Start with `thesis-outline-r55.md` for the report structure, 222-word provisional abstract, output contract, completed results, and next steps. `thesis-next-steps-r54.md` is the updated research note; the earlier R54 ZIP remains an immutable historical snapshot.

## What was measured

The R55 script replays saved R51 postclip predictions. It first verifies all eight original model/reference score tables, then evaluates 72 settings: four reference versions, three model/box-cutoff combinations, and six endpoint-score cutoffs. It does not run a model or train one.

A pair passes the simulated screen when its box score is strictly above the stated cutoff and both endpoints have finite coordinates inside the original 1280×720 image with endpoint scores at least the stated cutoff. The original matcher is recomputed among offered pairs against all reference fronts.

A reference-supported pair success requires an assigned reference with two locatable corners and both errors within the 5- or 10-pixel diagnostic tolerance. All offered pairs remain in the supported-fraction denominator. Every reference front with two locatable corners remains in the recall denominator.

Unmatched outputs and matches to incomplete reference pairs are unverified under this complete-pair criterion, not all proven physical errors. JSON fields beginning `correct_pair_` mean reference-supported success under this explicit definition, not externally established physical correctness. `acceptance_review_ledger` likewise includes cases needing review, not only established errors.

## Reproduce

From the extracted `r55-analysis` folder:

```bash
python -B analyze_automatic_pairs.py --inputs ../r54-analysis/inputs.json --scorer ../r54-analysis/pose_scoring.py --output replay
```

Python 3 and its standard library are sufficient. No GPU, images, network, model weights, or additional notebook is required. The verified original scorer and immutable saved inputs are included under `r54-analysis`.

`automatic-pair-results.json` contains all four references, per-image counts, two tolerance partitions, paired supported-target gains/losses relative to endpoint cutoff 0.50, and review ledgers at the declared 0.50/0.90 settings. `automatic-pair-results.md` presents the primary frozen666 and reviewed R50 views. The script and copied inputs are pinned by hashes.

## Independent verification

The highlighted candidate box >0.20 / endpoint ≥0.50, ≥0.80, ≥0.95 settings were separately recomputed for frozen666 and R50. A separately implemented confidence-ordered IoU matcher agreed with the original scorer; all six aggregate results, 120 image-level results, category partitions, and fractions matched. The shipped replay also checks every original baseline table before the new analysis.

This establishes reproducibility of the reported arithmetic and associations, not independent validation on new photographs.

## Interpretation

- All four references describe the same 20 repeatedly examined development photographs.
- The box cutoff 0.20 and endpoint sensitivity checks are post-hoc exploration. They are not new runtime defaults or approved automatic-use gates.
- Pair screening preserves 722 front proposals at candidate box >0.20. Box presence/count quality still needs its own evaluation.
- Endpoint scores are not assumed to measure physical visibility or localization probability.
- The source cache excludes box scores below 0.13 and cannot establish full AP.
- Naturally unavailable coordinates cannot fully verify a pair. One available endpoint may still provide partial localization evidence.
- At zero offered pairs, the supported fraction is undefined.
- R53 notebook results remain pending; no improvement is claimed for them here.

## Provenance

`manifest.json` records byte counts and SHA-256 digests for every deliverable in this bundle. `source-provenance.json` records the inspected source revisions and blob IDs. The saved-input JSON preserves original archive, source-closure, prediction-cache and reference provenance.

Upstream baomai: `351eb3cf960ccc34829e2bc72e1fa4645acc6295`.
Local project source snapshot: `5001d83439eaf31c7ecae378c27a0de847e65686`.

The application design is specified in the thesis blueprint. No running viewer, label, model checkpoint, notebook setting, or deployment setting was modified by this audit.
