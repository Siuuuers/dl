# Three-frame annotation review — quarantined proposal

This package preserves 129 individually reviewed source rows in three images. It contains 87 changed boxes and five corrected endpoint positions, with all instance and visibility states retained. All three images remain quarantined: 35 upper-front/roof-or-rim extents and one left extent beside the gripper remain unresolved. There are no scoring-eligible images here.

`candidate/` contains the separately versioned manifest, exact proposal labels, preserved source labels, all-row decisions, read-only verifier, and nine original/source/proposal figures. Figure paths in the row ledgers are relative to that candidate directory. Read `candidate/README.md` for the review decisions and full repository report links; repository-relative links resolve in the repository version of that README.

`source/` contains the byte-identical upstream manifest and only the three selected original JPEG/label pairs. The manifest inventories all 320 upstream frames; the other 317 image/label pairs are intentionally not included. This is a selected pilot, not a complete pool review.

`editor/` contains three 1280x720 PNG/TXT pairs for further annotation review. PNG files are lossless exports of the decoded original JPEG RGB pixels, without resizing, retouching, or coordinate transforms. They are not native original PNGs or JPEG-byte-identical files. `PNG-export.json` records both encoded and decoded-pixel identities. Every TXT exactly matches its quarantined candidate. Opening these files in an editor does not change their disposition; no browser Save/reopen acceptance is claimed by this package.

`reviewer-records/` preserves exact first-review, peer-reassessment and final consistency records. Their historical absolute paths and references to additional scratch crops document the review process; they are not portable executable paths, and those individual scratch crops are not all bundled. The normalized candidate ledgers and nine bundled comparisons are the portable final record. In particular, the earlier frame_0383 top expansions were withdrawn after the front-versus-roof/rim challenge.

`selected-figures/` contains the three report illustrations. `verification.json` records source and candidate integrity, complete row accounting, geometry and unresolved-field preservation; it is not physical truth certification. `inventory.json` lists SHA256 and byte length for every other payload file. The archive's own digest and fresh-restore result are recorded in the repository report JSON.

From the repository root containing this candidate, after extracting this ZIP to `/path/review`:

```bash
python data/candidates/additional-pilot-2026-11-07/verify.py --root . --candidate /path/review/candidate --source-root /path/review/source
python /path/review/candidate/render_comparison.py --source-root /path/review/source --candidate /path/review/candidate --output /path/new-figures
```

The verifier uses the existing repository label parser and geometry helper without a model runtime. Rendering requires Pillow, NumPy and Matplotlib; the recorded versions reproduce the saved nine comparisons. Keep the frozen development dataset, model comparison and default unchanged. No training or inference was run for this annotation proposal.
