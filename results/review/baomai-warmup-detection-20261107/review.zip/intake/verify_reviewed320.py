"""Verify the pinned upstream reviewed package without model inference or relabeling."""
from collections import Counter
from hashlib import sha1, sha256
from io import BytesIO
import json
import math
from pathlib import Path, PurePosixPath
import stat
from zipfile import ZipFile

from PIL import Image, ExifTags

ROOT = Path('/workspace/scratch/ad3aa7140d65')
ZIP_PATH = ROOT / 'heldout-upstream-intake/reviewed320.download.zip'
DEST = ROOT / 'heldout-reviewed320'
META = ROOT / 'heldout-intake-metadata'
EXPECTED_ZIP_SHA = 'b28bcce5fffe91f3e486ff11ec3085a67c868fe09e65c14788bc6fe494af4dd0'
EXPECTED_META_BLOBS = {
    'manifest.json': '5cc53414681d873fef5112e715d8ff1ee64eeadf',
    'README.txt': '402a10a574eba8f8c9accdc376795bbcf4325b55',
    'pose_schema.yaml': '697a0a01b24847472803a8e61787d12bdfe68a20',
    'validation_report.json': '798c78373a2282fe7076a110d628a387f4e084f8',
}

payload = ZIP_PATH.read_bytes()
assert len(payload) == 43424432
assert sha256(payload).hexdigest() == EXPECTED_ZIP_SHA
frozen_path = ROOT / 'dl/data/manifest.json'
frozen = json.loads(frozen_path.read_text())
assert sha256(frozen_path.read_bytes()).hexdigest() == '72ae8365d5abf0b45b75d400a2e6d22119c0e31b54ee33035feb8edc1f967926'
frozen_hashes = {r['image_sha256']: r for r in frozen['records']}
source_blobs = {r['path']: r for r in json.loads((META / 'reviewed320-source-git-blobs.json').read_text())['entries']}
source_blob_matches = Counter()
pixel_hashes_frozen = {}
for record in frozen['records']:
    image_path = ROOT / 'dl/data' / record['image']
    if image_path.stat().st_size > 200:
        b = image_path.read_bytes()
        assert sha256(b).hexdigest() == record['image_sha256']
        with Image.open(BytesIO(b)) as im:
            pixel_hashes_frozen[sha256(im.convert('RGB').tobytes()).hexdigest()] = record['id']

errors = []
counts = Counter()
dimensions = Counter()
formats = Counter()
pixel_hashes = []
raw_hashes = []
exif_fields = Counter()
examples = {}

def issue(kind, image, line=None, detail=None):
    errors.append({'kind': kind, 'image': image, 'line': line, 'detail': detail})

with ZipFile(BytesIO(payload)) as z:
    members = z.infolist()
    names = [i.filename for i in members]
    assert len(names) == len(set(names)) == 644
    assert z.testzip() is None
    assert not any(PurePosixPath(n).is_absolute() or '..' in PurePosixPath(n).parts or '\\' in n for n in names)
    assert not any(stat.S_ISLNK(i.external_attr >> 16) for i in members)
    archive_meta = {}
    for name, expected_blob in EXPECTED_META_BLOBS.items():
        data = z.read('white_box_pose/' + name)
        blob = sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert blob == expected_blob, name
        archive_meta[name] = {'git_blob': blob, 'sha256': sha256(data).hexdigest(), 'bytes': len(data)}
    manifest = json.loads(z.read('white_box_pose/manifest.json').decode('utf-8-sig'))
    assert manifest == json.loads((META / 'reviewed320-source-manifest.json').read_text())
    assert len(manifest['images']) == 320
    allowed = {'white_box_pose/' + n for n in EXPECTED_META_BLOBS}
    for record in manifest['images']:
        allowed.update('white_box_pose/' + record[k] for k in ['image', 'label'])
    assert set(names) == allowed
    for record in manifest['images']:
        name = record['image']
        image_bytes = z.read('white_box_pose/' + name)
        label_bytes = z.read('white_box_pose/' + record['label'])
        assert sha256(image_bytes).hexdigest() == record['image_sha256'], name
        assert sha256(label_bytes).hexdigest() == record['label_sha256'], name
        for kind, data in [('image', image_bytes), ('label', label_bytes)]:
            source_path = 'box_in_basket/white_box_pose/' + record[kind]
            expected = source_blobs[source_path]
            git_bytes = data
            if kind == 'image':
                git_bytes = ('version https://git-lfs.github.com/spec/v1\noid sha256:' + sha256(data).hexdigest() + '\nsize ' + str(len(data)) + '\n').encode()
            git_blob = sha1(b'blob ' + str(len(git_bytes)).encode() + b'\0' + git_bytes).hexdigest()
            assert git_blob == expected['git_blob'] and len(git_bytes) == expected['git_blob_bytes'], source_path
            source_blob_matches['image_pointer_matches' if kind == 'image' else 'label_blob_matches'] += 1
        raw_hashes.append(record['image_sha256'])
        if record['image_sha256'] in frozen_hashes:
            issue('raw_hash_overlap_frozen157', name)
        with Image.open(BytesIO(image_bytes)) as im:
            im.load()
            assert im.size == (record['width'], record['height']) == (1280, 720)
            dimensions[str(im.size)] += 1
            formats[str(im.format)] += 1
            pixels = sha256(im.convert('RGB').tobytes()).hexdigest()
            pixel_hashes.append(pixels)
            if pixels in pixel_hashes_frozen:
                issue('decoded_pixel_overlap_materialized_frozen', name, detail=pixel_hashes_frozen[pixels])
            for tag in im.getexif().keys():
                exif_fields[ExifTags.TAGS.get(tag, str(tag))] += 1
        lines = [line for line in label_bytes.decode('utf-8-sig').splitlines() if line.strip()]
        assert len(lines) == record['object_count'], name
        for i, line in enumerate(lines, 1):
            counts['objects'] += 1
            fields = line.split()
            if len(fields) != 11:
                issue('field_count', name, i, len(fields))
                continue
            try:
                vals = list(map(float, fields))
            except ValueError:
                issue('non_numeric', name, i)
                continue
            if not all(math.isfinite(v) for v in vals):
                issue('nonfinite', name, i)
                continue
            cls, cx, cy, w, h, lx, ly, lv, rx, ry, rv = vals
            if cls != 0:
                issue('nonzero_class', name, i, cls)
            if not all(0 <= v <= 1 for v in [cx, cy, w, h, lx, ly, rx, ry]):
                issue('coordinate_range', name, i)
            xmin, xmax, ymin, ymax = cx-w/2, cx+w/2, cy-h/2, cy+h/2
            if w <= 0 or h <= 0 or xmin < -1e-6 or ymin < -1e-6 or xmax > 1+1e-6 or ymax > 1+1e-6:
                issue('invalid_box', name, i)
            for side, x, y, v in [('left', lx, ly, lv), ('right', rx, ry, rv)]:
                counts['visibility_' + str(v)] += 1
                if v not in (0, 2):
                    issue('visibility_code', name, i, v)
                if v == 0 and (x != 0 or y != 0):
                    issue('noncanonical_missing', name, i, side)
                if v == 2 and not (xmin-1e-6 <= x <= xmax+1e-6 and ymin-1e-6 <= y <= ymax+1e-6):
                    issue('point_outside_box', name, i, side)
            if lv == 2 and rv == 2:
                counts['both_visible_objects'] += 1
                if lx > rx:
                    issue('image_x_order', name, i)
            if lv == 0 and rv == 0:
                counts['both_missing_objects'] += 1
                examples.setdefault('both_missing', {'image': name, 'line': i})
            if (lv == 0) != (rv == 0):
                counts['one_missing_objects'] += 1
        counts['images'] += 1
        counts['labels'] += 1
    assert len(set(raw_hashes)) == 320
    assert len(set(pixel_hashes)) == 320
    assert counts['objects'] == manifest['object_count'] == 12987
    DEST.mkdir(exist_ok=True)
    for member in members:
        dest = DEST / member.filename
        dest.parent.mkdir(parents=True, exist_ok=True)
        data = z.read(member)
        if dest.exists():
            assert dest.read_bytes() == data
        else:
            dest.write_bytes(data)

report = {
    'purpose': 'Archive and label intake verification only; no model training or inference.',
    'source_commit': '9a6bf2432582af517d789c94eab2ac27e03a304b',
    'zip_path': str(ZIP_PATH), 'zip_bytes': len(payload), 'zip_sha256': EXPECTED_ZIP_SHA,
    'archive_entries': 644, 'unsafe_paths': 0, 'duplicate_paths': 0, 'symlinks': 0, 'crc_errors': 0,
    'extract_root': str(DEST / 'white_box_pose'),
    'metadata_matches_pinned_git_blobs': archive_meta,
    'counts': dict(counts), 'image_formats': dict(formats), 'dimensions': dict(dimensions),
    'all_image_sha256_match_manifest': True, 'all_label_sha256_match_manifest': True,
    'actual_payload_matches_all_source_image_pointers_and_label_git_blobs': dict(source_blob_matches),
    'unique_raw_hashes': len(set(raw_hashes)), 'unique_decoded_rgb_hashes': len(set(pixel_hashes)),
    'raw_hash_overlap_frozen157': len(set(raw_hashes) & set(frozen_hashes)),
    'materialized_frozen_images_compared_by_decoded_pixels': len(pixel_hashes_frozen),
    'decoded_pixel_overlap_materialized_frozen': len(set(pixel_hashes) & set(pixel_hashes_frozen)),
    'exif_tag_image_counts': dict(exif_fields),
    'independent_label_validation_errors': errors, 'examples': examples,
    'limits': [
        'Exact byte and decoded-pixel uniqueness do not establish independent scenes or capture sessions.',
        'Only 20 frozen originals are materialized locally for decoded-pixel comparison; all157 declared original hashes were compared.',
        'This mechanical audit does not adjudicate visible-front box or physical-corner semantics.',
        'No score or model prediction was generated for these prospective images.'
    ]
}
(META / 'payload-verification.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
