# Recover the pinned reviewed320 source ZIP

The original bounded LFS smudge completed in 10.4 seconds. Its pinned 133-byte pointer was passed on stdin, `GIT_LFS_SKIP_SMUDGE` was removed from the child environment, stdout went to a separate file, and the subprocess had a 50-second timeout. The source working-tree ZIP remains a pointer. Do not confuse that pointer with the actual recovered 43,424,432-byte payload.

The recipe below uses Python 3, Git and Git LFS on Linux/macOS. Clone setup and pinned-pointer reading are separate from the 50-second payload-transfer limit. No retry loop or model-weight download is needed.

```sh
GIT_LFS_SKIP_SMUDGE=1 git clone --no-checkout --filter=blob:none --single-branch --branch grasp-vision https://github.com/an94-doll/embedding_vision.git reviewed320-source

python3 - <<'PY'
import hashlib
import os
from pathlib import Path
import signal
import subprocess

repo = Path('reviewed320-source').resolve()
commit = '9a6bf2432582af517d789c94eab2ac27e03a304b'
source_path = 'box_in_basket/white_box_pose_reviewed_320_images_20261028_145012.zip'
expected_size = 43_424_432
expected_sha256 = 'b28bcce5fffe91f3e486ff11ec3085a67c868fe09e65c14788bc6fe494af4dd0'
pointer = subprocess.check_output(
    ['git', 'show', f'{commit}:{source_path}'], cwd=repo, timeout=30)
expected_pointer = (
    'version https://git-lfs.github.com/spec/v1\n'
    f'oid sha256:{expected_sha256}\nsize {expected_size}\n'
).encode('ascii')
if pointer != expected_pointer:
    raise RuntimeError('Pinned source pointer differs from the audited ZIP.')

output = Path('reviewed320.download.zip')
partial = Path('reviewed320.download.zip.partial')
if output.exists() or partial.exists():
    raise RuntimeError('Choose a new output path; an output or partial file exists.')
env = os.environ.copy()
env.pop('GIT_LFS_SKIP_SMUDGE', None)
try:
    with partial.open('xb') as handle:
        proc = subprocess.Popen(
            ['git', '-c', 'lfs.dialtimeout=15', '-c', 'lfs.activitytimeout=30',
             'lfs', 'smudge', source_path],
            cwd=repo, env=env, stdin=subprocess.PIPE, stdout=handle,
            stderr=subprocess.PIPE, start_new_session=True)
        try:
            _, stderr = proc.communicate(input=pointer, timeout=50)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL)
            proc.communicate(timeout=5)
            raise RuntimeError('Git LFS transfer exceeded 50 seconds.')
        if proc.returncode != 0:
            raise RuntimeError(f'Git LFS transfer failed with exit {proc.returncode}.')
    payload = partial.read_bytes()
    actual_sha256 = hashlib.sha256(payload).hexdigest()
    if len(payload) != expected_size or actual_sha256 != expected_sha256:
        raise RuntimeError('Downloaded payload failed exact size/SHA256 verification.')
    partial.replace(output)
    print(f'Verified {output}: {expected_size} bytes, SHA256 {actual_sha256}')
finally:
    partial.unlink(missing_ok=True)
PY
```

The ZIP contains 644 files: 320 original JPEGs, 320 labels and four metadata files. `payload-verification.json` records safe paths, unique members, no symlinks, CRC checks, exact manifest hashes, and Git blob/pointer identity for every source item. Only extract the verified archive after checking these properties. The source metadata and split CSV are preserved as bytes in this capsule.

`verify_reviewed320.py` is the original capture-time audit helper, not a generalized dataset importer. Its `ROOT` expects a workspace containing `dl/data/manifest.json`, the source ZIP at `heldout-upstream-intake/reviewed320.download.zip`, the metadata in `heldout-intake-metadata`, and an extraction directory `heldout-reviewed320`. It compares decoded pixels only for materialized frozen images, while comparing declared raw SHA256 values against all 157. The recorded run materialized 20 frozen validation originals. Changing this root/layout for reproduction does not authorize label adaptation or scoring.

The source annotations remain unapproved for current-policy supplementary evaluation: the supplied boxes in frame_0160 extend into the metal rack/base. Preserve source bytes and identities, then perform a separately versioned physical annotation review before releasing a scoring reference.
