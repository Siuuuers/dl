# Warmup detection review and additional-frame intake evidence

This capsule records a completed physical review of nine lost and eight gained matches on the frozen 20-image development reference, point-availability accounting, and a recovered 320-frame source-pool audit. A separate three-image semantic pilot requires annotation adaptation before supplementary scoring. No new inference, training, label edit or replacement decision is included.

## Source and interpretation

- Result/report base: `Siuuuers/dl` commit `2799b8332bb46ba07d0ef95652d7f398559573c9` (PR 17).
- Evaluation/replay source used for the portable case figures: `2f0260c19835fcd60eb2f12040b7c77ebd2ca890`.
- Earlier original-image review checkout: `679b87b38e7b0bca5fbd02fb1519a90fb2379541`; the recorded raw image/label bytes are unchanged.
- Frozen policy: `baomai-visible-front-v1`, SHA-256 `3cda361ac4c5c9ba36b037e7e8968e0629eb3bca8d489c187beb8dd66e208a91`.
- Additional source: `an94-doll/embedding_vision`, grasp-vision commit `9a6bf2432582af517d789c94eab2ac27e03a304b`.

Original evidence JSON preserves capture-time absolute paths for traceability. Those paths describe the review workspace; portable commands below accept explicit input/output directories. Case rows are explicitly one-based where named as such. Gold indices in model score records are zero-based.

`losses/` and `gains/` contain physical findings, reference identity and saved numerical measurements. These cases were selected from known model disagreements; their review was not blinded and does not estimate annotation-error prevalence. `semantic-pilot/` contains supplied-label-only inspection of frame_0001, frame_0160 and frame_0383. That pilot used no model predictions and does not certify all 129 rows or the other 317 images.

`intake/` retains source metadata, per-image/label hashes, source Git blob identities, prior-use evidence, old-data overlap mapping and actual ZIP verification. The original intake audit script is preserved with its capture-time workspace paths; its mechanical checks do not approve physical box semantics. The 43 MB source ZIP, raw validation PNGs and checkpoint weights are not duplicated here.

## Restore the original saved evaluation

Use a checkout of the result base above with its original validation PNGs materialized through Git LFS. The evaluation archive at `results/evaluation/baomai-warmup-a100-001/evaluation.zip` must have SHA-256:

`a321cd6f9c0f7cf5cc4830df2c7b36c7d833097ce93085c684f3d13bc3836787`

Extract it to a new `evaluation-evidence` directory, and this capsule to a new `review-evidence` directory. Before extraction, verify each whole-archive checksum and each archive's inventory. `inventory.json` records the size and SHA-256 of every other file in this capsule; it intentionally cannot hash itself.

## Recompute the cohort accounting

With the result checkout at `dl-source`:

```sh
python review-evidence/helpers/compute_cohorts.py --root dl-source --evidence evaluation-evidence --output cohort-replay.json
```

This verifies the frozen reference and exact saved per-image score hashes, then recounts all three disjoint point-availability groups and four overlapping image-edge groups. It refuses a different reference, score bytes, count result or an existing output. It does not load model weights or change the scorer. Only the three point-availability groups partition all 664 objects.

## Reproduce the case figures

```sh
python review-evidence/helpers/render_lost_cases.py --root dl-source --output lost-figures
python review-evidence/helpers/render_gained_cases.py --root dl-source --evidence evaluation-evidence --transitions review-evidence/object-transition-details.json --output gained-figures
```

The portable helpers reproduce all nine and eight PNGs byte-for-byte in the recorded runtime. Rendering is not a new physical review. The gain renderer reports original IDs rendered, rather than asserting a new visual inspection. `helpers/changes.json` records the path-parameterization changes relative to the original capture-time renderers. `render-verification.json` records all 17 successful PNG comparisons.

The rendering runtime was Python 3.12.14, Pillow 13.0.0, Matplotlib 3.11.2 and NumPy 2.5.4, with DejaVu Sans. Different rendering libraries or fonts may change PNG bytes without changing the source measurements. The cohort helper itself requires no machine-learning runtime.

## Reproduce the semantic-pilot overlays

Recover the pinned upstream ZIP as described in `intake/recover-source.md`. Its actual payload is 43,424,432 bytes with SHA-256:

`b28bcce5fffe91f3e486ff11ec3085a67c868fe09e65c14788bc6fe494af4dd0`

After validating that checksum and archive paths, extract the payload so `additional-source/white_box_pose/images` and `labels` contain the original files:

```sh
python review-evidence/helpers/render_semantic_intake.py --root additional-source/white_box_pose --output semantic-figures
```

`semantic-pilot/overlay-inputs.json` records all six source image/label hashes, supplied rows, pixel coordinates, crop extents and six figure hashes. `semantic-pilot/render-verification.json` confirms those inputs and byte-identical re-rendering of all six figures. The renderer adds no predictions and performs no label conversion.

## Decision and next work

Retain M0. The original comparison still has warmup FN 37 versus control FN 36, and its rule is unchanged. The additional-frame pool is unscored by these checkpoints. Its supplied bottom-stack boxes include visible rack/base in frame_0160 and require separately versioned adaptation under the existing visible-front rule. Preserve source hashes and row identities, review included front boxes and endpoint states, adjudicate or quarantine ambiguity, and freeze exact adapted labels before supplementary scoring.

The upstream 48-image test listing includes 18 images from the current reference (15 training and three validation), including re-encodings. The 320 additions have zero exact raw-hash overlap with the frozen 157, but upstream already used them in another model's random frame split. No independent scene/capture-session claim follows. The original five excluded final-test images have not been recovered as a certified set.
