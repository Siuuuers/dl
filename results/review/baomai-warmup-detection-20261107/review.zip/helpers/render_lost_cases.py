"""Deterministic raw/reference crops for a physical annotation-policy review."""
import json
import sys
from pathlib import Path

import argparse
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
ROOT = args.root.resolve()
OUTPUT = args.output.resolve()
OUTPUT.mkdir(parents=True, exist_ok=False)
OUT = OUTPUT / 'crops'
OUT.mkdir()
sys.path.insert(0, str(ROOT / 'scripts'))
from evaluate_pose import preflight_dataset
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from PIL import Image

CASES = {
    ('new_000009', 8): (600, 0, 740, 70),
    ('new_000009', 52): (570, 435, 680, 520),
    ('new_000009', 57): (710, 440, 850, 545),
    ('new_000010', 14): (560, 410, 805, 560),
    ('new_000011', 15): (630, 0, 775, 80),
    ('new_000011', 61): (650, 415, 765, 510),
    ('new_000053', 1): (610, 0, 800, 95),
    ('new_000056', 4): (370, 300, 590, 465),
    ('new_000059', 1): (940, 0, 1190, 100),
}

records = {r['id']: r for r in preflight_dataset(ROOT, require_weights=False)['records']}
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 11})
inventory = []
for (identifier, row), crop in CASES.items():
    record = records[identifier]
    original = Image.open(record['image_path']).convert('RGB')
    fig, axes = plt.subplots(1, 2, figsize=(13, 6), sharex=True, sharey=True)
    neighbors = []
    for axis in axes:
        axis.imshow(original, interpolation='nearest')
        axis.set_xlim(crop[0], crop[2])
        axis.set_ylim(crop[3], crop[1])
        axis.set_xlabel('Original X (px)')
    axes[0].set_ylabel('Original Y (px)')
    axes[0].set_title('Original pixels, no annotation')
    axes[1].set_title('Frozen target (green); nearby rows (orange)')
    for index, gold in enumerate(record['gold']):
        box = gold['bbox_xyxy']
        if box[2] < crop[0] or box[0] > crop[2] or box[3] < crop[1] or box[1] > crop[3]:
            continue
        color = '#00ff92' if index+1 == row else '#ff9f43'
        axes[1].add_patch(Rectangle((box[0], box[1]), box[2]-box[0], box[3]-box[1],
                                   fill=False, linewidth=1.4 if index+1 == row else .8,
                                   edgecolor=color, clip_on=True))
        label_x = max(crop[0]+1, box[0]+2)
        label_y = max(crop[1]+3, box[1]+3)
        axes[1].text(label_x, label_y, str(index+1), color='black', fontsize=9,
                     va='top', bbox={'facecolor': color, 'edgecolor': 'none', 'pad': .7, 'alpha': .8},
                     clip_on=True)
        if index+1 == row:
            for x, y, v in gold['keypoints']:
                if v == 2:
                    axes[1].scatter(x, y, marker='o', s=45, facecolors='none', edgecolors=color, linewidths=1.5)
        neighbors.append({'row_one_based': index+1, 'gold': gold})
    fig.suptitle(f'{identifier} · target label row {row} · original-image inspection', fontsize=16)
    fig.text(.5, .035, 'Nearest-neighbor display only. No pixel correction, inferred corner, or reference edit.', ha='center', fontsize=10)
    fig.subplots_adjust(left=.06, right=.99, top=.86, bottom=.15, wspace=.10)
    path = OUT / f'{identifier}-row-{row:02d}.png'
    fig.savefig(path, dpi=150, facecolor='white')
    plt.close(fig)
    inventory.append({'image_id': identifier, 'target_row_one_based': row, 'crop_xyxy': crop,
                      'source_image': str(record['image_path']), 'figure': str(path),
                      'reference_rows_shown': neighbors})
(OUTPUT / 'crop-inputs.json').write_text(json.dumps(inventory, indent=2)+'\n')
print(json.dumps({'figures': len(inventory), 'output': str(OUT)}))
