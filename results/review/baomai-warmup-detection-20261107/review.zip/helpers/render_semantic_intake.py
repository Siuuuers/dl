"""Plot only supplied annotations for a model-blind three-image intake pilot."""
import argparse
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from PIL import Image


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    crops = {'frame_0001': (600, 495, 885, 690),
             'frame_0160': (385, 525, 625, 685),
             'frame_0383': (505, 470, 730, 600)}
    inputs = []
    for name, crop in crops.items():
        image_path = args.root / 'images' / f'{name}.jpg'
        label_path = args.root / 'labels' / f'{name}.txt'
        original = Image.open(image_path).convert('RGB')
        width, height = original.size
        rows = []
        for row_number, line in enumerate(label_path.read_text().splitlines(), 1):
            values = list(map(float, line.split()))
            cls, cx, cy, bw, bh, *points = values
            box = [(cx-bw/2)*width, (cy-bh/2)*height, (cx+bw/2)*width, (cy+bh/2)*height]
            keypoints = [[points[i]*width, points[i+1]*height, points[i+2]] for i in (0, 3)]
            rows.append({'row_one_based': row_number, 'class_id': int(cls),
                         'box_xyxy': box, 'keypoints': keypoints, 'source_row': line})

        def show(axis, annotation):
            axis.imshow(original, interpolation='nearest')
            if not annotation:
                return
            for row in rows:
                x1, y1, x2, y2 = row['box_xyxy']
                axis.add_patch(Rectangle((x1, y1), x2-x1, y2-y1, fill=False,
                                         edgecolor='#00ee82', linewidth=.8))
                axis.text(x1+1, y1+1, str(row['row_one_based']), va='top', fontsize=6,
                          color='black', bbox={'facecolor': '#ffce52', 'edgecolor': 'none', 'pad': .4},
                          clip_on=True)
                for point, color, marker in zip(row['keypoints'], ('#ff0088', '#00bfff'), ('o', '+')):
                    if point[2] == 2:
                        axis.scatter(point[0], point[1], s=24, marker=marker, color=color, linewidths=1)

        fig, axis = plt.subplots(figsize=(12.8, 7.2))
        show(axis, True)
        axis.set_xlim(0, width)
        axis.set_ylim(height, 0)
        axis.set_title(f'{name} · supplied white_box annotations only · green boxes / pink left / blue right', fontsize=12)
        axis.set_xlabel('Original X (px)')
        axis.set_ylabel('Original Y (px)')
        fig.subplots_adjust(left=.05, right=.99, top=.94, bottom=.08)
        full_path = args.output / f'{name}-supplied-full.png'
        fig.savefig(full_path, dpi=130, facecolor='white')
        plt.close(fig)

        fig, axes = plt.subplots(1, 2, figsize=(12.5, 5.5), sharex=True, sharey=True)
        for axis, annotation in zip(axes, (False, True)):
            show(axis, annotation)
            axis.set_xlim(crop[0], crop[2])
            axis.set_ylim(crop[3], crop[1])
            axis.set_xlabel('Original X (px)')
        axes[0].set_ylabel('Original Y (px)')
        axes[0].set_title('Original pixels')
        axes[1].set_title('Supplied boxes and endpoints')
        fig.suptitle(f'{name} · lower-stack semantic intake', fontsize=16)
        fig.text(.5, .035, 'No model prediction or label conversion. Pink: source left endpoint. Blue: source right endpoint.',
                 ha='center', fontsize=10)
        fig.subplots_adjust(left=.055, right=.99, top=.85, bottom=.15, wspace=.1)
        crop_path = args.output / f'{name}-supplied-crop.png'
        fig.savefig(crop_path, dpi=150, facecolor='white')
        plt.close(fig)
        digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
        inputs.append({'image_id': name, 'image_path': str(image_path), 'image_sha256': digest(image_path),
                       'label_path': str(label_path), 'label_sha256': digest(label_path), 'size': [width, height],
                       'crop_xyxy': crop, 'source_rows': rows,
                       'figures': [{'path': str(path), 'sha256': digest(path)} for path in (full_path, crop_path)]})
    (args.output / 'overlay-inputs.json').write_text(json.dumps(inputs, indent=2)+'\n')
    print(json.dumps({'images': len(inputs), 'figures': 2*len(inputs), 'output': str(args.output)}))


if __name__ == '__main__':
    main()
