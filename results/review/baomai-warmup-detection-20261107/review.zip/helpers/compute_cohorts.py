"""Reproduce the fixed reference point-availability and edge-touch accounting."""

import argparse
import hashlib
import json
from pathlib import Path
import sys


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--evidence', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
if args.output.exists():
    raise FileExistsError(f'output already exists: {args.output}')
recorded = json.loads((Path(__file__).resolve().parents[1] / 'cohort-diagnostics.json').read_text())
sys.path.insert(0, str(args.root / 'scripts'))
from evaluate_pose import preflight_dataset

preflight = preflight_dataset(args.root, require_weights=False)
if preflight['manifest_sha256'] != recorded['reference_manifest_sha256']:
    raise ValueError('reference manifest differs from the reviewed reference')
matched = {}
for role in ('m0', 'control', 'warmup'):
    path = args.evidence / role / 'per_image.json'
    if hashlib.sha256(path.read_bytes()).hexdigest() != recorded['input_per_image_sha256'][role]:
        raise ValueError(f'{role}: saved score bytes differ from the reviewed input')
    rows = [row for row in json.loads(path.read_text()) if row['threshold'] == 0.25]
    if len(rows) != 20 or {row['image_id'] for row in rows} != {r['id'] for r in preflight['records']}:
        raise ValueError(f'{role}: primary image inventory differs')
    matched[role] = {(row['image_id'], match['gold_index']) for row in rows for match in row['matches']}

predicates = {
    'both_reference_corners_visible': lambda g: sum(p[2] == 2 for p in g['keypoints']) == 2,
    'one_reference_corner_visible': lambda g: sum(p[2] == 2 for p in g['keypoints']) == 1,
    'neither_reference_corner_locatable': lambda g: sum(p[2] == 2 for p in g['keypoints']) == 0,
    'reference_box_touches_top_edge': lambda g: g['bbox_xyxy'][1] <= 0.0001,
    'reference_box_touches_bottom_edge': lambda g: g['bbox_xyxy'][3] >= 719.9999,
    'reference_box_touches_left_edge': lambda g: g['bbox_xyxy'][0] <= 0.0001,
    'reference_box_touches_right_edge': lambda g: g['bbox_xyxy'][2] >= 1279.9999,
}
cohorts = {}
for name, predicate in predicates.items():
    ids = {(r['id'], index) for r in preflight['records'] for index, gold in enumerate(r['gold'])
           if predicate(gold)}
    cohorts[name] = {
        'reference_objects': len(ids),
        'fn': {role: len(ids - found) for role, found in matched.items()},
        'ids': [{'image_id': identifier, 'gold_index': index, 'reference_row_1based': index + 1}
                for identifier, index in sorted(ids)],
    }
if cohorts != recorded['cohorts']:
    raise ValueError('recomputed cohorts differ from the preserved review record')
result = {
    'status': 'verified',
    'reference_manifest_sha256': preflight['manifest_sha256'],
    'input_per_image_sha256': recorded['input_per_image_sha256'],
    'primary_box_confidence': 0.25,
    'matching_iou': 0.5,
    'cohorts': cohorts,
    'matches_recorded_cohorts': True,
    'no_new_inference_or_scoring_rule': True,
}
args.output.parent.mkdir(parents=True, exist_ok=True)
with args.output.open('x', encoding='utf-8') as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps({'status': 'verified', 'cohorts': len(cohorts), 'output': str(args.output)}))
