"""Build deterministic review figures from fixed original pixels and saved predictions."""

from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import math
import sys

sys.dont_write_bytecode = True
import argparse
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--evidence', type=Path, required=True)
parser.add_argument('--transitions', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
ROOT = args.root.resolve()
EVIDENCE = args.evidence.resolve()
OUT = args.output.resolve()
OUT.mkdir(parents=True, exist_ok=False)
sys.path.insert(0, str(ROOT / 'scripts'))
from evaluate_pose import preflight_dataset
from pose_scoring import _box_iou

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from PIL import Image


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


records = {r['id']: r for r in preflight_dataset(ROOT, require_weights=False)['records']}
transition_path = args.transitions.resolve()
gains = json.loads(transition_path.read_text())['matched_object_transitions']['warmup_vs_control']['gained']
predictions, scores = {}, {}
input_hashes = {}
for role in ('m0', 'control', 'warmup'):
    pp = EVIDENCE / role / 'predictions.jsonl'
    sp = EVIDENCE / role / 'per_image.json'
    input_hashes[str(pp.relative_to(EVIDENCE))] = digest(pp)
    input_hashes[str(sp.relative_to(EVIDENCE))] = digest(sp)
    predictions[role] = {(r['image_id'], r['threshold']): r for r in
                         [json.loads(line) for line in pp.read_text().splitlines()][1:]}
    scores[role] = {(r['image_id'], r['threshold']): r for r in json.loads(sp.read_text())}

plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10})
cases = []
for gain in gains:
    identifier, gi = gain['image_id'], gain['gold_index']
    record = records[identifier]
    gold = record['gold'][gi]
    x1, y1, x2, y2 = gold['bbox_xyxy']
    crop = [max(0, math.floor(x1-55)), max(0, math.floor(y1-45)),
            min(1280, math.ceil(x2+55)), min(720, math.ceil(y2+45))]
    case = {**gain, 'reference': gold, 'reference_label_text':
            Path(record['label_path']).read_text().splitlines()[gain['reference_row_1based']-1],
            'image_sha256': digest(Path(record['image_path'])),
            'label_sha256': digest(Path(record['label_path'])),
            'crop_xyxy': crop, 'roles': {}}
    for role in predictions:
        case['roles'][role] = {}
        for threshold in (.15, .25):
            ps = predictions[role][identifier, threshold]['predictions']
            sc = scores[role][identifier, threshold]
            match = next((m for m in sc['matches'] if m['gold_index'] == gi), None)
            best = max(range(len(ps)), key=lambda i: _box_iou(gold['bbox_xyxy'], ps[i]['bbox_xyxy']))
            selected = match['prediction_index'] if match else best
            case['roles'][role][str(threshold)] = {
                'matched': match is not None,
                'match_iou': match['iou'] if match else None,
                'matched_prediction_index': match['prediction_index'] if match else None,
                'matched_prediction': ps[match['prediction_index']] if match else None,
                'best_iou_prediction_index': best,
                'best_iou': _box_iou(gold['bbox_xyxy'], ps[best]['bbox_xyxy']),
                'best_iou_prediction': ps[best],
                'best_iou_prediction_matched_to_reference_rows': [m['gold_index']+1 for m in sc['matches']
                                                                  if m['prediction_index'] == best],
                'displayed_prediction_index': selected,
                'displayed_prediction': ps[selected],
            }
    nearby = []
    for index, neighbor in enumerate(record['gold']):
        nx1, ny1, nx2, ny2 = neighbor['bbox_xyxy']
        if min(nx2,crop[2]) > max(nx1,crop[0]) and min(ny2,crop[3]) > max(ny1,crop[1]):
            nearby.append({'reference_row_1based': index+1, 'reference': neighbor})
    case['nearby_reference_rows'] = nearby
    original = Image.open(record['image_path']).convert('RGB')
    fig, axes = plt.subplots(1, 3, figsize=(13.2, 4.9), sharex=True, sharey=True)
    for axis in axes:
        axis.imshow(original, interpolation='nearest')
        axis.set_xlim(crop[0], crop[2]); axis.set_ylim(crop[3], crop[1])
        axis.set_xlabel('Original image X (px)')
    axes[0].set_ylabel('Original image Y (px)')
    axes[0].set_title('Original pixels\nNo reference or model overlay')
    for neighbor in nearby:
        ng = neighbor['reference']; xx1,yy1,xx2,yy2 = ng['bbox_xyxy']
        color = '#00d68b' if neighbor['reference_row_1based'] == gi+1 else '#3cc7ef'
        axes[1].add_patch(Rectangle((xx1,yy1),xx2-xx1,yy2-yy1,fill=False,color=color,
                                    linewidth=2.0 if neighbor['reference_row_1based']==gi+1 else 1.0))
        axes[1].text(max(xx1,crop[0]+1),max(yy1,crop[1]+1),str(neighbor['reference_row_1based']),
                     fontsize=9,color='black',va='top',bbox={'facecolor':color,'alpha':.75,'pad':1})
    for point in gold['keypoints']:
        if point[2]==2:
            axes[1].scatter([point[0]],[point[1]],facecolors='none',edgecolors='#00d68b',s=60,linewidths=1.8)
    axes[1].set_title(f'Frozen reference row {gi+1} (green)\nNearby reference rows (cyan)')
    axes[2].add_patch(Rectangle((x1,y1),x2-x1,y2-y1,fill=False,color='#00d68b',linewidth=2))
    titles=[]
    for role,color,style in (('control','#f28e2b','--'),('warmup','#e90080','-')):
        row=case['roles'][role]['0.25']; p=row['displayed_prediction']; px1,py1,px2,py2=p['bbox_xyxy']
        axes[2].add_patch(Rectangle((px1,py1),px2-px1,py2-py1,fill=False,color=color,linewidth=1.8,linestyle=style))
        iou=_box_iou(gold['bbox_xyxy'],p['bbox_xyxy'])
        titles.append(f'{role}: conf {p["confidence"]:.3f}, IoU {iou:.6f}')
    axes[2].set_title('\n'.join(titles),fontsize=10)
    fig.suptitle(f'{identifier} · reference row {gi+1} · warmup gained vs control',fontsize=16,fontweight='bold')
    fig.text(.5,.055,'Green: frozen reference · Orange dashed: control primary box · Magenta: warmup primary box',ha='center',fontsize=10)
    fig.text(.5,.014,'A control miss uses its highest-IoU box for illustration; overlap alone does not establish physical identity. No labels changed.',ha='center',fontsize=9,color='#4b5563')
    fig.subplots_adjust(left=.06,right=.985,top=.80,bottom=.20,wspace=.08)
    figure=OUT/f'{identifier}-row-{gi+1:02d}.png'
    fig.savefig(figure,dpi=140,facecolor='white');plt.close(fig)
    case['figure']={'path':str(figure.relative_to(OUT)), 'sha256':digest(figure)}
    cases.append(case)

result={'schema_version':1,'kind':'baomai-warmup-gained-case-review','status':'rendered-no-new-visual-review',
        'created_at_utc':datetime.now(timezone.utc).isoformat(),
        'source_revision':'679b87b38e7b0bca5fbd02fb1519a90fb2379541',
        'comparison_revision':'2799b8332bb46ba07d0ef95652d7f398559573c9',
        'annotation_policy':{'path':'docs/annotation-policy.md','policy_id':'baomai-visible-front-v1',
                             'sha256':digest(ROOT/'docs/annotation-policy.md')},
        'source_transition_packet_sha256':digest(transition_path),
        'input_prediction_and_score_sha256':input_hashes,
        'original_image_ids_rendered':sorted({c['image_id'] for c in cases}),
        'primary_box_confidence':.25,'matching_iou':.5,'endpoint_confidence':.5,
        'scope':'Re-render the eight fixed gained cases; rendering does not constitute a new physical review. Saved predictions only; no model loaded or reference edited.',
        'cases':cases}
(OUT/'gained-review-packet.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'cases':len(cases),'figures':[c['figure']['path'] for c in cases],'packet_sha256':digest(OUT/'gained-review-packet.json')}))
