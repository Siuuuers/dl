# Independent ambiguity review

**Disposition: retain every existing row in this narrow set unchanged, add no new row, and record the unresolved cases.** This review does not certify these rows or the completeness of any image. Root concurred with that conservative disposition. It makes no model, training, or validation change.

The reviewer inspected all four full originals and seven broad source-pixel crops before reading source labels. Labels were then used to locate the requested one-based row IDs, followed by eight detail crops without label or prediction overlays. The observations concern physical front identity separately from box extent and corner visibility.

## Source and evidence

The originals and labels are pinned to `Siuuuers/dl` source revision `d43a58b9456a782ace14e20f0bf7ed2da3572ca1`, under `data/images/train` and `data/labels/train`. The convention is `baomai-visible-front-v1`, recorded in `docs/annotation-policy.md`. File hashes, exact original row tokens and approximate observation coordinates are in [decisions.json](decisions.json). Every source image and label in this review matched the frozen data manifest.

[crop-provenance.json](crop-provenance.json) records all 15 raw crop rectangles, source hashes and crop hashes. Each rectangle uses half-open pixel coordinates. All raw crops were verified as exact pixel subarrays of their source originals; see [verification.json](verification.json). `view-crops` contains only nearest-neighbor enlargements for inspection. Enlarging pixels supplies no new physical detail. Full original PNGs are not duplicated here.

## Decisions

| Case | What the original pixels support | Recorded decision |
|---|---|---|
| `new_000018`, row 27 | A perforated roof reaches a pale transition at the bottom frame. A separate positive-area front plane cannot be distinguished securely from its edge/rim. | Retain unchanged and unresolved. Both corners stay missing. The frame edge supplies no corner. |
| `new_000034`, row 15 | A possible tiny top-frame edge is not a securely isolated second front. Much of its rectangle overlaps the upper portion of the clear front below. | Retain unchanged. The legacy left visible point at approximately `(628.75, 3.48)` is unconfirmed, not corrected or newly certified. |
| `new_000034`, bottom fragments near x380–570 | Two perforated roofs and tiny pale edge transitions are visible. Front-plane identity remains unresolved. | Add neither fragment. This is a plane-identity question, not a minimum-pixel rule or a declaration of background. |
| `new_000034`, rows 48–50 | The gripper opening has an upper pale patch and a lower white patch separated by a transverse boundary. The lowest tip has no equally secure independent separator. | Retain all three rows. Do not turn two face-like fragments into three certified instances or force their row correspondence. No bbox edit is accepted from this evidence. |
| `new_000049`, row 18 | The top approximately four pixels do not isolate a distinct second front or separating contour from row 19. | Retain as an unsupported-instance concern. No deletion is adopted from uncertain absence. |
| `new_000049`, row 21 | A separate bright top-edge fragment exists, unlike the row-18 case. Its identity as target front rather than projecting lip remains uncertain. | Retain unresolved. Do not delete it by analogy with row 18 or infer a full-width replacement box. |
| `new_000049`, row 6 | The opening exposes a narrow bright segment and darker material. A shadowed face is plausible, but material identity and extrema are not established. | Retain unchanged. Brightness or color alone does not settle identity; gripper boundaries do not supply corners. |
| `old_000057`, above row 1 | A bright rounded edge is visible above the first broad recessed front, without a confirmed additional front plane. | Add no front. Do not infer an extra object from stack spacing. |

The missing-point triples remain exactly as supplied. No existing visible-point token was changed. The unresolved visible point in `new_000034` row 15 needs a separate explicit adjudication if a later correction would alter it; this review does not bypass the existing preservation contract.

## Raw crop index

| Original | Broad context | Narrow detail |
|---|---|---|
| `new_000018` | [Bottom](raw-crops/new_000018_bottom.png) | [Bottom frame](raw-crops/new_000018_bottom_detail.png) |
| `new_000034` | [Top](raw-crops/new_000034_top.png), [bottom](raw-crops/new_000034_bottom.png), [gripper](raw-crops/new_000034_gripper.png) | [Top frame](raw-crops/new_000034_top_detail.png), [bottom frame](raw-crops/new_000034_bottom_detail.png), [opening](raw-crops/new_000034_gripper_detail.png) |
| `new_000049` | [Top](raw-crops/new_000049_top.png), [gripper](raw-crops/new_000049_gripper.png) | [Top left](raw-crops/new_000049_top_left_detail.png), [top right](raw-crops/new_000049_top_right_detail.png), [opening](raw-crops/new_000049_gripper_detail.png) |
| `old_000057` | [Top](raw-crops/old_000057_top.png) | [Top frame](raw-crops/old_000057_top_detail.png) |

Approximate pixel ranges in the decision record locate observed material; they are not accepted annotation boxes. No inference, training, generative enhancement, source-label overlay, or repository mutation was performed. This bounded review supplies uncertainty evidence for the parent report, not a new training candidate by itself.
