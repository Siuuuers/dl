#!/usr/bin/env python3
"""Render exact-source comparison crops; no generated or enhanced image content."""
import argparse
import hashlib
import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

CASES = [
    ("new_000049", [14, 24, 25, 26], (325, 585, 490, 720),
     "Four boxes omit exposed front material", "049"),
    ("new_000018", [32, 33, 34], (435, 550, 625, 680),
     "Three boxes extend through the thumb", "018"),
]


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--repo", type=Path, required=True)
    ap.add_argument("--original-images", type=Path, required=True)
    ap.add_argument("--adjudication", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--provenance", type=Path, required=True)
    args = ap.parse_args()
    adj = json.loads(args.adjudication.read_text())
    recs = {r["id"]: r for r in json.loads((args.repo / "data/manifest.json").read_text())["records"]}
    decisions = {(r["image_id"], r["original_row"]): r for r in adj["accepted"]}
    args.output.mkdir(parents=True, exist_ok=True)
    fp = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    fonts = {n: ImageFont.truetype(fp, n) for n in [13, 15, 18, 23]}
    provenance = []
    for ident, rows, roi, title, short in CASES:
        source = args.original_images / (ident + ".png")
        source_sha = hashlib.sha256(source.read_bytes()).hexdigest()
        assert source_sha == recs[ident]["image_sha256"]
        original = Image.open(source).convert("RGB")
        assert original.size == (1280, 720)
        crop = original.crop(roi)
        scale = 2
        crop = crop.resize((crop.width * scale, crop.height * scale), Image.Resampling.NEAREST)
        cw, ch = crop.size
        margin, gap, y0 = 22, 18, 106
        canvas = Image.new("RGB", (2*margin + 3*cw + 2*gap, y0 + ch + 64), "#f7f9fc")
        draw = ImageDraw.Draw(canvas)
        draw.text((margin, 16), title, fill="#172b42", font=fonts[23])
        draw.text((margin, 51), ident + "  |  Original row IDs " + ", ".join(map(str, rows)),
                  fill="#41546a", font=fonts[15])
        labels = ["Original pixels", "Existing boxes", "Proposed boxes"]
        source_lines = (args.repo / "data" / recs[ident]["label"]).read_text().splitlines()
        for panel in range(3):
            x0 = margin + panel*(cw+gap)
            canvas.paste(crop, (x0, y0))
            draw.text((x0, 80), labels[panel], font=fonts[18], fill="#172b42")
            if panel == 0:
                continue
            color = "#0879c9" if panel == 1 else "#00814e"
            def transform(x, y):
                return (x0 + (x-roi[0])*scale, y0 + (y-roi[1])*scale)
            for row in rows:
                d = decisions[(ident, row)]
                bounds = d["source_bbox_xyxy_original_pixels"] if panel == 1 else d["bbox_xyxy_original_pixels"]
                x1, y1, x2, y2 = bounds
                draw.rectangle((*transform(x1, y1), *transform(x2, y2)), outline=color, width=2)
                tx, ty = transform(x1, y1)
                draw.rectangle((tx+2, ty+2, tx+26, ty+19), fill=color)
                draw.text((tx+4, ty+2), str(row), fill="white", font=fonts[13])
                t = list(map(float, source_lines[row-1].split()))
                for i in [5, 8]:
                    if t[i+2] == 2:
                        px, py = transform(t[i]*1280, t[i+1]*720)
                        draw.ellipse((px-3, py-3, px+3, py+3), fill="#fff09a", outline="#26313c", width=1)
        draw.text((margin, y0+ch+15), "All original corner tokens stay unchanged. A hand boundary does not reveal a hidden corner.",
                  fill="#41546a", font=fonts[13])
        draw.text((margin, y0+ch+35), "Source crop enlarged 2x with nearest-neighbor pixels. Box coordinates remain in original-image units.",
                  fill="#41546a", font=fonts[13])
        dest = args.output / ("training-consistency-" + short + "-2026-11-11.png")
        canvas.save(dest)
        provenance.append({"image_id": ident, "source_image_sha256": source_sha,
            "source_dimensions": [1280, 720], "crop_xyxy": list(roi), "scale": scale,
            "resampling": "nearest_neighbor", "source_rows": rows, "figure": dest.name,
            "figure_sha256": hashlib.sha256(dest.read_bytes()).hexdigest(),
            "generated_or_enhanced_pixels": False,
            "old_and_new_bounds": [{"row": row,
                "old": decisions[(ident,row)]["source_bbox_xyxy_original_pixels"],
                "new": decisions[(ident,row)]["bbox_xyxy_original_pixels"]} for row in rows]})
    args.provenance.write_text(json.dumps({"figures": provenance}, indent=2)+"\n")
    print(json.dumps({"figures": len(provenance), "output": str(args.output)}))


if __name__ == "__main__":
    main()
