#!/usr/bin/env python3
"""Read-only composition audit of the frozen six-image consistency proposal.

Requires Python 3.11+ and Git; the unchanged repository verifier uses only the
standard library. --original-images contains the six <image_id>.png originals.
No image rendering, model loading, inference, training, or repository write is
performed. The optional JSON output should be outside the inspected repository.
Mechanical success does not establish visual correctness or model improvement.
"""

import sys
sys.dont_write_bytecode = True

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import struct
import subprocess


BASE = "61ae0e68fc517a6dfc7d8c19b63d846303a79e03"
CANDIDATE = "consistency-2026-11-11"
PARENT = "annotations-2026-11-10"
SOURCE_SHA = "72ae8365d5abf0b45b75d400a2e6d22119c0e31b54ee33035feb8edc1f967926"
PARENT_SHA = "28fc8f5da95605089d61fb062132200ed296c3a10b216f1a61dbda1798ea4ba7"
PARENT_REVIEW_SHA = "84dd73407aa147637d8eb68f8ff8268c856d70c46a8a8bf144549e00e6480c85"
INVENTORY_SHA = "d71c7fb5ecf1f4cf58c0120b76588d5913d653bc3f18c89ce8b59725d9343294"
SCOPE_SHA = "de9f1d44301fcfb0e4fb07b14a502256529c3e33abc468411d4468511b6d0f7a"
ADJUDICATION_SHA = "60c5cbf8f215c796a28c13c184e88ad7fc9dffac08d821e2b77194ac97b147fb"
FINAL_MANIFEST_SHA = "2f59ec8a09466922eb2f20fd66c5f0f8a972a6c5694bbb41c17d51277ff3b9a9"
POLICY_SHA = "3cda361ac4c5c9ba36b037e7e8968e0629eb3bca8d489c187beb8dd66e208a91"
SCOPE_PATH = "results/review/baomai-training-consistency-20261111/scope.json"
ADJUDICATION_PATH = "results/review/baomai-training-consistency-20261111/adjudication.json"
SCOPE_IDS = ["new_000018", "new_000034", "new_000049", "old_000007", "old_000057", "new_000132"]
DELTA_IDS = SCOPE_IDS[:3]
ACCEPTED_ROWS = {"new_000018": [24, 25, 26, 32, 33, 34], "new_000034": [55, 56, 57],
                 "new_000049": [9, 14, 24, 25, 26]}
CODE_SHA = {
    "scripts/verify_pose_annotation_candidate.py": "0dc3d263b4aad594e1019de8f8318dcd963d9c0c2f4604ad2dee408c83af7979",
    "scripts/verify_pose_candidate.py": "03395b9a82a4c120647a1cac51c89fd214d8cf9b15c04e2196a40f39077d8491",
    "scripts/evaluate_pose.py": "3f80bd09efbe97327b705ffe6ad3e662111f3e2bc71b69b51a9d38d7baa90ce0",
    "scripts/pose_scoring.py": "04e5cdbef26df978707d0b6e4b82f05471b6012845f7986b9c05c71644ec0018",
}
PROTECTED = ("scripts", "experiments", "metadata", "notebooks", "configs",
             "data/labels", "data/references", "data/candidates", "data/manifest.json")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    return sha_bytes(Path(path).read_bytes())


def read_json(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, f"Duplicate JSON key {key}: {path}")
            result[key] = value
        return result

    def reject(value):
        raise ValueError(f"Nonfinite JSON value {value}: {path}")

    return json.loads(Path(path).read_text(encoding="utf-8"),
                      object_pairs_hook=unique, parse_constant=reject)


def pinned_json(path, expected):
    require(sha(path) == expected, f"Frozen SHA-256 differs: {path}")
    return read_json(path)


def git(repo, *args):
    return subprocess.check_output(["git", "-C", str(repo), *args])


def safe_path(root, relative):
    path = root / relative
    require(path.resolve().is_relative_to(root.resolve()), f"Escaping path: {relative}")
    require(not path.is_symlink() and path.is_file(), f"Expected regular file: {path}")
    return path


def protected_snapshot(repo):
    """Compare protected tracked bytes to the pre-review commit, not HEAD."""
    entries = git(repo, "ls-tree", "-r", "-z", "--full-tree", BASE, "--", *PROTECTED)
    snapshot = {}
    for item in entries.split(b"\0"):
        if not item:
            continue
        meta, raw_name = item.split(b"\t", 1)
        mode, kind, oid = meta.decode().split()
        name = raw_name.decode()
        require(kind == "blob" and mode in ("100644", "100755"), f"Unexpected protected Git item: {name}")
        path = safe_path(repo, name)
        data = path.read_bytes()
        actual = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        require(actual == oid, f"Protected source/reference/historical file changed: {name}")
        snapshot[name] = sha_bytes(data)
    require(snapshot, "Protected source inventory is empty")
    # Additions under protected trees are allowed only in the new candidate.
    for prefix in PROTECTED:
        start = repo / prefix
        if not start.exists() or start.is_file():
            continue
        for path in start.rglob("*"):
            require(not path.is_symlink(), f"Symlink in protected tree: {path}")
            if not path.is_file():
                continue
            relative = path.relative_to(repo).as_posix()
            if relative.startswith(f"data/candidates/{CANDIDATE}/"):
                continue
            require(relative in snapshot, f"Unexpected added source/reference/historical file: {relative}")
    return snapshot


def label_statistics(raw):
    rows = [line.split() for line in raw.decode("utf-8").splitlines()]
    require(all(len(row) == 11 for row in rows), "Unexpected label field count")
    groups = Counter(sum(float(row[index]) == 2 for index in (7, 10)) for row in rows)
    visible = groups[1] + 2 * groups[2]
    return {"objects": len(rows), "visible_endpoints": visible,
            "missing_endpoints": 2 * len(rows) - visible,
            "objects_by_locatable_corners": {str(k): groups[k] for k in (0, 1, 2)}}


def audit_selection(repo, inventory, scope, records, originals):
    require(inventory["source_revision"] == scope["source_revision"] == BASE,
            "Inventory/scope source revision differs")
    require(inventory["source_manifest_sha256"] == scope["source_manifest_sha256"] == SOURCE_SHA,
            "Inventory/scope source manifest differs")
    require(scope["status"] == "declared_before_original_pixel_review", "Prospective scope status differs")
    require(inventory["cohort"]["selection_status"] == "root_accepted_before_original_image_review",
            "Prospective inventory status differs")
    require(not any(inventory["cohort"]["preimage_condition"].values()),
            "Inventory pre-image condition differs")
    union = set()
    for review_pass in inventory["review_passes"]:
        pinned_json(safe_path(repo, review_pass["source"]), review_pass["source_sha256"])
        union.update(review_pass["image_ids"])
    require(sorted(union) == inventory["reviewed_training_image_ids"] and len(union) == 55,
            "Historical review union differs")
    train_ids = {r["id"] for r in records if r["split"] == "train"}
    remaining = sorted(train_ids - union)
    require(len(remaining) == 82 and remaining == inventory["unreviewed_training_image_ids"],
            "Unreviewed remainder differs")
    metadata = {key: label_statistics(originals[key]) for key in remaining}
    for declared in inventory["unreviewed_image_metadata"]:
        for key, value in metadata[declared["image_id"]].items():
            require(declared[key] == value, f"Original-label metadata differs: {declared['image_id']}:{key}")
    nonempty = [key for key in remaining if metadata[key]["objects"]]
    empty = [key for key in remaining if not metadata[key]["objects"]]
    require((len(nonempty), len(empty)) == (70, 12), "Selection pool counts differ")
    q, extra = divmod(len(nonempty), 5)
    strata, selected, offset = [], [], 0
    for index in range(5):
        count = q + (index < extra)
        ids = nonempty[offset:offset + count]
        offset += count
        winner = min(ids, key=lambda key: (-metadata[key]["missing_endpoints"], key))
        strata.append(ids)
        selected.append(winner)
        declared = inventory["cohort"]["strata"][index]
        require(declared["image_ids"] == ids and declared["selected_image_id"] == winner,
                f"Balanced stratum {index + 1} differs")
    selected.append(empty[0])
    require(selected == SCOPE_IDS == scope["selection"]["selected_ids"]
            == inventory["cohort"]["selected_image_ids_in_review_order"], "Selected six IDs differ")
    require(scope["selection"]["stratum_sizes"] == [len(s) for s in strata] == [14] * 5,
            "Stratum sizes differ")
    by_id = {r["id"]: r for r in records}
    require([r["id"] for r in scope["selected_records"]] == SCOPE_IDS, "Scope records differ")
    for record in scope["selected_records"]:
        require(all(by_id[record["id"]][key] == value for key, value in record.items()),
                f"Scope source record differs: {record['id']}")
    combined = {"objects": 0, "visible_endpoints": 0, "missing_endpoints": 0}
    groups = Counter()
    for image_id in SCOPE_IDS:
        stats = label_statistics(originals[image_id])
        for key in combined:
            combined[key] += stats[key]
        groups.update(stats["objects_by_locatable_corners"])
    require(combined == {"objects": 135, "visible_endpoints": 223, "missing_endpoints": 47}
            and dict(groups) == {"0": 9, "1": 29, "2": 97}, "Frozen cohort counts differ")
    return {"reviewed_training_ids": 55, "remaining_training_ids": 82,
            "nonempty_pool": 70, "empty_pool": 12, "stratum_sizes": [14] * 5,
            "selected_image_ids": selected, **combined,
            "objects_by_locatable_corners": dict(groups),
            "selection_recomputed_from_original_metadata": True,
            "scope_and_inventory_bytes_unchanged": True}


def audit(args):
    repo = args.repo.resolve()
    originals_dir = args.original_images.resolve()
    inventory_path = args.inventory
    if inventory_path is None:
        possibilities = [repo / "results/review/baomai-training-consistency-20261111/inventory.json",
                         Path(__file__).resolve().parents[1] / "inventory/inventory.json"]
        inventory_path = next((p for p in possibilities if p.is_file()), possibilities[0])
    inventory_path = inventory_path.resolve()
    if args.output:
        require(not args.output.resolve().is_relative_to(repo), "Write audit output outside inspected repository")
    require(git(repo, "cat-file", "-t", BASE).strip() == b"commit", "Frozen source commit unavailable")
    head = git(repo, "rev-parse", "HEAD").decode().strip()
    subprocess.run(["git", "-C", str(repo), "merge-base", "--is-ancestor", BASE, head], check=True)
    protected_before = protected_snapshot(repo)
    for relative, expected in CODE_SHA.items():
        require(sha(safe_path(repo, relative)) == expected, f"Existing verifier/helper changed: {relative}")
    require(sha(repo / "docs/annotation-policy.md") == POLICY_SHA, "Annotation policy changed")
    inventory = pinned_json(inventory_path, INVENTORY_SHA)
    scope = pinned_json(repo / SCOPE_PATH, SCOPE_SHA)
    adjudication_path = args.adjudication.resolve() if args.adjudication else repo / ADJUDICATION_PATH
    adjudication = pinned_json(adjudication_path, ADJUDICATION_SHA)
    parent_dir = repo / "data/candidates" / PARENT
    candidate_dir = repo / "data/candidates" / CANDIDATE
    parent = pinned_json(parent_dir / "manifest.json", PARENT_SHA)
    parent_review = pinned_json(parent_dir / "review.json", PARENT_REVIEW_SHA)
    proposal = pinned_json(candidate_dir / "manifest.json", FINAL_MANIFEST_SHA)
    review = read_json(candidate_dir / "review.json")
    require(adjudication["status"] == "accepted_bounded_review"
            and adjudication["candidate_id"] == CANDIDATE, "Final adjudication identity/status differs")
    for key in ("scope", "all_row_disposition", "unresolved_and_retained", "boundary_note", "review_provenance"):
        require(review[key] == adjudication[key], f"Review/adjudication evidence differs: {key}")
    require(proposal["created_at_utc"] == adjudication["completed_at_utc"], "Final adjudication date differs")
    require(proposal["candidate_id"] == review["candidate_id"] == CANDIDATE, "Candidate identity differs")
    require(proposal["source_revision"] == review["source_revision"] == BASE, "Candidate source revision differs")
    require(proposal["source_manifest_sha256"] == SOURCE_SHA, "Candidate original manifest differs")
    require(proposal["annotation_policy"] == scope["annotation_policy"] == parent["annotation_policy"],
            "Candidate annotation policy differs")
    # No monkeypatches: call the fixed, unmodified repository verifier directly.
    sys.path.insert(0, str(repo / "scripts"))
    from verify_pose_candidate import read_reference
    from verify_pose_annotation_candidate import verify_annotation_candidate
    _, records, by_id, original_bytes, _, source_counts = read_reference(repo, SOURCE_SHA)
    selection = audit_selection(repo, inventory, scope, records, original_bytes)
    image_checks = []
    for image_id in SCOPE_IDS:
        record = by_id[image_id]
        path = safe_path(originals_dir, image_id + ".png")
        raw = path.read_bytes()
        require(sha_bytes(raw) == record["image_sha256"], f"Actual original PNG hash differs: {image_id}")
        require(len(raw) >= 24 and raw[:8] == b"\x89PNG\r\n\x1a\n" and raw[12:16] == b"IHDR",
                f"Expected original PNG header: {image_id}")
        size = list(struct.unpack(">II", raw[16:24]))
        require(size == record["original_size"] == [1280, 720], f"Original PNG size differs: {image_id}")
        image_checks.append({"image_id": image_id, "sha256": sha_bytes(raw), "bytes": len(raw), "size": size})
    parent_verified = verify_annotation_candidate(repo, parent_dir / "manifest.json")
    verified = verify_annotation_candidate(repo, candidate_dir / "manifest.json")
    require(parent_verified["reference_labels_verified"] == verified["reference_labels_verified"] == 157,
            "Original label verification count differs")
    parent_changes = {c["image_id"]: c for c in parent["changes"]}
    changes = {c["image_id"]: c for c in proposal["changes"]}
    require(len(parent_changes) == 8 and len(changes) == len(proposal["changes"]) == 11,
            "Expected exact eight inherited files plus three disjoint delta files")
    require(set(changes) == set(parent_changes) | set(DELTA_IDS)
            and not set(parent_changes).intersection(SCOPE_IDS), "Candidate composition or disjointness differs")
    inherited_files = []
    for image_id, original_change in parent_changes.items():
        require(changes[image_id] == original_change, f"Inherited change object differs: {image_id}")
        relative = original_change["candidate_label"]
        inherited_raw = safe_path(parent_dir, relative).read_bytes()
        require(safe_path(candidate_dir, relative).read_bytes() == inherited_raw,
                f"Inherited label bytes differ: {image_id}")
        inherited_files.append({"image_id": image_id, "path": relative, "sha256": sha_bytes(inherited_raw)})
    parent_decisions = {d["id"]: d for d in parent_review["decisions"]}
    decisions = {d["id"]: d for d in review["decisions"]}
    require(len(parent_decisions) == 12 and len(decisions) == len(review["decisions"]),
            "Inherited or new review decision identities differ")
    for identifier, original_decision in parent_decisions.items():
        require(decisions.get(identifier) == original_decision, f"Inherited decision object differs: {identifier}")
    inherited = proposal["inherits"]
    require(inherited == review["inherited_review"], "Manifest/review inheritance descriptor differs")
    require(inherited["candidate_id"] == PARENT and inherited["source_revision"] == BASE
            and inherited["manifest"] == {"path": f"data/candidates/{PARENT}/manifest.json", "sha256": PARENT_SHA}
            and inherited["review"] == {"path": f"data/candidates/{PARENT}/review.json", "sha256": PARENT_REVIEW_SHA}
            and inherited["changed_image_ids"] == sorted(parent_changes)
            and inherited["inherited_decision_ids"] == [d["id"] for d in parent_review["decisions"]],
            "Declared inheritance differs from exact parent")
    require(review["scope"]["images"] == SCOPE_IDS, "Candidate review scope differs from prospective scope")
    require(review["sources"] == [by_id[key] for key in SCOPE_IDS], "Candidate review source records differ")
    delta_rows, delta_review_ids = [], set()
    for image_id in DELTA_IDS:
        change = changes[image_id]
        before_lines = original_bytes[image_id].splitlines(keepends=True)
        after_lines = (candidate_dir / change["candidate_label"]).read_bytes().splitlines(keepends=True)
        require(len(before_lines) == len(after_lines) == change["source_objects"] == change["candidate_objects"],
                f"Delta row count changed: {image_id}")
        require(change["deletions"] == change["additions"] == [], f"Delta adds/deletes a row: {image_id}")
        require(change["row_map"] == [{"original_row": n, "candidate_row": n} for n in range(1, len(before_lines) + 1)],
                f"Delta row mapping changed: {image_id}")
        declared_rows = {operation["original_row"] for operation in change["replacements"]}
        actual_rows = {n for n, (before, after) in enumerate(zip(before_lines, after_lines), 1) if before != after}
        require(actual_rows == declared_rows and len(declared_rows) == len(change["replacements"]),
                f"Actual and declared delta rows differ: {image_id}")
        require(sorted(actual_rows) == ACCEPTED_ROWS[image_id], f"Frozen accepted row set differs: {image_id}")
        for n, (before, after) in enumerate(zip(before_lines, after_lines), 1):
            b, a = before.decode().split(), after.decode().split()
            require(b[0] == a[0] and b[5:] == a[5:], f"Class or corner tokens changed: {image_id}:{n}")
            if n not in declared_rows:
                require(before == after, f"Unchanged row bytes differ: {image_id}:{n}")
        for operation in change["replacements"]:
            n, identifier = operation["original_row"], operation["review_id"]
            require(operation["changed_fields"] == ["bbox"] and operation["donor_endpoints"] == [],
                    f"Delta is not bbox-only: {image_id}:{n}")
            require(identifier not in parent_decisions and identifier not in delta_review_ids,
                    f"New decision collides/repeats: {identifier}")
            delta_review_ids.add(identifier)
            decision = decisions[identifier]
            require(decision["image_id"] == image_id and decision["source_rows_1based"] == [n]
                    and decision["operation"] == "bbox_replacement"
                    and decision["source_row_text"] == operation["source_row_text"]
                    and decision["candidate_row_text"] == operation["candidate_row_text"]
                    and decision["corner_tokens_preserved"] is True,
                    f"New review decision/operation correspondence differs: {identifier}")
            expected_box = decision["bbox_xyxy_original_pixels"]
            tokens = [float(t) for t in operation["candidate_row_text"].split()[1:5]]
            xc, yc, width, height = tokens
            actual_box = [(xc-width/2)*1280, (yc-height/2)*720, (xc+width/2)*1280, (yc+height/2)*720]
            require(len(expected_box) == 4 and max(abs(a-b) for a, b in zip(actual_box, expected_box)) <= 1e-4,
                    f"Declared original-pixel box differs from row geometry: {identifier}")
            delta_rows.append({"image_id": image_id, "original_row": n, "candidate_row": n,
                               "review_id": identifier, "bbox_xyxy_original_pixels": expected_box,
                               "corner_tokens_exact": True})
    require(set(decisions) - set(parent_decisions) == delta_review_ids
            == set(review["new_accepted_decision_ids"])
            and len(review["new_accepted_decision_ids"]) == len(delta_review_ids),
            "Unexpected/unbound new accepted decisions")
    require(len(adjudication["accepted"]) == len(delta_rows) == 14
            and review["new_accepted_decision_ids"] == [d["id"] for d in adjudication["accepted"]],
            "Final adjudication accepted count/order differs")
    operations = {op["review_id"]: op for image_id in DELTA_IDS for op in changes[image_id]["replacements"]}
    for accepted in adjudication["accepted"]:
        operation = operations[accepted["id"]]
        number = operation["original_row"]
        expected_decision = dict(accepted)
        expected_decision.update({"review_status": "accepted_incremental", "source_rows_1based": [number],
                                 "operation": "bbox_replacement", "source_row_text": operation["source_row_text"],
                                 "candidate_row_text": operation["candidate_row_text"],
                                 "corner_tokens_preserved": True, "original_pixels_adjudicated_by_root": True})
        require(decisions[accepted["id"]] == expected_decision,
                f"Accepted decision is not exact adjudication plus mechanical row binding: {accepted['id']}")
        xc, yc, width, height = map(float, operation["source_row_text"].split()[1:5])
        box = [(xc-width/2)*1280, (yc-height/2)*720, (xc+width/2)*1280, (yc+height/2)*720]
        require(accepted["original_row"] == number and len(accepted["source_bbox_xyxy_original_pixels"]) == 4
                and max(abs(a-b) for a, b in zip(box, accepted["source_bbox_xyxy_original_pixels"])) <= 1e-4,
                f"Adjudication source row/geometry differs: {accepted['id']}")
    dispositions = review["all_row_disposition"]
    require([d["image_id"] for d in dispositions] == SCOPE_IDS, "Complete row disposition image scope differs")
    held = adjudication["unresolved_and_retained"]["held_complete_bbox_replacements"]
    held_pairs = {(d["image_id"], d["original_row"]) for d in held}
    require(len(held) == len(held_pairs) == 9 and all(d["decision"] == "retain_source_unchanged" for d in held),
            "Held replacement accounting differs")
    disposition_totals = Counter()
    for disposition in dispositions:
        image_id = disposition["image_id"]
        count = len(original_bytes[image_id].splitlines())
        accepted = ACCEPTED_ROWS.get(image_id, [])
        retained = [n for n in range(1, count + 1) if n not in accepted]
        held_rows = sorted(n for key, n in held_pairs if key == image_id)
        unresolved = adjudication["unresolved_and_retained"]["identity_source_rows_retained"].get(image_id, [])
        require(disposition["original_rows_reviewed"] == count
                and disposition["accepted_box_rows"] == accepted
                and disposition["retained_source_rows_without_new_edits"] == retained
                and disposition["held_box_rows"] == held_rows
                and disposition["unresolved_identity_rows"] == unresolved
                and set(held_rows + unresolved).issubset(retained)
                and disposition["all_corner_tokens_preserved"] is True
                and disposition["full_image_certified"] is False,
                f"All-row disposition/retained uncertainty differs: {image_id}")
        disposition_totals.update({"original_rows": count, "accepted_box_rows": len(accepted),
                                   "retained_rows": len(retained), "held_box_rows": len(held_rows),
                                   "retained_identity_concern_rows": len(unresolved)})
    require(dict(disposition_totals) == {"original_rows": 135, "accepted_box_rows": 14,
                                       "retained_rows": 121, "held_box_rows": 9,
                                       "retained_identity_concern_rows": 8}, "All-row totals differ")
    expected_scope_counts = {"training_images_reviewed": 6, "original_rows_reviewed": 135,
                             "original_visible_endpoints": 223, "original_missing_endpoints": 47,
                             "new_bbox_replacements": 14, "new_additions": 0,
                             "new_deletions": 0, "new_endpoint_edits": 0}
    require(all(review["scope"][key] == value for key, value in expected_scope_counts.items())
            and review["scope"]["source_scope_sha256"] == SCOPE_SHA
            and review["scope"]["inventory_sha256"] == INVENTORY_SHA
            and review["scope"]["source_revision"] == BASE,
            "Review scope counts or frozen selection bindings differ")
    preserved_endpoints = Counter()
    for image_id in SCOPE_IDS:
        raw_after = ((candidate_dir / changes[image_id]["candidate_label"]).read_bytes()
                     if image_id in changes else original_bytes[image_id])
        before_rows, after_rows = original_bytes[image_id].decode().splitlines(), raw_after.decode().splitlines()
        require(len(before_rows) == len(after_rows), f"Scope row count changed: {image_id}")
        for n, (before, after) in enumerate(zip(before_rows, after_rows), 1):
            b, a = before.split(), after.split()
            require(b[0] == a[0] and b[5:] == a[5:], f"Scope class/corner tokens changed: {image_id}:{n}")
            preserved_endpoints.update("visible" if float(b[i]) == 2 else "missing" for i in (7, 10))
    require(dict(preserved_endpoints) == {"visible": 223, "missing": 47}, "Preserved corner counts differ")
    new_counts = {"changed_train_files": 3, "replaced_rows": len(delta_rows), "added_rows": 0,
                  "deleted_rows": 0, "donor_endpoints_transferred": 0, "new_visible_endpoints": 0,
                  "net_object_change": 0, "all_existing_corner_tokens_preserved": True}
    require(proposal["new_edit_counts_relative_to_parent"] == new_counts, "Declared new edit counts differ")
    expected_edits = dict(parent["expected_edit_counts"])
    expected_edits["changed_train_files"] += 3
    expected_edits["replaced_rows"] += len(delta_rows)
    require(proposal["expected_edit_counts"] == expected_edits, "Declared cumulative edit counts differ")
    require(proposal["expected_counts"] == parent["expected_counts"] == verified["counts"],
            "Dataset counts changed from selected parent")
    require(verified["counts"]["val"] == source_counts["val"], "Validation counts changed")
    require(verified["removed_objects"] == 6 and verified["added_objects"] == 5
            and verified["merged_endpoints"] == 2 and verified["replaced_objects"] == 3 + len(delta_rows),
            "Cumulative actual operation counts differ")
    protected_after = protected_snapshot(repo)
    require(protected_before == protected_after, "Protected source/reference files changed during audit")
    require(sha(repo / SCOPE_PATH) == SCOPE_SHA and sha(inventory_path) == INVENTORY_SHA,
            "Frozen selection inputs changed during audit")
    require(sha(adjudication_path) == ADJUDICATION_SHA
            and sha(candidate_dir / "manifest.json") == FINAL_MANIFEST_SHA,
            "Final adjudication/candidate changed during audit")
    require(git(repo, "rev-parse", "HEAD").decode().strip() == head, "Git HEAD changed during audit")
    return {"schema_version": 1, "kind": "independent_training_consistency_composition_audit",
            "status": "passed", "candidate_id": CANDIDATE, "source_revision": BASE,
            "observed_repository_head": head, "audit_script_sha256": sha(Path(__file__)),
            "candidate_manifest_sha256": sha(candidate_dir / "manifest.json"),
            "candidate_review_sha256": sha(candidate_dir / "review.json"),
            "source_manifest_sha256": SOURCE_SHA, "scope_sha256": SCOPE_SHA,
            "adjudication_sha256": ADJUDICATION_SHA,
            "inventory_sha256": INVENTORY_SHA, "annotation_policy_sha256": POLICY_SHA,
            "existing_verifier_sha256": CODE_SHA,
            "original_labels_verified": 157, "original_train_labels_verified": 137,
            "original_validation_labels_verified": 20,
            "all_original_label_sha256": {r["id"]: sha_bytes(original_bytes[r["id"]]) for r in records},
            "selection": selection, "actual_scope_original_images": image_checks,
            "parent_manifest_sha256": PARENT_SHA, "parent_review_sha256": PARENT_REVIEW_SHA,
            "inherited_change_objects_exact": 8, "inherited_decision_objects_exact": 12,
            "inherited_label_files": inherited_files, "delta_disjoint_from_parent": True,
            "new_delta": {"image_ids": DELTA_IDS, "counts": new_counts, "rows": delta_rows},
            "all_six_scope_corner_triplets_exact": dict(preserved_endpoints),
            "adjudication_linkage_exact": True, "all_row_disposition_totals": dict(disposition_totals),
            "held_and_unresolved_rows_preserved": True,
            "full_row_maps_verified": True, "unmodified_rows_byte_preserved": True,
            "existing_verifier_result": verified, "parent_verifier_result": parent_verified,
            "protected_source_and_reference_file_count": len(protected_before),
            "protected_source_and_reference_sha256": protected_before,
            "protected_source_and_validation_modifications": [],
            "source_bytes_unchanged_during_audit": True,
            "limits": {"visual_correctness_verified_by_this_audit": False,
                       "image_pixels_rendered_by_this_audit": False,
                       "original_pngs_hashed": 6, "other_original_png_payloads_checked": False,
                       "model_loaded": False, "inference_performed": False, "training_performed": False,
                       "new_model_performance_established": False,
                       "mechanical_success_is_not_full_annotation_certification": True}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--original-images", type=Path, required=True,
                        help="Directory directly containing the six frozen <image_id>.png originals")
    parser.add_argument("--inventory", type=Path, help="Exact frozen pre-image inventory JSON")
    parser.add_argument("--adjudication", type=Path, help="Exact final adjudication JSON; defaults to its repository path")
    parser.add_argument("--output", type=Path, help="Optional report JSON path outside the inspected repo")
    args = parser.parse_args()
    try:
        result = audit(args)
    except (OSError, ValueError, KeyError, TypeError, IndexError, AttributeError, subprocess.CalledProcessError) as error:
        result = {"schema_version": 1, "kind": "independent_training_consistency_composition_audit",
                  "status": "failed", "error_type": type(error).__name__, "error": str(error),
                  "audit_script_sha256": sha(Path(__file__))}
    text = json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n"
    if args.output:
        require(not args.output.resolve().is_relative_to(args.repo.resolve()),
                "Write audit output outside inspected repository")
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
        print(json.dumps({"status": result["status"], "output": str(args.output.resolve()),
                          "output_sha256": sha(args.output), "error": result.get("error")}))
    else:
        print(text, end="")
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
