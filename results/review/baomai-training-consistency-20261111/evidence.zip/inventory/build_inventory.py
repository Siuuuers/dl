#!/usr/bin/env python3
"""Inventory documented training review and freeze a label-only six-image cohort.

No image payload is opened, no model is imported, and no prediction is read.
The balanced-strata rule was accepted by root before original-image review.
"""

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
SOURCE_REVISION = "61ae0e68fc517a6dfc7d8c19b63d846303a79e03"
SOURCE_MANIFEST_SHA256 = "72ae8365d5abf0b45b75d400a2e6d22119c0e31b54ee33035feb8edc1f967926"
FROZEN_COHORT = ("new_000018", "new_000034", "new_000049", "old_000007", "old_000057", "new_000132")
PASS_PATHS = (
    "docs/training-pilot-2026-11-06.json",
    "data/candidates/box-refinement-2026-11-07/review.json",
    "data/candidates/annotations-2026-11-10/review.json",
    "data/candidates/partial-fronts-2026-11-11/review.json",
    "data/candidates/visible-extent-079-2026-11-11/review.json",
    "data/candidates/visible-extent-2026-11-11/review.json",
)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def repeated_groups(values):
    groups = defaultdict(list)
    for key, value in values:
        groups[value].append(key)
    return [ids for ids in groups.values() if len(ids) > 1]


def summarize(rows):
    return {
        "images": len(rows), "nonempty_label_images": sum(row["objects"] > 0 for row in rows),
        "empty_label_images": sum(row["objects"] == 0 for row in rows),
        "objects": sum(row["objects"] for row in rows),
        "visible_endpoints": sum(row["visible_endpoints"] for row in rows),
        "missing_endpoints": sum(row["missing_endpoints"] for row in rows),
        "objects_by_locatable_corners": {str(n): sum(row["objects_by_locatable_corners"][str(n)] for row in rows) for n in range(3)},
        "geometry_error_rows": sum(len(row["geometry_error_rows"]) for row in rows),
        "numeric_duplicate_row_groups": sum(len(row["numeric_duplicate_row_groups"]) for row in rows),
        "identical_bbox_row_groups": sum(len(row["identical_bbox_row_groups"]) for row in rows),
        "box_pairs_iou_ge_0_5": sum(len(row["box_pairs_iou_ge_0_5"]) for row in rows),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    def git(*arguments):
        return subprocess.check_output(["git", "-C", str(root), *arguments], text=True).strip()
    source_revision, source_status = git("rev-parse", "HEAD"), git("status", "--porcelain")
    assert source_revision == SOURCE_REVISION and source_status == ""
    assert not args.output.resolve().is_relative_to(root)
    sys.path.insert(0, str(root / "scripts"))
    from verify_pose_candidate import read_reference, check_geometry, GEOMETRY_EPSILON_PX
    from pose_scoring import _box_iou
    manifest_hash, records, by_id, source_bytes, gold, _ = read_reference(root, SOURCE_MANIFEST_SHA256)
    training = sorted((row for row in records if row["split"] == "train"), key=lambda row: row["id"])
    training_ids = {row["id"] for row in training}
    documents = [read(root / name) for name in PASS_PATHS]
    pilot, boxes, annotation, partial, single079, extent = documents
    pass_ids = [
        [row["image_id"] for row in pilot["verified_originals"]],
        [row["image_id"] for row in boxes["primary_reviews"]] + [boxes["empty_control"]["image_id"]],
        annotation["scope"]["images"], partial["scope"]["images"],
        single079["scope"]["images"], extent["scope"]["images"],
    ]
    scopes = [
        {"pass": "initial_training_identity_pilot", "targeted_source_rows": sum(len(row["target_rows_one_based"]) for row in pilot["verified_originals"]),
         "description": "Purposive identity/duplicate review with full-scene context and an empty control; not full annotation certification."},
        {"pass": "box_refinement", "recorded_coverage": boxes["coverage"],
         "unresolved_identity_rows": boxes["unresolved_identity_rows"],
         "description": "Every source row, edge and endpoint state considered in three nonempty images plus one empty control; unresolved identities/bounds retained, full policy certification false."},
        {"pass": "reviewed_annotation_overlay", "recorded_scope": annotation["scope"],
         "description": "Focused omissions, instance identity and occlusion review; contextual row totals are not counts of fully certified rows."},
        {"pass": "partial_front_extension", "recorded_scope": partial["scope"],
         "description": "Focused omissions, gripper-only rows and unequivocal duplicates; legacy extents and unresolved identities retained."},
        {"pass": "standalone_visible_extent_079", "recorded_scope": single079["scope"],
         "description": "Four context rows, three box replacements; soft boundaries and unrelated rows remain outside certification."},
        {"pass": "cumulative_visible_extent", "recorded_scope": extent["scope"],
         "unresolved_and_retained": extent["unresolved_and_retained"],
         "description": "Six-image targeted pass, sixteen selected existing rows among141; eleven replacements plus one addition, five selected existing rows left unchanged and uncertain."},
    ]
    reviewed, passes = set(), []
    for path, ids, scope in zip(PASS_PATHS, pass_ids, scopes):
        ids = sorted(set(ids))
        assert set(ids) <= training_ids
        new_ids = sorted(set(ids) - reviewed)
        passes.append({**scope, "source": path, "source_sha256": sha(root / path),
                       "image_count": len(ids), "image_ids": ids, "new_image_ids_contributed": new_ids,
                       "source_objects_in_images": sum(by_id[image_id]["instances"] for image_id in ids),
                       "full_image_certification_claimed_by_this_inventory": False})
        reviewed.update(ids)
    remainder = sorted(training_ids - reviewed)
    assert len(reviewed) == 55 and len(remainder) == 82
    metadata = {}
    for record in training:
        image_id = record["id"]
        objects = gold[image_id]
        numeric_rows = [tuple(map(float, line.split())) for line in source_bytes[image_id].decode().splitlines()]
        assert len(numeric_rows) == len(objects)
        corners = Counter(sum(point[2] == 2 for point in obj["keypoints"]) for obj in objects)
        invalid, overlaps = [], []
        for row_number, obj in enumerate(objects, 1):
            try:
                check_geometry([obj], *record["original_size"], f"{image_id}:source-row-{row_number}")
            except ValueError as error:
                invalid.append({"source_row_one_based": row_number, "validator_message": str(error)})
        for first in range(len(objects)):
            for second in range(first + 1, len(objects)):
                iou = _box_iou(objects[first]["bbox_xyxy"], objects[second]["bbox_xyxy"])
                if iou >= 0.5:
                    overlaps.append({"source_rows_one_based": [first + 1, second + 1], "box_iou": iou,
                                     "locatable_corners": [sum(p[2] == 2 for p in objects[index]["keypoints"]) for index in (first, second)]})
        metadata[image_id] = {
            "image_id": image_id, "split": "train", "objects": len(objects),
            "visible_endpoints": sum(n * count for n, count in corners.items()),
            "missing_endpoints": 2 * len(objects) - sum(n * count for n, count in corners.items()),
            "objects_by_locatable_corners": {str(n): corners[n] for n in range(3)},
            "empty_label": not objects,
            "source_label": "data/" + record["label"], "source_label_sha256": record["label_sha256"],
            "declared_original_image": "data/" + record["image"], "declared_original_image_sha256": record["image_sha256"],
            "original_size": record["original_size"],
            "label_semantics_and_declared_counts_verified": True, "image_payload_opened": False,
            "geometry_error_rows": invalid,
            "numeric_duplicate_row_groups": repeated_groups(enumerate(numeric_rows, 1)),
            "identical_bbox_row_groups": repeated_groups((n, tuple(obj["bbox_xyxy"])) for n, obj in enumerate(objects, 1)),
            "box_pairs_iou_ge_0_5": overlaps,
        }
    unreviewed = [metadata[image_id] for image_id in remainder]
    nonempty = [row for row in unreviewed if row["objects"] > 0]
    empty = [row for row in unreviewed if row["empty_label"]]
    size, extra = divmod(len(nonempty), 5)
    strata, offset, selected = [], 0, []
    for index in range(5):
        group_size = size + (index < extra)
        group = nonempty[offset:offset + group_size]
        offset += group_size
        winner = min(group, key=lambda row: (-row["missing_endpoints"], row["image_id"]))
        selected.append(winner["image_id"])
        strata.append({"stratum_one_based": index + 1, "image_count": len(group),
                       "image_ids": [row["image_id"] for row in group], "selected_image_id": winner["image_id"],
                       "selected_missing_endpoint_count": winner["missing_endpoints"],
                       "all_missing_endpoint_counts_zero": all(row["missing_endpoints"] == 0 for row in group)})
    selected.append(empty[0]["image_id"])
    assert tuple(selected) == FROZEN_COHORT and set(selected) <= set(remainder)
    original_hash_groups = repeated_groups((row["id"], row["image_sha256"]) for row in records)
    prior_changes = {}
    for candidate_id in ("annotations-2026-11-10", "visible-extent-2026-11-11"):
        name = f"data/candidates/{candidate_id}/manifest.json"
        proposal = read(root / name)
        prior_changes[candidate_id] = {"manifest_sha256": sha(root / name),
            "changed_unreviewed_image_ids": sorted(set(remainder) & {row["image_id"] for row in proposal["changes"]})}
    result = {
        "schema_version": 1, "kind": "documented_training_review_inventory_and_prospective_cohort",
        "status": "complete_label_only_inventory_root_accepted_scope",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_revision": source_revision, "source_working_tree_status": source_status,
        "source_manifest_sha256": manifest_hash, "script_sha256": sha(__file__),
        "validator_source_sha256": {name: sha(root / name) for name in
            ("scripts/evaluate_pose.py", "scripts/verify_pose_candidate.py", "scripts/pose_scoring.py")},
        "annotation_policy": {"path": "docs/annotation-policy.md", "sha256": sha(root / "docs/annotation-policy.md")},
        "review_passes": passes,
        "reviewed_training_image_ids": sorted(reviewed), "unreviewed_training_image_ids": remainder,
        "accounting": {"all_training": summarize(list(metadata.values())),
                       "documented_review_history": summarize([metadata[image_id] for image_id in sorted(reviewed)]),
                       "absent_from_documented_passes": summarize(unreviewed)},
        "unreviewed_image_metadata": unreviewed,
        "mechanical_scope": {
            "all157_original_label_hashes_semantics_and_declared_counts_verified": True,
            "training_geometry_validator": "verify_pose_candidate.check_geometry; called for every original training row",
            "geometry_epsilon_px": GEOMETRY_EPSILON_PX,
            "numeric_duplicate_definition": "All11 parsed numeric fields equal within an image; this is a label-record fact, not a physical identity decision.",
            "bbox_duplicate_definition": "All4 parsed original-pixel box edges equal within an image; endpoint tuples may differ.",
            "overlap_screen": "Source-label box IoU>=0.50; these pairs are review flags and never proof of a duplicate physical front.",
            "declared_image_hash_duplicate_groups_all157": original_hash_groups,
            "declared_image_hashes_independently_rehashed_here": False,
            "identical_nonempty_label_file_groups_in_unreviewed": repeated_groups((row["image_id"], row["source_label_sha256"]) for row in nonempty),
            "identical_empty_label_files_are_not_duplicate_image_evidence": True,
            "prior_overlay_intersection": prior_changes,
        },
        "cohort": {
            "selection_status": "root_accepted_before_original_image_review",
            "rule": "Sort unreviewed nonempty training image IDs lexicographically; split into5 contiguous balanced strata, assigning any remainder to earlier strata; within each choose the highest missing-endpoint count, tie by lexicographic ID; append the lexicographically first remaining empty-labelled training image.",
            "selection_inputs": "Frozen original label metadata and documented review-ID union only; no model predictions or image viewing.",
            "strata": strata, "empty_label_candidates": [row["image_id"] for row in empty],
            "selected_image_ids_in_review_order": selected,
            "empty_label_control": empty[0]["image_id"],
            "metadata": [metadata[image_id] for image_id in selected],
            "totals": summarize([metadata[image_id] for image_id in selected]),
            "preimage_condition": {"inventory_author_viewed_selected_original_images": False,
                                   "inventory_author_opened_image_payloads": False,
                                   "model_predictions_read_or_used": False,
                                   "model_inference_or_training_performed": False,
                                   "repository_files_edited": False},
            "acceptance_for_later_visual_review": [
                "Use full original pixels before label overlays and inspect every image region for omissions, extra identities and observed front extent.",
                "Use the existing visible-front policy and preserve independently unlocatable corners; no hidden coordinates inferred from boxes, neighboring instances or brightness.",
                "Record a decision for every source row and any independently supported omitted front; preserve unresolved decisions without forcing a correction.",
                "The empty-labelled control is not presumed physically empty until the full original is inspected.",
                "Keep proposed edits separate, source-hashed and reviewable; no validation selection, inference or training is authorized by this inventory.",
            ],
        },
        "limits": [
            "55 denotes documented targeted visual-review history, not55 completely certified images;82 denotes absence from these recorded scopes, not proof nobody has ever inspected them.",
            "Counts, corner availability, duplicate fields and valid geometry describe labels, not independent physical truth.",
            "Filename order is a deterministic coverage device, not capture/session grouping, random sampling or independent-scene evidence.",
            "The last two strata contain only zero-missing old-prefix labels and therefore select ordinary labelled controls by the tie rule.",
            "Near-duplicate images, physical instance identity and omitted fronts cannot be settled from metadata hashes or overlap scores.",
            "Additional-pool pilots, validation-image reviews, input hashing and training execution do not enlarge the original-training visual-review union.",
        ],
    }
    assert git("rev-parse", "HEAD") == source_revision and git("status", "--porcelain") == source_status
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"output": str(args.output), "sha256": sha(args.output), "size_bytes": args.output.stat().st_size,
                      "unreviewed": result["accounting"]["absent_from_documented_passes"],
                      "cohort_ids": selected, "cohort_totals": result["cohort"]["totals"]}, indent=2))


if __name__ == "__main__":
    main()
