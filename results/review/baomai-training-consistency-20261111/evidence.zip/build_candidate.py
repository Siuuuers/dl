#!/usr/bin/env python3
"""Rebuild the bounded annotation proposal from an explicit adjudication record.

Uses frozen original labels and the selected PR35 overlay; no model execution.
The adjudication, not this script, supplies the original-image judgments.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path

CANDIDATE = "consistency-2026-11-11"
BASE = "61ae0e68fc517a6dfc7d8c19b63d846303a79e03"
PARENT = "annotations-2026-11-10"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--repo", type=Path, required=True)
    ap.add_argument("--adjudication", type=Path, required=True)
    args = ap.parse_args()
    root = args.repo.resolve()
    adj = json.loads(args.adjudication.read_text())
    assert adj["status"] == "accepted_bounded_review"
    assert adj["candidate_id"] == CANDIDATE
    parent = root / "data/candidates" / PARENT
    out = root / "data/candidates" / CANDIDATE
    old = json.loads((parent / "manifest.json").read_text())
    old_review = json.loads((parent / "review.json").read_text())
    source = json.loads((root / "data/manifest.json").read_text())
    records = {r["id"]: r for r in source["records"]}
    changes = copy.deepcopy(old["changes"])
    decisions = copy.deepcopy(old_review["decisions"])
    inherited_ids = {c["image_id"] for c in changes}
    new_ids = sorted({d["image_id"] for d in adj["accepted"]})
    assert not inherited_ids.intersection(new_ids)
    assert set(new_ids) <= {"new_000018", "new_000034", "new_000049"}
    for change in changes:
        dest = out / change["candidate_label"]
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes((parent / change["candidate_label"]).read_bytes())
    for ident in new_ids:
        record = records[ident]
        original = root / "data" / record["label"]
        assert sha(original) == record["label_sha256"]
        source_lines = original.read_bytes().splitlines(keepends=True)
        lines = list(source_lines)
        replacements = []
        used = set()
        for d in sorted((d for d in adj["accepted"] if d["image_id"] == ident),
                        key=lambda d: d["original_row"]):
            number = d["original_row"]
            assert number not in used
            used.add(number)
            before = source_lines[number - 1].decode().rstrip("\r\n")
            tokens = before.split()
            x1, y1, x2, y2 = d["bbox_xyxy_original_pixels"]
            assert 0 <= x1 < x2 <= 1280 and 0 <= y1 < y2 <= 720
            bbox = [(x1+x2)/2560, (y1+y2)/1440, (x2-x1)/1280, (y2-y1)/720]
            after = " ".join([tokens[0], *(f"{x:.8f}" for x in bbox), *tokens[5:]])
            assert before != after and before.split()[5:] == after.split()[5:]
            ending = source_lines[number - 1][len(before.encode()):]
            assert ending in (b"", b"\n", b"\r\n")
            lines[number - 1] = after.encode() + ending
            review_id = d["id"]
            replacements.append({"original_row": number, "candidate_row": number,
                "source_row_text": before, "candidate_row_text": after,
                "changed_fields": ["bbox"], "donor_endpoints": [],
                "review_status": "accepted_incremental", "reason": d["reason"],
                "review_id": review_id})
            decision = copy.deepcopy(d)
            decision.update({"review_status": "accepted_incremental",
                "source_rows_1based": [number], "operation": "bbox_replacement",
                "source_row_text": before, "candidate_row_text": after,
                "corner_tokens_preserved": True,
                "original_pixels_adjudicated_by_root": True})
            decisions.append(decision)
        relative = "labels/train/" + ident + ".txt"
        dest = out / relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(b"".join(lines))
        changes.append({"image_id": ident, "source_label": record["label"],
            "candidate_label": relative, "source_label_sha256": sha(original),
            "candidate_label_sha256": sha(dest), "source_image_sha256": record["image_sha256"],
            "source_objects": len(source_lines), "candidate_objects": len(lines),
            "deletions": [], "replacements": replacements, "additions": [],
            "row_map": [{"original_row": n, "candidate_row": n}
                        for n in range(1, len(lines)+1)]})
    inherited = {"candidate_id": PARENT,
        "manifest": {"path": str((parent / "manifest.json").relative_to(root)), "sha256": sha(parent / "manifest.json")},
        "review": {"path": str((parent / "review.json").relative_to(root)), "sha256": sha(parent / "review.json")},
        "source_revision": BASE, "changed_image_ids": sorted(inherited_ids),
        "inherited_decision_ids": [d["id"] for d in old_review["decisions"]],
        "newly_visually_certified_by_this_review": False,
        "preservation": "Exact eight inherited label files, change objects and accepted decision objects. No other historical candidate is accumulated."}
    review = {"schema_version": 1, "candidate_id": CANDIDATE,
        "policy_id": "baomai-visible-front-v1",
        "status": "assistant-reviewed incremental annotation proposal; no new model result",
        "human_or_supervisor_certified": False, "full_image_certified": False,
        "source_revision": BASE, "scope": adj["scope"],
        "sources": [records[i] for i in adj["scope"]["images"]],
        "inherited_review": inherited, "decisions": decisions,
        "new_accepted_decision_ids": [d["id"] for d in adj["accepted"]],
        "all_row_disposition": adj["all_row_disposition"],
        "unresolved_and_retained": adj["unresolved_and_retained"],
        "not_inherited": ["visible-extent-2026-11-11", "partial-fronts-2026-11-11",
                          "dedup-2026-11-06", "box-2026-11-07"],
        "boundary_note": adj["boundary_note"], "review_provenance": adj["review_provenance"],
        "hypothesis": "Correcting gross visible-front extent inconsistencies may improve supervision. This box-only delta includes both expansion to observed material and removal of hidden width. No inference, training, threshold selection or performance claim is part of this review."}
    save(out / "review.json", review)
    n = len(adj["accepted"])
    counts = copy.deepcopy(old["expected_edit_counts"])
    counts["changed_train_files"] += len(new_ids)
    counts["replaced_rows"] += n
    manifest = {"schema_version": 1, "kind": "training_annotation_overlay", "status": "proposed",
        "candidate_id": CANDIDATE, "created_at_utc": adj["completed_at_utc"],
        "source_repository": "Siuuuers/dl", "source_revision": BASE,
        "source_manifest_sha256": sha(root / "data/manifest.json"),
        "annotation_policy": copy.deepcopy(old["annotation_policy"]),
        "review": {"path": "review.json", "sha256": sha(out / "review.json")},
        "inherits": inherited,
        "scope": f"Exact selected PR35 eight-file overlay plus {n} original-image-supported box-only replacements in {len(new_ids)} disjoint training files. All existing class/corner tokens and row counts are preserved in the new delta. No additions, deletions or validation edits.",
        "changes": sorted(changes, key=lambda c: c["image_id"]),
        "expected_counts": copy.deepcopy(old["expected_counts"]),
        "expected_edit_counts": counts,
        "new_edit_counts_relative_to_parent": {"changed_train_files": len(new_ids),
            "replaced_rows": n, "added_rows": 0, "deleted_rows": 0,
            "donor_endpoints_transferred": 0, "new_visible_endpoints": 0,
            "net_object_change": 0, "all_existing_corner_tokens_preserved": True}}
    save(out / "manifest.json", manifest)
    print(json.dumps({"candidate": str(out), "new_replacements": n,
                      "candidate_manifest_sha256": sha(out / "manifest.json")}))


if __name__ == "__main__":
    main()
