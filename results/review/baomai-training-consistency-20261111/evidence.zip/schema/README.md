# Candidate contract audit for the next bounded review

**Recommendation:** retain the selected PR35 eight-file overlay as the control. If the new cohort yields supported edits, create one separately named candidate containing those exact eight files plus only the new accepted delta. Preserve the previously tested visible-extent candidate independently; its four additional files do not enter the next baseline by default. Do not prepare training or a new fixed study wrapper before the review determines the actual intervention.

This is a read-only audit of source commit `61ae0e68fc517a6dfc7d8c19b63d846303a79e03`. The source checkout was clean. Both existing candidates passed the unchanged annotation verifier; no new labels, candidate, training or inference were created. Exact source hashes and verifier results are in `audit.json`.

## Composition and identity

| Item | Frozen identity / treatment |
|---|---|
| Selected control | `data/candidates/annotations-2026-11-10/manifest.json`; SHA256 `28fc8f5da95605089d61fb062132200ed296c3a10b216f1a61dbda1798ea4ba7` |
| Control review | SHA256 `84dd73407aa147637d8eb68f8ff8268c856d70c46a8a8bf144549e00e6480c85` |
| Exact inherited image IDs | `065`, `067`, `068`, `072`, `097`, `101`, `102`, `103`, all with `new_000` prefix |
| Control train counts | 137 images, 3,771 objects, 6,841 visible endpoints, 701 missing endpoint slots, 13 empty images |
| In-training validation | Original 20 images, 664 objects, 1,227 visible endpoints, 101 missing slots, 3 empty images; unchanged |
| Separate historical candidate | `visible-extent-2026-11-11`, manifest SHA256 `ab89253e4c2e886a6f1274fa50e400cf568c132e9cecc83d8f558d567b88c6d4`; its additional `061/079/082/094` files are excluded unless explicitly selected for a different composition |

The generic overlay format describes edits **against the frozen original labels**, not a chain of mutable directories. A cumulative candidate therefore copies the eight control label files, their manifest change objects and accepted review decisions exactly, then adds the accepted new operations. Its full `expected_counts` describe original labels plus the entire cumulative overlay; separately recorded delta counts describe only the difference from the eight-file control.

The requested review outside the earlier targeted IDs should be disjoint from the eight inherited files. Check that assertion against the root-supplied cohort. If a proposed change overlaps an inherited file, stop composition and declare that exception explicitly; exact inheritance no longer describes the comparison. If there is no supported new delta, retain the review record alone.

## What the unchanged verifier permits

Source: [annotation verifier](https://github.com/Siuuuers/dl/blob/61ae0e68fc517a6dfc7d8c19b63d846303a79e03/scripts/verify_pose_annotation_candidate.py).

| Operation | Mechanical contract | Implication for this pass |
|---|---|---|
| Box-only replacement | Exact original row text; unchanged class token; `changed_fields: ["bbox"]`; exact old point tokens; no undeclared byte changes | Preferred when pixels support a bounded extent correction without changing point semantics |
| Delete a row with both points missing | Explicit accepted deletion, exact source text and complete original-to-candidate row map | Allowed mechanically; original pixels must establish non-target or redundant identity. Missing points or high overlap alone do not justify deletion |
| Delete a row with a visible point | Every deleted visible endpoint must be transferred exactly once to an original missing slot of a retained replacement row, with declared donor provenance | Cannot remove an unsupported visible point through ordinary deletion. Do not invent a recipient or misstate duplicate identity to satisfy the guard |
| Modify an existing `v=2` point | Forbidden: its complete original three-token coordinate/visibility tuple must remain identical | Record a suspected wrong point separately. A later explicit bounded proposal mechanism is required; do not relax this global guard |
| Change retained `v=0` to `v=2` | Currently permitted with an accepted replacement and declared changed field; an empty donor list is not universally forbidden | This is broader than a donor-only rule. For the present scope, add an explicit all-old-corner-tokens-unchanged check and do not use this allowance silently |
| Add a supported new front | Append after retained rows, in declared order, with a unique addition ID and valid 11-field row; missing and visible points are both representable | Prefer `0 0 0` for independently unlocatable corners. Any newly marked visible point needs a separate explicit scope decision and original-pixel evidence |

The verifier preserves unchanged row bytes and line endings, including rows not reviewed. Replacements preserve their original line ending; additions end in LF. Deleted rows map to `candidate_row: null`; retained rows preserve order and are renumbered after deletions. Numeric equality is insufficient for unchanged fields: their tokens must also match.

## Minimum candidate and review record

Use the existing four-part package: `manifest.json`, `review.json`, changed `labels/train/*.txt`, and a short `README.md`; retain original-pixel review figures/provenance where they clarify the decisions. Do not create a redundant second standalone label overlay unless it is independently useful.

The manifest needs `schema_version: 1`, `kind: "training_annotation_overlay"`, `status: "proposed"`, a new `candidate_id`, full source revision, original manifest hash, hash-bound policy/review descriptors, explicit per-image operations and full train/val counts. Each changed image binds the original image hash, original/candidate label hashes and paths, row counts, deletions/replacements/additions and full row map. Each operation references a review decision by ID and repeats its exact `reason` and `review_status: "accepted_incremental"`.

The review should additionally state the actual cohort, original-first inspection method, reviewer/root adjudication, original image and label identities, accepted versus unchanged-uncertain decisions, approximate edge choices, and limited scope. Record the parent manifest/review hashes and inherited decisions separately from the new decisions. Preserve any suspected unsupported point in a separate unresolved issue rather than encoding a disallowed edit.

## Checks needed beyond the generic verifier

1. **Control composition:** exact eight inherited label bytes, change objects and accepted decision objects; exact new delta image set; no silently inherited visible-extent or PR40 extension. The manifest's `inherits` field is descriptive and is not enforced by the generic verifier.
2. **Point preservation for this scope:** compare every retained source corner token, including `v=0` slots; require box-only `changed_fields` and empty donors for pure box edits. If new fronts have no supported corners, require all six appended point tokens to be canonical zeros. These are additional scope constraints, not changes to the existing verifier.
3. **Counts and bytes:** run the existing verifier against all 157 original labels; reconcile replacement/addition/deletion and visible/missing endpoint counts with the declared delta. `expected_counts` is enforced; `expected_edit_counts` and `new_edit_counts_relative_to_parent` are not currently enforced by that function.
4. **Physical inputs and provenance:** independently hash the actual reviewed PNGs against the original manifest. The generic verifier checks image-hash metadata but reports `image_bytes_verified: false`; it also checks the source revision's format, not existence of its Git object. Record actual source commit and image-byte verification separately.
5. **Frozen evaluation:** original image bytes, split, validation labels and separately versioned post-training reference remain unchanged. A future matched study must bind the two candidate manifests explicitly; both runner arms truthfully remain `candidate`.

The current [visible-extent study wrapper](https://github.com/Siuuuers/dl/blob/61ae0e68fc517a6dfc7d8c19b63d846303a79e03/scripts/package_visible_extent_results.py) hard-codes that historical candidate ID/path and six-image scope. Do not repurpose or loosen it for the new review. Generic annotation verification and staging already support a new candidate path; any later study contract should be separately named and bind the final accepted composition.

## Partial fronts and unresolved images

The [policy](https://github.com/Siuuuers/dl/blob/61ae0e68fc517a6dfc7d8c19b63d846303a79e03/docs/annotation-policy.md) allows a supported positive-area visible front with zero, one or two locatable corners. It adopts no minimum area. Box extrema enclose observed front material, excluding guessed hidden width, roof, rim, rack, gripper and hand. A rectangle may contain occluder pixels between supported visible portions.

Partial review is supported: accepted edits can coexist with unchanged legacy or uncertain rows, with `full_image_certified: false` and explicit unresolved records. Only operations tied to accepted decisions may change labels. A genuinely uncertain image is not an empty negative; do not erase its labels. The overlay cannot silently quarantine images or change the fixed split/count contract.

Geometry still requires finite values, positive boxes, canonical missing slots, image-X ordering when both corners are visible, strict half-open visible-point bounds and point containment within the box. The `1e-4` original-pixel tolerance is only for serialization. If a supported tighter box conflicts with an apparently unsupported old visible point, record the conflict; do not inflate the box, snap the point or bypass the endpoint guard.

**Next input awaited:** the root-supplied bounded cohort and original-pixel findings. No further candidate construction is justified before those decisions exist.
