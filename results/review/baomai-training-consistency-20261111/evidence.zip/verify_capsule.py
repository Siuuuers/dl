#!/usr/bin/env python3
"""Check the evidence capsule's exact members, sizes and SHA256 digests."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path, PurePosixPath


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("archive", type=Path)
    args = ap.parse_args()
    with zipfile.ZipFile(args.archive) as z:
        names = z.namelist()
        assert len(names) == len(set(names)), "duplicate ZIP member"
        for n in names:
            p = PurePosixPath(n)
            assert not p.is_absolute() and ".." not in p.parts
        assert z.testzip() is None, "ZIP CRC failure"
        inventory = json.loads(z.read("payload-index.json"))
        entries = inventory["payloads"]
        assert set(names) == {r["path"] for r in entries} | {"payload-index.json"}
        for r in entries:
            data = z.read(r["path"])
            assert len(data) == r["bytes"], r["path"]
            assert hashlib.sha256(data).hexdigest() == r["sha256"], r["path"]
    print(json.dumps({"status": "verified", "payloads": len(entries), "members": len(names),
        "archive_bytes": args.archive.stat().st_size,
        "archive_sha256": hashlib.sha256(args.archive.read_bytes()).hexdigest(),
        "scope": "Capsule integrity only; original-image semantics and external Git/source checks are separate."}, indent=2))


if __name__ == "__main__":
    main()
