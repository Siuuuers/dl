#!/usr/bin/env python3
"""Render original-pixel review aids; never writes annotations or predictions."""
import argparse
import hashlib
import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

REGIONS = {
    "new_000018": {"upper": (80, 130, 955, 555), "lower": (170, 515, 790, 720),
                   "jaw": (425, 410, 945, 650)},
    "new_000034": {"upper": (175, 0, 920, 290), "middle": (270, 245, 895, 565),
                   "lower": (340, 540, 680, 720), "jaw": (535, 410, 820, 555)},
    "new_000049": {"upper": (135, 0, 700, 150), "middle": (0, 270, 840, 530),
                   "lower": (40, 525, 620, 720), "jaw": (590, 385, 825, 525)},
    "old_000007": {"stack": (555, 75, 900, 505)},
    "old_000057": {"stack": (545, 0, 980, 495)},
    "new_000132": {},
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def draw_rows(im, rows, roi=(0, 0, 1280, 720), scale=1):
    im = im.crop(roi).resize(((roi[2] - roi[0]) * scale, (roi[3] - roi[1]) * scale),
                            Image.Resampling.NEAREST)
    draw = ImageDraw.Draw(im)
    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 12)
    def point(x, y):
        return ((x - roi[0]) * scale, (y - roi[1]) * scale)
    for row in rows:
        x1, y1, x2, y2 = row["bbox_xyxy"]
        if x2 < roi[0] or x1 > roi[2] or y2 < roi[1] or y1 > roi[3]:
            continue
        draw.rectangle((*point(x1, y1), *point(x2, y2)), outline="#00aaff", width=1)
        tx, ty = point(x1, y1)
        tx = max(0, min(im.width - 31, tx))
        ty = max(0, min(im.height - 15, ty))
        draw.rectangle((tx, ty, tx + 29, ty + 14), fill="#102030")
        draw.text((tx + 1, ty), str(row["row_one_based"]), font=font, fill="white")
        for side, (x, y, v) in enumerate(row["keypoints"]):
            if v != 2:
                continue
            px, py = point(x, y)
            draw.ellipse((px - 2, py - 2, px + 2, py + 2),
                         fill="#fff000" if side == 0 else "#ff36ba")
    return im


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--source", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((args.source / "data/manifest.json").read_text())
    records = {r["id"]: r for r in manifest["records"]}
    evidence = {"kind": "original_annotation_review_aids", "no_predictions": True,
                "full_originals_viewed_before_overlays": True,
                "reviewer": "root", "images": []}
    for ident, regions in REGIONS.items():
        rec = records[ident]
        image_path = args.source / "data" / rec["image"]
        label_path = args.source / "data" / rec["label"]
        assert digest(image_path) == rec["image_sha256"]
        assert digest(label_path) == rec["label_sha256"]
        im = Image.open(image_path).convert("RGB")
        w, h = im.size
        rows = []
        for i, line in enumerate(label_path.read_text().splitlines(), 1):
            t = list(map(float, line.split()))
            assert len(t) == 11
            cx, cy, bw, bh = t[1:5]
            rows.append({"row_one_based": i, "source_text": line,
                         "bbox_xyxy": [(cx - bw/2)*w, (cy - bh/2)*h,
                                       (cx + bw/2)*w, (cy + bh/2)*h],
                         "keypoints": [[t[5]*w, t[6]*h, int(t[7])],
                                       [t[8]*w, t[9]*h, int(t[10])]]})
        draw_rows(im, rows).save(args.output / (ident + "_source_overlay.png"))
        for name, roi in regions.items():
            crop = im.crop(roi)
            scale = 2 if crop.width < 700 else 1
            crop.resize((crop.width*scale, crop.height*scale), Image.Resampling.NEAREST).save(
                args.output / (ident + "_" + name + "_raw.png"))
            draw_rows(im, rows, roi, scale).save(
                args.output / (ident + "_" + name + "_overlay.png"))
        evidence["images"].append({"id": ident, "image_sha256": rec["image_sha256"],
                                    "label_sha256": rec["label_sha256"],
                                    "rows": rows, "regions": regions})
    (args.output / "source-review-geometry.json").write_text(
        json.dumps(evidence, indent=2) + "\n")
    print(json.dumps({"images": len(evidence["images"]),
                      "rows": sum(len(i["rows"]) for i in evidence["images"]),
                      "output": str(args.output)}))


if __name__ == "__main__":
    main()
