from pathlib import Path
from PIL import Image, ImageDraw
import json,hashlib,datetime,math,argparse,textwrap
P=Path('/workspace/scratch/11398f9f3638')
parser=argparse.ArgumentParser(description='Reproduce native-pixel reconciliation proofs from the frozen hydrated originals and review records.')
parser.add_argument('--original-image-root',type=Path,default=P/'pr43-return/source/data/images/train')
parser.add_argument('--initial-review',type=Path,default=P/'training-consistency-audit/independent-review/review.json')
parser.add_argument('--root-initial-review',type=Path,default=P/'training-consistency-audit/root-review/initial-review.json')
parser.add_argument('--output-dir',type=Path,default=P/'training-consistency-audit/independent-review')
args=parser.parse_args();O=args.output_dir;O.mkdir(parents=True,exist_ok=True)
D=O/'reconciliation-proofs';D.mkdir(exist_ok=True)
initial_path=args.initial_review;initial_bytes=initial_path.read_bytes();initial=json.loads(initial_bytes)
root_path=args.root_initial_review;root_bytes=root_path.read_bytes();root=json.loads(root_bytes)
root_boxes={i['image_id']:i['rough_bbox_xyxy_for_reconciliation'] for i in root['images']}
final={
'new_000018':{
24:([793,454,924,495],'Retain initial geometry: original shows upper-left exposed material beginning near x793 at y454; foreground jaw covers material farther left. Soft right curvature remains within about 2–3 px.'),
25:([807,488,918,524],'Original shows the upper exposed fragment beginning around y488 and the rounded right face reaching approximately x918. Initial right edge916 was slightly inside visible material; root left800 would include jaw material.'),
26:([815,521,910,552],'Original seam is near y521, with foreground jaw extending to about x815 at the upper-left visible extreme. Initial left812/top516 included jaw/previous-front material.'),
32:([452,579,534,609],'Original left step begins around y579 and the lower step is near y607–609. Initial bottom613 crossed into the next front. Right extreme follows the hand boundary at the upper seam around x534; no coordinate averaging.'),
33:([457,607,511,635],'Original shows a new left-edge step near x457,y607 and another lower step around y633–635. Initial top608 was close, but bottom637 included transition below; x511 is the visible upper hand-boundary extreme.'),
34:([460,633,486,659],'Original lower left fragment starts near the y633 step and ends near y657–659. Upper visible portion extends to the hand near x486; initial right483 omitted a narrow visible piece.')},
'new_000034':{
55:([574,659,616,685],'Original raw fragment below row54 has an upper slanted seam reaching the gripper near x616,y659; left lower step lies around y682–685. Initial right611 missed the upper-right exposed portion.'),
56:([578,679,601,703],'Original exposed face reaches the gripper near x601 around its upper transition and ends near y700–703 at the next step. Initial right597 clipped visible upper material.'),
57:([580,698,593,720],'Original narrow gray strip is visible between rack and gripper from approximately y698 to image bottom. Its upper-right portion reaches about x593; initial x589 was too narrow. Bottom stays clipped at720, with existing left v2 token retained.')},
'new_000049':{
9:([0,439,140,495],'Retain initial geometry: rounded physical front ends near x140, while original x162 includes rack/background. The image-left edge remains clipped and unavailable.'),
14:([350,645,478,669],'Original right-edge zoom shows white front material to roughly x476–478 near y650 before the hand. Initial right472 omitted supported visible material; preserve the rounded left v2 junction token.'),
24:([356,663,472,686],'Original shows front material reaching x470–472 around y664–666. Initial right466 cut this upper-right piece. This follows the hand intersection and is not an average of proposals.'),
25:([364,681,454,701],'Original shows the upper seam entering the hand around x452–454,y681. Initial right449 was too narrow; left/top adjusted to the visible stepped transition.'),
26:([365,698,442,716],'Original final visible front starts near the y698 transition and reaches the hand around x440–442 there. Initial top705/right412 from source, and own first top699/right436, omit visible material; lower edge remains around716.')}
}
holds={
('new_000018',23):'Instance and excessive left extent are supported, but the first estimate also changes the roof/front top from419.74 to407. The upper face/roof transition is not confidently separated; hold the complete replacement rather than accepting uncertain top geometry.',
('new_000018',28):'Observed front and hand occlusion are clear, but the first estimate changes top650.82 to637 across the roof/front transition. No final front-only upper extent is sufficiently resolved in this pass; hold.',
('new_000018',29):'Visible row and overextended right bound are supported, but the exact upper/lower seams in the shaded lower stack remain weak. Hold the complete replacement rather than treating a right-edge improvement as certification of every edge.',
('new_000018',30):'Bottom-clipped front is supported, but its upper seam and relationship to the image-border/lip transition remain weak. Hold the complete replacement; preserve both unavailable corners.',
('new_000018',31):'A broad upper exposed segment before the thumb may support nearly the old right extreme, but the seam with row14/32 is not resolved tightly enough to adopt the first estimate. Hold.',
('new_000034',43):'Occluded width is clearly excessive. Reinspection shows slanted seams meeting the gripper; the full proposed top/bottom extrema remain disputed beyond ordinary 1–3px blur. Hold instead of averaging root/peer boxes or copying the full legacy-height band.',
('new_000034',44):'Right extent is excessive, but slanted visible-row seams change the full box top more than a small rounding adjustment. Full-box replacement held until the face-versus-rounded lip transition is adjudicated.',
('new_000034',45):'Right extent is excessive, but proposed upper extent may include the preceding front where it is hidden by the gripper. Hold the full replacement rather than extrapolating a hidden slanted seam.',
('new_000034',54):'Bright top transition spans approximately y625–637. Original pixels do not resolve whether the higher material is target front or upper surface. Peer625 and root637 are materially different semantic choices, not quantities to average. Hold full replacement.'
}

def dashed(draw,box,fill,width=1,step=5):
 x1,y1,x2,y2=[int(round(v)) for v in box]
 for x in range(x1,x2,step*2):
  draw.line((x,y1,min(x+step,x2),y1),fill=fill,width=width);draw.line((x,y2,min(x+step,x2),y2),fill=fill,width=width)
 for y in range(y1,y2,step*2):
  draw.line((x1,y,x1,min(y+step,y2)),fill=fill,width=width);draw.line((x2,y,x2,min(y+step,y2)),fill=fill,width=width)

def draw_row(im,old,box,row,status):
 d=ImageDraw.Draw(im)
 dashed(d,old['bbox_xyxy'],(255,75,75))
 color=(40,255,120) if status=='recommend_box_only' else (255,185,30)
 dashed(d,box,color) if status=='hold_unchanged' else d.rectangle(tuple(box),outline=color,width=1)
 x,y=box[:2];tx=max(0,min(1210,int(x)));ty=max(0,min(704,int(y)-13));label=f'{row} '+('RECOMMEND' if status=='recommend_box_only' else 'HOLD')
 d.rectangle((tx,ty,tx+len(label)*6+3,ty+12),fill='black');d.text((tx+1,ty+1),label,fill=color)
 for kx,ky,v in old['keypoints']:
  if v:d.ellipse((kx-2,ky-2,kx+2,ky+2),outline=(255,255,0),width=1)
 return im
records=[];groups=[]
for imrec in initial['images']:
 ident=imrec['id'];proposed=[r for r in imrec['rows'] if 'proposed_bbox_xyxy' in r]
 if not proposed:continue
 source_path=args.original_image_root/f'{ident}.png';source_hash=hashlib.sha256(source_path.read_bytes()).hexdigest();assert source_hash==imrec['original_sha256'],(ident,'source hash mismatch');raw=Image.open(source_path).convert('RGB');assert raw.size==(1280,720)
 group=raw.copy()
 for old in proposed:
  row=old['row'];key=(ident,row);own=old['proposed_bbox_xyxy']
  if row in final.get(ident,{}):
   box,reason=final[ident][row];status='recommend_box_only';finalbox=box
   for x,y,v in old['keypoints']:
    if v:assert box[0]<=x<=box[2] and box[1]<=y<=box[3],(ident,row,'point exclusion')
  else:status='hold_unchanged';finalbox=None;box=own;reason=holds[key]
  overlay=draw_row(raw.copy(),old,box,row,status)
  fullpath=D/f'{ident}-row{row:02d}-native-overlay.png';overlay.save(fullpath)
  group=draw_row(group,old,box,row,status)
  union=[min(old['bbox_xyxy'][0],box[0]),min(old['bbox_xyxy'][1],box[1]),max(old['bbox_xyxy'][2],box[2]),max(old['bbox_xyxy'][3],box[3])]
  cx=(union[0]+union[2])/2;cy=(union[1]+union[3])/2;w=max(180,union[2]-union[0]+32);h=max(100,union[3]-union[1]+40)
  left=max(0,math.floor(cx-w/2));top=max(0,math.floor(cy-h/2));right=min(1280,math.ceil(cx+w/2));bottom=min(720,math.ceil(cy+h/2));roi=[left,top,right,bottom]
  rc=raw.crop(roi);oc=overlay.crop(roi)
  panel_width=max(720,2*rc.width+16);header=86
  pair=Image.new('RGB',(panel_width,rc.height+header),(28,31,38));pair.paste(rc,(0,header));pair.paste(oc,(rc.width+16,header));d=ImageDraw.Draw(pair)
  texts=[f'{ident} row{row}: {status}; original1280x720; native crop origin({left},{top}), scale1',
         'RAW ORIGINAL | OVERLAY: red dashed=legacy; green=recommended; amber=HELD initial; yellow=unchanged v2',
         f'Final: {finalbox if finalbox is not None else "HOLD - original label unchanged"}; initial peer: {own}']
  yy=6
  for txt in texts:
   for line in textwrap.wrap(txt,width=(panel_width-14)//6):d.text((7,yy),line,fill='white');yy+=13
  pairpath=D/f'{ident}-row{row:02d}-raw-overlay.png';pair.save(pairpath)
  records.append({'image_id':ident,'original_row':row,'old_bbox_xyxy':old['bbox_xyxy'],'initial_peer_bbox_xyxy':own,'initial_root_bbox_xyxy':root_boxes.get(ident,{}).get(str(row)),'decision':status,'recommended_bbox_xyxy':finalbox,'reason':reason,'original_endpoint_tokens_preserved':True,'existing_v2_point_containment_checked':status=='recommend_box_only','boundary_uncertainty':'Approximately1–3px at soft rounded/blurred edges; this is a review convention, not physical metrology.','proof_native_overlay':str(fullpath),'proof_raw_overlay':str(pairpath),'proof_crop_xyxy':roi,'source_image_dimensions':[1280,720],'source_image_sha256':source_hash,'proof_scale':1})
 group_path=D/f'{ident}-group-native-overlay.png';group.save(group_path)
 pair=Image.new('RGB',(2560,762),(28,31,38));pair.paste(raw,(0,42));pair.paste(group,(1280,42));d=ImageDraw.Draw(pair)
 d.text((10,7),f'{ident}: unchanged raw original (left) | all originally proposed rows (right); each frame 1280x720, no resampling',fill='white')
 d.text((10,23),'Green = final recommended box; amber dashed = initial estimate HELD (no accepted edit); red dashed = legacy; yellow = preserved v2',fill='white')
 group_pair_path=D/f'{ident}-group-raw-overlay.png';pair.save(group_pair_path)
 groups.append({'image_id':ident,'native_overlay':str(group_path),'raw_overlay_pair':str(group_pair_path),'original_frame_dimensions':[1280,720],'resampling':'none','source_image_sha256':source_hash})
assert len(records)==23
result={'kind':'independent_coordinate_reconciliation','status':'recommendations_pending_root_final_image_acceptance','created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'initial_peer_review_sha256':hashlib.sha256(initial_bytes).hexdigest(),'root_initial_review_sha256':hashlib.sha256(root_bytes).hexdigest(),'initial_peer_review_preserved':initial_path.read_bytes()==initial_bytes,'method':'Root notes first read only after independent review.json was complete. Rechecked raw original crops at disputed seams, with rulers outside image and nearest-neighbor magnification for inspection. No averaging as a substitute for visible boundaries. Proof native frames and paired crops use original-resolution pixels without resampling. No repo edits, inference, predictions, training, point-token edits, additions or deletions.','counts':{'original_proposals':len(records),'recommended':sum(r['decision']=='recommend_box_only' for r in records),'held':sum(r['decision']=='hold_unchanged' for r in records)},'records':records,'proof_groups':groups,'limits':['These are assistant recommendations awaiting root original-pixel acceptance.','Held initial estimates must not be applied.','No unchanged legacy row or endpoint is thereby fully recertified.','Boundary values do not establish calibrated physical accuracy or model quality.']}
(O/'reconciliation.json').write_text(json.dumps(result,indent=2)+'\n')
index={'kind':'native_pixel_proof_provenance','original_frame_dimensions':[1280,720],'resampling':'none','scale':1,'source_image_directory_semantics':'hydrated data/images/train; source hashes verified before rendering','images':{g['image_id']:{'source_image':f"data/images/train/{g['image_id']}.png",'sha256':g['source_image_sha256'],'group_native_overlay':str(Path(g['native_overlay']).relative_to(O)),'group_raw_overlay_pair':str(Path(g['raw_overlay_pair']).relative_to(O)),'group_roi':[0,0,1280,720]} for g in groups},'panels':[{'image_id':r['image_id'],'original_row':r['original_row'],'source_image_sha256':r['source_image_sha256'],'roi_xyxy':r['proof_crop_xyxy'],'scale':1,'old_bbox_xyxy':r['old_bbox_xyxy'],'initial_peer_bbox_xyxy':r['initial_peer_bbox_xyxy'],'recommended_bbox_xyxy':r['recommended_bbox_xyxy'],'decision':r['decision'],'raw_overlay_panel':str(Path(r['proof_raw_overlay']).relative_to(O)),'native_full_overlay':str(Path(r['proof_native_overlay']).relative_to(O))} for r in records]}
(O/'proof-index.json').write_text(json.dumps(index,indent=2)+'\n')
md=['# Coordinate reconciliation','',f'**{result["counts"]["recommended"]} recommendations; {result["counts"]["held"]} held unchanged.** Initial independent `review.json` is preserved. Root must inspect the paired original/overlay proofs before acceptance.','', '| Image | Row | Decision | Final recommended box |','|---|---:|---|---|']
for r in records:md.append(f'| {r["image_id"]} | {r["original_row"]} | {r["decision"]} | `{r["recommended_bbox_xyxy"]}` |')
md+=['','## Material reconciliation changes','', '- New_000018 rows32/33: initial lower seam613 crossed the next front. Rechecked visible left step lies near607–609; final recommendations use row32 bottom609 and row33 top607.', '- New_000034 row54: held because625 versus637 changes the front/roof interpretation. No coordinate average used.', '- New_000049 row24: original shows front extending near470–472 at the upper hand intersection; final right472 replaces initial466.', '- Several other whole-box estimates are held where the occlusion error is clear but all four front-only extrema remain unresolved.', '', 'Each group proof contains untouched1280×720 original and1280×720 overlay at native resolution. Each of the23 row proofs also has a native crop pair with its original offset; no image reconstruction or resampling. Amber means HELD, not a recommendation.','']
(O/'reconciliation.md').write_text('\n'.join(md))
print(json.dumps(result['counts']));print(str(O/'reconciliation.json'));print(str(D))
