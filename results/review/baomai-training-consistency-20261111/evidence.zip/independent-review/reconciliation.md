# Coordinate reconciliation

**14 recommendations; 9 held unchanged.** Initial independent `review.json` is preserved. Root must inspect the paired original/overlay proofs before acceptance.

| Image | Row | Decision | Final recommended box |
|---|---:|---|---|
| new_000018 | 23 | hold_unchanged | `None` |
| new_000018 | 24 | recommend_box_only | `[793, 454, 924, 495]` |
| new_000018 | 25 | recommend_box_only | `[807, 488, 918, 524]` |
| new_000018 | 26 | recommend_box_only | `[815, 521, 910, 552]` |
| new_000018 | 28 | hold_unchanged | `None` |
| new_000018 | 29 | hold_unchanged | `None` |
| new_000018 | 30 | hold_unchanged | `None` |
| new_000018 | 31 | hold_unchanged | `None` |
| new_000018 | 32 | recommend_box_only | `[452, 579, 534, 609]` |
| new_000018 | 33 | recommend_box_only | `[457, 607, 511, 635]` |
| new_000018 | 34 | recommend_box_only | `[460, 633, 486, 659]` |
| new_000034 | 43 | hold_unchanged | `None` |
| new_000034 | 44 | hold_unchanged | `None` |
| new_000034 | 45 | hold_unchanged | `None` |
| new_000034 | 54 | hold_unchanged | `None` |
| new_000034 | 55 | recommend_box_only | `[574, 659, 616, 685]` |
| new_000034 | 56 | recommend_box_only | `[578, 679, 601, 703]` |
| new_000034 | 57 | recommend_box_only | `[580, 698, 593, 720]` |
| new_000049 | 9 | recommend_box_only | `[0, 439, 140, 495]` |
| new_000049 | 14 | recommend_box_only | `[350, 645, 478, 669]` |
| new_000049 | 24 | recommend_box_only | `[356, 663, 472, 686]` |
| new_000049 | 25 | recommend_box_only | `[364, 681, 454, 701]` |
| new_000049 | 26 | recommend_box_only | `[365, 698, 442, 716]` |

## Material reconciliation changes

- New_000018 rows32/33: initial lower seam613 crossed the next front. Rechecked visible left step lies near607–609; final recommendations use row32 bottom609 and row33 top607.
- New_000034 row54: held because625 versus637 changes the front/roof interpretation. No coordinate average used.
- New_000049 row24: original shows front extending near470–472 at the upper hand intersection; final right472 replaces initial466.
- Several other whole-box estimates are held where the occlusion error is clear but all four front-only extrema remain unresolved.

Each group proof contains untouched1280×720 original and1280×720 overlay at native resolution. Each of the23 row proofs also has a native crop pair with its original offset; no image reconstruction or resampling. Amber means HELD, not a recommendation.
