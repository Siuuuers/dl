# Independent original-first six-image review

Completed 2026-11-11T15:21:24.989580+00:00.

Reviewed all **135 original rows** in five positive images and the full-frame negative `new_000132`. Original PNG hashes all matched the frozen scope/manifest. No repo labels, checkpoints, or model outputs were altered.

## Independent findings

- `new_000132`: confirmed empty rack/gripper negative; retain empty label.
- 23 box-only coordinate proposals below. Every retained original v2 endpoint fits these proposed boxes and would remain byte-for-byte unchanged.
- No addition or deletion was independently finalized. The central strip in `new_000018` merits reconciliation; see the uncertainty record.
- Most unchanged legacy boxes have nonzero padding/visible-face alignment uncertainty. Unchanged means no exact edit finalized here, not policy certification.

## Proposed box coordinates

All coordinates are original-image pixel `[x1,y1,x2,y2]`. Integer values are review estimates with roughly 1–4 px boundary uncertainty, not calibrated measurement.

| Image | Original row | Proposed visible bbox | Reason |
|---|---:|---|---|
| new_000018 | 23 | `[777, 407, 935, 459]` | Observed front extends above the old top bound; old left bound includes gripper/neighboring stack. |
| new_000018 | 24 | `[793, 454, 924, 495]` | Exclude left gripper extent and lower neighboring face; include visible upper slant. |
| new_000018 | 25 | `[807, 487, 916, 524]` | Use observed exposed right front; old left bound extrapolates through gripper. |
| new_000018 | 26 | `[812, 516, 911, 552]` | Use observed exposed right front; old left/lower bounds include gripper, hand, and background. |
| new_000018 | 28 | `[319, 637, 463, 684]` | Visible front begins above old top bound; right extent stops at hand; exclude next lower front. |
| new_000018 | 29 | `[329, 678, 450, 708]` | Retain separately supported lower front and restrict right extent to hand boundary. |
| new_000018 | 30 | `[333, 702, 438, 720]` | Retain bottom-clipped front; exclude hand to its right, preserve both unavailable corners. |
| new_000018 | 31 | `[448, 546, 600, 584]` | Visible upper segment supports broad right extreme before hand occludes the lower region; trim lower neighboring face. |
| new_000018 | 32 | `[454, 580, 539, 613]` | Right side substantially occluded by thumb; old right bound describes hidden width. |
| new_000018 | 33 | `[457, 608, 507, 637]` | Right side substantially occluded by thumb; old right bound describes hidden width. |
| new_000018 | 34 | `[459, 633, 483, 660]` | Only lower left front fragment remains visible before hand; old right/bottom bounds include hand. |
| new_000034 | 43 | `[539, 448, 627, 487]` | Gripper covers right side; use visible slanted front fragment and retain left endpoint. |
| new_000034 | 44 | `[544, 469, 620, 513]` | Gripper covers right side; use visible slanted front fragment and retain left endpoint. |
| new_000034 | 45 | `[548, 493, 614, 535]` | Gripper covers right side; use visible slanted front fragment and retain left endpoint. |
| new_000034 | 54 | `[570, 625, 631, 665]` | Lowest central stack: visible top face boundary and gripper occlusion give much narrower observed front. |
| new_000034 | 55 | `[575, 658, 611, 683]` | Lowest central stack: restrict right edge to the gripper boundary. |
| new_000034 | 56 | `[578, 678, 597, 701]` | Lowest central stack: restrict right edge to the gripper boundary. |
| new_000034 | 57 | `[581, 696, 589, 720]` | Lowest central stack: only a narrow bottom-clipped strip remains visible; preserve left endpoint. |
| new_000049 | 9 | `[0, 439, 140, 495]` | Image-left clipped front has an observed rounded right extent near x140, not x162. |
| new_000049 | 14 | `[349, 645, 472, 669]` | Observed front continues rightward beyond old x424 bound, until hand; expand to visible front. |
| new_000049 | 24 | `[356, 663, 466, 685]` | Observed front continues rightward beyond old x422 bound, until hand; expand to visible front. |
| new_000049 | 25 | `[365, 682, 449, 701]` | Observed front continues rightward beyond old x419 bound, until hand; expand to visible front. |
| new_000049 | 26 | `[365, 699, 436, 716]` | Observed front continues rightward beyond old x412 bound, until hand; expand to visible front. |

## Unresolved whole-image regions

- **new_000018 [602, 450, 617, 550]:** Existing row22 is supported by upper exposed strip near x602–615, y451–485. A lower pale strip near x603–616, y519–548 appears distinct; intermediate shadowed segment around y487–516 is unresolved. Do not add inferred rows from spacing.
- **new_000034 [380, 705, 575, 720]:** Lower left/middle cassette roofs meet image border. A narrow front/lip transition may enter the image, but no separately supported front addition finalized.
- **new_000049 [360, 714, 445, 720]:** Below lowest retained center front, border-adjacent pixels may be same front/lip or another front. No addition finalized.
- **old_000057 [555, 0, 975, 25]:** Bright top-border strip may be the bottom of a preceding cassette or rim/transition of first retained face. No separate addition finalized.

## All-row coverage

| Image | Rows inspected | Box proposals | Held identity/extent uncertainties |
|---|---:|---|---|
| new_000018 | 34 | 23, 24, 25, 26, 28, 29, 30, 31, 32, 33, 34 | 27 |
| new_000034 | 57 | 43, 44, 45, 54, 55, 56, 57 | 15, 48, 49, 50 |
| new_000049 | 26 | 9, 14, 24, 25, 26 | 6, 18, 21 |
| old_000007 | 10 | None | None specifically held |
| old_000057 | 8 | None | None specifically held |
| new_000132 | 0 | None | None specifically held |

Each row’s original 11 tokens, exact old pixel coordinates, identity assessment, disposition, point-preservation instruction, and proposed coordinates or uncertainty are in `review.json`. All-row overlays and original-only raw crops are in this directory.

## Point and identity cautions

- New_000018 row15 and top-clipped/bottom-clipped rows have physical-corner ambiguity; no point movement is proposed.
- New_000034 row15’s identity and its top-border v2 association remain unresolved; row57 is a very narrow exposed strip requiring separate endpoint scrutiny.
- New_000049 rows14/24/25/26 require box expansion; their left endpoint tokens stay exact, with rounded-junction localization uncertainty disclosed.
- Old positive controls show ten and eight individually supported retained fronts respectively. Rounded bright edge transitions and legacy box padding were not exhaustively redrawn.

This pass reports original-image evidence and candidate geometry only. It does not establish model improvement or validate unseen acquisition sessions.
