These are whole-image assistant-reviewed annotation candidates, not a training split or human sign-off.
Only frames with no unresolved fields are exported here. Do not train on proposal-only files from held frames.
The original training dataset is unchanged. Keep complete image annotations together and decide capture-group splits before a controlled training comparison.
