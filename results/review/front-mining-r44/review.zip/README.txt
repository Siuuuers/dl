Open review.html. All row cards for one photograph are on the same page; Next/Previous changes photographs.
All 507 current fronts were inspected; all 508 stable identities remain visible, including the prior deletion.
Choose R42 or R43 history beside the latest R44 annotations. Unchanged rows remain present.
A manually traced outline is provided for frame_0160 source002 as an explanatory review aid, not a segmentation training mask.
history/pr131-r43.zip preserves the exact returned R43 package, including original photographs and complete R42 evidence.
The five saved prediction figures remain R42 historical comparisons. No updated scores, inference, model training or promotion are claimed.
A new uncertainty can revoke a former complete-image export gate; consult manifest.json.
Offline verification: python review.py --check-capsule PATH_TO_THIS_ZIP
