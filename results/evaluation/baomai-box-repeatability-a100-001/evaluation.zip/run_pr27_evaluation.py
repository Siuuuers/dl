#!/usr/bin/env python3
"""Run the fixed prospective comparison from the verified PR27 return."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time


BASE = Path('/workspace/scratch/470b9cd0057a')
ROOT = BASE / 'dl'
PYTHON = BASE / 'eval-venv/bin/python'
RETURN = BASE / 'pr27-return/extracted'
OUTPUT = BASE / 'pr27-evaluation'
SOURCE = '8ce9fe233dc3b4b9f3ccfc4491a952dca541a64b'


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def clean_source():
    head = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip()
    status = subprocess.check_output(['git', '-C', str(ROOT), 'status', '--porcelain'], text=True)
    if head != SOURCE or status:
        raise RuntimeError(f'Expected clean published source {SOURCE}, got {head}: {status}')


def main():
    clean_source()
    OUTPUT.mkdir(exist_ok=False)
    evidence = OUTPUT / 'evidence'
    logs = OUTPUT / 'logs'
    logs.mkdir()
    commands = []
    for seed in (43, 44):
        for arm in ('reference', 'candidate'):
            destination = evidence / f'seed-{seed}' / 'checkpoints' / arm
            shutil.copytree(RETURN / f'seed-{seed}' / arm, destination,
                            ignore=shutil.ignore_patterns('*.pt'))

    def run(name, script, arguments):
        clean_source()
        command = [str(PYTHON), str(ROOT / 'scripts' / script), '--root', str(ROOT), *arguments]
        record = {'name': name, 'command': command, 'cwd': str(ROOT),
                  'started_at_utc': datetime.now(timezone.utc).isoformat()}
        print(f'START {name}', flush=True)
        started = time.monotonic()
        log = logs / f'{name}.log'
        with log.open('x') as stream:
            result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
        record.update(exit_code=result.returncode, wall_seconds=time.monotonic() - started,
                      log=str(log.relative_to(OUTPUT)),
                      log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
        commands.append(record)
        write_json(OUTPUT / 'commands.json', commands)
        print(f'END {name}: exit={result.returncode}, seconds={record["wall_seconds"]:.2f}', flush=True)
        if result.returncode:
            print(log.read_text()[-8000:], flush=True)
            raise RuntimeError(f'{name} failed; preserve its outputs')

    jobs = [(43, 'm0', None), (43, 'm1', 'reference'), (43, 'm2', 'candidate'),
            (44, 'm1', 'reference'), (44, 'm2', 'candidate')]
    for seed, model, arm in jobs:
        seed_root = evidence / f'seed-{seed}'
        output = seed_root / model
        manifest = RETURN / f'seed-{seed}' / arm / 'checkpoint-manifest.json' if arm else None
        checkpoint_args = ['--checkpoint-manifest', str(manifest)] if manifest else []
        run(f'seed-{seed}-{model}-inference', 'evaluate_pose.py',
            ['--device', 'cpu', '--threads', '4', '--conf', '0.15', '0.25', '0.40',
             '--endpoint-conf', '0.50', '--matching-iou', '0.50', '--overlays', '0',
             '--output', str(output), *checkpoint_args])
        run(f'seed-{seed}-{model}-quality', 'diagnose_pose_quality.py',
            ['--predictions', str(output / 'predictions.jsonl'), '--output', str(seed_root / f'{model}-quality'),
             *checkpoint_args])
        metrics = json.loads((output / 'summary.json').read_text())['metrics']
        print(json.dumps({'seed': seed, 'model': model, 'metrics': metrics}, allow_nan=False), flush=True)
        if model == 'm0':
            for name in ('m0', 'm0-quality'):
                shutil.copytree(seed_root / name, evidence / 'seed-44' / name)
    run('repeatability-summary', 'summarize_box_repeatability.py',
        ['--evidence', str(evidence), '--output', str(OUTPUT / 'repeatability-summary.json')])
    clean_source()
    write_json(OUTPUT / 'execution-status.json', {
        'status': 'complete', 'exit_code': 0, 'source': SOURCE, 'fresh_model_inferences': 5,
        'unique_image_model_threshold_records': 300,
        'm0_inferred_once_and_copied': True,
        'completed_at_utc': datetime.now(timezone.utc).isoformat()})


if __name__ == '__main__':
    main()
