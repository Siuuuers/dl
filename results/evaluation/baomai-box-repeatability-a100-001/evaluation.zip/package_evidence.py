from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess
import sys
import time
import zipfile


BASE = Path('/workspace/scratch/470b9cd0057a')
OUT = BASE / 'pr27-package'
ROOT = BASE / 'dl'
REPLAY = BASE / 'dl-replay'
SOURCE = '8ce9fe233dc3b4b9f3ccfc4491a952dca541a64b'
TREE = 'ab3a5d540cc1445236f121651a18c0fee0813ae1'
RETURN = '265fe52dc6e2d8721986fcfdf8944eb4ed33497f'
TRAINING = 'f087c35f74bf304eb61998edcaa2172fe1cba49c'
PAYLOAD = OUT / 'payload'
EXTRACTED = OUT / 'fresh-extraction'
ARCHIVE = OUT / 'evaluation.zip'
commands = []


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def run(command, cwd=None, env=None):
    started = datetime.now(timezone.utc).isoformat()
    before = time.monotonic()
    result = subprocess.run(command, cwd=cwd, env=env, text=True, capture_output=True)
    record = {'command': [str(x) for x in command], 'cwd': str(cwd) if cwd else None,
              'started_at_utc': started, 'exit_code': result.returncode,
              'wall_seconds': time.monotonic() - before,
              'stdout': result.stdout, 'stderr': result.stderr}
    commands.append(record)
    write(OUT / 'packaging-commands.json', commands)
    if result.returncode:
        raise RuntimeError(record)
    return result.stdout.strip()


def copy(source, relative):
    source = Path(source)
    assert source.is_file() and not source.is_symlink(), source
    relative = PurePosixPath(relative)
    assert not relative.is_absolute() and '..' not in relative.parts
    assert relative.suffix.lower() not in {'.pt', '.pth', '.zip', '.pyc'}
    destination = PAYLOAD / str(relative)
    destination.parent.mkdir(parents=True, exist_ok=True)
    assert not destination.exists(), destination
    before = sha(source)
    shutil.copyfile(source, destination)
    assert sha(source) == sha(destination) == before, source


def semantic(value, top=False):
    if isinstance(value, dict):
        return {key: semantic(item) for key, item in value.items()
                if key != 'created_at_utc' and not (top and key == 'command')}
    if isinstance(value, list):
        return [semantic(item) for item in value]
    return value


def main():
    assert not any(p.exists() for p in (PAYLOAD, EXTRACTED, ARCHIVE, REPLAY))
    PAYLOAD.mkdir()
    evaluation = BASE / 'pr27-evaluation'
    original_summary = read(evaluation / 'repeatability-summary.json')
    original_status = read(evaluation / 'execution-status.json')
    independent = read(BASE / 'pr27-independent/independent-review.json')
    audit = read(BASE / 'pr27-audit/audit.json')
    assert original_status['status'] == 'complete' and original_status['exit_code'] == 0
    assert original_status['fresh_model_inferences'] == independent['unique_models'] == 5
    assert original_status['unique_image_model_threshold_records'] == independent['unique_image_threshold_records'] == 300
    assert independent['unique_score_aggregates'] == independent['unique_quality_aggregates'] == 15
    assert independent['status'] == 'verified' and audit['status'] == 'PASS'
    assert original_summary['source']['revision'] == SOURCE
    assert original_summary['source']['working_tree_status'] == ''
    assert all(row['exit_code'] == 0 for row in read(evaluation / 'commands.json'))
    for path in sorted((evaluation / 'evidence').rglob('*')):
        if path.is_file():
            copy(path, str(path.relative_to(evaluation)))
    for name in ['repeatability-summary.json', 'commands.json', 'execution-status.json', 'm0-continuity.json']:
        copy(evaluation / name, name)
    for path in sorted((evaluation / 'logs').glob('*.log')):
        copy(path, 'logs/' + path.name)
    for path in sorted((BASE / 'pr27-audit').iterdir()):
        if path.is_file():
            copy(path, 'audit/' + path.name)
    for name in ['independent_score.py', 'independent-review.json', 'review_failure_locations.py', 'failure-review-locations.json', 'execution-record.json']:
        copy(BASE / 'pr27-independent' / name, 'independent/' + name)
    for name in ['runtime.json', 'requirements.txt', 'probe.py']:
        copy(BASE / 'evaluation-runtime' / name, 'runtime/' + name)
    copy(BASE / 'run_pr27_evaluation.py', 'run_pr27_evaluation.py')
    copy(BASE / 'pr27-return/archive-transport-audit.json', 'return/archive-transport-audit.json')
    copy(BASE / 'pr27-return/extracted/gpu-results-manifest.json', 'return/gpu-results-manifest.json')
    for path in sorted((BASE / 'pr27-return/extracted/resource-trial').iterdir()):
        if path.is_file():
            copy(path, 'return/resource-trial/' + path.name)
    copy(__file__, 'package_evidence.py')
    readme = '''# Box-repeatability evaluation evidence — 2026-11-10

This capsule preserves the completed PR #27 evaluation of the fixed seeds 43 and 44.
The decision remains retain-M0. Historical seed 42 is separate context.

## Identity and scope

- Returned GPU archive: PR #27, commit `265fe52dc6e2d8721986fcfdf8944eb4ed33497f`.
- GPU archive SHA-256: `4e4d36aaee4bfe316a5517afa68a276e76eef07ed8680347bd9b52ffbe455beb` (79,587,975 bytes).
- Training source: `f087c35f74bf304eb61998edcaa2172fe1cba49c`.
- Inference and replay source: `8ce9fe233dc3b4b9f3ccfc4491a952dca541a64b`.
- Five fresh model evaluations: M0 once, and original/corrected arms for each new seed.
- 300 unique image/model/threshold records and 15 score aggregates; the separate
  quality calculation checks the same 300 records and 15 aggregates.
- M0 evidence is copied identically into the two seed folders to satisfy the
  paired replay layout. Those copies do not represent two independent runs.
- `inventory.json` hashes every other payload file; it deliberately does not hash itself.

Model weights, the raw GPU ZIP, original PNGs and original reference labels are
not duplicated here. The original images/labels are obtained from the pinned
repository. The four returned model weights remain in the original PR #27 ZIP.
Checkpoint manifests, receipts, inventories, epoch CSVs and logs are preserved.
The saved-prediction replay below does not load weights or perform inference.

## Replay

Use Python 3.12.14 for the closest numeric reproduction. No ML packages are
needed for this saved-prediction summary. Extract this ZIP into a fresh directory,
and prepare a clean repository checkout at the exact published commit:

```bash
GIT_LFS_SKIP_SMUDGE=1 git clone https://github.com/Siuuuers/dl.git dl-replay
GIT_LFS_SKIP_SMUDGE=1 git -C dl-replay checkout --detach 8ce9fe233dc3b4b9f3ccfc4491a952dca541a64b
git -C dl-replay lfs pull --include='data/images/val/*.png' --exclude=''
python dl-replay/scripts/summarize_box_repeatability.py \\
  --root dl-replay \\
  --evidence /absolute/path/to/extracted/evidence \\
  --output /absolute/path/to/new-repeatability-summary.json
```

The output path must not exist. The script verifies the original validation
PNG/label hashes, fixed recipes and correction proposal, completed checkpoint
evidence, shared runtime/settings, identical M0 payloads, and saved scores.
Compare the entire resulting JSON with `repeatability-summary.json`, omitting
only `created_at_utc` fields and the top-level `command` path/argument record.
In this summary schema the omitted timestamp fields are at the top level and
inside each of the two `per_seed` entries. All other values must match exactly;
no numeric tolerance, source-identity exclusion, path rewrite or timing-field
exclusion is used for this semantic comparison.

The external `verification.json` beside the distributed ZIP records the archive
hash, readback inventory check, clean-source status, one fresh extraction and
the successful complete saved-prediction replay.

## Evidence layout

- `evidence/`: both seed folders, raw predictions, scores, quality diagnostics,
  and small completed-checkpoint evidence bundles.
- `repeatability-summary.json`: official complete unrounded study summary.
- `commands.json`, `execution-status.json`, `logs/`: executed inference,
  diagnostic and summary commands, exit codes and logs.
- `m0-continuity.json`: comparison with the historical M0 payloads.
- `audit/`: original-return byte, receipt, source, staging and completion audit.
- `independent/`: independent scoring implementation, all-record recomputation,
  failure-location diagnostics and execution records.
- `runtime/`: CPU package identity, frozen environment and preparation probe.
- `return/`: original GPU manifest, transport audit and resource-trial records.
- `run_pr27_evaluation.py`, `package_evidence.py`: exact orchestration sources.

The orchestration files retain original scratch paths as execution provenance;
the portable replay command above is the supported way to recompute this capsule.
Two prospective seeds on a repeatedly used development split do not establish
unseen-scene accuracy, physical acceptance tolerances, significance or deployment
readiness. Recorded remote inventories are reconciled evidence, not hardware
attestation. The return audit verified weights when the original GPU ZIP was
available; this compact capsule alone cannot repeat that weight-byte check.
'''
    (PAYLOAD / 'README.md').write_text(readme)
    inventory = {}
    for path in sorted(PAYLOAD.rglob('*')):
        if path.is_file():
            inventory[path.relative_to(PAYLOAD).as_posix()] = {'size_bytes': path.stat().st_size, 'sha256': sha(path)}
    write(PAYLOAD / 'inventory.json', {'schema_version': 1, 'payload_files': inventory,
          'inventory_self_excluded': True, 'model_weights_included': False})
    with zipfile.ZipFile(ARCHIVE, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(PAYLOAD.rglob('*')):
            if path.is_file():
                info = zipfile.ZipInfo(path.relative_to(PAYLOAD).as_posix(), (2026, 11, 10, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.create_system = 3
                info.external_attr = (stat.S_IFREG | 0o644) << 16
                archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(ARCHIVE) as archive:
        infos = archive.infolist()
        names = [info.filename for info in infos]
        assert len(names) == len(set(names)) == len(inventory) + 1
        assert set(names) == set(inventory) | {'inventory.json'}
        assert archive.testzip() is None
        for info in infos:
            path = PurePosixPath(info.filename)
            assert not path.is_absolute() and '..' not in path.parts and '\\' not in info.filename
            assert stat.S_ISREG(info.external_attr >> 16) and not info.is_dir()
            assert path.suffix.lower() not in {'.pt', '.pth', '.zip', '.pyc'}
            data = archive.read(info)
            if info.filename != 'inventory.json':
                assert len(data) == inventory[info.filename]['size_bytes']
                assert hashlib.sha256(data).hexdigest() == inventory[info.filename]['sha256']
        assert json.loads(archive.read('inventory.json')) == read(PAYLOAD / 'inventory.json')
        EXTRACTED.mkdir()
        for info in infos:
            destination = EXTRACTED / info.filename
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open('xb') as stream:
                stream.write(archive.read(info))
    for relative, expected in inventory.items():
        assert sha(EXTRACTED / relative) == expected['sha256']
    env = {**os.environ, 'GIT_LFS_SKIP_SMUDGE': '1'}
    run(['git', '-C', str(ROOT), 'worktree', 'add', '--detach', str(REPLAY), SOURCE], env=env)
    assert run(['git', '-C', str(REPLAY), 'rev-parse', 'HEAD']) == SOURCE
    assert run(['git', '-C', str(REPLAY), 'rev-parse', 'HEAD^{tree}']) == TREE
    lfs = run(['git', '-C', str(REPLAY), 'config', '--get-regexp', r'^filter\.lfs\.'])
    assert 'filter.lfs.clean git-lfs clean -- %f' in lfs
    manifest = read(REPLAY / 'data/manifest.json')
    hydrated = []
    for row in manifest['records']:
        relative = 'data/' + row['image']
        source, destination = ROOT / relative, REPLAY / relative
        assert sha(source) == row['image_sha256']
        destination.unlink()
        os.link(source, destination)
        assert sha(destination) == row['image_sha256']
        hydrated.append({'path': relative, 'sha256': row['image_sha256']})
    assert len(hydrated) == 157
    before_status = run(['git', '-C', str(REPLAY), 'status', '--porcelain'])
    assert before_status == '', before_status
    output = OUT / 'replayed-summary.json'
    run([sys.executable, str(REPLAY / 'scripts/summarize_box_repeatability.py'), '--root', str(REPLAY),
         '--evidence', str(EXTRACTED / 'evidence'), '--output', str(output)], cwd=REPLAY)
    replayed = read(output)
    assert semantic(replayed, True) == semantic(original_summary, True)
    after_status = run(['git', '-C', str(REPLAY), 'status', '--porcelain'])
    assert after_status == '', after_status
    archive_hash = sha(ARCHIVE)
    sidecar = OUT / 'evaluation.zip.sha256'
    sidecar.write_text(archive_hash + '  evaluation.zip\n')
    replay_command = next(row for row in commands if str(REPLAY / 'scripts/summarize_box_repeatability.py') in row['command'])
    verification = {
        'schema_version': 1, 'kind': 'baomai-box-repeatability-evaluation-capsule-verification',
        'status': 'PASS', 'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'archive': {'path': 'evaluation.zip', 'sha256': archive_hash, 'size_bytes': ARCHIVE.stat().st_size,
                    'members': len(inventory) + 1, 'verified_payload_files': len(inventory),
                    'safe_unique_regular_paths': True, 'crc_valid': True,
                    'all_payload_hashes_and_sizes_match_inventory': True,
                    'no_model_weight_files_or_nested_archives': True,
                    'inventory_sha256': sha(PAYLOAD / 'inventory.json')},
        'checksum_sidecar': {'path': sidecar.name, 'sha256': sha(sidecar)},
        'source': original_summary['source'],
        'return_commit': RETURN, 'training_source_commit': TRAINING,
        'original_gpu_archive': audit['archive'],
        'reference': original_summary['shared_provenance']['reference'],
        'candidate_manifest_sha256': audit['candidate_manifest_sha256'],
        'inference_runtime': original_summary['shared_provenance']['inference']['runtime'],
        'evaluation_scope': {'fresh_model_inferences': 5, 'unique_image_model_threshold_records': 300,
            'unique_score_aggregates': 15, 'unique_quality_records': 300, 'unique_quality_aggregates': 15,
            'm0_inferred_once_then_copied': True, 'prospective_seeds': [43, 44],
            'historical_seed_42_included_in_aggregation': False,
            'original_execution_commands': len(read(evaluation / 'commands.json')),
            'all_original_execution_exit_codes': [row['exit_code'] for row in read(evaluation / 'commands.json')]},
        'fresh_extraction_and_replay': {'source_commit': SOURCE, 'source_tree': TREE,
            'working_tree_before': before_status, 'working_tree_after': after_status,
            'original_pngs_hydrated_and_hash_verified': len(hydrated),
            'hydration': 'Hardlinks from original hash-verified inputs; unchanged Git LFS content.',
            'python': sys.version.split()[0], 'executions': 1, 'command': replay_command,
            'original_summary_sha256': sha(evaluation / 'repeatability-summary.json'),
            'replayed_summary_sha256': sha(output), 'complete_semantics_equal': True,
            'excluded_json_paths': ['/created_at_utc', '/per_seed/0/created_at_utc', '/per_seed/1/created_at_utc', '/command'],
            'numeric_tolerance': None, 'inference_or_weight_loading_performed': False},
        'packaging_command': [sys.executable, str(Path(__file__).resolve())],
        'packaging_script_sha256': sha(__file__),
        'commands': commands,
        'input_evidence': {name: inventory[name] for name in ['repeatability-summary.json',
            'commands.json', 'execution-status.json', 'm0-continuity.json', 'audit/audit.json',
            'audit/execution.json', 'independent/independent-review.json',
            'independent/execution-record.json', 'independent/failure-review-locations.json']},
        'limits': ['The capsule contains saved predictions and checkpoint evidence, not model weights or original image bytes.',
                   'The original GPU archive and initial checkpoint bytes were checked by the preserved return audit; the compact replay does not repeat weight-byte validation.',
                   'Five model inferences generate 300 unique records and 15 aggregates; copied M0 evidence is not counted twice.',
                   'The replay confirms complete saved-result semantics, excluding only the explicitly listed timestamp and invocation fields.',
                   'Two prospective seeds on the reused development split do not establish statistical significance, unseen-scene accuracy or a physical acceptance tolerance.']
    }
    write(OUT / 'verification.json', verification)
    print(json.dumps({'status': 'PASS', 'archive_sha256': archive_hash,
                      'archive_size_bytes': ARCHIVE.stat().st_size, 'members': len(inventory) + 1,
                      'replay_exit_code': replay_command['exit_code'], 'semantic_equality': True,
                      'verification_sha256': sha(OUT / 'verification.json')}))


if __name__ == '__main__':
    main()
