#!/usr/bin/env python3
"""Verify the immutable PR27 return without deserializing model weights."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import zipfile

TRAINING_COMMIT = "f087c35f74bf304eb61998edcaa2172fe1cba49c"
RETURN_COMMIT = "265fe52dc6e2d8721986fcfdf8944eb4ed33497f"
ARCHIVE_SHA = "4e4d36aaee4bfe316a5517afa68a276e76eef07ed8680347bd9b52ffbe455beb"
ARCHIVE_SIZE = 79587975


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with Path(path).open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def git(root, *args):
    return subprocess.check_output(["git", "-C", str(root), *args])


def audit(root, archive, extracted):
    sys.path.insert(0, str(root / "scripts"))
    from evaluate_pose import preflight_dataset
    from package_gpu_results import collect_arm, check_pair, portable_relative
    from package_box_repeatability import (ARMS, CANDIDATE_MANIFEST, CANDIDATE_SHA256,
                                          SEEDS, STUDY_ID, check_study_arm,
                                          collect_trial, study_settings)
    from pose_checkpoint import BOX_REPEATABILITY_RECIPES, recipe_identity
    from stage_pose_training import source_state, source_name, yaml_bytes, code_hashes
    from train_pose_comparison import SOURCE_FILES

    require(archive.stat().st_size == ARCHIVE_SIZE and digest(archive) == ARCHIVE_SHA,
            "returned archive size/hash differs")
    index_path = extracted / "gpu-results-manifest.json"
    index = read(index_path)
    require(index["schema_version"] == 1 and index["kind"] == "baomai-box-repeatability-results"
            and index["study_id"] == STUDY_ID and index["seeds"] == list(SEEDS), "study index differs")
    require(datetime.fromisoformat(index["created_at_utc"]).utcoffset() is not None,
            "archive index timestamp lacks timezone")
    payloads = index["files"]
    require(len(payloads) == 27 and len({row["path"] for row in payloads}) == 27,
            "expected exactly 27 distinct payloads")
    with zipfile.ZipFile(archive) as zipped:
        names = zipped.namelist()
        require(len(names) == 28 and set(names) == {"gpu-results-manifest.json", *(p["path"] for p in payloads)},
                "archive inventory differs")
        require(zipped.testzip() is None, "ZIP CRC failure")
        for item in zipped.infolist():
            portable_relative(item.filename)
            require(not item.is_dir() and not stat.S_ISLNK(item.external_attr >> 16),
                    "archive contains directory/symlink")
        require(zipped.read("gpu-results-manifest.json") == index_path.read_bytes(), "extracted index differs")
        for row in payloads:
            name = portable_relative(row["path"])
            local = extracted / name
            require(local.resolve().is_relative_to(extracted.resolve()) and not local.is_symlink(),
                    "extracted path unsafe")
            require(local.stat().st_size == row["size_bytes"] and digest(local) == row["sha256"],
                    f"extracted payload differs: {name}")
            with zipped.open(name) as stream:
                actual = hashlib.file_digest(stream, "sha256").hexdigest()
            require(actual == row["sha256"] and zipped.getinfo(name).file_size == row["size_bytes"],
                    f"ZIP payload differs: {name}")

    preflight = preflight_dataset(root, require_weights=True)
    candidate_path = root / CANDIDATE_MANIFEST
    require(digest(candidate_path) == CANDIDATE_SHA256, "candidate manifest changed")
    state = source_state(root, candidate_path)
    require(len(state["records"]) == 157, "source image inventory differs")
    reference = read(root / "data/manifest.json")
    proposal = read(candidate_path)
    changes = {change["image_id"]: change for change in proposal["changes"]}
    independent_files = []
    edge_inventory = {}
    for record in reference["records"]:
        image_path, label_path = root / "data" / record["image"], root / "data" / record["label"]
        require(digest(image_path) == record["image_sha256"] and digest(label_path) == record["label_sha256"],
                f"independent frozen image/label hash differs: {record['id']}")
        rows = [line.split() for line in label_path.read_text().splitlines() if line.strip()]
        require(len(rows) == record["instances"], f"source object count differs: {record['id']}")
        independent_files.append({"image_id": record["id"], "image_sha256": record["image_sha256"],
                                  "label_sha256": record["label_sha256"]})
        if record["id"] not in changes:
            continue
        change = changes[record["id"]]
        overlay = candidate_path.parent / change["candidate_label"]
        require(digest(overlay) == change["candidate_label_sha256"], "overlay hash differs")
        amended = [line.split() for line in overlay.read_text().splitlines() if line.strip()]
        require(len(rows) == len(amended), "candidate row count differs")
        specified = {row["original_row"]: row for row in change["rows"]}
        changed = []
        edges = 0
        width, height = record["original_size"]
        for number, (before, after) in enumerate(zip(rows, amended), 1):
            require(before[0] == after[0] and before[5:] == after[5:], "class or endpoint tokens changed")
            if before == after:
                require(number not in specified, "declared change did not change row")
                continue
            require(number in specified, "unlisted row changed")
            change_row = specified[number]
            require(before == change_row["source_row_text"].split()
                    and after == change_row["candidate_row_text"].split(), "row change text differs")
            def box(row):
                x, y, w, h = map(float, row[1:5])
                return [(x-w/2)*width, (y-h/2)*height, (x+w/2)*width, (y+h/2)*height]
            observed = [name for name, a, b in zip(("left", "top", "right", "bottom"), box(before), box(after))
                        if abs(b-a) > 0.0001]
            require(observed == change_row["box_edges_changed"], "changed edge identity differs")
            edges += len(observed)
            changed.append(number)
        require(set(changed) == set(specified), "changed row inventory differs")
        edge_inventory[record["id"]] = {"changed_edges": edges, "original_rows": changed}
    require({key: value["changed_edges"] for key, value in edge_inventory.items()}
            == {"new_000030": 8, "new_000012": 6, "new_000128": 2}, "8/6/2 overlay differs")

    pairs, run_summaries, verified_stagings = {}, {}, []
    source_hashes = {}
    for relative in SOURCE_FILES:
        recorded = index["training_source"]["files_sha256"][relative]
        pinned = hashlib.sha256(git(root, "show", f"{TRAINING_COMMIT}:{relative}")).hexdigest()
        require(recorded == pinned == digest(root / relative), f"training source differs: {relative}")
        source_hashes[relative] = pinned
    require(set(index["training_source"]["files_sha256"]) == set(SOURCE_FILES), "source inventory differs")
    require(index["training_source"]["revision"] == TRAINING_COMMIT
            and index["training_source"]["working_tree_status"] == "", "immutable clean training revision differs")

    def reconcile_staging(staging, label):
        require(staging["source"] == state["source"] == index["source"], f"staging source differs: {label}")
        require(staging["code_sha256"] == code_hashes(), f"staging implementation hashes differ: {label}")
        for relative, sha in staging["code_sha256"].items():
            require(sha == hashlib.sha256(git(root, "show", f"{TRAINING_COMMIT}:{relative}")).hexdigest(),
                    "staging code differs from pinned Git")
        for arm in ARMS:
            variant = staging["variants"][arm]
            expected = [{"path": relative, "source_path": source_name(item["source"], root),
                         "source_sha256": item["sha256"], "output_sha256": item["sha256"]}
                        for relative, item in sorted(state["plans"][arm].items())]
            require(variant["files"] == expected and len(expected) == 314,
                    f"recorded 157-image/label variant inventory differs: {label}/{arm}")
            require(variant["counts"] == state["counts"][arm], "recorded variant counts differ")
            require(variant["data_yaml"] == f"{arm}/data.yaml", "YAML relative path differs")
            reconstructed = yaml_bytes(Path(staging["output_root"]) / arm)
            require(hashlib.sha256(reconstructed).hexdigest() == variant["data_yaml_sha256"],
                    f"reconstructed remote YAML bytes differ: {label}/{arm}")
        verified_stagings.append(label)

    collected_files = []
    for seed in SEEDS:
        pair = {arm: collect_arm(preflight, extracted / f"seed-{seed}" / arm, arm) for arm in ARMS}
        pairs[seed] = pair
        check_pair(pair["reference"], pair["candidate"])
        expected_pair = {"seed": seed, **recipe_identity(BOX_REPEATABILITY_RECIPES[seed]), "arms": {}}
        for arm, bundle in pair.items():
            check_study_arm(bundle, seed)
            receipt, staging = bundle["receipt"], bundle["staging"]
            run = extracted / f"seed-{seed}" / arm
            require(receipt["source"] == index["training_source"] and receipt["runtime"] == index["runtime"],
                    "run source/runtime differs from study index")
            require(study_settings(receipt) == index["shared_training_settings"], "shared settings differ")
            reconcile_staging(staging, f"seed-{seed}/{arm}")
            require(receipt["completed_epochs"] == list(range(1,31))
                    and receipt["batches_completed"] == 1050 and receipt["images_processed"] == 4110
                    and receipt["optimizer_steps"] == 78, "recorded completion counts differ")
            require(receipt["execution"]["exit_code"] == 0 and receipt["execution"]["stop_reason"] is None
                    and receipt["finalization_completed"] and receipt["training_returned"],
                    "run completion/finalization failed")
            with (run / "fit/results.csv").open(newline="") as stream:
                csv_rows = list(csv.DictReader(stream))
            require(len(csv_rows) == 30 and [int(row["epoch"]) for row in csv_rows] == list(range(1,31)),
                    "CSV epochs incomplete")
            require(all(math.isfinite(float(value)) for row in csv_rows for value in row.values()),
                    "nonfinite CSV value")
            require(all(float(b["time"]) > float(a["time"]) for a,b in zip(csv_rows,csv_rows[1:])),
                    "CSV elapsed times do not increase")
            log = re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", (run / "train.log").read_text())
            log_epochs = sorted(set(int(x) for x in re.findall(r"(?m)^\s*(\d+)/30\s+", log)))
            require(log_epochs == list(range(1,31)) and "30 epochs completed in " in log
                    and re.search(r"Optimizer stripped from .*?/fit/weights/last\.pt,", log),
                    "log does not corroborate full epochs/final last.pt")
            require("Traceback (most recent call last)" not in log, "training traceback in log")
            changed_samples = [{"epoch": sample["epoch"], "batch": sample["batch"],
                                "changed_image_ids": sorted(set(sample["image_ids"]) & set(changes))}
                               for sample in receipt["batch_samples"]
                               if set(sample["image_ids"]) & set(changes)]
            expected_pair["arms"][arm] = {"checkpoint_manifest": f"seed-{seed}/{arm}/checkpoint-manifest.json",
                                          "checkpoint_identity": bundle["identity"]}
            collected_files.extend({"path": f"seed-{seed}/{row['path']}", "sha256": row["sha256"],
                                    "size_bytes": row["size_bytes"]} for row in bundle["files"])
            run_summaries[f"seed-{seed}/{arm}"] = {
                "checkpoint_identity": bundle["identity"], "completed_epochs": 30,
                "batches_completed": receipt["batches_completed"], "image_presentations": receipt["images_processed"],
                "recorded_optimizer_updates": receipt["optimizer_steps"], "execution": receipt["execution"],
                "loader_verification": receipt["loader_verification"], "csv_epochs": len(csv_rows),
                "log_epochs": log_epochs, "last_checkpoint_finalization_in_log": True,
                "recorded_parameter_change": receipt["optimizer_parameter_change_observed"],
                "first_recorded_batches": len(receipt["batch_samples"]), "changed_image_samples": changed_samples}
        require(expected_pair == index["pairs"][f"seed-{seed}"], "archive pair index differs from actual validated bundle")
    require(set(index["pairs"]) == {"seed-43", "seed-44"}, "unexpected seed pair")
    first, second = pairs[43]["reference"], pairs[44]["reference"]
    for key in ("source", "runtime"):
        require(first["receipt"][key] == second["receipt"][key], "cross-seed source/runtime differs")
    require(study_settings(first["receipt"]) == study_settings(second["receipt"]), "cross-seed non-seed settings differ")
    trial_index, trial_files = collect_trial(preflight, extracted / "resource-trial", pairs[43]["candidate"])
    require(trial_index == index["resource_trial"], "resource trial index differs")
    reconcile_staging(read(extracted / "resource-trial/staging-manifest.json"), "resource-trial")
    collected_files.extend({key: row[key] for key in ("path", "sha256", "size_bytes")} for row in trial_files)
    require(sorted(collected_files, key=lambda x: x["path"]) == payloads, "validated bundle inventory differs from ZIP index")
    return {
        "schema_version": 1, "status": "PASS", "kind": "baomai-box-repeatability-return-audit",
        "created_at_utc": datetime.now(timezone.utc).isoformat(), "return_commit": RETURN_COMMIT,
        "training_source_commit": TRAINING_COMMIT,
        "audit_source_commit": git(root, "rev-parse", "HEAD").decode().strip(),
        "archive": {"sha256": ARCHIVE_SHA, "size_bytes": ARCHIVE_SIZE, "members": 28,
                    "safe_unique_paths": True, "crc_valid": True, "verified_payloads": 27},
        "initial_checkpoint_bytes_verified": True, "all_four_checkpoint_bytes_verified": True,
        "fixed_recipe_candidate_and_seed_checks": True, "shared_source_runtime_nonseed_settings": True,
        "source_hashes_verified_against_pinned_git_and_current": source_hashes,
        "candidate_manifest_sha256": CANDIDATE_SHA256,
        "original_images_and_labels_verified": 157, "independent_source_inventory": independent_files,
        "edge_inventory": edge_inventory, "counts": state["counts"],
        "five_staging_inventories_and_remote_yaml_reconciled": verified_stagings,
        "runs": run_summaries, "resource_trial": trial_index, "training_runtime": index["runtime"],
        "input_files": [{"path": "gpu-results-manifest.json", "sha256": digest(index_path)}, *payloads],
        "limits": [
            "No model deserialization, inference or accuracy claim in this audit.",
            "Remote staged images/labels and environment are omitted from the return; recorded inventories and reconstructed YAML are reconciled with immutable local originals, not hardware attestation.",
            "The first four recorded batch samples for each full run contain no corrected training image; this return does not directly sample a changed-label batch.",
            "Logs include trainer validation of best.pt; the evaluated study artifact remains the validated final-epoch last.pt.",
            "GPU settings disable AMP but permit cuDNN TF32 and deterministic warning-only behavior; bitwise reproducibility is not certified."
        ]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--extracted", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), "refusing existing audit output")
    result = audit(args.root.resolve(), args.archive.resolve(), args.extracted.resolve())
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"status": result["status"], "output": str(args.output.resolve()),
                      "archive": result["archive"], "runs": len(result["runs"]),
                      "source_images_verified": result["original_images_and_labels_verified"],
                      "edge_inventory": result["edge_inventory"]}, indent=2))


if __name__ == "__main__":
    main()
