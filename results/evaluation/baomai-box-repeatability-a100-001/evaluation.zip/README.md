# Box-repeatability evaluation evidence — 2026-11-10

This capsule preserves the completed PR #27 evaluation of the fixed seeds 43 and 44.
The decision remains retain-M0. Historical seed 42 is separate context.

## Identity and scope

- Returned GPU archive: PR #27, commit `265fe52dc6e2d8721986fcfdf8944eb4ed33497f`.
- GPU archive SHA-256: `4e4d36aaee4bfe316a5517afa68a276e76eef07ed8680347bd9b52ffbe455beb` (79,587,975 bytes).
- Training source: `f087c35f74bf304eb61998edcaa2172fe1cba49c`.
- Inference and replay source: `8ce9fe233dc3b4b9f3ccfc4491a952dca541a64b`.
- Five fresh model evaluations: M0 once, and original/corrected arms for each new seed.
- 300 unique image/model/threshold records and 15 score aggregates; the separate
  quality calculation checks the same 300 records and 15 aggregates.
- M0 evidence is copied identically into the two seed folders to satisfy the
  paired replay layout. Those copies do not represent two independent runs.
- `inventory.json` hashes every other payload file; it deliberately does not hash itself.

Model weights, the raw GPU ZIP, original PNGs and original reference labels are
not duplicated here. The original images/labels are obtained from the pinned
repository. The four returned model weights remain in the original PR #27 ZIP.
Checkpoint manifests, receipts, inventories, epoch CSVs and logs are preserved.
The saved-prediction replay below does not load weights or perform inference.

## Replay

Use Python 3.12.14 for the closest numeric reproduction. No ML packages are
needed for this saved-prediction summary. Extract this ZIP into a fresh directory,
and prepare a clean repository checkout at the exact published commit:

```bash
GIT_LFS_SKIP_SMUDGE=1 git clone https://github.com/Siuuuers/dl.git dl-replay
GIT_LFS_SKIP_SMUDGE=1 git -C dl-replay checkout --detach 8ce9fe233dc3b4b9f3ccfc4491a952dca541a64b
git -C dl-replay lfs pull --include='data/images/val/*.png' --exclude=''
python dl-replay/scripts/summarize_box_repeatability.py \
  --root dl-replay \
  --evidence /absolute/path/to/extracted/evidence \
  --output /absolute/path/to/new-repeatability-summary.json
```

The output path must not exist. The script verifies the original validation
PNG/label hashes, fixed recipes and correction proposal, completed checkpoint
evidence, shared runtime/settings, identical M0 payloads, and saved scores.
Compare the entire resulting JSON with `repeatability-summary.json`, omitting
only `created_at_utc` fields and the top-level `command` path/argument record.
In this summary schema the omitted timestamp fields are at the top level and
inside each of the two `per_seed` entries. All other values must match exactly;
no numeric tolerance, source-identity exclusion, path rewrite or timing-field
exclusion is used for this semantic comparison.

The external `verification.json` beside the distributed ZIP records the archive
hash, readback inventory check, clean-source status, one fresh extraction and
the successful complete saved-prediction replay.

## Evidence layout

- `evidence/`: both seed folders, raw predictions, scores, quality diagnostics,
  and small completed-checkpoint evidence bundles.
- `repeatability-summary.json`: official complete unrounded study summary.
- `commands.json`, `execution-status.json`, `logs/`: executed inference,
  diagnostic and summary commands, exit codes and logs.
- `m0-continuity.json`: comparison with the historical M0 payloads.
- `audit/`: original-return byte, receipt, source, staging and completion audit.
- `independent/`: independent scoring implementation, all-record recomputation,
  failure-location diagnostics and execution records.
- `runtime/`: CPU package identity, frozen environment and preparation probe.
- `return/`: original GPU manifest, transport audit and resource-trial records.
- `run_pr27_evaluation.py`, `package_evidence.py`: exact orchestration sources.

The orchestration files retain original scratch paths as execution provenance;
the portable replay command above is the supported way to recompute this capsule.
Two prospective seeds on a repeatedly used development split do not establish
unseen-scene accuracy, physical acceptance tolerances, significance or deployment
readiness. Recorded remote inventories are reconciled evidence, not hardware
attestation. The return audit verified weights when the original GPU ZIP was
available; this compact capsule alone cannot repeat that weight-byte check.
