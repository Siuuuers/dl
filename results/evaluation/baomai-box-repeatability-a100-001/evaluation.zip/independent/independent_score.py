#!/usr/bin/env python3
"""Independently check the saved seed-43/44 results with only the standard library."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import struct
import sys


THRESHOLDS = (0.15, 0.25, 0.40)
FIELDS = ("fn", "fp", "missing_endpoints", "conditional_median_error_px", "conditional_p95_error_px")
COUNTS = ("gold_count", "prediction_count", "tp", "fn", "fp", "duplicate_fp", "other_fp",
          "visible_endpoints", "returned_endpoints", "missing_endpoints")
QUALITY_COUNTS = ("gold_count", "prediction_count", "tp", "fn", "fp", "visible_endpoints",
                  "returned_visible_endpoints", "both_visible_objects", "both_visible_objects_with_both_returned",
                  "unlocatable_reference_endpoints", "unlocatable_on_matched_objects", "returned_on_unlocatable_reference")
RADIUS_FIELDS = ("visible_endpoints_within_radius", "both_visible_objects_within_radius")
INPUT_HASHES = {}
MAX_FLOAT_DIFFERENCE = 0.0
FLOAT_COMPARISONS = 0


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    INPUT_HASHES[str(path.resolve())] = digest(path)
    return path.read_text(encoding="utf-8")


def read_json(path):
    return json.loads(read(path))


def equivalent(actual, expected, where):
    """Exact structure/counts; tolerate only arithmetic representation in floats."""
    global MAX_FLOAT_DIFFERENCE, FLOAT_COMPARISONS
    if isinstance(expected, dict):
        require(isinstance(actual, dict) and set(actual) == set(expected), f"{where}: keys differ")
        for key in expected:
            equivalent(actual[key], expected[key], f"{where}.{key}")
    elif isinstance(expected, list):
        require(isinstance(actual, list) and len(actual) == len(expected), f"{where}: sequence differs")
        for index, value in enumerate(expected):
            equivalent(actual[index], value, f"{where}[{index}]")
    elif isinstance(expected, float):
        require(type(actual) in (int, float) and math.isfinite(actual) and math.isfinite(expected),
                f"{where}: nonfinite/non-numeric value")
        difference = abs(actual - expected)
        MAX_FLOAT_DIFFERENCE = max(MAX_FLOAT_DIFFERENCE, difference)
        FLOAT_COMPARISONS += 1
        require(difference <= 1e-10, f"{where}: numerical difference {difference!r}")
    else:
        require(type(actual) is type(expected) and actual == expected, f"{where}: {actual!r} != {expected!r}")


def subset(actual, expected, where):
    require(set(expected) <= set(actual), f"{where}: expected fields missing")
    equivalent({key: actual[key] for key in expected}, expected, where)


def percentile(values, fraction):
    if not values:
        return None
    ordered = sorted(values)
    position = fraction * (len(ordered) - 1)
    lo, hi = int(math.floor(position)), int(math.ceil(position))
    return ordered[lo] + (ordered[hi] - ordered[lo]) * (position - lo)


def stats(values):
    values = list(values)
    return {"count": len(values), "mean": math.fsum(values) / len(values) if values else None,
            "median": percentile(values, 0.50), "p95": percentile(values, 0.95)}


def ratio(numerator, denominator):
    return numerator / denominator if denominator else None


def load_reference(root):
    manifest = read_json(root / "data/manifest.json")
    result = {}
    for record in manifest["records"]:
        if record["split"] != "val":
            continue
        image_path = root / "data" / record["image"]
        label_path = root / "data" / record["label"]
        require(digest(image_path) == record["image_sha256"], f"image hash: {record['id']}")
        require(digest(label_path) == record["label_sha256"], f"label hash: {record['id']}")
        INPUT_HASHES[str(image_path.resolve())] = record["image_sha256"]
        with image_path.open("rb") as stream:
            header = stream.read(24)
        require(header[:8] == b"\x89PNG\r\n\x1a\n" and header[12:16] == b"IHDR", "PNG header")
        width, height = struct.unpack(">II", header[16:24])
        require([width, height] == record["original_size"], "original dimensions")
        objects = []
        for line in read(label_path).splitlines():
            if not line.strip():
                continue
            row = [float(token) for token in line.split()]
            require(len(row) == 11 and all(math.isfinite(x) for x in row), "label fields")
            require(row[0] == 0 and row[7] in (0, 2) and row[10] in (0, 2), "class/visibility")
            require(all(0 <= row[k] <= 1 for k in (1, 2, 3, 4, 5, 6, 8, 9)), "normalized coordinates")
            require(row[3] > 0 and row[4] > 0, "positive box size")
            points = [(row[k] * width, row[k + 1] * height, int(row[k + 2])) for k in (5, 8)]
            require(all(v == 2 or (x == 0 and y == 0) for x, y, v in points), "missing-point representation")
            center_x, center_y = row[1] * width, row[2] * height
            half_w, half_h = row[3] * width / 2, row[4] * height / 2
            objects.append({"class": 0, "box": (center_x - half_w, center_y - half_h,
                                               center_x + half_w, center_y + half_h), "points": points})
        require(len(objects) == record["instances"], "object count")
        require(sum(p[2] == 2 for obj in objects for p in obj["points"]) == record["visible_endpoints"], "endpoint count")
        require(record["id"] not in result, "duplicate reference image")
        result[record["id"]] = {**record, "width": width, "height": height, "objects": objects}
    require(len(result) == 20 and sum(len(r["objects"]) for r in result.values()) == 664, "frozen validation size")
    return dict(sorted(result.items()))


def overlap(a, b):
    width = min(a[2], b[2]) - max(a[0], b[0])
    height = min(a[3], b[3]) - max(a[1], b[1])
    if width <= 0 or height <= 0:
        return 0.0
    intersection = width * height
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - intersection
    return intersection / union


def point_present(point, width, height):
    x, y, confidence = point
    return (confidence >= 0.50 and x is not None and y is not None and math.isfinite(x) and math.isfinite(y)
            and 0 <= x < width and 0 <= y < height)


def image_result(record, predictions):
    gold = record["objects"]
    overlaps = [[overlap(prediction["bbox_xyxy"], item["box"]) for item in gold] for prediction in predictions]
    available = set(range(len(gold)))
    matched = []
    for pi in sorted(range(len(predictions)), key=lambda i: (-predictions[i]["confidence"], i)):
        candidates = [(overlaps[pi][gi], -gi, gi) for gi in available
                      if gold[gi]["class"] == predictions[pi]["class_id"] and overlaps[pi][gi] >= 0.50]
        if candidates:
            iou, _, gi = max(candidates)
            available.remove(gi)
            matched.append({"gold_index": gi, "prediction_index": pi, "iou": iou})
    matched_predictions = {m["prediction_index"] for m in matched}
    matched_gold = {m["gold_index"] for m in matched}
    unmatched = [pi for pi in range(len(predictions)) if pi not in matched_predictions]
    duplicates = [pi for pi in unmatched if any(predictions[pi]["class_id"] == gold[gi]["class"]
                  and overlaps[pi][gi] >= 0.50 for gi in matched_gold)]
    endpoints = {}
    errors = []
    hidden_matched = hidden_returned = 0
    for match in matched:
        gi, pi = match["gold_index"], match["prediction_index"]
        for side, (reference, point) in enumerate(zip(gold[gi]["points"], predictions[pi]["keypoints"])):
            present = point_present(point, record["width"], record["height"])
            if reference[2] == 0:
                hidden_matched += 1
                hidden_returned += int(present)
            elif present:
                dx, dy = point[0] - reference[0], point[1] - reference[1]
                error = math.hypot(dx, dy)
                endpoints[(gi, side)] = {"error_px": error, "dx_px": dx, "dy_px": dy}
                errors.append(error)
    visible = sum(p[2] == 2 for obj in gold for p in obj["points"])
    both = {i for i, obj in enumerate(gold) if all(point[2] == 2 for point in obj["points"])}
    both_returned = {i for i in both if (i, 0) in endpoints and (i, 1) in endpoints}
    tp, fp = len(matched), len(predictions) - len(matched)
    score = {"gold_count": len(gold), "prediction_count": len(predictions), "tp": tp, "fn": len(gold) - tp,
             "fp": fp, "duplicate_fp": len(duplicates), "other_fp": fp - len(duplicates),
             "visible_endpoints": visible, "returned_endpoints": len(errors), "missing_endpoints": visible - len(errors),
             "endpoint_coverage": ratio(len(errors), visible), "conditional_median_error_px": percentile(errors, 0.50),
             "conditional_p95_error_px": percentile(errors, 0.95), "endpoint_errors_px": errors,
             "matches": matched, "unmatched_gold_indices": sorted(available), "unmatched_prediction_indices": unmatched,
             "duplicate_prediction_indices": duplicates, "other_fp_prediction_indices": [i for i in unmatched if i not in duplicates]}
    quality = {key: score[key] for key in ("gold_count", "prediction_count", "tp", "fn", "fp", "visible_endpoints")}
    quality.update(returned_visible_endpoints=len(errors), both_visible_objects=len(both),
                   both_visible_objects_with_both_returned=len(both_returned),
                   unlocatable_reference_endpoints=2 * len(gold) - visible, unlocatable_on_matched_objects=hidden_matched,
                   returned_on_unlocatable_reference=hidden_returned, radii=[])
    successes = {}
    for radius in (2, 5, 10):
        successes[radius] = {i for i in both_returned if all(endpoints[i, side]["error_px"] <= radius for side in (0, 1))}
        quality["radii"].append({"radius_px": radius, "visible_endpoints_within_radius": sum(e <= radius for e in errors),
                                 "both_visible_objects_within_radius": len(successes[radius])})
    return score, quality, endpoints, successes


def aggregate(scores, qualities, threshold):
    total = {key: sum(row[key] for row in scores) for key in COUNTS}
    errors = [error for row in scores for error in row["endpoint_errors_px"]]
    total.update(endpoint_coverage=ratio(total["returned_endpoints"], total["visible_endpoints"]),
                 conditional_median_error_px=percentile(errors, 0.50), conditional_p95_error_px=percentile(errors, 0.95),
                 image_count=len(scores), threshold=threshold)
    quality = {key: sum(row[key] for row in qualities) for key in QUALITY_COUNTS}
    quality.update(image_count=len(qualities), box_confidence=threshold,
                   object_precision=ratio(quality["tp"], quality["prediction_count"]),
                   object_recall=ratio(quality["tp"], quality["gold_count"]),
                   visible_endpoint_coverage=ratio(quality["returned_visible_endpoints"], quality["visible_endpoints"]),
                   both_visible_objects_returned_fraction=ratio(quality["both_visible_objects_with_both_returned"], quality["both_visible_objects"]),
                   returned_on_unlocatable_reference_fraction=ratio(quality["returned_on_unlocatable_reference"], quality["unlocatable_on_matched_objects"]), radii=[])
    for index, radius in enumerate((2, 5, 10)):
        counts = {key: sum(row["radii"][index][key] for row in qualities) for key in RADIUS_FIELDS}
        quality["radii"].append({"radius_px": radius, **counts,
              "visible_endpoint_success_rate": ratio(counts["visible_endpoints_within_radius"], quality["visible_endpoints"]),
              "both_visible_object_success_rate": ratio(counts["both_visible_objects_within_radius"], quality["both_visible_objects"])})
    return total, quality


def audit_model(reference, folder):
    lines = [json.loads(line) for line in read(folder / "predictions.jsonl").splitlines() if line.strip()]
    require(len(lines) == 61 and lines[0]["record_type"] == "run", f"{folder}: prediction count")
    rows = lines[1:]
    keys = [(row["image_id"], row["threshold"]) for row in rows]
    require(len(set(keys)) == 60 and set(keys) == {(image, t) for image in reference for t in THRESHOLDS}, "complete threshold sweeps")
    saved_scores = {(r["image_id"], r["threshold"]): r for r in read_json(folder / "per_image.json")}
    quality_folder = folder.parent / (folder.name + "-quality")
    saved_quality = {(r["image_id"], r["box_confidence"]): r for r in read_json(quality_folder / "quality-per-image.json")}
    require(len(saved_scores) == len(saved_quality) == 60, "saved per-image count")
    scores, qualities, endpoints, successes = {}, {}, {}, {}
    for row in rows:
        key = (row["image_id"], row["threshold"])
        record = reference[row["image_id"]]
        for field in ("image_sha256", "label_sha256", "width", "height"):
            require(row[field] == record[field], f"prediction input inventory: {field}")
        score, quality, points, paired = image_result(record, row["predictions"])
        subset(saved_scores[key], {"image_id": key[0], "threshold": key[1], **score}, f"{folder.name}/{key}/score")
        equivalent(saved_quality[key], {"image_id": key[0], "box_confidence": key[1], **quality}, f"{folder.name}/{key}/quality")
        scores[key], qualities[key] = score, quality
        if key[1] == 0.25:
            endpoints.update({(key[0], gi, side): value for (gi, side), value in points.items()})
            successes[key[0]] = paired
    saved_total = {r["threshold"]: r for r in read_json(folder / "summary.json")["metrics"]}
    saved_qtotal = {r["box_confidence"]: r for r in read_json(quality_folder / "quality-summary.json")["metrics"]}
    totals, qtotals = [], []
    for threshold in THRESHOLDS:
        selected_keys = [key for key in keys if key[1] == threshold]
        total, qtotal = aggregate([scores[k] for k in selected_keys], [qualities[k] for k in selected_keys], threshold)
        subset(saved_total[threshold], total, f"{folder.name}/{threshold}/aggregate")
        equivalent(saved_qtotal[threshold], qtotal, f"{folder.name}/{threshold}/quality-aggregate")
        totals.append(total)
        qtotals.append(qtotal)
    return {"metrics": totals, "quality": qtotals, "endpoints": endpoints, "successes": successes,
            "scores": scores, "predictions": {k: row for k, row in zip(keys, rows)}, "header": lines[0]}


def difference(new, old):
    deltas = {key: new[key] - old[key] for key in FIELDS}
    return {"passes": all(x <= 0 for x in deltas.values()) and any(x < 0 for x in deltas.values()),
            "statistics_available": True, "new_minus_old": deltas}


def pair_details(reference, before, after):
    old_points, new_points = before["endpoints"], after["endpoints"]
    common = sorted(old_points.keys() & new_points.keys())
    changes = [new_points[key]["error_px"] - old_points[key]["error_px"] for key in common]
    old_success = {(image, gi) for image, values in before["successes"].items() for gi in values[5]}
    new_success = {(image, gi) for image, values in after["successes"].items() for gi in values[5]}
    summary = {"common_returned_endpoints": len(common), "error_change_px": stats(changes),
               "worse_endpoints": sum(x > 0 for x in changes), "better_endpoints": sum(x < 0 for x in changes),
               "equal_endpoints": sum(x == 0 for x in changes), "returned_only_old": len(old_points.keys() - new_points.keys()),
               "returned_only_new": len(new_points.keys() - old_points.keys()),
               "both_corners_within_5px": {"old_success": len(old_success), "new_success": len(new_success),
                   "success_both": len(old_success & new_success), "became_failure": len(old_success - new_success),
                   "became_success": len(new_success - old_success)}}
    details = {"common_endpoint_errors": {"reference": stats(old_points[key]["error_px"] for key in common),
                                           "candidate": stats(new_points[key]["error_px"] for key in common)},
               "returned_only_reference": [{"id": list(key), **old_points[key]} for key in sorted(old_points.keys() - new_points.keys())],
               "returned_only_candidate": [{"id": list(key), **new_points[key]} for key in sorted(new_points.keys() - old_points.keys())],
               "both_corners_5px_became_failure": [list(key) for key in sorted(old_success - new_success)],
               "both_corners_5px_became_success": [list(key) for key in sorted(new_success - old_success)],
               "object_match_changes": []}
    for image in reference:
        key = (image, 0.25)
        old_matches = {m["gold_index"]: m for m in before["scores"][key]["matches"]}
        new_matches = {m["gold_index"]: m for m in after["scores"][key]["matches"]}
        lost, gained = sorted(old_matches.keys() - new_matches.keys()), sorted(new_matches.keys() - old_matches.keys())
        if lost or gained:
            details["object_match_changes"].append({"image_id": image, "lost_gold_indices": lost, "gained_gold_indices": gained,
                "gains": [{"gold_index": gi, "match_iou": new_matches[gi]["iou"],
                    "confidence": after["predictions"][key]["predictions"][new_matches[gi]["prediction_index"]]["confidence"]} for gi in gained],
                "losses": [{"gold_index": gi, "match_iou": old_matches[gi]["iou"],
                    "confidence": before["predictions"][key]["predictions"][old_matches[gi]["prediction_index"]]["confidence"]} for gi in lost]})
    return summary, details


def audit(root, evidence, official_summary=None):
    reference = load_reference(root)
    models = {"m0": audit_model(reference, evidence / "seed-43/m0")}
    for seed in (43, 44):
        for arm in ("m1", "m2"):
            models[f"{seed}/{arm}"] = audit_model(reference, evidence / f"seed-{seed}" / arm)
    for name in ("predictions.jsonl", "per_image.json", "summary.json", "run_status.json"):
        before, after = evidence / "seed-43/m0" / name, evidence / "seed-44/m0" / name
        require(digest(before) == digest(after), f"M0 copied artifact differs: {name}")
        INPUT_HASHES[str(after.resolve())] = digest(after)
    for name in ("quality-summary.json", "quality-per-image.json", "run_status.json"):
        before, after = evidence / "seed-43/m0-quality" / name, evidence / "seed-44/m0-quality" / name
        require(digest(before) == digest(after), f"M0 copied quality artifact differs: {name}")
        INPUT_HASHES[str(after.resolve())] = digest(after)
    output = {"schema_version": 1, "kind": "independent-box-repeatability-score-audit", "status": "verified",
              "created_at_utc": datetime.now(timezone.utc).isoformat(),
              "unique_models": 5, "unique_image_threshold_records": 300, "unique_score_aggregates": 15,
              "unique_quality_records": 300, "unique_quality_aggregates": 15,
              "m0_copy_verified_separately_not_counted_twice": True,
              "models": {name: {"metrics": row["metrics"], "quality": row["quality"], "model_sha256": row["header"]["model_sha256"]}
                         for name, row in models.items()}, "per_seed": {}}
    for seed in (43, 44):
        runs = {"m0": models["m0"], "m1": models[f"{seed}/m1"], "m2": models[f"{seed}/m2"]}
        primary = {name: next(row for row in run["metrics"] if row["threshold"] == 0.25) for name, run in runs.items()}
        comparisons = []
        paired, paired_details = {}, {}
        for threshold in THRESHOLDS:
            per_threshold = {name: next(row for row in run["metrics"] if row["threshold"] == threshold) for name, run in runs.items()}
            comparisons.append({"box_confidence": threshold, "primary": threshold == 0.25,
                "comparisons": {f"{new}_vs_{old}": difference(per_threshold[new], per_threshold[old])
                                for new, old in (("m1", "m0"), ("m2", "m0"), ("m2", "m1"))}})
        for new, old in (("m1", "m0"), ("m2", "m0"), ("m2", "m1")):
            paired[f"{new}_vs_{old}"], paired_details[f"{new}_vs_{old}"] = pair_details(reference, runs[old], runs[new])
        common = sorted(set.intersection(*(set(run["endpoints"]) for run in runs.values())))
        common_metrics = {name: {field: stats(run["endpoints"][key][field] for key in common)
                                for field in ("error_px", "dx_px", "dy_px")} for name, run in runs.items()}
        empty = {image: {name: {str(t): run["scores"][image, t]["fp"] for t in THRESHOLDS} for name, run in runs.items()}
                 for image, record in reference.items() if not record["objects"]}
        residual = {name: [image for image, record in reference.items() if record["objects"]
                          and (run["scores"][image, 0.25]["fn"] or run["scores"][image, 0.25]["fp"])]
                    for name, run in runs.items()}
        output["per_seed"][str(seed)] = {"primary": primary,
            "candidate_minus_reference": difference(primary["m2"], primary["m1"])["new_minus_old"],
            "comparisons": comparisons, "paired_primary_diagnostics": paired,
            "independent_paired_details": paired_details, "three_model_common_endpoint_count": len(common),
            "three_model_common_endpoint_metrics": common_metrics, "empty_scene_false_detections": empty,
            "nonempty_images_with_miss_or_extra": residual}
    output["candidate_minus_reference_summary"] = {}
    for field in FIELDS:
        values = [output["per_seed"][str(seed)]["candidate_minus_reference"][field] for seed in (43, 44)]
        output["candidate_minus_reference_summary"][field] = {"seed_count": 2, "mean": math.fsum(values) / 2,
            "min": min(values), "max": max(values), "improved": sum(x < 0 for x in values),
            "tied": sum(x == 0 for x in values), "worsened": sum(x > 0 for x in values)}
    if official_summary:
        official = read_json(official_summary)
        require(official["prospective_seeds"] == [43, 44] and official["decision"] == "retain-M0"
                and official["predeclared_adoption_eligible"] == [], "fixed study scope/decision")
        equivalent(official["candidate_minus_reference_summary"], output["candidate_minus_reference_summary"], "study aggregation")
        require(len(official["per_seed"]) == 2, "two seed summaries")
        for row in official["per_seed"]:
            expected = output["per_seed"][str(row["seed"]) ]
            for key in ("candidate_minus_reference", "comparisons", "paired_primary_diagnostics", "empty_scene_false_detections"):
                equivalent(row[key], expected[key], f"seed{row['seed']}/{key}")
            equivalent(row["common_returned_endpoints"]["count"], expected["three_model_common_endpoint_count"], "common endpoint count")
            equivalent(row["common_returned_endpoints"]["metrics"], expected["three_model_common_endpoint_metrics"], "common endpoint metrics")
        output["official_study_summary_verified"] = str(official_summary.resolve())
    else:
        output["official_study_summary_verified"] = None
    output["verification_method"] = {
        "implementation": "Standalone standard-library parser, direct-area IoU, confidence-ordered greedy one-to-one matching, Euclidean endpoint errors and linearly interpolated quantiles; no repository imports.",
        "checked": "All saved per-image score fields, match identities/overlaps, unpaired indices, endpoint errors, aggregate metrics, radius counts/rates and available official study pair summaries.",
        "arithmetic_comparison_absolute_tolerance": 1e-10,
        "arithmetic_tolerance_scope": "Comparison of independently recomputed floating-point values only; counts and identities exact; no tolerance in model decision or sign of metric deltas.",
        "maximum_observed_float_difference": MAX_FLOAT_DIFFERENCE, "float_comparisons": FLOAT_COMPARISONS,
        "decision": "retain-M0; descriptive study, no new model promotion",
        "limits": "No fresh inference or weight deserialization in this independent script; predictions are inputs. Reused development data, two prospective seeds, conditional errors and illustrative radii preserve the study limitations."}
    for path, expected_hash in INPUT_HASHES.items():
        require(digest(Path(path)) == expected_hash, f"input changed while verifying: {path}")
    output["input_files_sha256"] = dict(sorted(INPUT_HASHES.items()))
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--official-summary", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), f"output already exists: {args.output}")
    result = audit(args.root.resolve(), args.evidence.resolve(), args.official_summary)
    result["command"] = [sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]]
    result["script_sha256"] = digest(Path(__file__))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"output": str(args.output.resolve()), "status": result["status"],
                      "unique_records": 300, "unique_aggregates": 15,
                      "maximum_float_difference": MAX_FLOAT_DIFFERENCE,
                      "candidate_minus_reference_summary": result["candidate_minus_reference_summary"]}, indent=2))


if __name__ == "__main__":
    main()
