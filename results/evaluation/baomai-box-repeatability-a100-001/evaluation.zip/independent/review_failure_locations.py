#!/usr/bin/env python3
"""Preserve exact saved-prediction evidence for persistent misses and two changed matches."""

from collections import Counter
from datetime import datetime, timezone
import argparse
import json
from pathlib import Path
import sys

import independent_score as audit


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    audit.require(not args.output.exists(), "output already exists")
    reference = audit.load_reference(args.root)
    locations = {"m0": "seed-43/m0", "43-reference": "seed-43/m1", "43-candidate": "seed-43/m2",
                 "44-reference": "seed-44/m1", "44-candidate": "seed-44/m2"}
    runs = {}
    for name, relative in locations.items():
        folder = args.evidence / relative
        scores = {(r["image_id"], r["threshold"]): r for r in audit.read_json(folder / "per_image.json")}
        predictions = [json.loads(line) for line in audit.read(folder / "predictions.jsonl").splitlines() if line.strip()][1:]
        predictions = {(r["image_id"], r["threshold"]): r["predictions"] for r in predictions}
        misses = {(image, gi) for (image, threshold), row in scores.items() if threshold == 0.25
                  for gi in row["unmatched_gold_indices"]}
        runs[name] = {"scores": scores, "predictions": predictions, "misses": misses}
    persistent = sorted(set.intersection(*(run["misses"] for run in runs.values())))
    queue = []
    for image, gi in persistent:
        obj = reference[image]["objects"][gi]
        entry = {"image_id": image, "gold_index_zero_based": gi, "label_row_one_based": gi + 1,
                 "image": reference[image]["image"], "label": reference[image]["label"],
                 "image_sha256": reference[image]["image_sha256"], "label_sha256": reference[image]["label_sha256"],
                 "frozen_bbox_xyxy": obj["box"], "frozen_keypoints": obj["points"],
                 "locatable_reference_corners": sum(p[2] == 2 for p in obj["points"]), "models": {}}
        for name, run in runs.items():
            conditions = {}
            for threshold in (0.15, 0.25, 0.40):
                predictions = run["predictions"][image, threshold]
                overlaps = [(audit.overlap(obj["box"], p["bbox_xyxy"]), i) for i, p in enumerate(predictions)
                            if p["class_id"] == obj["class"]]
                overlaps.sort(key=lambda value: (-value[0], value[1]))
                best = None
                if overlaps:
                    iou, index = overlaps[0]
                    best = {"prediction_index": index, "confidence": predictions[index]["confidence"],
                            "iou": iou, "bbox_xyxy": predictions[index]["bbox_xyxy"]}
                match = next((m for m in run["scores"][image, threshold]["matches"] if m["gold_index"] == gi), None)
                conditions[str(threshold)] = {"matched": match is not None, "match": match,
                                               "max_overlap_prediction": best,
                                               "qualifying_overlap_count": sum(value >= 0.50 for value, _ in overlaps)}
            primary, low = conditions["0.25"], conditions["0.15"]
            if primary["qualifying_overlap_count"]:
                category = "qualifying_box_assigned_elsewhere"
            elif low["qualifying_overlap_count"]:
                category = "qualifying_overlap_only_below_primary_confidence"
            else:
                category = "no_qualifying_overlap_at_low_diagnostic_confidence"
            entry["models"][name] = {"diagnostic_category": category, "thresholds": conditions}
        queue.append(entry)
    transitions = []
    for seed, image, gi in ((43, "new_000058", 18), (44, "new_000056", 13)):
        item = {"seed": seed, "image_id": image, "gold_index_zero_based": gi, "label_row_one_based": gi + 1,
                "frozen_bbox_xyxy": reference[image]["objects"][gi]["box"],
                "frozen_keypoints": reference[image]["objects"][gi]["points"], "arms": {}}
        for arm in ("reference", "candidate"):
            run = runs[f"{seed}-{arm}"]
            observations = []
            for threshold in (0.15, 0.25, 0.40):
                score = run["scores"][image, threshold]
                match = next((m for m in score["matches"] if m["gold_index"] == gi), None)
                prediction = None if match is None else run["predictions"][image, threshold][match["prediction_index"]]
                observations.append({"box_confidence": threshold, "matched": match is not None,
                                     "match": match, "prediction": prediction})
            item["arms"][arm] = observations
        transitions.append(item)
    counts = Counter(item["locatable_reference_corners"] for item in queue)
    summary = {"persistent_missed_objects": len(queue), "unique_ever_missed_objects": len(set.union(*(r["misses"] for r in runs.values()))),
               "persistent_misses_by_locatable_corners": {str(key): counts[key] for key in (0, 1, 2)},
               "diagnostic_categories_by_model": {name: dict(Counter(item["models"][name]["diagnostic_category"] for item in queue))
                                                   for name in runs}}
    report = {"schema_version": 1, "kind": "box-repeatability-failure-review-locations",
              "created_at_utc": datetime.now(timezone.utc).isoformat(), "summary": summary,
              "primary_box_confidence": 0.25, "matching_iou": 0.50,
              "queue_order": "Original image ID then label row, not a favorable result ranking.",
              "persistent_misses": queue, "candidate_lost_match_diagnostics": transitions,
              "interpretation": [
                  "Both candidate-only losses correspond to one locatable reference corner; their candidate boxes are matched at diagnostic0.15 with confidence below the fixed0.25 gate.",
                  "The persistent queue is a review index. Reference visibility0 does not itself prove why a point was unlocatable, and maximum-overlap values do not certify physical object identity or correct label boundaries.",
                  "No new confidence threshold, annotation change, or model adoption is authorized by this post-result diagnosis.",
                  "Use original-image review to distinguish persistent localization failures, occlusion, ambiguous target boundaries and annotation uncertainty; preserve the completed study reference and findings.",
                  "With no new inputs, prioritize existing training-label consistency and related failure categories before proposing a new fixed intervention. Two seed outcomes do not justify selecting the best model or claiming generalization."],
              "script_sha256": audit.digest(Path(__file__)), "scorer_script_sha256": audit.digest(Path(audit.__file__)),
              "command": [sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]],
              "input_files_sha256": dict(sorted(audit.INPUT_HASHES.items()))}
    for name, digest in audit.INPUT_HASHES.items():
        audit.require(audit.digest(Path(name)) == digest, "input changed")
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"output": str(args.output.resolve()), **summary}, indent=2))


if __name__ == "__main__":
    main()
