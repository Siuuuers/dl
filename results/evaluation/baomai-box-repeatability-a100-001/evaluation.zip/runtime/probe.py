import importlib.metadata
import json
import platform
import subprocess
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
import torchvision
from ultralytics import YOLO


expected = {
    "torch": "2.10.0+cpu",
    "torchvision": "0.25.0+cpu",
    "ultralytics": "8.4.182",
    "numpy": "2.5.4",
    "Pillow": "13.0.0",
    "opencv-python": "5.0.0.93",
}
actual = {name: importlib.metadata.version(name) for name in expected}
assert actual == expected, (actual, expected)
assert platform.python_version() == "3.12.14"
assert torch.version.cuda is None
torch.set_num_threads(4)
boxes = torch.tensor([[0.0, 0.0, 10.0, 10.0], [0.0, 0.0, 10.0, 10.0]])
kept = torchvision.ops.nms(boxes, torch.tensor([0.9, 0.8]), 0.7).tolist()
assert kept == [0], kept
resized = cv2.resize(np.zeros((8, 8, 3), dtype=np.uint8), (4, 4))
assert resized.shape == (4, 4, 3)
result = {
    "python": platform.python_version(),
    "platform": platform.platform(),
    "executable": sys.executable,
    "packages": actual,
    "torch_cuda": torch.version.cuda,
    "cuda_available": torch.cuda.is_available(),
    "torch_threads": torch.get_num_threads(),
    "torchvision_nms_smoke_result": kept,
    "opencv_resize_smoke_shape": list(resized.shape),
    "ultralytics_yolo_import": YOLO.__name__,
    "scope": "Package identity, imports and small library-operation checks only; no model loaded or inference/training run.",
    "commands": [
        "python -m venv /workspace/scratch/470b9cd0057a/eval-venv",
        "/workspace/scratch/470b9cd0057a/eval-venv/bin/python -m pip install --disable-pip-version-check --timeout 30 --retries 1 torch==2.10.0+cpu torchvision==0.25.0+cpu --index-url https://download.pytorch.org/whl/cpu",
        "/workspace/scratch/470b9cd0057a/eval-venv/bin/python -m pip install --disable-pip-version-check --timeout 30 --retries 1 ultralytics==8.4.182 opencv-python==5.0.0.93 numpy==2.5.4 pillow==13.0.0 torch==2.10.0+cpu torchvision==0.25.0+cpu",
        "/workspace/scratch/470b9cd0057a/eval-venv/bin/python /workspace/scratch/470b9cd0057a/evaluation-runtime/probe.py",
    ],
}
output = Path(__file__).resolve().parent
(output / "runtime.json").write_text(json.dumps(result, indent=2) + "\n")
freeze = subprocess.run([sys.executable, "-m", "pip", "freeze", "--all"], check=True, capture_output=True, text=True)
(output / "requirements.txt").write_text(freeze.stdout)
print(json.dumps(result, indent=2))
