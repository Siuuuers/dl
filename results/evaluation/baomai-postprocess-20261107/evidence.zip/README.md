# Fixed cassette NMS experiment: evidence

The model is the original epoch173, not a new trained checkpoint. All 240
image/settings predictions use the same 20 development images and 664 reference
objects. The published plan and inference source are commit
`89895a172d94421f90c13a7858d9e8e8db4c11fd` in `Siuuuers/dl`.

At confidence 0.25 the primary NMS 0.60 hypothesis fails the declared guard:
FN 39→40 and missing endpoints 43→44, although FP falls 63→46. The secondary
NMS 0.68 setting passes on this reference: FN 39, FP 61, missing endpoints 43,
and identical conditional median/p95 errors. All 625 matched objects retain
identical prediction dictionaries. Duplicate FP remains 17; other FP falls 46→44.
This small development-reference result is not an independent-test result.
The default NMS remains 0.70.

## Contents

- `fresh/`: full raw prediction stream, all per-image scores, aggregate CSV/JSON,
  and explicit successful completion status.
- `audit.json`: original full-grid prediction/match change audit.
- `independent-audit.json`, `verify_predictions.py`: independently recomputed
  scores, candidate guards, historical-control parity and match identities.
- `readiness.json`, `summarize_readiness.py`: per-image baseline errors and
  reference-corner-availability cohorts.
- `folder-output-068/`, `folder-output-default/`: saved label-free runner
  predictions, status and CSV. The four candidate images and two default images
  all reproduce the fixed-grid raw outputs exactly.
- `folder-commands.json`, `folder-parity.json`, `verify_folder.py`: exact executed
  commands, exit codes, clean source identity and reproducible raw-output check.
  Folder source is `2c409f4fa7c16367b7895a8b021611a277c68a3c`.
- `folder-checks.log`, `experiment-checks.log`: 14 and 7 focused checks passing
  at that clean folder-source revision.
- `replay-receipt.json`, execution logs: original inference and replay evidence.
- `visual-review/`: selected raw-pixel/box comparisons, rendering script and
  exact source/evidence identities. Figures do not approve or edit labels.
- `inventory.json`: SHA-256 and byte size of every other payload in this ZIP.

The original images/model and six full folder overlays are omitted from this
compact archive. Inputs are the existing hash-identified validation originals in
the repository. Original output-path strings in run records are preserved as
provenance; they are not portable file links. Selected diagnostic figures are
included, and all overlays can be recreated by the folder command.

## Reproduce without model inference

From the published report branch, obtain the original validation image payloads:

```bash
git lfs pull --include='data/images/val/*.png' --exclude=''
python3 -m zipfile -e results/evaluation/baomai-postprocess-20261107/evidence.zip ../postprocess-evidence
python3 scripts/experiment_pose_postprocess.py \
  --replay ../postprocess-evidence/fresh/predictions.jsonl \
  --output ../postprocess-replay
python3 ../postprocess-evidence/verify_predictions.py \
  --repo . --results ../postprocess-evidence --replay ../postprocess-replay
python3 ../postprocess-evidence/verify_folder.py --evidence ../postprocess-evidence
python3 ../postprocess-evidence/summarize_readiness.py --repo . --evidence ../postprocess-evidence
```

The numerical paths use Python's standard library and existing repository
scorers. They verify the frozen reference identities. The independent audit also
reads the historical M0 stream in the repository's existing
`results/evaluation/baomai-warmup-a100-001/evaluation.zip`.

The replay output must be a new directory. Four files must exactly equal the
saved fresh outputs: `predictions.jsonl`, `summary.json`, `per_image.json` and
`metrics.csv`. Timing fields are retained as recorded measurements, not rerun.

The selected figures can be rendered with Matplotlib and Pillow, without Torch:

```bash
python3 ../postprocess-evidence/visual-review/render_review.py \
  --root . --evidence ../postprocess-evidence --output ../postprocess-figures
```

## Interpretation of selected cases

In `new_000008`, one lower-confidence extra box disappears while the matched box
is unchanged. Its IoU with the nearby reference is 0.455410 and with the retained
prediction is 0.689612. This is an extra overlapping output under the fixed
matcher, not proof of an imaginary physical cassette.

In `new_000009`, NMS 0.68 replaces three gripper-region other-FP outputs with three
others. A separate top-border sliver accounts for that image's net FP reduction.
At NMS 0.60, reference row 51 loses its narrower match while a wider,
higher-confidence unmatched box remains. NMS 0.50 also loses row 50. Original
pixels show exposed front portions beside the gripper; those losses should not
be erased by deleting difficult reference objects.

Images 7 and 90 each replace one unmatched output with another, with no FP-count
improvement. Across all four changed images, seven outputs disappear and five
appear. All 625 matched outputs remain identical at 0.68.

Boxes in the figures are postprocessed/clipped output coordinates. Especially
at borders, their overlaps cannot fully reconstruct the pre-NMS geometry.
The actual experiment therefore used fresh framework inference for every
image/settings pair. No hidden-corner coordinate was inferred, and no reference
annotation was approved or modified by this review.
