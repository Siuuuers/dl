#!/usr/bin/env python3
"""Audit this fixed postprocessing result with stdlib and the existing scorer.

Print a JSON receipt to stdout; a failed check prints status=failed and exits 1.
No model is loaded, no inference is run, and no repository files are written.

Example:
  python3 -B verify_predictions.py --repo /path/to/dl \
      --results /path/to/evidence --replay /path/to/evidence/replay
"""

import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import re
import sys
import zipfile


sys.dont_write_bytecode = True
NMS_VALUES = (0.70, 0.60, 0.68, 0.50)
CONFIDENCES = (0.15, 0.25, 0.40)
GATE_FIELDS = ("fn", "fp", "missing_endpoints", "conditional_median_error_px", "conditional_p95_error_px")
IDENTITY = {
    "model_sha256": "e0aab1b377491700318e0b14cd4c558ec3c1684087a13b7dde2298ebdbf2847e",
    "manifest_sha256": "72ae8365d5abf0b45b75d400a2e6d22119c0e31b54ee33035feb8edc1f967926",
    "model_card_sha256": "636f0952e9f36e7e26b091bd0ab9b857f841317673507611e998af1ada719566",
}
HISTORICAL_ZIP = "results/evaluation/baomai-warmup-a100-001/evaluation.zip"
HISTORICAL_ENTRY = "m0/predictions.jsonl"
REPLAY_FILES = ("predictions.jsonl", "summary.json", "per_image.json", "metrics.csv")


def check(condition, message):
    # Explicit raising keeps every assertion active even under python -O.
    if not condition:
        raise AssertionError(message)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def unique_keys(pairs):
    result = {}
    for key, value in pairs:
        check(key not in result, f"duplicate JSON field: {key}")
        result[key] = value
    return result


def reject_constant(value):
    raise ValueError(f"nonstandard JSON number: {value}")


def parse_json(text):
    return json.loads(text, object_pairs_hook=unique_keys, parse_constant=reject_constant)


def read_json(path):
    return parse_json(Path(path).read_text(encoding="utf-8"))


def parse_jsonl(text):
    return [parse_json(line) for line in text.splitlines() if line.strip()]


def row_key(row):
    return row["nms_iou"], row["threshold"], row["image_id"]


def finite_number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def gate(candidate, baseline):
    comparisons = []
    for field in GATE_FIELDS:
        value, reference = candidate[field], baseline[field]
        finite = finite_number(value) and finite_number(reference)
        comparisons.append({"metric": field, "baseline": reference, "candidate": value,
                            "finite": finite, "no_worse": finite and value <= reference,
                            "strictly_better": finite and value < reference})
    passed = all(row["no_worse"] for row in comparisons) and any(row["strictly_better"] for row in comparisons)
    return {"passes_declared_gate": passed, "comparisons": comparisons, "automatic_adoption": False}


def canonical(prediction):
    return json.dumps(prediction, sort_keys=True, separators=(",", ":"), allow_nan=False)


def difference_indices(first, second):
    remaining = Counter(canonical(prediction) for prediction in second)
    different = []
    for index, prediction in enumerate(first):
        token = canonical(prediction)
        if remaining[token]:
            remaining[token] -= 1
        else:
            different.append(index)
    return different


def category(index, score):
    if index in {pair["prediction_index"] for pair in score["matches"]}:
        return "TP"
    return "duplicate_FP" if index in score["duplicate_prediction_indices"] else "other_FP"


def audit(args):
    repo, results = args.repo.resolve(), args.results.resolve()
    fresh = results / "fresh"
    sys.path.insert(0, str(repo / "scripts"))
    from evaluate_pose import INFERENCE, preflight_dataset
    from pose_scoring import aggregate_scores, score_image
    from diagnose_pose_quality import aggregate_quality, quality_for_image

    summary = read_json(fresh / "summary.json")
    saved_per_image = read_json(fresh / "per_image.json")
    stream = parse_jsonl((fresh / "predictions.jsonl").read_text(encoding="utf-8"))
    check(len(stream) == 242, "expected one run header, 240 prediction records, and one completion footer")
    header, rows, footer = stream[0], stream[1:-1], stream[-1]
    check(header["record_type"] == "run" and header["schema"] == "baomai-fixed-postprocess-v1"
          and header["schema_version"] == 1, "unexpected run schema")
    check(summary["schema"] == header["schema"] and summary["schema_version"] == 1,
          "summary schema differs from run")
    check(footer == {"record_type": "completion", "status": "complete", "prediction_records": 240},
          "inference completion footer is missing or inconsistent")
    check(summary["run"] == header and summary["plan"] == header["plan"],
          "summary run or plan differs from predictions")
    check(summary["prediction_file_sha256"] == sha256(fresh / "predictions.jsonl"),
          "prediction file hash differs from summary")
    status = read_json(fresh / "run_status.json")
    check(status == {"status": "complete", "exit_code": 0, "scored_image_settings_pairs": 240,
                     "model_sha256": IDENTITY["model_sha256"]}, "fresh run did not complete successfully")
    plan = header["plan"]
    check(plan["nms_ious"] == list(NMS_VALUES) and plan["box_confidences"] == list(CONFIDENCES)
          and plan["reference_images"] == 20 and plan["expected_prediction_records"] == 240,
          "grid differs from the recorded fixed experiment")
    check(plan["matching_iou"] == 0.50 and plan["endpoint_confidence"] == 0.50
          and plan["illustrative_radii_px"] == [2, 5, 10] and plan["gate_metrics"] == list(GATE_FIELDS),
          "scoring or guard settings differ")
    check(plan["baseline"] == {"nms_iou": 0.70, "threshold": 0.25}
          and plan["primary_candidate"] == {"nms_iou": 0.60, "threshold": 0.25}
          and plan["secondary_candidates"] == [{"nms_iou": 0.68, "threshold": 0.25},
                                                 {"nms_iou": 0.50, "threshold": 0.25}],
          "candidate roles differ from the pre-inference plan")
    check(header["inference_base"] == INFERENCE, "inference base settings differ")
    source = header["source"]
    check(isinstance(source["revision"], str) and re.fullmatch(r"[0-9a-f]{40}", source["revision"])
          and source["working_tree_status"] == "", "inference source was not a recorded clean revision")
    expected_source_files = {"scripts/evaluate_pose.py", "scripts/pose_scoring.py", "scripts/pose_checkpoint.py",
                             "scripts/experiment_pose_postprocess.py", "scripts/diagnose_pose_quality.py"}
    check(set(source["files_sha256"]) == expected_source_files, "source file inventory differs")
    for relative, expected in source["files_sha256"].items():
        check(sha256(repo / relative) == expected, f"source bytes differ: {relative}")
    runtime = header["runtime"]
    check(runtime["backend_end2end"] is False and runtime["backend_fp16"] is False
          and runtime["loaded_kpt_shape"] == [2, 3] and runtime["ultralytics"] == "8.4.182",
          "recorded runtime differs from ordinary-NMS FP32 two-corner inference")

    preflight = preflight_dataset(repo, require_weights=False)
    for field, expected in IDENTITY.items():
        check(header[field] == expected == preflight[field], f"reference identity differs: {field}")
    records = {row["id"]: row for row in preflight["records"]}
    image_fields = ("id", "image", "label", "image_sha256", "label_sha256", "width", "height")
    check(len(records) == 20 and header["images"] == [
        {field: row[field] for field in image_fields} for row in preflight["records"]],
        "reference image inventory differs")
    expected_grid = {(nms, confidence, identifier) for nms in NMS_VALUES
                     for confidence in CONFIDENCES for identifier in records}
    check(len({row_key(row) for row in rows}) == 240
          and {row_key(row) for row in rows} == expected_grid, "incomplete or duplicate image/settings grid")

    recomputed = []
    for row in rows:
        check(row["record_type"] == "prediction", "unexpected record type inside predictions")
        reference = records[row["image_id"]]
        for field in ("image_sha256", "label_sha256", "width", "height"):
            check(row[field] == reference[field], f"prediction reference differs: {row_key(row)} {field}")
        check(row["inference"] == {**INFERENCE, "iou": row["nms_iou"], "conf": row["threshold"]},
              f"per-record inference settings differ: {row_key(row)}")
        check(all(finite_number(p["confidence"]) and row["threshold"] < p["confidence"] <= 1
                  for p in row["predictions"]), f"prediction confidence outside its cell: {row_key(row)}")
        scored = score_image(reference["gold"], row["predictions"], reference["width"], reference["height"], 0.50, 0.50)
        quality = quality_for_image(reference["gold"], row["predictions"], reference["width"], reference["height"], [2, 5, 10])
        recomputed.append({"image_id": row["image_id"], "nms_iou": row["nms_iou"], "threshold": row["threshold"],
                           **scored, "quality": quality})
    check(recomputed == saved_per_image, "a recomputed per-image score or quality record differs")
    metrics = []
    for nms in NMS_VALUES:
        for confidence in CONFIDENCES:
            selected = [row for row in recomputed if (row["nms_iou"], row["threshold"]) == (nms, confidence)]
            check(len(selected) == 20, "aggregate does not contain exactly 20 images")
            metric = aggregate_scores(selected)
            metric.pop("endpoint_errors_px")
            tp, fp, fn = metric["tp"], metric["fp"], metric["fn"]
            metric.update(nms_iou=nms, threshold=confidence, precision=tp / (tp + fp), recall=tp / (tp + fn),
                          f1=2 * tp / (2 * tp + fp + fn), fn_plus_fp=fn + fp,
                          quality=aggregate_quality([row["quality"] for row in selected]))
            metrics.append(metric)
    check(metrics == summary["metrics"], "a recomputed aggregate, rate, or quality result differs")
    by_cell = {(row["nms_iou"], row["threshold"]): row for row in metrics}
    baseline = by_cell[0.70, 0.25]
    comparisons = [{"role": role, "nms_iou": nms, "threshold": 0.25,
                    **gate(by_cell[nms, 0.25], baseline)}
                   for role, nms in (("primary", 0.60), ("secondary", 0.68), ("secondary", 0.50))]
    check(comparisons == summary["candidate_comparisons"], "declared guard results differ")
    check([row["passes_declared_gate"] for row in comparisons] == [False, True, False],
          "unexpected primary/secondary guard decisions")

    with zipfile.ZipFile(repo / HISTORICAL_ZIP) as archive:
        historical_stream = parse_jsonl(archive.read(HISTORICAL_ENTRY).decode("utf-8"))
    historical_header, historical_rows = historical_stream[0], historical_stream[1:]
    check(historical_header["record_type"] == "run", "historical run header missing")
    for field, expected in IDENTITY.items():
        check(historical_header[field] == expected, f"historical identity differs: {field}")
    historical = {(row["threshold"], row["image_id"]): row for row in historical_rows}
    check(len(historical_rows) == len(historical) == 60, "historical control coverage differs")
    control_pairs = 0
    for row in rows:
        if row["nms_iou"] != 0.70:
            continue
        old = historical[row["threshold"], row["image_id"]]
        for field in ("image_id", "threshold", "image_sha256", "label_sha256", "width", "height", "predictions"):
            check(row[field] == old[field], f"historical control mismatch: {row_key(row)} {field}")
        control_pairs += 1
    check(control_pairs == 60, "historical control comparison incomplete")

    raw_map = {row_key(row): row for row in rows}
    score_map = {row_key(row): row for row in recomputed}
    identical_matches, changes = 0, []
    for identifier in records:
        before, after = score_map[0.70, 0.25, identifier], score_map[0.68, 0.25, identifier]
        old = raw_map[0.70, 0.25, identifier]["predictions"]
        new = raw_map[0.68, 0.25, identifier]["predictions"]
        old_matches = {pair["gold_index"]: old[pair["prediction_index"]] for pair in before["matches"]}
        new_matches = {pair["gold_index"]: new[pair["prediction_index"]] for pair in after["matches"]}
        check(old_matches == new_matches, f"0.68 changed a matched object or prediction: {identifier}")
        identical_matches += len(old_matches)
        removed, added = difference_indices(old, new), difference_indices(new, old)
        if removed or added:
            changes.append({"image_id": identifier, "fn_before": before["fn"], "fn_after": after["fn"],
                            "fp_before": before["fp"], "fp_after": after["fp"],
                            "removed_prediction_indices_0based": removed,
                            "removed_categories": [category(index, before) for index in removed],
                            "added_prediction_indices_0based": added,
                            "added_categories": [category(index, after) for index in added]})
    removed_count = sum(len(row["removed_prediction_indices_0based"]) for row in changes)
    added_count = sum(len(row["added_prediction_indices_0based"]) for row in changes)
    check(identical_matches == 625 and removed_count == 7 and added_count == 5 and len(changes) == 4,
          "0.68 match identity or prediction-change counts differ")
    check({row["image_id"]: (row["fp_before"], row["fp_after"]) for row in changes} == {
        "new_000007": (2, 2), "new_000008": (4, 3), "new_000009": (14, 13), "new_000090": (13, 13)},
        "0.68 per-image false-positive changes differ")
    check(Counter(cat for row in changes for cat in row["removed_categories"]) == Counter(duplicate_FP=1, other_FP=6)
          and Counter(cat for row in changes for cat in row["added_categories"]) == Counter(duplicate_FP=1, other_FP=4),
          "0.68 changed prediction categories differ")
    candidate = by_cell[0.68, 0.25]
    check((baseline["fn"], baseline["fp"], baseline["duplicate_fp"], baseline["other_fp"]) == (39, 63, 17, 46)
          and (candidate["fn"], candidate["fp"], candidate["duplicate_fp"], candidate["other_fp"]) == (39, 61, 17, 44),
          "0.68 aggregate object error conclusion differs")
    lost_rows = {}
    for nms in (0.60, 0.50):
        lost, gained = {}, {}
        for identifier in records:
            before = {pair["gold_index"] for pair in score_map[0.70, 0.25, identifier]["matches"]}
            after = {pair["gold_index"] for pair in score_map[nms, 0.25, identifier]["matches"]}
            if before - after:
                lost[identifier] = sorted(index + 1 for index in before - after)
            if after - before:
                gained[identifier] = sorted(index + 1 for index in after - before)
        expected = {"new_000009": [51] if nms == 0.60 else [50, 51]}
        check(lost == expected and not gained, f"lost/gained reference matches differ at NMS {nms}")
        lost_rows[f"{nms:.2f}"] = lost
    empty_records = [row for row in recomputed if row["gold_count"] == 0]
    check(len(empty_records) == 36 and all(row["prediction_count"] == 0 for row in empty_records),
          "empty-scene results differ")

    replay_files = []
    if args.replay is not None:
        for name in REPLAY_FILES:
            check((fresh / name).read_bytes() == (args.replay / name).read_bytes(), f"replay file differs: {name}")
            replay_files.append(name)
    primary_fields = ("nms_iou", "threshold", "tp", "fn", "fp", "duplicate_fp", "other_fp", "missing_endpoints",
                      "conditional_median_error_px", "conditional_p95_error_px", "precision", "recall", "f1", "fn_plus_fp")
    return {
        "schema": "baomai-independent-postprocess-audit-v1", "status": "verified",
        "audit_script_sha256": sha256(Path(__file__)),
        "inference_source_revision": source["revision"], "inference_working_tree_status": source["working_tree_status"],
        "input_predictions_sha256": sha256(fresh / "predictions.jsonl"),
        "input_summary_sha256": sha256(fresh / "summary.json"),
        "input_per_image_sha256": sha256(fresh / "per_image.json"),
        "reference_images": 20, "grid_cells": 12, "prediction_records": 240,
        "per_image_scores_and_quality_exactly_reproduced": 240,
        "aggregate_metrics_and_quality_exactly_reproduced": 12,
        "historical_control_prediction_pairs_exactly_equal": control_pairs,
        "historical_source": {"zip": HISTORICAL_ZIP, "entry": HISTORICAL_ENTRY},
        "primary_confidence_metrics": [{field: row[field] for field in primary_fields}
                                       for row in metrics if row["threshold"] == 0.25],
        "guard_outcomes": [{key: row[key] for key in ("role", "nms_iou", "threshold", "passes_declared_gate")}
                           for row in comparisons],
        "nms_068_at_confidence_025": {
            "identical_matched_reference_prediction_records": identical_matches,
            "lost_or_gained_reference_matches": 0, "removed_predictions": removed_count,
            "added_predictions": added_count, "changed_images": len(changes),
            "fn_delta": candidate["fn"] - baseline["fn"], "fp_delta": candidate["fp"] - baseline["fp"],
            "duplicate_fp_delta": candidate["duplicate_fp"] - baseline["duplicate_fp"], "changes": changes},
        "lost_reference_rows_1based_at_confidence_025": lost_rows,
        "empty_image_settings_pairs_with_zero_predictions": len(empty_records),
        "replay_checked": args.replay is not None, "replay_files_exactly_equal": replay_files,
        "scope": "Fixed development-reference result; no training, model loading, new inference, or independent-test claim.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True, help="repository with recorded scorer bytes, reference images/labels, and historical ZIP")
    parser.add_argument("--results", type=Path, required=True, help="evidence directory containing fresh/")
    parser.add_argument("--replay", type=Path, help="optional replay directory containing the four comparison files")
    args = parser.parse_args()
    try:
        report = audit(args)
    except Exception as error:
        print(json.dumps({"schema": "baomai-independent-postprocess-audit-v1", "status": "failed",
                          "error_type": type(error).__name__, "error": str(error)}, indent=2, allow_nan=False))
        return 1
    print(json.dumps(report, indent=2, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
