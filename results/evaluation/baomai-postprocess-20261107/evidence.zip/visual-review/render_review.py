"""Reproduce selected raw-pixel/box figures; no model inference or label edits."""
from pathlib import Path
import argparse
import hashlib
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from PIL import Image

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--evidence', type=Path, required=True)
parser.add_argument('--output', type=Path)
args = parser.parse_args()
ROOT = args.root
EVIDENCE = args.evidence
OUT = args.output or EVIDENCE / 'visual-review'
OUT.mkdir(parents=True, exist_ok=True)

records = {}
for line in (EVIDENCE / 'fresh/predictions.jsonl').read_text().splitlines():
    rec = json.loads(line)
    if rec['record_type'] == 'prediction':
        records[rec['image_id'], rec['nms_iou'], rec['threshold']] = rec
scores = {(r['image_id'], r['nms_iou'], r['threshold']): r
          for r in json.loads((EVIDENCE / 'fresh/per_image.json').read_text())}
audit = json.loads((EVIDENCE / 'audit.json').read_text())

GREEN = '#10b981'
ORANGE = '#f59e0b'
PURPLE = '#b456f0'
BLUE = '#26b8ff'


def signature(pred):
    return json.dumps(pred, sort_keys=True, separators=(',', ':'))


def gold(image_id):
    result = []
    for i, line in enumerate((ROOT / 'data/labels/val' / f'{image_id}.txt').read_text().splitlines()):
        v = list(map(float, line.split()))
        cx, cy, w, h = v[1:5]
        result.append({'row': i + 1, 'bbox_xyxy': [1280 * (cx - w / 2), 720 * (cy - h / 2),
                                                  1280 * (cx + w / 2), 720 * (cy + h / 2)]})
    return result


def base(ax, image_id, crop, title):
    image = Image.open(ROOT / 'data/images/val' / f'{image_id}.png').convert('RGB')
    x0, y0, x1, y1 = crop
    ax.imshow(image, interpolation='nearest')
    ax.set_xlim(x0, x1)
    ax.set_ylim(y1, y0)
    ax.set_title(title, fontsize=10, loc='left')
    ax.tick_params(labelsize=7)
    ax.set_xlabel('Original-image x (px)', fontsize=8)
    ax.set_ylabel('y (px)', fontsize=8)


def box(ax, coords, color, label=None, style='-', width=1.5, label_xy=None):
    x0, y0, x1, y1 = coords
    ax.add_patch(Rectangle((x0, y0), x1 - x0, y1 - y0,
                           fill=False, edgecolor=color, linewidth=width, linestyle=style))
    if label is not None:
        ax.text(*(label_xy or (x0, y0)), label, color=color, fontsize=7,
                bbox={'facecolor': '#111111', 'alpha': .8, 'pad': 1, 'edgecolor': 'none'},
                va='bottom')


def iou(a, b):
    intersection = max(0., min(a[2], b[2]) - max(a[0], b[0])) * max(0., min(a[3], b[3]) - max(a[1], b[1]))
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - intersection
    return intersection / union if union else 0.


# The only two newly lost references at the primary confidence are narrow
# visible-front boxes beside the occluder. Draw only the four relevant model
# boxes, not a misleading attempt to reconstruct the complete pre-NMS pool.
image_id = 'new_000009'
crop = (578, 416, 690, 497)
g = gold(image_id)
p0 = records[image_id, .7, .25]['predictions']
fig, axes = plt.subplots(2, 3, figsize=(12, 7.2))
base(axes[0, 0], image_id, crop, 'Raw original pixels')
base(axes[0, 1], image_id, crop, 'Frozen reference boxes (not re-approved)')
for row in (49, 50, 51, 52):
    box(axes[0, 1], g[row - 1]['bbox_xyxy'], GREEN if row in (50, 51) else '#dddddd',
        f'G{row}', style='--', label_xy=(579, g[row - 1]['bbox_xyxy'][1] + 5))
selected = {53: (PURPLE, 'P53'), 58: (ORANGE, 'P58'),
            50: (PURPLE, 'P50'), 52: (ORANGE, 'P52')}
for ax, nms in zip([axes[0, 2], axes[1, 0], axes[1, 1], axes[1, 2]], [.7, .68, .6, .5]):
    base(ax, image_id, crop, f'NMS {nms:.2f}: selected output boxes')
    present = {signature(p) for p in records[image_id, nms, .25]['predictions']}
    for idx, (color, name) in selected.items():
        p = p0[idx]
        if signature(p) not in present:
            continue
        coords = p['bbox_xyxy']
        label_x = 660 if idx in (50, 53) else 579
        label_y = coords[1] + (3 if idx in (50, 53) else 9)
        box(ax, coords, color, f'{name} {p["confidence"]:.3f}', label_xy=(label_x, label_y))
fig.suptitle('new_000009: stricter NMS can retain a wider unmatched box and lose a narrower matched box', fontsize=12)
for ax in axes[0]:
    ax.set_xlabel('')
fig.text(.02, .02, 'Confidence 0.25. Orange: baseline matches (P58→G50, P52→G51). Purple: higher-confidence unmatched outputs.\n'
         'Indices P are zero-based in baseline JSONL; G are one-based label rows. Only four selected predictions are drawn. No corner estimates are inferred.', fontsize=8)
fig.tight_layout(rect=[0, .09, 1, .95])
fig.subplots_adjust(hspace=.25)
fig.savefig(OUT / 'new_000009-occlusion-nms.png', dpi=150)
plt.close(fig)

# An "other FP" is not necessarily a separate imaginary physical object: here
# its overlap with the frozen reference is below the matching gate even though
# a higher-confidence matched prediction covers the same image region.
image_id = 'new_000008'
crop = (675, 425, 900, 545)
g = gold(image_id)
p0 = records[image_id, .7, .25]['predictions']
fig, axes = plt.subplots(1, 3, figsize=(12, 3.9))
base(axes[0], image_id, crop, 'Raw original pixels')
base(axes[1], image_id, crop, 'NMS 0.70: selected reference/output boxes')
box(axes[1], g[16]['bbox_xyxy'], GREEN, 'G17', '--')
box(axes[1], p0[25]['bbox_xyxy'], PURPLE, 'P25 retained 0.831')
box(axes[1], p0[34]['bbox_xyxy'], ORANGE, 'P34 removed 0.402')
base(axes[2], image_id, crop, 'NMS 0.68: same matched output remains')
box(axes[2], g[16]['bbox_xyxy'], GREEN, 'G17', '--')
box(axes[2], p0[25]['bbox_xyxy'], PURPLE, 'P25 retained 0.831')
fig.suptitle('new_000008: one extra box removed beside the gripper; reference/matched output retained', fontsize=12)
fig.text(.02, .02, 'P34 is classified as other_FP: IoU with G17 = 0.455410. Its IoU with the retained P25 is 0.689612.\n'
         'These are recorded box relationships, not a certification of physical face bounds. Only selected predictions are drawn.', fontsize=8)
fig.tight_layout(rect=[0, .14, 1, .93])
fig.savefig(OUT / 'new_000008-gripper-nms.png', dpi=150)
plt.close(fig)

# Two border regions have changed prediction identity but unchanged FP count.
specs = [('new_000007', (690, 0, 840, 63), [51], [52], [38], 'duplicate_FP: one replaced by one'),
         ('new_000090', (1160, 630, 1280, 720), [50], [53], [47], 'other_FP: one replaced by one')]
fig, axes = plt.subplots(2, 3, figsize=(11.7, 6.8))
for row, (image_id, crop, removed, added, common, subtitle) in enumerate(specs):
    p0 = records[image_id, .7, .25]['predictions']
    pn = records[image_id, .68, .25]['predictions']
    base(axes[row, 0], image_id, crop, f'{image_id}: raw original pixels')
    base(axes[row, 1], image_id, crop, f'NMS 0.70; {subtitle}')
    base(axes[row, 2], image_id, crop, 'NMS 0.68; no net FP reduction here')
    for idx in common:
        box(axes[row, 1], p0[idx]['bbox_xyxy'], PURPLE)
        box(axes[row, 2], p0[idx]['bbox_xyxy'], PURPLE)
    for idx in removed:
        box(axes[row, 1], p0[idx]['bbox_xyxy'], ORANGE)
    for idx in added:
        box(axes[row, 2], pn[idx]['bbox_xyxy'], BLUE)
fig.suptitle('Border cases: changed boxes are not equivalent to fewer false detections', fontsize=12)
fig.text(.02, .02, 'Purple: common selected output. Orange: removed baseline output. Blue: newly surviving output.\n'
         'Saved boxes are postprocessed/clipped to the image; their overlap alone does not recover the pre-NMS geometry.', fontsize=8)
fig.tight_layout(rect=[0, .09, 1, .95])
fig.savefig(OUT / 'border-replacements-nms068.png', dpi=150)
plt.close(fig)

# Compact machine-readable review facts, all derived from the saved records.
metadata = {'scope': 'Selected-case visual and numerical review; no labels approved, no corners inferred, no inference or training.',
            'prediction_indices': 'zero-based in indicated NMS/confidence record',
            'reference_rows': 'one-based TXT row numbers',
            'confidence': .25, 'images': {}, 'changes_068': [], 'totals': []}
for image_id in ('new_000007', 'new_000008', 'new_000009', 'new_000090'):
    metadata['images'][image_id] = {}
    for kind, suffix in [('images', 'png'), ('labels', 'txt')]:
        path = ROOT / 'data' / kind / 'val' / f'{image_id}.{suffix}'
        metadata['images'][image_id][kind + '_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
    assert metadata['images'][image_id]['images_sha256'] == records[image_id, .7, .25]['image_sha256']
    assert metadata['images'][image_id]['labels_sha256'] == records[image_id, .7, .25]['label_sha256']
    b = scores[image_id, .7, .25]
    n = scores[image_id, .68, .25]
    old_matches = {m['gold_index']: records[image_id, .7, .25]['predictions'][m['prediction_index']] for m in b['matches']}
    new_matches = {m['gold_index']: records[image_id, .68, .25]['predictions'][m['prediction_index']] for m in n['matches']}
    assert old_matches == new_matches
    metadata['images'][image_id]['matched_predictions_identical'] = True
matched_count = 0
for (image_id, nms, threshold), b in scores.items():
    if nms != .7 or threshold != .25:
        continue
    n = scores[image_id, .68, .25]
    old_matches = {m['gold_index']: records[image_id, .7, .25]['predictions'][m['prediction_index']] for m in b['matches']}
    new_matches = {m['gold_index']: records[image_id, .68, .25]['predictions'][m['prediction_index']] for m in n['matches']}
    assert old_matches == new_matches
    matched_count += len(old_matches)
assert matched_count == 625
metadata['nms068_all_matched_predictions_identical_by_reference_object'] = matched_count
metadata['changes_068'] = [c for c in audit['changes'] if c['confidence'] == .25 and c['nms_iou'] == .68]
for nms in (.7, .68, .6, .5):
    rr = [r for (im, n, t), r in scores.items() if n == nms and t == .25]
    metadata['totals'].append({'nms_iou': nms, **{key: sum(r[key] for r in rr) for key in
                                                ('tp', 'fn', 'fp', 'duplicate_fp', 'other_fp', 'missing_endpoints')}})
metadata['lost_row_overlaps'] = [
    {'image_id': 'new_000009', 'gold_row': 51, 'removed_baseline_prediction_index': 52,
     'retained_higher_confidence_baseline_prediction_index': 50,
     'prediction_pair_iou': iou(records['new_000009', .7, .25]['predictions'][52]['bbox_xyxy'],
                                records['new_000009', .7, .25]['predictions'][50]['bbox_xyxy']),
     'lost_at_nms': [.6, .5]},
    {'image_id': 'new_000009', 'gold_row': 50, 'removed_baseline_prediction_index': 58,
     'retained_higher_confidence_baseline_prediction_index': 53,
     'prediction_pair_iou': iou(records['new_000009', .7, .25]['predictions'][58]['bbox_xyxy'],
                                records['new_000009', .7, .25]['predictions'][53]['bbox_xyxy']),
     'lost_at_nms': [.5]}]
metadata['source_files_sha256'] = {str(p.relative_to(EVIDENCE)): hashlib.sha256(p.read_bytes()).hexdigest()
                                 for p in (EVIDENCE / 'audit.json', EVIDENCE / 'fresh/predictions.jsonl', EVIDENCE / 'fresh/per_image.json')}
(OUT / 'visual-review-facts.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps({'created': [str(p) for p in OUT.glob('*.png')], 'facts': str(OUT / 'visual-review-facts.json')}))
