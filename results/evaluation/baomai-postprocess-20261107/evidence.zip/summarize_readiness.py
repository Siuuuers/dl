#!/usr/bin/env python3
"""Describe the baseline's existing development-reference errors; no inference."""
import argparse
import json
from pathlib import Path


def summarize(repo, evidence):
    scores = json.loads((evidence / 'fresh/per_image.json').read_text())
    selected = [x for x in scores if x['nms_iou'] == 0.70 and x['threshold'] == 0.25]
    assert len(selected) == 20
    cohorts = {n: {'objects': 0, 'misses': 0} for n in [2, 1, 0]}
    images = []
    for score in selected:
        rows = [line.split() for line in (repo / f"data/labels/val/{score['image_id']}.txt").read_text().splitlines() if line.strip()]
        assert len(rows) == score['gold_count']
        for index, row in enumerate(rows):
            assert len(row) == 11 and all(float(row[i]) in [0, 2] for i in [7, 10])
            n = sum(float(row[i]) == 2 for i in [7, 10])
            cohorts[n]['objects'] += 1
            cohorts[n]['misses'] += index in score['unmatched_gold_indices']
        images.append({k: score[k] for k in ['image_id', 'gold_count', 'fn', 'fp']})
    assert [(cohorts[n]['objects'], cohorts[n]['misses']) for n in [2, 1, 0]] == [(584, 14), (59, 15), (21, 10)]
    for cohort in cohorts.values():
        cohort['miss_rate'] = cohort['misses'] / cohort['objects']
    nonempty = [x for x in images if x['gold_count'] > 0]
    empty = [x for x in images if x['gold_count'] == 0]
    assert len(nonempty) == 17 and all(x['fn'] + x['fp'] > 0 for x in nonempty)
    assert len(empty) == 3 and all(x['fp'] == 0 for x in empty)
    top = sorted(images, key=lambda x: x['fn'] + x['fp'], reverse=True)[:2]
    return {'nms_iou': 0.70, 'box_confidence': 0.25, 'matching_iou': 0.50,
            'images': images, 'nonempty_images_with_matching_errors': len(nonempty),
            'empty_images_without_false_detections': len(empty),
            'reference_visible_corner_cohorts': cohorts,
            'one_or_no_corner_objects': 80, 'misses_in_those_objects': 25,
            'fraction_of_all_misses': 25 / 39,
            'two_images_with_most_fn_plus_fp': top,
            'interpretation': 'Association with reference corner availability, not proof of occlusion cause. Frozen labels are not fully visually certified. These are development-image results.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--evidence', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(summarize(args.repo, args.evidence), indent=2, allow_nan=False))
