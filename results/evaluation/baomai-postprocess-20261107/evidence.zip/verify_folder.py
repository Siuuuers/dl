#!/usr/bin/env python3
"""Compare saved label-free folder results with the fixed experiment's raw outputs."""
import argparse
import hashlib
import json
from pathlib import Path


def verify(root):
    grid = [json.loads(line) for line in (root / 'fresh/predictions.jsonl').read_text().splitlines()]
    assert grid[-1] == {'record_type': 'completion', 'status': 'complete', 'prediction_records': 240}
    predictions = {(r['image_id'], r['nms_iou'], r['threshold']): r
                   for r in grid if r['record_type'] == 'prediction'}
    commands = json.loads((root / 'folder-commands.json').read_text())
    assert commands['source_revision'] == '2c409f4fa7c16367b7895a8b021611a277c68a3c'
    assert not commands['working_tree_status']
    assert len(commands['commands']) == 2
    assert all(r['exit_code'] == 0 for r in commands['commands'])
    report = {'source_revision': commands['source_revision'], 'runs': []}
    for name, iou, expected_ids in [('068', 0.68, [7, 8, 9, 90]), ('default', 0.70, [7, 146])]:
        folder = root / f'folder-output-{name}'
        status = json.loads((folder / 'run_status.json').read_text())
        assert status['status'] == 'complete' and status['failed_images'] == 0
        assert status['selected_images'] == status['succeeded_images'] == len(expected_ids)
        assert status['ground_truth_available'] is False
        assert status['inference'] == {**grid[0]['inference_base'], 'iou': iou, 'conf': 0.25}
        assert status['source']['revision'] == commands['source_revision']
        assert not status['source']['working_tree_status']
        rows = [json.loads(line) for line in (folder / 'predictions.jsonl').read_text().splitlines()]
        assert [r['image'] for r in rows] == [f'new_{n:06}.png' for n in expected_ids]
        checked = []
        for row in rows:
            assert row['status'] == 'complete'
            reference = predictions[(Path(row['image']).stem, iou, 0.25)]
            raw = [{k: v for k, v in p.items() if k != 'endpoint_status'} for p in row['predictions']]
            assert raw == reference['predictions'], row['image']
            for key in ['image_sha256', 'width', 'height']:
                assert row[key] == reference[key]
            assert row['prediction_count'] == len(raw)
            # Inputs/overlays are optional in the compact archive; check originals when present.
            original = root / f'folder-input-{name}' / row['image']
            if original.exists():
                assert hashlib.sha256(original.read_bytes()).hexdigest() == row['image_sha256']
            checked.append({'image': row['image'], 'prediction_count': len(raw), 'raw_predictions_exactly_equal': True})
        assert status['prediction_count'] == sum(r['prediction_count'] for r in rows)
        report['runs'].append({'name': name, 'nms_iou': iou, 'status': 'complete', 'images': checked,
                               'source': status['source'], 'runtime': status['runtime']})
    report['all_six_complete_prediction_lists_exactly_equal'] = True
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(verify(args.evidence), indent=2, allow_nan=False))
