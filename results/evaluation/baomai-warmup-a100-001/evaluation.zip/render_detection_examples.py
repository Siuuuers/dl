"""Plot two fixed detection-gate examples using saved predictions and raw pixels."""

import argparse
import json
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.root / "scripts"))
    from evaluate_pose import preflight_dataset
    from pose_scoring import _box_iou
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    from matplotlib.patches import Rectangle
    from PIL import Image

    records = {r["id"]: r for r in preflight_dataset(args.root, require_weights=False)["records"]}
    labels = {"m0": "M0 · original", "control": "Control · bias 0.1", "warmup": "Warmup · bias 0.0001"}
    predictions, scores = {}, {}
    for model in labels:
        rows = [json.loads(line) for line in (args.evidence / model / "predictions.jsonl").read_text().splitlines()]
        predictions[model] = {(r["image_id"], r["threshold"]): r for r in rows[1:]}
        rows = json.loads((args.evidence / model / "per_image.json").read_text())
        scores[model] = {(r["image_id"], r["threshold"]): r for r in rows}
    cases = [("new_000010", 13, (563, 792, 418, 535)),
             ("new_000056", 3, (382, 581, 325, 425))]
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11})
    fig, axes = plt.subplots(2, 3, figsize=(13.5, 8.5))
    examples = []
    for row, (identifier, gold_index, crop) in enumerate(cases):
        record = records[identifier]
        gold = record["gold"][gold_index]
        original = Image.open(record["image_path"]).convert("RGB")
        for column, model in enumerate(labels):
            axis = axes[row, column]
            matched = next((m for m in scores[model][identifier, .25]["matches"]
                            if m["gold_index"] == gold_index), None)
            threshold = .15 if model == "warmup" and identifier == "new_000010" else .25
            candidates = predictions[model][identifier, threshold]["predictions"]
            chosen = (matched["prediction_index"] if matched is not None else
                      max(range(len(candidates)), key=lambda i: _box_iou(gold["bbox_xyxy"], candidates[i]["bbox_xyxy"])))
            prediction = candidates[chosen]
            overlap = _box_iou(gold["bbox_xyxy"], prediction["bbox_xyxy"])
            excluded = threshold != .25
            color = "#f59e0b" if excluded else "#ef0985"
            axis.imshow(original, interpolation="nearest")
            for box, box_color, style in ((gold["bbox_xyxy"], "#00db8b", "-"),
                                           (prediction["bbox_xyxy"], color, "--" if excluded else "-")):
                x1, y1, x2, y2 = box
                axis.add_patch(Rectangle((x1, y1), x2-x1, y2-y1, fill=False,
                                         edgecolor=box_color, linewidth=2, linestyle=style))
            for g, p in zip(gold["keypoints"], prediction["keypoints"]):
                if g[2] == 2:
                    axis.scatter([g[0]], [g[1]], s=42, facecolors="none", edgecolors="#00db8b", linewidths=1.6)
                    if p[2] >= .5:
                        axis.scatter([p[0]], [p[1]], s=38, marker="x", color=color, linewidths=1.7)
            axis.set_xlim(crop[0], crop[1])
            axis.set_ylim(crop[3], crop[2])
            status = "matched" if matched is not None else ("below confidence cut" if excluded else "below IoU gate")
            axis.set_title(f"{labels[model]} · {status}\nconfidence {prediction['confidence']:.3f} · IoU {overlap:.3f}", fontsize=11.5, pad=8)
            axis.set_xlabel("Original image X (px)")
            if column == 0:
                axis.set_ylabel(f"{identifier} · row {gold_index+1}\nOriginal image Y (px)")
            examples.append({"image_id": identifier, "reference_row_one_based": gold_index+1,
                             "model": model, "matched_at_primary": matched is not None,
                             "displayed_prediction_threshold": threshold, "prediction_index": chosen,
                             "confidence": prediction["confidence"], "iou": overlap,
                             "reference": gold, "prediction": prediction, "crop_xyxy": [crop[0],crop[2],crop[1],crop[3]]})
    legend = [Line2D([0],[0],color="#00db8b",lw=2,label="Frozen reference box"),
              Line2D([0],[0],color="#ef0985",lw=2,label="Prediction at primary 0.25"),
              Line2D([0],[0],color="#f59e0b",lw=2,ls="--",label="Prediction retained only in 0.15 diagnostic")]
    fig.legend(handles=legend,loc="lower center",bbox_to_anchor=(.5,.085),ncol=3,frameon=False,fontsize=10)
    fig.suptitle("Two reasons an object remains a miss",fontsize=19,fontweight="bold",y=.98)
    fig.text(.5,.035,"Primary rule remains box confidence 0.25 and matching IoU 0.50. Dashed box is excluded from that primary run.",ha="center",fontsize=10)
    fig.text(.5,.010,"Reference row 14 has no locatable gold corners. Row 4 has two; close corners do not bypass the box-matching gate.",ha="center",fontsize=10,color="#4b5563")
    fig.subplots_adjust(left=.072,right=.988,top=.88,bottom=.21,wspace=.15,hspace=.50)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    fig.savefig(args.output,dpi=160,facecolor="white")
    plt.close(fig)
    (args.evidence / "detection-visual-examples.json").write_text(json.dumps(examples,indent=2)+"\n")
    print(json.dumps([{k:v for k,v in item.items() if k not in ("reference","prediction","crop_xyxy")} for item in examples],indent=2))


if __name__ == "__main__":
    main()
