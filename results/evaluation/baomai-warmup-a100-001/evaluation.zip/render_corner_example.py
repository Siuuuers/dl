"""Render a fixed scientific comparison crop from saved predictions and original pixels."""

import argparse
import json
import math
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.root / "scripts"))
    from evaluate_pose import preflight_dataset
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from PIL import Image

    records = preflight_dataset(args.root, require_weights=False)["records"]
    record = next(r for r in records if r["id"] == "new_000058")
    gold_index, side = 12, 0
    gx, gy, _ = record["gold"][gold_index]["keypoints"][side]
    original = Image.open(record["image_path"]).convert("RGB")
    labels = {"m0": "M0 · original epoch173", "control": "Control · bias start 0.1", "warmup": "Warmup · bias start 0.0001"}
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 12})
    fig, axes = plt.subplots(1, 3, figsize=(13.8, 5.6), sharex=True, sharey=True)
    examples = []
    for axis, model in zip(axes, labels):
        per_image = json.loads((args.evidence / model / "per_image.json").read_text())
        scored = next(r for r in per_image if r["image_id"] == record["id"] and r["threshold"] == 0.25)
        match = next(p for p in scored["matches"] if p["gold_index"] == gold_index)
        saved = [json.loads(line) for line in (args.evidence / model / "predictions.jsonl").read_text().splitlines()]
        item = next(r for r in saved[1:] if r["image_id"] == record["id"] and r["threshold"] == 0.25)
        prediction = item["predictions"][match["prediction_index"]]
        px, py, confidence = prediction["keypoints"][side]
        error = math.hypot(px - gx, py - gy)
        axis.imshow(original, interpolation="nearest")
        axis.set_xlim(614, 678)
        axis.set_ylim(387, 329)
        axis.plot([gx, px], [gy, py], color="white", linewidth=2, zorder=4)
        axis.scatter([gx], [gy], facecolors="none", edgecolors="#00eb8f", linewidths=2.5, s=165, zorder=6, label="Frozen reference")
        axis.scatter([px], [py], color="#e90080", marker="x", linewidths=2.6, s=110, zorder=7, label="Model prediction")
        axis.set_title(f"{labels[model]}\nCorner error: {error:.2f} px", fontsize=13, pad=13)
        axis.set_xlabel("Original image X (px)")
        axis.set_xticks([620, 640, 660])
        axis.set_yticks([340, 360, 380])
        examples.append({"model": model, "image_id": record["id"], "gold_row_one_based": gold_index + 1,
                         "side": "left", "gold_xy": [gx, gy], "predicted_xy": [px, py],
                         "corner_error_px": error, "endpoint_confidence": confidence, "matching_iou": match["iou"]})
    axes[0].set_ylabel("Original image Y (px)")
    handles, names = axes[0].get_legend_handles_labels()
    fig.legend(handles, names, loc="lower center", bbox_to_anchor=(0.5, 0.102), ncol=2, frameon=False)
    fig.suptitle("The same corner after lowering bias warmup", x=0.5, y=0.985, fontsize=19, fontweight="bold")
    fig.text(0.5, 0.049, "new_000058 · reference row 13, left corner · identical crop and scale · box confidence 0.25", ha="center", fontsize=10.5)
    fig.text(0.5, 0.012, "Selected diagnostic example. Errors are against the unchanged annotation; no reference was edited.", ha="center", fontsize=10.5, color="#4b5563")
    fig.subplots_adjust(left=0.066, right=0.985, top=0.79, bottom=0.30, wspace=0.08)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.output, dpi=170, facecolor="white")
    plt.close(fig)
    (args.evidence / "visual-example.json").write_text(json.dumps(examples, indent=2) + "\n")
    print(json.dumps(examples, indent=2))


if __name__ == "__main__":
    main()
