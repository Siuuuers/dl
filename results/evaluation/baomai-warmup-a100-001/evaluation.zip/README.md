# Baomai bias-warmup evaluation evidence, 2026-11-07

This capsule preserves new inference and diagnostics for M0 epoch173, the fresh original-recipe control, and lower-bias warmup returned in https://github.com/Siuuuers/dl/pull/16.

The decision remains `retain-M0`. Warmup improves all five primary metrics against M0, but the predeclared requirement to pass against the fresh control also is not met: FN 37 versus 36. Full values and the exact rule are in `comparison.json`. Primary box confidence is 0.25, matching IoU 0.50, and endpoint confidence 0.50. Secondary box confidences remain 0.15 and 0.40.

## Source and original artifacts

- Original return: commit `dc388867bb3b59ab376c8cdc1875d96e1665f99d`, path `results/gpu/baomai-warmup-a100-001/baomai-warmup-results.zip`.
- Returned ZIP: 39,776,499 bytes, SHA-256 `2e8ca425c585a17468d8c651014e811681ccefe2a0f1a6a579a920178d560a6a`.
- Training and fresh inference source: clean `679b87b38e7b0bca5fbd02fb1519a90fb2379541`.
- Comparison replay source: clean `2f0260c19835fcd60eb2f12040b7c77ebd2ca890`.
- M0 SHA-256: `e0aab1b377491700318e0b14cd4c558ec3c1684087a13b7dde2298ebdbf2847e`.
- Control SHA-256: `3f617ec3f6b5ad89f1472c43546796459ff80d4cf3127e8466b16b5fb2512335`.
- Warmup SHA-256: `aab940375edc0f8915f6949e56e61c4805797e2cbeb8e6780ae7d5e5c94538bd`.

Model weights and original images are not duplicated here. The returned ZIP holds both final-epoch weights; M0 and the original validation PNGs are in the repository's Git LFS. The small `checkpoints` bundles preserve training receipts, manifests, CSVs and raw logs. Replay validates this provenance without deserializing a model. The original staged training-data payloads and the user's repaired notebook/constraints file were not returned.

## Replay without a machine-learning runtime

In a separate checkout of Siuuuers/dl, with this capsule extracted to `../baomai-warmup-evidence`:

```bash
git switch --detach 2f0260c19835fcd60eb2f12040b7c77ebd2ca890
git lfs pull --include='data/images/val/*.png' --exclude=''
python scripts/summarize_warmup_comparison.py \
  --root . --evidence ../baomai-warmup-evidence \
  --output ../baomai-warmup-recomputed.json
```

Use a new output path. The script deliberately refuses an existing result. It uses only the Python standard library, validates the frozen reference inputs, the correct schema-2 recipe roles, matched training provenance, complete run statuses and original prediction replay, then computes all primary and secondary comparisons. No training or inference is needed for this replay. With the same clean source, only `created_at_utc` and `command` should differ from `comparison.json`; using another source revision also changes the recorded comparison `source` identity.

`inventory.json` lists size and SHA-256 for every other file in this ZIP, excluding itself to avoid a recursive checksum. The surrounding repository also provides `evaluation.sha256` and `docs/warmup-comparison-verification-2026-11-07.json` for whole-archive integrity, fresh-restoration replay, and final publication checks.

## Contents and audit scope

`m0`, `control` and `warmup` contain the raw prediction records, per-image results, summaries and completed statuses. Their `-quality` directories contain the fixed diagnostic radii and per-image accounting. Each model contributes 60 image/threshold pairs. `execution.json`, six root logs and `runtime-freeze.txt` record the actual commands, runtime and timestamps. Automatically selected overlays are omitted because they are reproducible.

`return16-training-audit.json` independently verifies original archive integrity, recorded clean source, receipt hashes and the one-setting intervention. It also compares the historical control training CSV. Its scope excludes inference; the separate `warmup-historical-control-prediction-verification.json` verifies exact equality of all 60 fresh/historical control prediction records after ignoring only `stage_ms` and `predict_call_wall_ms`. No byte-identical checkpoint or tensor claim is made.

`warmup-summarizer-verification.json` records the positive development replay and two rejected altered-evidence probes. `return16-summarizer-review.json` independently recounts the 60 primary image/model pairs and same-endpoint/object-transition statistics. Those checks originally used the local development summary; the surrounding final verification records equivalence to the published-code result in `comparison.json`.

`warmup-object-transition-details.json` preserves all control-only object cases and the other lost/gained IDs. `gold_index` is zero-based; explicit one-based label-line fields identify rows for inspection. Best overlap is a diagnostic, not an alternative matching policy. A zero-overlap nearest-box tie-break does not imply that a prediction depicts the same object.

The notebook setup reproduction and initial fix proof preserve the original nested-program error and the two focused checks. `warmup-notebook-final-verification.json` connects that initial fix hash to the final notebook's status-only Markdown changes and confirms unchanged code cells and training pin. These checks use safe substitutes; they neither install packages nor run a GPU.

## Recreate the two scientific figures

With original validation PNGs available, use an environment with Pillow and Matplotlib:

```bash
python ../baomai-warmup-evidence/render_corner_example.py \
  --root . --evidence ../baomai-warmup-evidence \
  --output ../baomai-warmup-corner-comparison.png
python ../baomai-warmup-evidence/render_detection_examples.py \
  --root . --evidence ../baomai-warmup-evidence \
  --output ../baomai-warmup-detection-tradeoffs.png
```

These scripts use fixed cases, identical crops and actual reference/prediction coordinates. They also rewrite their deterministic `visual-example.json` and `detection-visual-examples.json` records. The first revisits the historical corner example. The second distinguishes a low-confidence occluded object from a box-IoU failure; its orange dashed box comes only from the secondary 0.15 run and is excluded at primary 0.25. Reference labels are never edited by these renderers.

This is a one-seed development-set comparison. It does not establish performance on independent scenes, physical accuracy, or grasp readiness.
