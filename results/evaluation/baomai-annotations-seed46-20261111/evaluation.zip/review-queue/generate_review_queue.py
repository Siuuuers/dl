#!/usr/bin/env python3
"""Build the fixed seed46 review queue from stored text evidence, without ML imports.

This script reads official comparison summaries, PR30 reference files and prior
review context. It does not change labels, rerun matching, or load checkpoints.
The independent case audit supplies detailed official-match diagnostics for the
three named transition cases. Outputs are deterministic for identical inputs.
"""

import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path


CONFIDENCE = 0.25
REFERENCE = Path("data/references/visible-front-2026-11-10")
REFERENCE_SHA = "edf2d01624b96d0a4e652b1fa1fdfbc861c453f825343c840972493a908e6ed2"
VARIANTS = ("m0", "seed45_control", "seed45_candidate", "seed46_control", "seed46_candidate")
SPECIAL = {
    ("new_000007", 15): "new_10px_pair_failure_vs_seed46_control",
    ("new_000008", 1): "primary_detection_loss_vs_seed46_control",
    ("new_000090", 43): "primary_detection_gain_vs_seed46_control",
}


def read_json(path):
    return json.loads(path.read_text())


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def geometry(line, width, height):
    values = [float(x) for x in line.split()]
    require(len(values) == 11 and all(math.isfinite(x) for x in values), "Invalid label schema")
    class_id, cx, cy, w, h = values[:5]
    points = []
    for start in (5, 8):
        x, y, v = values[start:start + 3]
        require(v in (0, 2), "Unexpected reference visibility state")
        require(v != 0 or (x == 0 and y == 0), "Noncanonical missing corner")
        points.append([x * width, y * height, int(v)])
    return {
        "class_id": int(class_id),
        "box_xyxy_px": [(cx - w / 2) * width, (cy - h / 2) * height,
                        (cx + w / 2) * width, (cy + h / 2) * height],
        "keypoints_xy_visibility": points,
        "locatable_corners": sum(p[2] == 2 for p in points),
    }


def primary_rows(summary, model, image_ids):
    selected = [r for r in summary["per_image"]
                if r["model_id"] == model and r["box_confidence"] == CONFIDENCE]
    require(len(selected) == len(image_ids), f"Incomplete primary {model} image set")
    require({r["image_id"] for r in selected} == image_ids, "Primary image identities differ")
    result = {}
    for row in selected:
        rows = row["revised"]["missed_label_rows_one_based"]
        require(len(rows) == len(set(rows)), "Duplicate missed reference row")
        require(len(rows) == row["revised"]["score"]["fn"], "Miss count does not equal row set")
        result[row["image_id"]] = set(rows)
    return result


def source_record(path, logical_name):
    return {"path": logical_name, "sha256": sha256(path), "size_bytes": path.stat().st_size}


def fmt_key(key):
    return f"{key[0]}:{key[1]}"


def build(args):
    repo = args.repo.resolve()
    manifest_path = repo / REFERENCE / "manifest.json"
    history_path = repo / "docs/persistent-failure-review-2026-11-10.json"
    amendment_doc = repo / "docs/reference-amendment-2026-11-10.md"
    require(sha256(manifest_path) == REFERENCE_SHA, "PR30 reference manifest bytes differ")
    manifest = read_json(manifest_path)
    history = read_json(history_path)
    summaries = {45: read_json(args.seed45_summary), 46: read_json(args.seed46_summary)}
    cases = read_json(args.case_details)
    require(cases["status"] == "verified-numeric-interpretation", "Unverified case audit")
    files = {f["image_id"]: f for f in manifest["files"]}
    image_ids = set(files)
    require(len(files) == 20, "Expected the fixed 20-image reference set")
    require(summaries[45]["models"]["m0"]["model_sha256"] ==
            summaries[46]["models"]["m0"]["model_sha256"], "Baseline weights differ")

    labels, reverse_maps = {}, {}
    for image_id, file in files.items():
        current = repo / REFERENCE / file["label_path"]
        original = repo / file["source_label_path"]
        image = repo / "data/images/val" / f"{image_id}.png"
        for path, digest in ((current, file["label_sha256"]),
                             (original, file["source_label_sha256"]),
                             (image, file["image_sha256"])):
            require(sha256(path) == digest, f"Input bytes differ: {path.name}")
        lines = current.read_text().splitlines()
        source_lines = original.read_text().splitlines()
        require(len(lines) == file["row_count"], "Revised row count differs")
        require(len(source_lines) == file["source_row_count"], "Original row count differs")
        mapping = file["retained_source_to_revised_row_one_based"]
        require(len(mapping) == len(source_lines), "Original/revised map length differs")
        reverse = {new: old for old, new in enumerate(mapping, 1) if new is not None}
        require(len(reverse) == sum(x is not None for x in mapping), "Nonunique row map")
        require(set(reverse) | set(file["added_revised_rows_one_based"]) == set(range(1, len(lines) + 1)),
                "Revised map does not cover the complete reference")
        labels[image_id] = lines
        reverse_maps[image_id] = reverse

    miss_sets = {}
    for seed, summary in summaries.items():
        require(summary["revised_reference"]["manifest_sha256"] == REFERENCE_SHA,
                f"Seed {seed} reference bytes differ")
        require(summary["revised_reference"]["files"] == manifest["files"],
                f"Seed {seed} reference inventory differs")
        require(summary["experiment"]["recipe_id"] == f"reviewed-annotations-seed{seed}-v1",
                "Unexpected training recipe")
        for model in ("m0", "m1", "m2"):
            miss_sets[(seed, model)] = primary_rows(summary, model, image_ids)
    require(miss_sets[(45, "m0")] == miss_sets[(46, "m0")], "Baseline primary miss sets differ")
    require(summaries[45]["experiment"]["candidate_manifest_sha256"] ==
            summaries[46]["experiment"]["candidate_manifest_sha256"], "Training overlays differ")

    variant_index = {
        "m0": (46, "m0"), "seed45_control": (45, "m1"), "seed45_candidate": (45, "m2"),
        "seed46_control": (46, "m1"), "seed46_candidate": (46, "m2"),
    }
    for mid in ("m0", "m1", "m2"):
        prediction_path = args.seed46_summary.parent / mid / "predictions.jsonl"
        require(sha256(prediction_path) == cases["input_files"][f"seed46_{mid}_predictions"]["sha256"],
                "Case audit prediction bytes differ from the current seed46 evidence")

    current_misses = {(image, row) for image, rows in miss_sets[(46, "m2")].items() for row in rows}
    require(len(current_misses) == 24, "This fixed queue expects exactly 24 primary candidate misses")
    objects = current_misses | set(SPECIAL)
    require(len(objects) == 26, "Unexpected duplicate or missing special-case object")
    prior = {(r["image_id"], r["source_row_one_based"]): r for r in manifest["queue_dispositions"]}
    prior_diagnosis = {(r["image_id"], r["label_row_one_based"]): r for r in history["rows"]}
    special_details = {(r["image_id"], r["row_one_based"]): r for r in cases["case_details"]
                       if r["reference"] == "revised" and (r["image_id"], r["row_one_based"]) in SPECIAL}
    require(set(special_details) == set(SPECIAL), "Special-case details missing")

    source_revision = summaries[46]["source"]["revision"]
    github = f"https://github.com/Siuuuers/dl/blob/{source_revision}"
    rows = []
    for image_id, row_no in sorted(objects):
        key = (image_id, row_no)
        file = files[image_id]
        original_no = reverse_maps[image_id].get(row_no)
        old_key = (image_id, original_no)
        previous = prior.get(old_key)
        old_diagnosis = prior_diagnosis.get(old_key)
        flags = {variant: row_no in miss_sets[variant_index[variant]][image_id] for variant in VARIANTS}
        is_current_miss = key in current_misses
        persistent = is_current_miss and all(flags.values())
        label_text = labels[image_id][row_no - 1]
        geom = geometry(label_text, file["width"], file["height"])
        roles = (["current_primary_candidate_miss"] if is_current_miss else [])
        if key in SPECIAL:
            roles.append(SPECIAL[key])
        tier = 1 if persistent else 2 if is_current_miss else 3
        record = {
            "object_id": fmt_key(key), "image_id": image_id,
            "reference_row_one_based": row_no, "original_row_one_based": original_no,
            "row_mapping_source": "PR30 manifest retained_source_to_revised_row_one_based (reversed)",
            "roles": roles, "priority_tier": tier,
            "priority_reason": ("Missed by all five compared model variants" if persistent else
                                "Current candidate miss with a changed match across variants" if is_current_miss else
                                "Paired localization or detection transition diagnostic"),
            "miss_flags": flags, "missed_by_variants_count": sum(flags.values()),
            "persistent_across_all_five_variants": persistent,
            "reference_geometry": geom,
            "reference_raw_label": label_text,
            "image": {"path": f"data/images/val/{image_id}.png", "sha256": file["image_sha256"],
                      "width": file["width"], "height": file["height"],
                      "url": f"{github}/data/images/val/{image_id}.png"},
            "reference_label": {"path": str(REFERENCE / file["label_path"]),
                                "sha256": file["label_sha256"],
                                "url": f"{github}/{REFERENCE / file['label_path']}#L{row_no}"},
            "original_label": {"path": file["source_label_path"], "sha256": file["source_label_sha256"]},
            "previous_queue_disposition": previous["disposition"] if previous else "not_in_previous_33_row_queue",
            "previous_reference_review": previous,
            "previous_diagnosis": ({k: old_diagnosis[k] for k in
                                    ("group", "observation", "next_action", "visual_review") if k in old_diagnosis}
                                   if old_diagnosis else None),
            "reference_edits": ([manifest["edits"][n - 1] for n in previous["edit_numbers_one_based"]]
                                if previous else []),
            "new_label_adjudication": False,
        }
        if key in SPECIAL:
            detail = special_details[key]
            require(detail["image_sha256"] == file["image_sha256"], "Case image differs")
            require(detail["locatable_corners"] == geom["locatable_corners"], "Case visibility differs")
            for actual, expected in zip(detail["reference_bbox_xyxy"], geom["box_xyxy_px"]):
                require(math.isclose(actual, expected, abs_tol=1e-9), "Case reference geometry differs")
            for actual_point, expected_point in zip(detail["reference_keypoints"], geom["keypoints_xy_visibility"]):
                require(all(math.isclose(a, b, abs_tol=1e-9) for a, b in zip(actual_point, expected_point)),
                        "Case reference corner coordinates differ")
            matched = detail["models_by_threshold"]["0.25"]
            for model, variant in (("m0", "m0"), ("m1", "seed46_control"), ("m2", "seed46_candidate")):
                require(matched[model]["matched"] != flags[variant], "Case match state disagrees with summary")
            record["current_prediction_context"] = matched
            if key == ("new_000007", 15):
                old_errors, new_errors = (matched[m]["visible_endpoint_errors_px"] for m in ("m1", "m2"))
                require(all(e is not None and e <= 10 for e in old_errors), "Control should pass the 10 px pair")
                require(any(e is not None and e > 10 for e in new_errors), "Candidate should fail the 10 px pair")
                record["diagnostic_note"] = (
                    "The officially matched candidate proposal returns both corners but exceeds 10 px on both. "
                    "A separate higher-IoU candidate proposal has slightly lower confidence and is unmatched. "
                    "Inspect duplicate/assignment competition and thin top-boundary geometry together. "
                    "Do not substitute the more favorable proposal into the official score.")
            elif key == ("new_000090", 43):
                record["diagnostic_note"] = (
                    "The primary gain crosses the fixed IoU 0.50 boundary narrowly. The reference bottom edge "
                    "was amended in PR30; unchanged edges and the missing right corner remain uncertified. "
                    "An additional benchmark match is not independent evidence of a newly discovered object.")
            else:
                record["diagnostic_note"] = (
                    "The candidate loses the control's primary box match on a previously unresolved top-clipped "
                    "reference. The control's matched right endpoint is below the 0.50 endpoint-confidence gate, "
                    "so this loss is not an additional lost returned visible endpoint. Preserve reference uncertainty.")
        record["next_review_action"] = (
            "Carry the existing unresolved decision forward. Review original pixels under the fixed visible-front "
            "policy only if a concrete boundary or identity question can be answered; preserve ambiguity otherwise. "
            "Use the phenotype to inspect analogous training supervision without moving validation rows into training."
            if previous and previous["disposition"] == "retained_unresolved" else
            "Inspect the original image first, then official match/duplicate/threshold behavior. For amended rows, "
            "retain the accepted correction and its residual limitations. Any further annotation change needs its "
            "own image-supported version; model disagreement or agreement is not an annotation verdict.")
        rows.append(record)

    rows.sort(key=lambda r: (r["priority_tier"], -r["missed_by_variants_count"],
                             r["previous_queue_disposition"] != "retained_unresolved",
                             r["image_id"], r["reference_row_one_based"]))
    for rank, row in enumerate(rows, 1):
        row["rank"] = rank
    misses = [r for r in rows if "current_primary_candidate_miss" in r["roles"]]
    prior_unresolved = {k for k, p in prior.items() if p["disposition"] == "retained_unresolved"}
    unresolved_misses = [r for r in misses if r["previous_queue_disposition"] == "retained_unresolved"]
    require({(r["image_id"], r["original_row_one_based"]) for r in unresolved_misses} == prior_unresolved,
            "Previous unresolved set does not exactly match current unresolved misses")
    counts = {
        "unique_queue_objects": len(rows), "current_primary_candidate_misses": len(misses),
        "persistent_across_five_variants": sum(r["persistent_across_all_five_variants"] for r in misses),
        "variable_current_misses": sum(not r["persistent_across_all_five_variants"] for r in misses),
        "previous_unresolved_rows_total": len(prior_unresolved),
        "previous_unresolved_rows_still_missed": len(unresolved_misses),
        "previous_unresolved_rows_missed_by_all_five": sum(r["persistent_across_all_five_variants"] for r in unresolved_misses),
        "current_misses_by_previous_disposition": dict(sorted(Counter(r["previous_queue_disposition"] for r in misses).items())),
        "current_misses_by_locatable_corners": dict(sorted(Counter(str(r["reference_geometry"]["locatable_corners"]) for r in misses).items())),
        "additional_unique_diagnostic_objects": len(rows) - len(misses),
        "primary_detection_loss_records": sum(SPECIAL[("new_000008", 1)] in r["roles"] for r in rows),
    }
    require(counts["persistent_across_five_variants"] == 21, "Unexpected persistence count")
    variants = {
        variant: {"summary_seed": seed, "model_id": mid,
                  "model_sha256": summaries[seed]["models"][mid]["model_sha256"]}
        for variant, (seed, mid) in variant_index.items()
    }
    return {
        "schema_version": 1, "kind": "seed46-targeted-error-review-queue",
        "status": "computed_from_stored_evidence_no_label_changes",
        "reference_id": manifest["reference_id"], "source_revision": source_revision,
        "settings": {"box_confidence": CONFIDENCE, "matching_iou": 0.50,
                     "endpoint_confidence": 0.50, "diagnostic_pair_radius_px": 10,
                     "corner_coordinate_system": "original image pixels",
                     "miss_definition": "No one-to-one reference match under the unchanged official scorer"},
        "inputs": {
            "seed45_summary": source_record(args.seed45_summary, "seed45/evidence/seed-45/comparison-original-and-pr30.json"),
            "seed46_summary": source_record(args.seed46_summary, "evidence/seed-46/comparison-original-and-pr30.json"),
            "case_details": source_record(args.case_details, "independent/seed46-case-details.json"),
            "reference_manifest": source_record(manifest_path, str(REFERENCE / "manifest.json")),
            "historical_diagnosis": source_record(history_path, "docs/persistent-failure-review-2026-11-10.json"),
            "reference_amendment_context": source_record(amendment_doc, "docs/reference-amendment-2026-11-10.md"),
            "generator": {"path": "review-queue/generate_review_queue.py", "sha256": sha256(Path(__file__))},
        },
        "variants": variants, "variant_order": list(VARIANTS),
        "ranking": "Persistent current misses first; then variable misses by number of missed variants; then separate transition diagnostics. Previously unresolved rows precede other rows within equal priority.",
        "counts": counts,
        "limits": [
            "Five related model variants are repeated comparisons on the same references, not five independent trials or confirmations of label truth.",
            "The same baseline is counted once after verifying identical primary missed-row sets in both seed summaries.",
            "The older 33-row diagnosis was assembled from different historical seed43/44 model variants. Its observations are context only; its old persistence flags are not reused here.",
            "The source PNGs and reference bytes are hash-verified. This queue generator performs no new visual adjudication and changes no labels.",
            "Prior unresolved labels remain unresolved. Persistent benchmark misses can involve reference identity or box-extent uncertainty.",
            "Seed45 used L4 and seed46 used A100 for training. Each control/candidate pair is matched internally; cross-seed changes are not attributable to seed alone.",
            "These validation views may be correlated and have been repeatedly inspected. They do not establish independent-scene reliability.",
            "10 px is a provisional Euclidean image-space tolerance per actual corner, not physical-unit or deployment certification; missing objects and one/zero-corner references are separate populations.",
        ],
        "recommendation": (
            "Keep epoch173 as the working default and stop seed searching. Use this queue for targeted supervision "
            "and error review: carry unresolved reference issues forward, inspect the small set of changed detections "
            "and duplicate/assignment behavior, and audit analogous training examples only for a specific remaining "
            "policy inconsistency. Any next intervention must be separately identified and justified from pixels. "
            "Do not request a seed47 sweep or alter reference labels to make predictions score better."),
        "rows": rows,
    }


def readme(data):
    counts = data["counts"]
    indexed = {r["object_id"]: r for r in data["rows"]}
    pair = indexed["new_000007:15"]["current_prediction_context"]
    old_pair = " / ".join(f"{v:.3f}" for v in pair["m1"]["visible_endpoint_errors_px"])
    new_pair = " / ".join(f"{v:.3f}" for v in pair["m2"]["visible_endpoint_errors_px"])
    gain = indexed["new_000090:43"]["current_prediction_context"]
    old_iou = gain["m1"]["highest_iou_prediction"]["iou"]
    new_iou = gain["m2"]["matched_prediction"]["iou"]
    lines = [
        "# Seed46 targeted review queue", "",
        "This queue contains **26 unique objects**: all **24 candidate misses** against the PR30 revised reference "
        "at confidence 0.25, one additional 10 px pair diagnostic, and one additional gained detection. "
        "The lost detection is already one of the 24 misses and appears only once.", "",
        "## What deserves attention", "",
        f"**{counts['persistent_across_five_variants']} of 24 misses persist across all five compared variants.** "
        "All **19 previously retained-unresolved reference rows** remain candidate misses; 18 of those are in the "
        "persistent group. The remaining misses are two previously amended rows (new_000008:33 and new_000009:57) "
        "and three rows outside the previous 33-row queue (new_000009:52, new_000011:61, new_000087:15).", "",
        "Five variants means epoch173 plus the seed45 and seed46 control/candidate pairs. These models and reused "
        "views are related; persistence is a review priority, not five independent trials or proof that a label is correct. "
        "The older diagnosis used the seed43/44 family; only its documented visual observations and PR30 dispositions "
        "are carried forward.", "",
        "The 24 current misses have " + ", ".join(f"{n} with {v} locatable " + ("corner" if v == "1" else "corners") for v, n in counts["current_misses_by_locatable_corners"].items()) + ". "
        "A high two-corner success rate therefore cannot summarize this miss queue.", "",
        "## Ranked objects", "",
        "M = missed by the fixed one-to-one reference matcher; D = matched. C = control; A = reviewed-annotation candidate. "
        "Rows are one-based **revised-reference rows**. The JSON also supplies the original row from the manifest map, "
        "exact box/corner coordinates, source hashes, visibility, prior reasoning and transition details.", "",
        "| Rank | Image:row | Tier | Locatable corners | M0 | C45 | A45 | C46 | A46 | Prior disposition / extra role |",
        "| ---: | --- | ---: | ---: | :---: | :---: | :---: | :---: | :---: | --- |",
    ]
    for row in data["rows"]:
        flags = " | ".join("M" if row["miss_flags"][v] else "D" for v in VARIANTS)
        prior = {"retained_unresolved": "Unresolved", "amended": "Amended", "not_in_previous_33_row_queue": "Outside prior queue"}[row["previous_queue_disposition"]]
        if len(row["roles"]) > 1 or not row["miss_flags"]["seed46_candidate"]:
            extras = {SPECIAL[("new_000008", 1)]: "detection loss", SPECIAL[("new_000007", 15)]: "10 px pair loss", SPECIAL[("new_000090", 43)]: "detection gain"}
            prior += "; " + ", ".join(extras[r] for r in row["roles"] if r in extras)
        lines.append(f"| {row['rank']} | {row['object_id']} | {row['priority_tier']} | {row['reference_geometry']['locatable_corners']} | {flags} | {prior} |")
    lines += [
        "", "Tier 1 contains the 21 persistent misses. Tier 2 contains three variable misses; tier 3 contains the two additional diagnostics.", "",
        "## Three paired transition cases", "",
        f"- **new_000007:15:** the official control match has corner errors **{old_pair} px**; the candidate match has "
        f"**{new_pair} px**. The candidate also returns a higher-IoU proposal at slightly lower confidence. The fixed "
        "confidence-ordered matcher selects the first proposal, so inspect duplicate/assignment competition together with "
        "top-boundary corner geometry. This is a detected-object localization diagnostic, not another detection miss.",
        "- **new_000008:1:** the candidate loses a control box match on an already unresolved top-clipped reference. "
        "The control's endpoint confidences are below 0.50, so the box-match loss does not create a further lost returned "
        "visible endpoint. This object is recorded once in tier 2.",
        f"- **new_000090:43:** the candidate gains a match as overlap moves from **IoU {old_iou:.6f} to {new_iou:.6f}** across the "
        "fixed 0.50 rule. PR30 amended this row's bottom edge. Preserve that correction and its residual uncertainty; "
        "the narrow score transition does not establish a newly discovered physical object.", "",
        "## Next work", "",
        data["recommendation"], "",
        "Start with original images and the existing annotation policy. For unresolved rows, record what question remains "
        "unanswerable from the available pixels instead of repeating a supposed correction. For clear targets, inspect whether "
        "the failure is due to box extent, confidence, duplicate assignment, occlusion or corner localization. Use those concrete "
        "phenotypes to review analogous examples in the existing training split. The prior eight-file training overlay has "
        "already been tested; repeating it with another seed does not resolve the identified supervision questions.", "",
        "No validation images enter training, no hidden corner coordinates are invented, and no reference is silently removed "
        "or changed based on predictions. Any future model-change claim needs an appropriate evaluation separate from repeatedly "
        "reviewed examples. Seed45 L4 versus seed46 A100 also prevents calling cross-seed differences a pure seed effect.", "",
        "## Reproduce", "",
        "The generator uses only the Python standard library, verifies all 20 original PNG and label hashes plus the revised "
        "labels and row mappings, and checks that the two M0 miss sets agree. It reads existing predictions only to verify "
        "their hashes against the independent case audit; it performs no inference, checkpoint loading or label edits.", "",
        "```bash", "python generate_review_queue.py \\",
        "  --repo /path/to/dl \\",
        "  --seed45-summary /path/to/seed45/evidence/seed-45/comparison-original-and-pr30.json \\",
        "  --seed46-summary /path/to/evidence/seed-46/comparison-original-and-pr30.json \\",
        "  --case-details /path/to/independent/seed46-case-details.json \\",
        "  --output /path/to/review-queue", "```", "",
        "The seed46 summary's sibling m0/m1/m2 directories must contain their predictions.jsonl files. "
        "Outputs are `review-queue.json` and this README. All source identities and the generator hash are recorded in the JSON. "
        "The queue is a read-only triage artifact and performs no new visual adjudication.", "",
    ]
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--seed45-summary", type=Path, required=True)
    parser.add_argument("--seed46-summary", type=Path, required=True)
    parser.add_argument("--case-details", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    data = build(args)
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "review-queue.json").write_text(json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False) + "\n")
    (args.output / "README.md").write_text(readme(data))
    print(json.dumps({"status": "generated", "counts": data["counts"],
                      "queue_sha256": sha256(args.output / "review-queue.json"),
                      "readme_sha256": sha256(args.output / "README.md")}, indent=2))


if __name__ == "__main__":
    main()
