"""Package and freshly replay the completed seed46 text evidence.

Only this packaging directory and a new detached replay worktree are written.
Saved-prediction replay and queue regeneration perform no model inference,
checkpoint loading or training.
"""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess
import sys
import time
import zipfile


WORK = Path('/workspace/scratch/e8c6ed25e3ab/seed46-work')
ROOT = Path('/workspace/scratch/e8c6ed25e3ab/dl')
REPLAY = Path('/workspace/scratch/e8c6ed25e3ab/dl-confirmation-replay')
PYTHON = WORK / 'runtime/venv/bin/python'
OUT = WORK / 'package'
PAYLOAD = OUT / 'payload'
EXTRACTED = OUT / 'fresh-extraction'
ARCHIVE = OUT / 'evaluation.zip'
SOURCE = 'e4bb7019bcffd80b08cab28c4877dd562ee1d796'
TREE = '39cc5696320384ce3f1679a70d3d5d51ceccd463'
RETURN = '8e8bb99cabcb44ed0ec0acd14db911aa44013fd8'
TRAINING = '23d7db97ca626f5591dbd26e699c0f23d318ee73'
RECIPE = 'reviewed-annotations-seed46-v1'
ALLOWED = {'.json', '.jsonl', '.csv', '.log', '.txt', '.md', '.py'}
commands = []


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def run(command, cwd=None, env=None):
    before = time.monotonic()
    started = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(command, cwd=cwd, env=env, text=True, capture_output=True)
    record = {'command': list(map(str, command)), 'cwd': str(cwd) if cwd else None,
              'started_at_utc': started, 'exit_code': result.returncode,
              'seconds': time.monotonic() - before, 'stdout': result.stdout,
              'stderr': result.stderr}
    commands.append(record)
    write(OUT / 'packaging-commands.json', commands)
    if result.returncode:
        raise RuntimeError(record)
    return result.stdout.strip()


def copy(source, relative):
    source = Path(source)
    relative = PurePosixPath(relative)
    assert source.is_file() and not source.is_symlink(), source
    assert not relative.is_absolute() and '..' not in relative.parts
    assert relative.suffix.lower() in ALLOWED, relative
    # Text-only payload: no camera pixels, model bytes, nested archives or caches.
    source.read_text(encoding='utf-8')
    destination = PAYLOAD / str(relative)
    destination.parent.mkdir(parents=True, exist_ok=True)
    assert not destination.exists()
    expected = sha(source)
    shutil.copyfile(source, destination)
    assert sha(source) == sha(destination) == expected


def semantic(value, root):
    """Normalize only explicit invocation/time/root-location fields."""
    value = json.loads(json.dumps(value))
    assert value['revised_reference']['root'] == str(root / 'data/references/visible-front-2026-11-10')
    assert value['procedure']['original_label_path_base'] == str(root)
    assert value['procedure']['revised_label_path_base'] == str(root / 'data/references/visible-front-2026-11-10')
    value['revised_reference']['root'] = '<REVISED_REFERENCE_ROOT>'
    value['procedure']['original_label_path_base'] = '<REPOSITORY_ROOT>'
    value['procedure']['revised_label_path_base'] = '<REVISED_REFERENCE_ROOT>'
    del value['created_at_utc']
    del value['command']
    return value


def main():
    assert sys.version_info[:3] == (3, 12, 14), sys.version
    assert os.path.samefile(sys.executable, PYTHON), sys.executable
    assert not any(p.exists() for p in (OUT, REPLAY))
    OUT.mkdir()
    PAYLOAD.mkdir()
    original_path = WORK / 'evidence/seed-46/comparison-original-and-pr30.json'
    original = read(original_path)
    independent = read(WORK / 'independent/seed46-numerical-audit.json')
    assert original['status'] == 'verified-descriptive-only'
    assert original['source']['revision'] == SOURCE
    assert original['source']['working_tree_status'] == ''
    assert original['experiment']['training_source']['revision'] == TRAINING
    assert original['experiment']['recipe_id'] == RECIPE
    assert original['experiment']['training_runtime']['device_name'] == 'NVIDIA A100-SXM4-40GB'
    assert run(['git', '-C', str(ROOT), 'rev-parse', 'HEAD']) == SOURCE
    assert run(['git', '-C', str(ROOT), 'rev-parse', 'HEAD^{tree}']) == TREE
    assert run(['git', '-C', str(ROOT), 'status', '--porcelain']) == ''
    assert independent['status'] == 'verified'
    assert independent['per_image_reference_evaluations_verified'] == 360
    assert independent['reference_specific_aggregates_verified'] == 18
    assert independent['official_comparison_sha256'] == sha(original_path)
    execution = read(WORK / 'execution.json')
    assert execution['status'] == 'complete'
    assert execution['source_revision'] == SOURCE
    assert execution['source_tree'] == TREE
    assert all(row['exit_code'] == 0 for row in execution['commands'])
    selected_independent = [
        'independent_annotation_score.py', 'interpret_seed46.py',
        'seed46-numerical-audit.json', 'seed46-case-details.json',
        'interpretation-summary.json', 'execution.json', 'case-details-run.log',
        'seed45-comparison.json', 'seed45-independent-numeric-audit.json',
    ]
    assert read(WORK / 'independent/interpretation-summary.json')['case_details_sha256'] == sha(WORK / 'independent/seed46-case-details.json')
    assert read(WORK / 'review-queue/verification.json')['status'] == 'verified'
    for path in sorted((WORK / 'evidence').rglob('*')):
        if path.is_file() and path.suffix != '.pt':
            copy(path, path.relative_to(WORK).as_posix())
    for name in ['execution.json', 'baseline-continuity.json', 'baseline-revised-continuity.json',
                 'archive-verification.json', 'original-pixel-review.json',
                 'alternate-proposal-diagnostics.json', 'decision-review.json']:
        copy(WORK / name, name)
    for path in sorted((WORK / 'audit').iterdir()):
        if path.is_file() and path.suffix in ALLOWED:
            copy(path, 'audit/' + path.name)
    for name in selected_independent:
        copy(WORK / 'independent' / name, 'independent/' + name)
    # Top-level runtime text only: never traverse the venv, caches or app config.
    for path in sorted((WORK / 'runtime').iterdir()):
        if path.is_file() and path.suffix in ALLOWED:
            copy(path, 'runtime/' + path.name)
    for name in ['generate_review_queue.py', 'review-queue.json', 'README.md', 'verification.json']:
        copy(WORK / 'review-queue' / name, 'review-queue/' + name)
    for path in sorted(WORK.glob('*.log')):
        copy(path, 'logs/' + path.name)
    # The separately reviewed publication report is external to this capsule.
    copy(WORK / 'run_evaluation.py', 'run_evaluation.py')
    copy(__file__, 'package_evidence.py')
    readme = '''# Reviewed-annotation seed46 confirmation evidence

Report date: 2026-11-11. Execution records use UTC.

This capsule preserves the completed evaluation of PR35's seed46 control and
reviewed-annotation candidate, together with a fresh epoch173 baseline. Both arms
completed 30 epochs from the same epoch173 initialization. Evaluation uses each
arm's final `last.pt`, not trainer-selected `best.pt`.

The fixed confirmation does not repeat a strict primary miss reduction against
the matched control: both miss 24 PR30 reference objects at confidence 0.25,
while extras decrease from 58 to 52. Seed45 and seed46 remain separate paired
comparisons. Epoch173 remains the working default. The completed result supports
targeted error/supervision review rather than another seed sweep.

## Identity and actual hardware

- GPU return: PR35, commit `8e8bb99cabcb44ed0ec0acd14db911aa44013fd8`.
- Return ZIP: 39,776,456 bytes; SHA-256 `df53683ccf6f266a605b2844f42a98e808f75686cfab09f14d680c9d061e8a91`.
- Training source: `23d7db97ca626f5591dbd26e699c0f23d318ee73`.
- Clean inference and replay source: `e4bb7019bcffd80b08cab28c4877dd562ee1d796`.
- Exact source tree: `39cc5696320384ce3f1679a70d3d5d51ceccd463`.
- Candidate manifest SHA-256: `28fc8f5da95605089d61fb062132200ed296c3a10b216f1a61dbda1798ea4ba7`.
- Recipe: `reviewed-annotations-seed46-v1`.
- Recipe SHA-256: `f18e0a813a1057e1b3ab3a44ea3ce9b2a3e7673cc2bf04ca09b394bfdd8c51b8`.
- Three fresh model runs, 180 unique image/model/threshold records, 360 per-image
  reference evaluations, and 18 reference-specific aggregates.
- Original and PR30 revised references are reported separately. The latter has
  661 objects, 1,228 locatable endpoints and 584 two-corner-eligible objects.

The returned training receipts identify **NVIDIA A100-SXM4-40GB** for both seed46
arms, with identical recorded runtimes and backend settings within the pair.
The PR describes later L4 sessions restoring and packaging completed Drive arms;
those sessions are not additional L4 training or partial-training resumption.
The PR34 notebook's completed-arm restoration path returns before training and
preserves the source, recipe and final-checkpoint checks.

Seed45 trained on L4. The paired comparisons remain internally matched, but
cross-seed differences cannot be attributed to seed alone because hardware also
changed. Remote receipts and notebook consistency are evidence of provenance,
not independent hardware or clock attestation. The separate resource-trial
receipt/log was not returned and is not independently reconstructed.

## Archive contents and omissions

Every ZIP member is a regular UTF-8 text file. `inventory.json` hashes and sizes
every other payload file and deliberately excludes itself. ZIP member names,
file types, UTF-8 decoding, CRCs, sizes and hashes are checked before fresh
extraction. The archive contains no original camera pixels, model weights,
returned GPU archive, virtual environment, package cache or application config.
The weights remain in PR35; their byte validation is recorded in the return audit.

The independent publication report review is intentionally external to this
capsule. Early `seed46-case-analysis.json` and `interpretation-run.log` are omitted;
the final `seed46-case-details.json`, interpretation summary and execution record
are preserved. `independent/seed45-comparison.json` retains the exact prior summary
for cross-seed interpretation and queue regeneration. Replaying seed45 itself
requires its earlier capsule and its own pinned source; its predictions are not
duplicated here.

## Replay the complete official summary

The recorded replay uses **Python 3.12.14**. Saved-prediction scoring uses only the
standard library and performs no training, inference or weight loading. Extract
the ZIP into a fresh directory, then obtain a clean pinned checkout and original
images through Git LFS:

```bash
GIT_LFS_SKIP_SMUDGE=1 git clone https://github.com/Siuuuers/dl.git dl-replay
GIT_LFS_SKIP_SMUDGE=1 git -C dl-replay checkout --detach e4bb7019bcffd80b08cab28c4877dd562ee1d796
git -C dl-replay lfs pull --include='data/images/**' --exclude=''
python dl-replay/scripts/rescore_annotation_comparison.py \\
  --root dl-replay \\
  --evidence /absolute/path/to/extracted/evidence/seed-46 \\
  --candidate data/candidates/annotations-2026-11-10/manifest.json \\
  --recipe reviewed-annotations-seed46-v1 \\
  --reference-dir dl-replay/data/references/visible-front-2026-11-10 \\
  --evaluation-revision e4bb7019bcffd80b08cab28c4877dd562ee1d796 \\
  --output /absolute/path/to/new-comparison.json
```

The output path must not exist. Keep the checkout clean and use this exact source:
the strict receipt/source audit checks script bytes, not just compatible behavior.
The verified fresh extraction used a new detached worktree, all 157 original PNGs
hash-verified and hardlinked from the original checkout, and a normal LFS clean
filter stat refresh. The index had to remain the exact source tree, with empty
Git status before and after replay.

Compare the complete replay output with
`evidence/seed-46/comparison-original-and-pr30.json`. Exclude only the top-level
`/created_at_utc` and `/command`. Check the actual original and new root values
before normalizing exactly these three fields:

- `/revised_reference/root`: `<REVISED_REFERENCE_ROOT>`.
- `/procedure/original_label_path_base`: `<REPOSITORY_ROOT>`.
- `/procedure/revised_label_path_base`: `<REVISED_REFERENCE_ROOT>`.

All remaining fields must match exactly, including every numerical result,
source identity, stored runtime, prediction timing and training timestamp. There
is **no numerical tolerance and no recursive removal of similarly named fields**.
The `semantic` function in `package_evidence.py` implements these checked rules.
The external `verification.json` records the fresh extraction, exact equality and
all exclusions; `packaging-commands.json` preserves the local execution transcript.

## Fresh M0 continuity is a different comparison

Fresh seed46 M0 uses the same epoch173 checkpoint and recorded CPU runtime as the
earlier M0 run, but its floating-point prediction payload is not bitwise identical.
The largest box-coordinate and keypoint-coordinate changes are each
**0.0001220703125 px**. Prediction counts/order, endpoint-availability flags and
discrete scoring/quality outcomes are preserved. Some conditional error quantiles
change by small amounts. These observations are documented separately in
`baseline-continuity.json` and `baseline-revised-continuity.json`.

Those measured differences between separate inference executions do not relax the
archive replay check: rescoring the exact newly stored predictions must reproduce
the full current summary exactly under the limited metadata rules above.

## Independent numerical scoring and case interpretation

`independent/independent_annotation_score.py` independently implements label
parsing, direct-area IoU, confidence-ordered one-to-one matching, endpoint
availability, Euclidean errors and quantiles with the standard library. It imports
no production matching or scoring functions:

```bash
python /absolute/path/to/extracted/independent/independent_annotation_score.py \\
  --root dl-replay \\
  --evidence /absolute/path/to/extracted/evidence/seed-46 \\
  --reference-dir dl-replay/data/references/visible-front-2026-11-10 \\
  --official-comparison /absolute/path/to/extracted/evidence/seed-46/comparison-original-and-pr30.json \\
  --output /absolute/path/to/new-independent-audit.json
python /absolute/path/to/extracted/independent/interpret_seed46.py \\
  --root dl-replay \\
  --evidence /absolute/path/to/extracted/evidence/seed-46 \\
  --reference-dir dl-replay/data/references/visible-front-2026-11-10 \\
  --audit /absolute/path/to/extracted/independent/seed46-numerical-audit.json \\
  --seed45-summary /absolute/path/to/extracted/independent/seed45-comparison.json \\
  --output /absolute/path/to/new-case-details.json
```

The preserved independent audit agrees on all counts and identities across all
360 per-image reference evaluations and 18 aggregates. Its largest arithmetic
difference from production is **1.099120794378905e-14**; this independently written
calculation permits 1e-10 absolute arithmetic tolerance. That separate tolerance
does not apply to the exact official replay.

## Regenerate the targeted review queue

```bash
python /absolute/path/to/extracted/review-queue/generate_review_queue.py \\
  --repo dl-replay \\
  --seed45-summary /absolute/path/to/extracted/independent/seed45-comparison.json \\
  --seed46-summary /absolute/path/to/extracted/evidence/seed-46/comparison-original-and-pr30.json \\
  --case-details /absolute/path/to/extracted/independent/seed46-case-details.json \\
  --output /absolute/path/to/new-review-queue
```

This deterministically produces `review-queue.json` and its README from verified
source bytes, stored miss sets, the PR30 row map and final case details. The fresh
extraction also regenerates both files byte-for-byte. It does not adjudicate labels.

The queue contains all **24 current candidate misses** plus two separate diagnostic
objects, with the paired detection loss attached to its existing miss record:
**26 unique objects** in total. Of the misses, **21** persist across the five related
M0/seed45/seed46 model variants, and all **19 previously unresolved reference rows**
remain misses. These variants are not independent trials or evidence of label truth.
The 24 misses include eight zero-corner, ten one-corner and six two-corner references;
18 of them lie outside the complete-pair metric's population.

## Layout and practical limits

- `evidence/seed-46/`: saved predictions, scores, quality results, complete summary,
  and small training/checkpoint evidence bundles with receipts and logs.
- `audit/`: archive, source, training, runtime and notebook-persistence review.
- `independent/`: final independent scorer, case code/results and prior seed45 summary.
- `review-queue/`: reproducible ranked objects, prior uncertainty and special cases.
- `runtime/`: text dependency records, probes and continuity script only.
- `original-pixel-review.json`: recorded inspection of original images.
- `alternate-proposal-diagnostics.json`: official versus alternate proposal details.
- `decision-review.json`: decision context and qualifications.
- `execution.json`, `logs/`: actual evaluation commands, exits and outputs.
- `run_evaluation.py`, `package_evidence.py`: exact orchestration sources.

Original scratch paths in execution records are retained as provenance; use the
portable commands above for a new workspace. This text capsule cannot redo weight
hash checks without separately obtaining the returned weights. No new inference,
training, checkpoint loading or reference annotation changes occur during replay.

These 20 repeatedly used development images and their endpoints are not independent
test trials. Small paired effects do not establish generalization or statistical
significance. Ten pixels is a provisional Euclidean radius in the original image,
not a calibrated physical tolerance. Reference ambiguity remains explicit; predictions
do not settle object identity or hidden corner locations. Old box-only training
interventions are not pooled into the present matched-pair result.
'''
    (PAYLOAD / 'README.md').write_text(readme)
    (OUT / 'README.md').write_text(readme)
    inventory = {p.relative_to(PAYLOAD).as_posix(): {'size_bytes': p.stat().st_size, 'sha256': sha(p)}
                 for p in sorted(PAYLOAD.rglob('*')) if p.is_file()}
    write(PAYLOAD / 'inventory.json', {'schema_version': 1, 'payload_files': inventory,
          'inventory_self_excluded': True, 'all_payload_files_text': True,
          'model_weights_included': False, 'camera_images_included': False})
    with zipfile.ZipFile(ARCHIVE, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(PAYLOAD.rglob('*')):
            if path.is_file():
                info = zipfile.ZipInfo(path.relative_to(PAYLOAD).as_posix(), (2026, 11, 11, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.create_system = 3
                info.external_attr = (stat.S_IFREG | 0o644) << 16
                archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(ARCHIVE) as archive:
        infos = archive.infolist()
        names = [info.filename for info in infos]
        assert len(names) == len(set(names)) == len(inventory) + 1
        assert set(names) == set(inventory) | {'inventory.json'}
        assert archive.testzip() is None
        EXTRACTED.mkdir()
        for info in infos:
            relative = PurePosixPath(info.filename)
            assert not relative.is_absolute() and '..' not in relative.parts and '\\' not in info.filename
            assert relative.as_posix() == info.filename and not (info.flag_bits & 1)
            assert stat.S_ISREG(info.external_attr >> 16) and not info.is_dir()
            assert relative.suffix.lower() in ALLOWED
            data = archive.read(info)
            data.decode('utf-8')
            if info.filename != 'inventory.json':
                assert len(data) == inventory[info.filename]['size_bytes']
                assert hashlib.sha256(data).hexdigest() == inventory[info.filename]['sha256']
            destination = EXTRACTED / info.filename
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open('xb') as stream:
                stream.write(data)
        assert read(EXTRACTED / 'inventory.json') == read(PAYLOAD / 'inventory.json')
    for relative, expected in inventory.items():
        assert sha(EXTRACTED / relative) == expected['sha256']
    run(['git', '-C', str(ROOT), 'worktree', 'add', '--detach', str(REPLAY), SOURCE],
        env={**os.environ, 'GIT_LFS_SKIP_SMUDGE': '1'})
    assert run(['git', '-C', str(REPLAY), 'rev-parse', 'HEAD']) == SOURCE
    assert run(['git', '-C', str(REPLAY), 'rev-parse', 'HEAD^{tree}']) == TREE
    hydrated = []
    for row in read(ROOT / 'data/manifest.json')['records']:
        relative = 'data/' + row['image']
        source, destination = ROOT / relative, REPLAY / relative
        assert sha(source) == row['image_sha256']
        assert not source.is_symlink() and source.is_file()
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            destination.unlink()
        os.link(source, destination)
        assert sha(destination) == row['image_sha256']
        hydrated.append({'path': relative, 'sha256': row['image_sha256']})
    assert len(hydrated) == 157
    # Refresh the stat cache through the normal LFS clean filter after manual hydration.
    # The resulting index must remain the exact original tree; no data change is accepted.
    run(['git', '-C', str(REPLAY), 'add', '--renormalize', '--sparse', '--', 'data/images'])
    assert run(['git', '-C', str(REPLAY), 'write-tree']) == TREE
    before = run(['git', '-C', str(REPLAY), 'status', '--porcelain'])
    assert before == '', before
    output = OUT / 'replayed-comparison.json'
    run([str(PYTHON), str(REPLAY / 'scripts/rescore_annotation_comparison.py'),
         '--root', str(REPLAY), '--evidence', str(EXTRACTED / 'evidence/seed-46'),
         '--candidate', 'data/candidates/annotations-2026-11-10/manifest.json',
         '--recipe', RECIPE,
         '--reference-dir', str(REPLAY / 'data/references/visible-front-2026-11-10'),
         '--evaluation-revision', SOURCE, '--output', str(output)], cwd=REPLAY)
    assert semantic(original, ROOT) == semantic(read(output), REPLAY)
    regenerated_queue = OUT / 'replayed-review-queue'
    run([str(PYTHON), str(EXTRACTED / 'review-queue/generate_review_queue.py'),
         '--repo', str(REPLAY),
         '--seed45-summary', str(EXTRACTED / 'independent/seed45-comparison.json'),
         '--seed46-summary', str(EXTRACTED / 'evidence/seed-46/comparison-original-and-pr30.json'),
         '--case-details', str(EXTRACTED / 'independent/seed46-case-details.json'),
         '--output', str(regenerated_queue)], cwd=EXTRACTED)
    for name in ['review-queue.json', 'README.md']:
        assert (regenerated_queue / name).read_bytes() == (EXTRACTED / 'review-queue' / name).read_bytes()
    after = run(['git', '-C', str(REPLAY), 'status', '--porcelain'])
    assert after == '', after
    assert run(['git', '-C', str(REPLAY), 'write-tree']) == TREE
    assert run(['git', '-C', str(ROOT), 'status', '--porcelain']) == ''
    sidecar = OUT / 'evaluation.zip.sha256'
    sidecar.write_text(sha(ARCHIVE) + '  evaluation.zip\n')
    verification = {'schema_version': 1, 'kind': 'reviewed-annotation-seed46-evidence-verification',
        'status': 'PASS', 'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'archive': {'path': 'evaluation.zip', 'size_bytes': ARCHIVE.stat().st_size,
            'sha256': sha(ARCHIVE), 'members': len(inventory) + 1,
            'verified_payload_files': len(inventory), 'safe_unique_regular_paths': True,
            'crc_valid': True, 'all_hashes_and_sizes_match': True, 'all_payloads_utf8_text': True,
            'camera_images_included': False, 'model_weights_included': False,
            'returned_gpu_zip_included': False, 'runtime_venv_cache_or_config_included': False,
            'independent_publication_report_review_included': False,
            'inventory_sha256': sha(PAYLOAD / 'inventory.json')},
        'return_revision': RETURN, 'training_source_revision': TRAINING,
        'recipe': RECIPE,
        'source': original['source'], 'model_sha256': {k: v['model_sha256'] for k, v in original['models'].items()},
        'evaluation_scope': {'fresh_model_inferences': 3, 'unique_prediction_records': 180,
            'per_image_reference_evaluations': 360, 'reference_specific_aggregates': 18,
            'seed': 46, 'other_training_interventions_pooled': False},
        'fresh_extraction_and_replay': {'source_revision': SOURCE, 'source_tree': TREE,
            'working_tree_before': before, 'working_tree_after': after,
            'hydrated_original_pngs': len(hydrated),
            'hydration': 'Hash-verified original bytes, hardlinked without alteration.',
            'hydrated_image_inventory': hydrated,
            'source_data_manifest_sha256': sha(ROOT / 'data/manifest.json'),
            'lfs_stat_refresh': 'git add --renormalize --sparse -- data/images; index tree required unchanged',
            'executions': 1, 'python': sys.version.split()[0], 'complete_semantics_equal': True,
            'numeric_tolerance': None, 'excluded_json_paths': ['/created_at_utc', '/command'],
            'normalized_checked_root_paths': ['/revised_reference/root',
                '/procedure/original_label_path_base', '/procedure/revised_label_path_base'],
            'original_comparison_sha256': sha(original_path), 'replayed_comparison_sha256': sha(output),
            'inference_or_weight_loading_performed': False},
        'fresh_queue_regeneration': {
            'executions': 1, 'byte_identical_files': ['review-queue.json', 'README.md'],
            'queue_sha256': sha(regenerated_queue / 'review-queue.json'),
            'readme_sha256': sha(regenerated_queue / 'README.md'),
            'counts': read(regenerated_queue / 'review-queue.json')['counts'],
            'label_adjudication_or_changes_performed': False},
        'independent_numerical_audit': {key: independent[key] for key in ['status',
            'per_image_reference_evaluations_verified', 'reference_specific_aggregates_verified', 'method']},
        'packaging_script_sha256': sha(__file__), 'commands': commands,
        'limits': ['A replay verifies saved evidence, not new model inference.',
            'Original weights remain in PR35; the preserved return audit checked their bytes.',
            'Seed46 A100 and seed45 L4 internally matched pairs are separate comparisons; cross-seed differences are not attributable to seed alone.',
            'Fresh M0 predictions have tiny floating-point differences from the prior run; exact discrete outcomes do not mean bitwise inference identity.',
            'The current saved-prediction replay is exact after only the documented metadata exclusions and checked root normalizations.',
            'Repeated development images, related model variants and unresolved references do not establish independent-test generalization or physical deployment tolerance.',
            'The independent publication report review is intentionally external to this capsule.']}
    write(OUT / 'verification.json', verification)
    print(json.dumps({'status': 'PASS', 'archive_sha256': sha(ARCHIVE),
        'archive_size_bytes': ARCHIVE.stat().st_size, 'members': len(inventory) + 1,
        'complete_semantics_equal': True, 'queue_byte_identical': True,
        'readme_sha256': sha(OUT / 'README.md'),
        'verification_sha256': sha(OUT / 'verification.json')}))


if __name__ == '__main__':
    main()
