"""Compare saved fresh M0 outputs across the seed45 and seed46 studies."""

from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path


WORK = Path('/workspace/scratch/e8c6ed25e3ab/seed46-work')
OLD = WORK / 'seed45-capsule/evidence/seed-45'
NEW = WORK / 'evidence/seed-46'
INPUTS = {}
TIMING = {'stage_ms', 'predict_call_wall_ms'}
AGGREGATE_TIMING = {'mean_stage_ms', 'mean_predict_call_wall_ms'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    INPUTS[str(path)] = sha(path)
    return json.loads(path.read_text())


def lines(path):
    INPUTS[str(path)] = sha(path)
    return [json.loads(line) for line in path.read_text().splitlines()]


def iou(a, b):
    inter = max(0.0, min(a[2], b[2]) - max(a[0], b[0])) * max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    denominator = (a[2]-a[0])*(a[3]-a[1]) + (b[2]-b[0])*(b[3]-b[1]) - inter
    return inter / denominator if denominator else 0.0


def returned(point, width, height):
    x, y, conf = point
    return conf >= .5 and x is not None and y is not None and math.isfinite(x) and math.isfinite(y) and 0 <= x < width and 0 <= y < height


def numerical_differences(a, b, path=''):
    if isinstance(a, dict):
        assert isinstance(b, dict) and set(a) == set(b), path
        result = []
        for key in a:
            result.extend(numerical_differences(a[key], b[key], path + '/' + str(key)))
        return result
    if isinstance(a, list):
        assert isinstance(b, list) and len(a) == len(b), path
        result = []
        for index, (x, y) in enumerate(zip(a, b)):
            result.extend(numerical_differences(x, y, path + '/' + str(index)))
        return result
    if a == b:
        return []
    assert isinstance(a, (int, float)) and isinstance(b, (int, float)), (path, a, b)
    return [{'path': path, 'old': a, 'new': b, 'new_minus_old': b-a}]


def main():
    old_lines, new_lines = (lines(root / 'm0/predictions.jsonl') for root in (OLD, NEW))
    old_header, new_header = old_lines[0], new_lines[0]
    old_records, new_records = old_lines[1:], new_lines[1:]
    assert len(old_records) == len(new_records) == 60
    key = lambda r: (r['image_id'], r['threshold'])
    assert [key(row) for row in old_records] == [key(row) for row in new_records]
    assert len({key(row) for row in old_records}) == 60
    for field in ['model_sha256', 'manifest_sha256', 'model_card_sha256', 'images', 'inference', 'box_confidences', 'runtime']:
        assert old_header[field] == new_header[field], field
    groups = {name: {'number_compared': 0, 'number_changed': 0, 'maximum_absolute_difference': 0.0,
                     'maximum_difference_location': None}
              for name in ['bbox_coordinate_px', 'keypoint_coordinate_px', 'detection_confidence', 'keypoint_confidence']}
    exact_records = []
    changed_records = []
    prediction_count = 0
    exact_predictions = 0
    minimum_corresponding_iou = 1.0
    minimum_geometric_winner_margin = 1.0
    max_keypoint_shift = {'euclidean_px': 0.0, 'location': None}

    def add(name, old, new, location):
        assert type(old) in (int, float) and type(new) in (int, float)
        assert math.isfinite(old) and math.isfinite(new)
        row = groups[name]
        row['number_compared'] += 1
        difference = abs(new-old)
        row['number_changed'] += difference != 0
        if difference > row['maximum_absolute_difference']:
            row['maximum_absolute_difference'] = difference
            row['maximum_difference_location'] = {**location, 'old': old, 'new': new,
                                                   'new_minus_old': new-old}

    for old, new in zip(old_records, new_records):
        identity = {'image_id': old['image_id'], 'threshold': old['threshold']}
        assert {k:v for k,v in old.items() if k not in TIMING | {'predictions'}} == {
            k:v for k,v in new.items() if k not in TIMING | {'predictions'}}
        assert len(old['predictions']) == len(new['predictions'])
        if {k:v for k,v in old.items() if k not in TIMING} == {k:v for k,v in new.items() if k not in TIMING}:
            exact_records.append(identity)
        else:
            changed_records.append(identity)
        for index, (a, b) in enumerate(zip(old['predictions'], new['predictions'])):
            location = {**identity, 'prediction_index': index}
            prediction_count += 1
            exact_predictions += a == b
            assert a['class_id'] == b['class_id']
            assert set(a) == set(b) == {'class_id', 'bbox_xyxy', 'confidence', 'keypoints'}
            overlaps = [iou(a['bbox_xyxy'], item['bbox_xyxy']) for item in new['predictions']]
            winner = max(range(len(overlaps)), key=overlaps.__getitem__)
            assert winner == index, (identity, index, winner)
            ordered = sorted(overlaps, reverse=True)
            assert len(ordered) == 1 or ordered[0] > ordered[1]
            minimum_corresponding_iou = min(minimum_corresponding_iou, overlaps[index])
            if len(ordered) > 1:
                minimum_geometric_winner_margin = min(minimum_geometric_winner_margin, ordered[0]-ordered[1])
            for axis, (x, y) in enumerate(zip(a['bbox_xyxy'], b['bbox_xyxy'])):
                add('bbox_coordinate_px', x, y, {**location, 'coordinate_index': axis})
            add('detection_confidence', a['confidence'], b['confidence'], location)
            assert len(a['keypoints']) == len(b['keypoints']) == 2
            for side, (pa, pb) in enumerate(zip(a['keypoints'], b['keypoints'])):
                assert len(pa) == len(pb) == 3
                assert returned(pa, old['width'], old['height']) == returned(pb, new['width'], new['height'])
                for axis in (0, 1):
                    if pa[axis] is None or pb[axis] is None:
                        assert pa[axis] is pb[axis]
                    else:
                        add('keypoint_coordinate_px', pa[axis], pb[axis], {**location, 'side': side, 'coordinate_index': axis})
                add('keypoint_confidence', pa[2], pb[2], {**location, 'side': side})
                if all(value is not None for value in [pa[0],pa[1],pb[0],pb[1]]):
                    shift = math.hypot(pa[0]-pb[0], pa[1]-pb[1])
                    if shift > max_keypoint_shift['euclidean_px']:
                        max_keypoint_shift = {'euclidean_px': shift, 'location': {**location, 'side': side,
                            'old_xy': pa[:2], 'new_xy': pb[:2]}}

    old_scores, new_scores = (read(root/'m0/per_image.json') for root in (OLD, NEW))
    assert len(old_scores) == len(new_scores) == 60
    score_counts = ['gold_count','prediction_count','tp','fn','fp','duplicate_fp','other_fp',
                    'visible_endpoints','returned_endpoints','missing_endpoints','endpoint_coverage']
    identities = ['unmatched_gold_indices','unmatched_prediction_indices',
                  'duplicate_prediction_indices','other_fp_prediction_indices']
    score_deltas = []
    max_iou_delta = 0.0
    max_endpoint_error_delta = 0.0
    match_pairs = 0
    for a, b in zip(old_scores, new_scores):
        assert key(a) == key(b)
        assert {k:a[k] for k in score_counts+identities} == {k:b[k] for k in score_counts+identities}
        assert [(m['gold_index'],m['prediction_index']) for m in a['matches']] == [
            (m['gold_index'],m['prediction_index']) for m in b['matches']]
        match_pairs += len(a['matches'])
        for x,y in zip(a['matches'],b['matches']):
            max_iou_delta = max(max_iou_delta, abs(x['iou']-y['iou']))
        assert len(a['endpoint_errors_px']) == len(b['endpoint_errors_px'])
        for x,y in zip(a['endpoint_errors_px'],b['endpoint_errors_px']):
            max_endpoint_error_delta = max(max_endpoint_error_delta, abs(x-y))
        deltas = {k: {'old':a[k],'new':b[k],'new_minus_old': b[k]-a[k]} for k in [
            'conditional_median_error_px','conditional_p95_error_px'] if a[k] != b[k]}
        if deltas:
            score_deltas.append({'image_id':a['image_id'],'threshold':a['threshold'],'deltas':deltas})

    old_summary, new_summary = (read(root/'m0/summary.json') for root in (OLD, NEW))
    metric_rows = []
    for a,b in zip(old_summary['metrics'],new_summary['metrics']):
        assert a['threshold'] == b['threshold']
        previous = {k:v for k,v in a.items() if k not in AGGREGATE_TIMING}
        current = {k:v for k,v in b.items() if k not in AGGREGATE_TIMING}
        changes = numerical_differences(previous,current)
        assert all(row['path'] in ['/conditional_median_error_px','/conditional_p95_error_px'] for row in changes)
        metric_rows.append({'threshold':a['threshold'],'old':previous,'new':current,'changes':changes})
    old_quality,new_quality = (read(root/'m0-quality/quality-per-image.json') for root in (OLD, NEW))
    assert len(old_quality) == len(new_quality) == 60
    assert old_quality == new_quality
    old_qsummary,new_qsummary = (read(root/'m0-quality/quality-summary.json') for root in (OLD, NEW))
    assert old_qsummary['metrics'] == new_qsummary['metrics']
    old_hashes,new_hashes=old_header['source']['files_sha256'],new_header['source']['files_sha256']
    assert old_hashes.keys() == new_hashes.keys()
    source_differences = {key:{'old':old_hashes[key],'new':new_hashes[key]}
                          for key in old_hashes if old_hashes[key] != new_hashes[key]}
    cpu = next((line.split(':',1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines()
                if line.startswith('model name')),None)
    result = {'schema_version':1,'kind':'fresh-m0-cross-study-continuity','status':'verified-numerical-continuity-not-bitwise',
        'created_at_utc':datetime.now(timezone.utc).isoformat(),
        'old_evidence':str(OLD),'new_evidence':str(NEW),
        'old_source_revision':old_header['source']['revision'],'new_source_revision':new_header['source']['revision'],
        'model_sha256':old_header['model_sha256'],'manifest_sha256':old_header['manifest_sha256'],
        'recorded_runtime_identical':True,'recorded_runtime':old_header['runtime'],
        'inference_settings_and_image_inventories_identical':True,
        'source_file_hash_differences':source_differences,
        'record_comparison':{'unique_records':60,'record_order_and_metadata_identical':True,
            'excluded_record_fields':sorted(TIMING),'exact_payload_records':len(exact_records),
            'different_payload_records':len(changed_records),'exact_payload_record_identities':exact_records,
            'total_prediction_occurrences_across_thresholds':prediction_count,
            'exact_prediction_occurrences':exact_predictions,
            'prediction_counts_and_class_ids_identical':True,
            'prediction_order_preserved_by_unique_maximum_iou_correspondence':True,
            'minimum_corresponding_box_iou':minimum_corresponding_iou,
            'minimum_unique_correspondence_iou_margin':minimum_geometric_winner_margin,
            'endpoint_availability_flags_identical_for_every_prediction':True,
            'numeric_differences':groups,'maximum_keypoint_euclidean_shift':max_keypoint_shift},
        'original_reference_score_continuity':{'per_image_records_compared':60,
            'all_count_and_coverage_fields_identical':True,'gold_prediction_match_pairs_compared':match_pairs,
            'ordered_match_identities_and_unmatched_duplicate_other_fp_indices_identical':True,
            'maximum_matched_box_iou_change':max_iou_delta,
            'maximum_corresponding_visible_endpoint_error_change_px':max_endpoint_error_delta,
            'per_image_quantile_changes':score_deltas,'aggregate_metrics':metric_rows,
            'excluded_aggregate_timing_fields':sorted(AGGREGATE_TIMING)},
        'original_reference_quality_continuity':{'all_60_per_image_records_exactly_equal':True,
            'all_three_aggregate_metric_records_exactly_equal':True,
            'metrics':old_qsummary['metrics']},
        'hardware_observation':{'current_cpu_model':cpu,'old_cpu_model_available_in_compared_headers':False,
            'same_physical_cpu_established':False},
        'method':'Separate standard-library saved-output comparison; no production scoring imports, model loading or inference. Prediction correspondence uses unique maximum box IoU, then same-index raw values are compared without tolerance.',
        'limits':['These fresh predictions are not bitwise-identical after timing exclusion; preserve the new baseline values in the new study.',
            'The recorded core package/runtime fields and inference settings match, but this comparison does not establish identical physical CPU hardware or every low-level execution detail.',
            'No cause for the floating-point differences is asserted. The file-hash difference in pose_checkpoint.py is recorded rather than assumed to explain the outputs.',
            'Original-reference match/count identities, endpoint availability and radius-success metrics are unchanged. Revised-reference continuity is outside this record and is checked in the completed dual-reference summary.',
            'Prediction occurrences repeat across fixed thresholds; they are not independent scenes or observations.']}
    for path,digest in INPUTS.items():
        assert sha(Path(path)) == digest, path
    result['input_files_sha256']=dict(sorted(INPUTS.items()))
    result['comparison_script_sha256']=sha(Path(__file__))
    output=WORK/'baseline-continuity.json'
    assert not output.exists()
    output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'status':result['status'],'exact_records':len(exact_records),
        'predictions':prediction_count,'exact_predictions':exact_predictions,
        'numeric_differences':groups,'maximum_keypoint_euclidean_shift':max_keypoint_shift,
        'original_metric_changes':[{'threshold':row['threshold'],'changes':row['changes']} for row in metric_rows],
        'quality_metrics_exact':True,'match_identities_exact':True,'output':str(output)},indent=2))


if __name__ == '__main__':
    main()
