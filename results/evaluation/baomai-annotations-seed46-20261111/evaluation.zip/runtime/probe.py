"""Record the restored CPU runtime without loading any trained model."""

from datetime import datetime, timezone
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import platform
import subprocess
import sys

import cv2
import numpy as np
from PIL import Image
import torch
import torchvision
import ultralytics
from torchvision.ops import nms


ROOT = Path(__file__).resolve().parent
EXPECTED = {
    "torch": "2.10.0+cpu",
    "torchvision": "0.25.0+cpu",
    "ultralytics": "8.4.182",
    "numpy": "2.5.4",
    "Pillow": "13.0.0",
    "opencv-python": "5.0.0.93",
}


def main():
    assert sys.version_info[:3] == (3, 12, 14), sys.version
    versions = {name: version(name) for name in EXPECTED}
    assert versions == EXPECTED, versions
    assert torch.version.cuda is None
    assert not torch.cuda.is_available()
    torch.set_num_threads(4)
    torch.set_num_interop_threads(1)
    boxes = torch.tensor([[0, 0, 10, 10], [1, 1, 9, 9], [20, 20, 30, 30]], dtype=torch.float32)
    scores = torch.tensor([0.9, 0.8, 0.7], dtype=torch.float32)
    kept = nms(boxes, scores, 0.5).tolist()
    assert kept == [0, 2], kept
    array = np.zeros((8, 8, 3), dtype=np.uint8)
    assert np.asarray(Image.fromarray(array)).shape == array.shape
    assert cv2.cvtColor(array, cv2.COLOR_RGB2BGR).shape == array.shape
    assert torch.from_numpy(array).shape == (8, 8, 3)
    assert torch.eye(2, dtype=torch.float32).matmul(torch.ones(2, dtype=torch.float32)).tolist() == [1, 1]
    freeze = subprocess.check_output([sys.executable, '-m', 'pip', 'freeze'], text=True)
    (ROOT / 'requirements.txt').write_text(freeze)
    result = {
        'schema_version': 1,
        'status': 'verified-cpu-runtime',
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'python_executable': sys.executable,
        'python': platform.python_version(),
        'platform': platform.platform(),
        'versions': versions,
        'versions_match_prior_recorded_cpu_runtime': True,
        'torch_cuda': torch.version.cuda,
        'cuda_available': torch.cuda.is_available(),
        'torch_threads': torch.get_num_threads(),
        'torch_interop_threads': torch.get_num_interop_threads(),
        'checks': {
            'cpu_torch_float32': True,
            'torchvision_nms_indices': kept,
            'numpy_torch_bridge': True,
            'pillow_array_roundtrip': True,
            'opencv_color_conversion': True,
            'ultralytics_import': ultralytics.__version__,
        },
        'requirements_sha256': hashlib.sha256(freeze.encode()).hexdigest(),
        'probe_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'trained_model_loaded': False,
        'model_inference_performed': False,
        'training_performed': False,
        'scope': 'Dedicated venv. Six recorded core package versions match the previous CPU evaluation; full dependency versions are preserved separately. The platform/kernel is recorded for comparison.',
    }
    (ROOT / 'runtime.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
