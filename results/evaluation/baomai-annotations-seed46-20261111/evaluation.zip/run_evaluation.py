"""Execute the fixed fresh three-model comparison; preserve every command and output."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
WORK = Path(__file__).resolve().parent
ROOT = WORK.parent / 'dl'
EVIDENCE = WORK / 'evidence/seed-46'
PYTHON = str(WORK / 'runtime/venv/bin/python')
REVISION = 'e4bb7019bcffd80b08cab28c4877dd562ee1d796'
CANDIDATE = 'data/candidates/annotations-2026-11-10/manifest.json'
sys.path.insert(0, str(ROOT / 'scripts'))
from evaluate_pose import file_sha256, preflight_dataset
from package_gpu_results import collect_arm, check_pair
from pose_checkpoint import recipe_identity
from verify_pose_annotation_candidate import verify_annotation_candidate

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

assert git('rev-parse', 'HEAD') == REVISION
assert not git('status', '--porcelain')
candidate = verify_annotation_candidate(ROOT, ROOT / CANDIDATE)
assert candidate['candidate_manifest_sha256'] == '28fc8f5da95605089d61fb062132200ed296c3a10b216f1a61dbda1798ea4ba7'
preflight = preflight_dataset(ROOT, require_weights=True)
arms = {arm: collect_arm(preflight, EVIDENCE / 'checkpoints' / arm, arm) for arm in ('reference', 'candidate')}
check_pair(arms['reference'], arms['candidate'])
recipe = recipe_identity('reviewed-annotations-seed46-v1')
for arm, bundle in arms.items():
    receipt = bundle['receipt']
    assert all(receipt[k] == v for k,v in recipe.items())
    assert receipt['source']['revision'] == '23d7db97ca626f5591dbd26e699c0f23d318ee73'
    assert receipt['source']['working_tree_status'] == ''
    assert bundle['staging']['source']['candidate_manifest_sha256'] == candidate['candidate_manifest_sha256']
    for path, digest in receipt['source']['files_sha256'].items():
        assert file_sha256(ROOT / path) == digest, path
    assert datetime.now(timezone.utc) > datetime.fromisoformat(receipt['created_at_utc'])
model_ids = {'m0': preflight['model_sha256'],
             'm1': arms['reference']['receipt']['checkpoint']['sha256'],
             'm2': arms['candidate']['receipt']['checkpoint']['sha256']}

log = {'created_at_utc': datetime.now(timezone.utc).isoformat(), 'source_revision': REVISION,
       'source_tree': git('rev-parse', 'HEAD^{tree}'), 'candidate_verification': candidate,
       'model_sha256': model_ids, 'commands': [], 'training_run': False}
def save():
    (WORK / 'execution.json').write_text(json.dumps(log, indent=2, allow_nan=False) + '\n')
save()
env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'YOLO_CONFIG_DIR': str(WORK/'runtime/ultralytics-config'), 'MPLCONFIGDIR': str(WORK/'runtime/matplotlib-config'), 'XDG_CACHE_HOME': str(WORK/'runtime/cache')}
def run(name, command):
    output = WORK / f'{name}.log'
    assert not output.exists(), output
    event = {'name': name, 'command': command, 'cwd': str(ROOT),
             'started_at_utc': datetime.now(timezone.utc).isoformat()}
    log['commands'].append(event); save()
    print(json.dumps({'event': 'started', 'name': name}), flush=True)
    started = time.monotonic()
    with output.open('x') as stream:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
    event.update(exit_code=result.returncode, seconds=time.monotonic()-started,
                 completed_at_utc=datetime.now(timezone.utc).isoformat(),
                 log_path=output.name, log_sha256=file_sha256(output))
    save()
    if result.returncode:
        print(output.read_text()[-14000:], flush=True)
        raise SystemExit(result.returncode)
    print(json.dumps({'event': 'completed', 'name': name, 'seconds': event['seconds']}), flush=True)

for model, arm in (('m0',None), ('m1','reference'), ('m2','candidate')):
    checkpoint = ['--checkpoint-manifest', str(EVIDENCE/'checkpoints'/arm/'checkpoint-manifest.json')] if arm else []
    run(model, [PYTHON, 'scripts/evaluate_pose.py', '--root', str(ROOT), '--output', str(EVIDENCE/model),
                '--device', 'cpu', '--threads', '4', '--conf', '0.15', '0.25', '0.40',
                '--endpoint-conf', '0.50', '--matching-iou', '0.50', '--overlays', '0', *checkpoint])
    run(model+'-quality', [PYTHON, 'scripts/diagnose_pose_quality.py', '--root', str(ROOT),
                         '--predictions', str(EVIDENCE/model/'predictions.jsonl'),
                         '--radii', '2', '5', '10', '--output', str(EVIDENCE/(model+'-quality')), *checkpoint])
    summary=json.loads((EVIDENCE/model/'summary.json').read_text())
    print(json.dumps({'model':model, 'original_metrics':[{k:row[k] for k in
        ('threshold','fn','fp','missing_endpoints','conditional_median_error_px','conditional_p95_error_px')}
        for row in summary['metrics']]}), flush=True)

assert not git('status','--porcelain')
run('dual-reference-comparison', [PYTHON, 'scripts/rescore_annotation_comparison.py', '--root', str(ROOT),
    '--evidence', str(EVIDENCE), '--candidate', CANDIDATE, '--recipe', 'reviewed-annotations-seed46-v1',
    '--reference-dir', str(ROOT/'data/references/visible-front-2026-11-10'),
    '--evaluation-revision', REVISION, '--output', str(EVIDENCE/'comparison-original-and-pr30.json')])
log['status']='complete'; log['completed_at_utc']=datetime.now(timezone.utc).isoformat();save()
print(json.dumps({'status':'complete','summary':str(EVIDENCE/'comparison-original-and-pr30.json')}),flush=True)
