#!/usr/bin/env python3
"""Independently verify the seed46 annotation result with only the standard library."""

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import struct
import sys


THRESHOLDS = (0.15, 0.25, 0.40)
FIELDS = ("fn", "fp", "missing_endpoints", "conditional_median_error_px", "conditional_p95_error_px")
COUNTS = ("gold_count", "prediction_count", "tp", "fn", "fp", "duplicate_fp", "other_fp",
          "visible_endpoints", "returned_endpoints", "missing_endpoints")
QUALITY_COUNTS = ("gold_count", "prediction_count", "tp", "fn", "fp", "visible_endpoints",
                  "returned_visible_endpoints", "both_visible_objects", "both_visible_objects_with_both_returned",
                  "unlocatable_reference_endpoints", "unlocatable_on_matched_objects", "returned_on_unlocatable_reference")
RADIUS_FIELDS = ("visible_endpoints_within_radius", "both_visible_objects_within_radius")
INPUT_HASHES = {}
MAX_FLOAT_DIFFERENCE = 0.0
FLOAT_COMPARISONS = 0


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    INPUT_HASHES[str(path.resolve())] = digest(path)
    return path.read_text(encoding="utf-8")


def read_json(path):
    return json.loads(read(path))


def equivalent(actual, expected, where):
    """Exact structure/counts; tolerate only arithmetic representation in floats."""
    global MAX_FLOAT_DIFFERENCE, FLOAT_COMPARISONS
    if isinstance(expected, dict):
        require(isinstance(actual, dict) and set(actual) == set(expected), f"{where}: keys differ")
        for key in expected:
            equivalent(actual[key], expected[key], f"{where}.{key}")
    elif isinstance(expected, list):
        require(isinstance(actual, list) and len(actual) == len(expected), f"{where}: sequence differs")
        for index, value in enumerate(expected):
            equivalent(actual[index], value, f"{where}[{index}]")
    elif where.endswith(".radius_px") and type(expected) in (int, float):
        require(type(actual) in (int, float) and actual == expected, f"{where}: radius value differs")
    elif isinstance(expected, float):
        require(type(actual) in (int, float) and math.isfinite(actual) and math.isfinite(expected),
                f"{where}: nonfinite/non-numeric value")
        difference = abs(actual - expected)
        MAX_FLOAT_DIFFERENCE = max(MAX_FLOAT_DIFFERENCE, difference)
        FLOAT_COMPARISONS += 1
        require(difference <= 1e-10, f"{where}: numerical difference {difference!r}")
    else:
        require(type(actual) is type(expected) and actual == expected, f"{where}: {actual!r} != {expected!r}")


def subset(actual, expected, where):
    require(set(expected) <= set(actual), f"{where}: expected fields missing")
    equivalent({key: actual[key] for key in expected}, expected, where)


def percentile(values, fraction):
    if not values:
        return None
    ordered = sorted(values)
    position = fraction * (len(ordered) - 1)
    lo, hi = int(math.floor(position)), int(math.ceil(position))
    return ordered[lo] + (ordered[hi] - ordered[lo]) * (position - lo)


def stats(values):
    values = list(values)
    return {"count": len(values), "mean": math.fsum(values) / len(values) if values else None,
            "median": percentile(values, 0.50), "p95": percentile(values, 0.95)}


def ratio(numerator, denominator):
    return numerator / denominator if denominator else None


def load_reference(root):
    manifest = read_json(root / "data/manifest.json")
    result = {}
    for record in manifest["records"]:
        if record["split"] != "val":
            continue
        image_path = root / "data" / record["image"]
        label_path = root / "data" / record["label"]
        require(digest(image_path) == record["image_sha256"], f"image hash: {record['id']}")
        require(digest(label_path) == record["label_sha256"], f"label hash: {record['id']}")
        INPUT_HASHES[str(image_path.resolve())] = record["image_sha256"]
        with image_path.open("rb") as stream:
            header = stream.read(24)
        require(header[:8] == b"\x89PNG\r\n\x1a\n" and header[12:16] == b"IHDR", "PNG header")
        width, height = struct.unpack(">II", header[16:24])
        require([width, height] == record["original_size"], "original dimensions")
        objects = []
        for physical_line, line in enumerate(read(label_path).splitlines(), 1):
            if not line.strip():
                continue
            row = [float(token) for token in line.split()]
            require(len(row) == 11 and all(math.isfinite(x) for x in row), "label fields")
            require(row[0] == 0 and row[7] in (0, 2) and row[10] in (0, 2), "class/visibility")
            require(all(0 <= row[k] <= 1 for k in (1, 2, 3, 4, 5, 6, 8, 9)), "normalized coordinates")
            require(row[3] > 0 and row[4] > 0, "positive box size")
            points = [(row[k] * width, row[k + 1] * height, int(row[k + 2])) for k in (5, 8)]
            require(all(v == 2 or (x == 0 and y == 0) for x, y, v in points), "missing-point representation")
            center_x, center_y = row[1] * width, row[2] * height
            half_w, half_h = row[3] * width / 2, row[4] * height / 2
            objects.append({"line": physical_line, "class": 0, "box": (center_x - half_w, center_y - half_h,
                                               center_x + half_w, center_y + half_h), "points": points})
        require(len(objects) == record["instances"], "object count")
        require(sum(p[2] == 2 for obj in objects for p in obj["points"]) == record["visible_endpoints"], "endpoint count")
        require(record["id"] not in result, "duplicate reference image")
        result[record["id"]] = {**record, "width": width, "height": height, "objects": objects}
    require(len(result) == 20 and sum(len(r["objects"]) for r in result.values()) == 664, "frozen validation size")
    return dict(sorted(result.items()))


def overlap(a, b):
    width = min(a[2], b[2]) - max(a[0], b[0])
    height = min(a[3], b[3]) - max(a[1], b[1])
    if width <= 0 or height <= 0:
        return 0.0
    intersection = width * height
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - intersection
    return intersection / union


def point_present(point, width, height):
    x, y, confidence = point
    return (confidence >= 0.50 and x is not None and y is not None and math.isfinite(x) and math.isfinite(y)
            and 0 <= x < width and 0 <= y < height)


def image_result(record, predictions):
    gold = record["objects"]
    overlaps = [[overlap(prediction["bbox_xyxy"], item["box"]) for item in gold] for prediction in predictions]
    available = set(range(len(gold)))
    matched = []
    for pi in sorted(range(len(predictions)), key=lambda i: (-predictions[i]["confidence"], i)):
        candidates = [(overlaps[pi][gi], -gi, gi) for gi in available
                      if gold[gi]["class"] == predictions[pi]["class_id"] and overlaps[pi][gi] >= 0.50]
        if candidates:
            iou, _, gi = max(candidates)
            available.remove(gi)
            matched.append({"gold_index": gi, "prediction_index": pi, "iou": iou})
    matched_predictions = {m["prediction_index"] for m in matched}
    matched_gold = {m["gold_index"] for m in matched}
    unmatched = [pi for pi in range(len(predictions)) if pi not in matched_predictions]
    duplicates = [pi for pi in unmatched if any(predictions[pi]["class_id"] == gold[gi]["class"]
                  and overlaps[pi][gi] >= 0.50 for gi in matched_gold)]
    endpoints = {}
    errors = []
    hidden_matched = hidden_returned = 0
    for match in matched:
        gi, pi = match["gold_index"], match["prediction_index"]
        for side, (reference, point) in enumerate(zip(gold[gi]["points"], predictions[pi]["keypoints"])):
            present = point_present(point, record["width"], record["height"])
            if reference[2] == 0:
                hidden_matched += 1
                hidden_returned += int(present)
            elif present:
                dx, dy = point[0] - reference[0], point[1] - reference[1]
                error = math.hypot(dx, dy)
                endpoints[(gi, side)] = {"error_px": error, "dx_px": dx, "dy_px": dy}
                errors.append(error)
    visible = sum(p[2] == 2 for obj in gold for p in obj["points"])
    both = {i for i, obj in enumerate(gold) if all(point[2] == 2 for point in obj["points"])}
    both_returned = {i for i in both if (i, 0) in endpoints and (i, 1) in endpoints}
    tp, fp = len(matched), len(predictions) - len(matched)
    score = {"gold_count": len(gold), "prediction_count": len(predictions), "tp": tp, "fn": len(gold) - tp,
             "fp": fp, "duplicate_fp": len(duplicates), "other_fp": fp - len(duplicates),
             "visible_endpoints": visible, "returned_endpoints": len(errors), "missing_endpoints": visible - len(errors),
             "endpoint_coverage": ratio(len(errors), visible), "conditional_median_error_px": percentile(errors, 0.50),
             "conditional_p95_error_px": percentile(errors, 0.95), "endpoint_errors_px": errors,
             "matches": matched, "unmatched_gold_indices": sorted(available), "unmatched_prediction_indices": unmatched,
             "duplicate_prediction_indices": duplicates, "other_fp_prediction_indices": [i for i in unmatched if i not in duplicates]}
    quality = {key: score[key] for key in ("gold_count", "prediction_count", "tp", "fn", "fp", "visible_endpoints")}
    quality.update(returned_visible_endpoints=len(errors), both_visible_objects=len(both),
                   both_visible_objects_with_both_returned=len(both_returned),
                   unlocatable_reference_endpoints=2 * len(gold) - visible, unlocatable_on_matched_objects=hidden_matched,
                   returned_on_unlocatable_reference=hidden_returned, radii=[])
    successes = {}
    for radius in (2, 5, 10):
        successes[radius] = {i for i in both_returned if all(endpoints[i, side]["error_px"] <= radius for side in (0, 1))}
        quality["radii"].append({"radius_px": radius, "visible_endpoints_within_radius": sum(e <= radius for e in errors),
                                 "both_visible_objects_within_radius": len(successes[radius])})
    return score, quality, endpoints, successes


def aggregate(scores, qualities, threshold):
    total = {key: sum(row[key] for row in scores) for key in COUNTS}
    errors = [error for row in scores for error in row["endpoint_errors_px"]]
    total.update(endpoint_coverage=ratio(total["returned_endpoints"], total["visible_endpoints"]),
                 conditional_median_error_px=percentile(errors, 0.50), conditional_p95_error_px=percentile(errors, 0.95),
                 image_count=len(scores), threshold=threshold)
    quality = {key: sum(row[key] for row in qualities) for key in QUALITY_COUNTS}
    quality.update(image_count=len(qualities), box_confidence=threshold,
                   object_precision=ratio(quality["tp"], quality["prediction_count"]),
                   object_recall=ratio(quality["tp"], quality["gold_count"]),
                   visible_endpoint_coverage=ratio(quality["returned_visible_endpoints"], quality["visible_endpoints"]),
                   both_visible_objects_returned_fraction=ratio(quality["both_visible_objects_with_both_returned"], quality["both_visible_objects"]),
                   returned_on_unlocatable_reference_fraction=ratio(quality["returned_on_unlocatable_reference"], quality["unlocatable_on_matched_objects"]), radii=[])
    for index, radius in enumerate((2, 5, 10)):
        counts = {key: sum(row["radii"][index][key] for row in qualities) for key in RADIUS_FIELDS}
        quality["radii"].append({"radius_px": radius, **counts,
              "visible_endpoint_success_rate": ratio(counts["visible_endpoints_within_radius"], quality["visible_endpoints"]),
              "both_visible_object_success_rate": ratio(counts["both_visible_objects_within_radius"], quality["both_visible_objects"])})
    return total, quality


# New study-specific orchestration below. Scoring above is standalone and imports no
# repository code. Reference object indices are never compared across references.
MODELS = ('m0', 'm1', 'm2')
COMPARISONS = (('m1', 'm0'), ('m2', 'm0'), ('m2', 'm1'))
PRIMARY = 0.25


def parse_revised_label(path, width, height):
    objects = []
    for physical_line, text in enumerate(read(path).splitlines(), 1):
        if not text.strip():
            continue
        values = [float(token) for token in text.split()]
        require(len(values) == 11 and all(math.isfinite(v) for v in values), 'revised label schema')
        require(values[0] == 0 and values[7] in (0, 2) and values[10] in (0, 2), 'revised class/visibility')
        require(all(0 <= values[k] <= 1 for k in (1, 2, 3, 4, 5, 6, 8, 9)), 'revised coordinate range')
        require(values[3] > 0 and values[4] > 0, 'revised positive box')
        cx, cy = values[1] * width, values[2] * height
        hw, hh = values[3] * width / 2, values[4] * height / 2
        points = [(values[k] * width, values[k + 1] * height, int(values[k + 2])) for k in (5, 8)]
        require(all(v == 2 or (x == 0 and y == 0) for x, y, v in points), 'revised missing point encoding')
        objects.append({'line': physical_line, 'class': 0, 'box': (cx-hw, cy-hh, cx+hw, cy+hh), 'points': points})
    return objects


def load_revised(root, original, reference_dir):
    manifest = read_json(reference_dir / 'manifest.json')
    require(manifest['reference_id'] == 'baomai-visible-front-2026-11-10', 'PR30 reference identity')
    require(manifest['source_manifest_sha256'] == digest(root / 'data/manifest.json'), 'PR30 original manifest binding')
    require(len(manifest['files']) == 20 and {r['image_id'] for r in manifest['files']} == set(original), 'PR30 image inventory')
    result = {}
    for entry in manifest['files']:
        identifier = entry['image_id']
        old = original[identifier]
        require(entry['image_sha256'] == old['image_sha256'], 'PR30 image binding')
        require(entry['source_label_sha256'] == old['label_sha256'], 'PR30 original label binding')
        require(digest(root / entry['source_label_path']) == entry['source_label_sha256'], 'PR30 source label bytes')
        path = reference_dir / entry['label_path']
        require(digest(path) == entry['label_sha256'], 'PR30 label bytes')
        objects = parse_revised_label(path, old['width'], old['height'])
        require(len(objects) == entry['row_count'], 'PR30 row count')
        result[identifier] = {**old, 'objects': objects, 'label_sha256': entry['label_sha256'],
                              'revised_label_path': entry['label_path']}
    counts = {'images': len(result), 'objects': sum(len(r['objects']) for r in result.values()),
              'visible_endpoints': sum(p[2] == 2 for r in result.values() for g in r['objects'] for p in g['points']),
              'missing_endpoints': sum(p[2] == 0 for r in result.values() for g in r['objects'] for p in g['points']),
              'empty_images': sum(not r['objects'] for r in result.values())}
    equivalent(manifest['counts'], counts, 'PR30 denominator counts')
    equivalent(counts, {'images': 20, 'objects': 661, 'visible_endpoints': 1228, 'missing_endpoints': 94, 'empty_images': 3}, 'frozen PR30 totals')
    point_inventory = lambda records: Counter((image, side, x, y) for image, record in records.items()
        for obj in record['objects'] for side, (x, y, v) in enumerate(obj['points']) if v == 2)
    before, after = point_inventory(original), point_inventory(result)
    require(not before-after and sum((after-before).values()) == 1, 'PR30 preserved corner coordinates plus one addition')
    both_inventory = lambda records: Counter((image, tuple(obj['points'])) for image, record in records.items()
        for obj in record['objects'] if all(p[2] == 2 for p in obj['points']))
    require(both_inventory(original) == both_inventory(result), 'both-corner eligible physical identities unchanged by PR30')
    return dict(sorted(result.items())), manifest


def eligibility(objects):
    counts = Counter(sum(p[2] == 2 for p in obj['points']) for obj in objects)
    return {str(n): counts[n] for n in (0, 1, 2)}


def public_view(record, score, quality, label_path):
    return {'label_path': label_path,
            'score': {k: v for k, v in score.items() if k not in ('endpoint_errors_px', 'matches', 'unmatched_gold_indices')},
            'quality': quality, 'objects_by_locatable_corners': eligibility(record['objects']),
            'misses_by_locatable_corners': eligibility([record['objects'][i] for i in score['unmatched_gold_indices']]),
            'missed_label_rows_one_based': [record['objects'][i]['line'] for i in score['unmatched_gold_indices']]}


def numeric_change(before, after):
    return {key: after[key] - value for key, value in before.items()
            if type(value) in (int, float) and type(after.get(key)) in (int, float)}


def comparison(before, after):
    return {'score': numeric_change(before['score'], after['score']),
            'quality': numeric_change(before['quality'], after['quality']),
            'radii': [{'radius_px': first['radius_px'],
                **{k: v for k, v in numeric_change(first, second).items() if k != 'radius_px'}}
                for first, second in zip(before['quality']['radii'], after['quality']['radii'])],
            'misses_by_locatable_corners': numeric_change(before['misses_by_locatable_corners'], after['misses_by_locatable_corners'])}


def common_diagnostics_independent(reference, endpoints):
    common = sorted(set.intersection(*(set(endpoints[name]) for name in MODELS)))
    eligible = {(image, i) for image, record in reference.items() for i, obj in enumerate(record['objects'])
                if all(p[2] == 2 for p in obj['points'])}
    successes = {name: {radius: {key for key in eligible
        if all((*key, side) in points and points[*key, side]['error_px'] <= radius for side in (0, 1))}
        for radius in (5, 10)} for name, points in endpoints.items()}
    paired = {}
    for new, old in COMPARISONS:
        shared = sorted(set(endpoints[old]) & set(endpoints[new]))
        changes = [endpoints[new][key]['error_px'] - endpoints[old][key]['error_px'] for key in shared]
        paired[f'{new}_vs_{old}'] = {'common_returned_endpoints': len(shared), 'error_change_px': stats(changes),
            'worse_endpoints': sum(v > 0 for v in changes), 'better_endpoints': sum(v < 0 for v in changes),
            'equal_endpoints': sum(v == 0 for v in changes),
            'returned_only_old': len(set(endpoints[old]) - set(shared)),
            'returned_only_new': len(set(endpoints[new]) - set(shared)),
            'both_corners': [{'radius_px': radius, 'eligible_objects': len(eligible),
                'old_success': len(successes[old][radius]), 'new_success': len(successes[new][radius]),
                'success_both': len(successes[old][radius] & successes[new][radius]),
                'became_failure': len(successes[old][radius] - successes[new][radius]),
                'became_success': len(successes[new][radius] - successes[old][radius])} for radius in (5, 10)]}
    return {'box_confidence': PRIMARY, 'count': len(common),
        'metrics': {name: {field: stats(endpoints[name][key][field] for key in common)
                          for field in ('error_px', 'dx_px', 'dy_px')} for name in MODELS},
        'paired': paired,
        'per_image': [{'image_id': image, 'common_returned_endpoints': sum(k[0] == image for k in common),
                      'median_error_px': {name: stats(endpoints[name][k]['error_px'] for k in common if k[0] == image)['median']
                                          for name in MODELS}} for image in sorted(reference)]}


def check_prediction(row, record):
    for field in ('image_sha256', 'label_sha256', 'width', 'height'):
        require(row[field] == record[field], f'{record["id"]}: prediction original {field}')
    for pred in row['predictions']:
        require(pred['class_id'] == 0 and 0 <= pred['confidence'] <= 1 and math.isfinite(pred['confidence']), 'prediction class/confidence')
        require(pred['confidence'] >= row['threshold'], 'prediction below requested threshold')
        require(len(pred['bbox_xyxy']) == 4 and all(math.isfinite(v) for v in pred['bbox_xyxy']), 'prediction box')
        require(len(pred['keypoints']) == 2 and all(len(p) == 3 for p in pred['keypoints']), 'prediction keypoint shape')


def audit(root, evidence, reference_dir, official_path):
    original = load_reference(root)
    revised, reference_manifest = load_revised(root, original, reference_dir)
    references = {'original': original, 'revised': revised}
    official = read_json(official_path)
    require(official['kind'] == 'baomai-annotation-comparison-dual-reference', 'comparison kind')
    require(official['experiment']['recipe_id'] == 'reviewed-annotations-seed46-v1', 'seed46 recipe identity')
    require(official['experiment']['recipe_sha256'] == 'f18e0a813a1057e1b3ab3a44ea3ce9b2a3e7673cc2bf04ca09b394bfdd8c51b8', 'seed46 recipe hash')
    require(official['experiment']['candidate_manifest_sha256'] == '28fc8f5da95605089d61fb062132200ed296c3a10b216f1a61dbda1798ea4ba7', 'unchanged reviewed candidate')
    require(official['revised_reference']['manifest_sha256'] == digest(reference_dir / 'manifest.json'), 'comparison PR30 hash')
    require(official['decision'] == 'review-required-no-promotion' and official['automatic_promotion'] is False, 'comparison does not auto-promote')
    expected_pairs = {(model, threshold, image) for model in MODELS for threshold in THRESHOLDS for image in original}
    saved_per_image = {(r['model_id'], r['box_confidence'], r['image_id']): r for r in official['per_image']}
    require(set(saved_per_image) == expected_pairs and len(official['per_image']) == 180, 'complete dual-reference per-image inventory')
    saved_metrics = {(r['model_id'], r['box_confidence']): r for r in official['metrics']}
    require(set(saved_metrics) == {(m, t) for m in MODELS for t in THRESHOLDS}, 'complete dual-reference aggregate inventory')
    endpoints = {reference: {model: {} for model in MODELS} for reference in references}
    computed_metrics = {}
    headers = {}
    populations = []
    per_image_verified = saved_score_verified = saved_quality_verified = 0
    match_identities = {}
    for model in MODELS:
        folder = evidence / model
        raw = [json.loads(line) for line in read(folder / 'predictions.jsonl').splitlines() if line.strip()]
        require(len(raw) == 61 and raw[0]['record_type'] == 'run', f'{model}: saved prediction records')
        header, items = raw[0], raw[1:]
        require(header['model_sha256'] == official['models'][model]['model_sha256'], f'{model}: model hash binding')
        headers[model] = header
        keys = [(r['image_id'], r['threshold']) for r in items]
        require(len(set(keys)) == 60 and set(keys) == {(i, t) for i in original for t in THRESHOLDS}, f'{model}: full threshold sweep')
        saved_scores = {(r['image_id'], r['threshold']): r for r in read_json(folder / 'per_image.json')}
        quality_folder = evidence / f'{model}-quality'
        saved_quality = {(r['image_id'], r['box_confidence']): r for r in read_json(quality_folder / 'quality-per-image.json')}
        saved_totals = {r['threshold']: r for r in read_json(folder / 'summary.json')['metrics']}
        saved_qtotals = {r['box_confidence']: r for r in read_json(quality_folder / 'quality-summary.json')['metrics']}
        require(set(saved_scores) == set(keys) == set(saved_quality), f'{model}: original per-image score/quality inventory')
        require(set(saved_totals) == set(THRESHOLDS) == set(saved_qtotals), f'{model}: original aggregate inventory')
        match_identities[model] = {reference: {} for reference in references}
        for threshold in THRESHOLDS:
            score_rows = {r: [] for r in references}; quality_rows = {r: [] for r in references}; views = {r: [] for r in references}
            pools = {r: {} for r in references}
            for item in sorted((r for r in items if r['threshold'] == threshold), key=lambda x: x['image_id']):
                image = item['image_id'];check_prediction(item, original[image]);pair = {}
                for reference, records in references.items():
                    record = records[image]
                    score, quality, returned, successes = image_result(record, item['predictions'])
                    label_path = 'data/' + original[image]['label'] if reference == 'original' else record['revised_label_path']
                    public = public_view(record, score, quality, label_path)
                    equivalent(saved_per_image[model, threshold, image][reference], public, f'{model}/{threshold}/{image}/{reference}')
                    per_image_verified += 1
                    if reference == 'original':
                        subset(saved_scores[image, threshold], {'image_id': image, 'threshold': threshold, **score}, f'{model}/{threshold}/{image}/original-score-replay')
                        equivalent(saved_quality[image, threshold], {'image_id': image, 'box_confidence': threshold, **quality}, f'{model}/{threshold}/{image}/original-quality-replay')
                        saved_score_verified += 1;saved_quality_verified += 1
                    pair[reference] = public
                    score_rows[reference].append(score);quality_rows[reference].append(quality);views[reference].append(public)
                    prediction_by_gold = {m['gold_index']: m['prediction_index'] for m in score['matches']}
                    for (gi, side), value in returned.items():
                        point = record['objects'][gi]['points'][side]
                        key = (image, side, point[0], point[1], prediction_by_gold[gi])
                        require(key not in pools[reference], 'distinct endpoint correspondence key')
                        pools[reference][key] = value['error_px']
                    if threshold == PRIMARY:
                        endpoints[reference][model].update({(image, gi, side): value for (gi, side), value in returned.items()})
                        match_identities[model][reference][image] = {'matched_gold_indices': sorted(prediction_by_gold),
                            'missed_gold_indices': score['unmatched_gold_indices']}
                equivalent(saved_per_image[model, threshold, image]['revised_minus_original'], comparison(pair['original'], pair['revised']), f'{model}/{threshold}/{image}/reference-delta')
            computed = {'model_id': model, 'box_confidence': threshold, 'primary': threshold == PRIMARY}
            for reference in references:
                total, qtotal = aggregate(score_rows[reference], quality_rows[reference], threshold)
                if reference == 'original':
                    subset(saved_totals[threshold], total, f'{model}/{threshold}/original-score-aggregate')
                    equivalent(saved_qtotals[threshold], qtotal, f'{model}/{threshold}/original-quality-aggregate')
                total.pop('threshold');qtotal.pop('box_confidence')
                view = {'score': total, 'quality': qtotal,
                    **{field: {str(n): sum(v[field][str(n)] for v in views[reference]) for n in range(3)}
                       for field in ('objects_by_locatable_corners', 'misses_by_locatable_corners')}}
                computed[reference] = view
                equivalent(saved_metrics[model, threshold][reference], view, f'{model}/{threshold}/{reference}/aggregate')
            computed['revised_minus_original'] = comparison(computed['original'], computed['revised'])
            equivalent(saved_metrics[model, threshold]['revised_minus_original'], computed['revised_minus_original'], f'{model}/{threshold}/reference-delta')
            computed_metrics[model, threshold] = computed
            shared = set(pools['original']) & set(pools['revised'])
            require(all(pools['original'][k] == pools['revised'][k] for k in shared), 'shared physical endpoint errors unchanged across references')
            populations.append({'model': model, 'box_confidence': threshold,
                'original_scored_endpoints': len(pools['original']), 'revised_scored_endpoints': len(pools['revised']),
                'common_physical_endpoint_correspondences': len(shared), 'shared_error_values_bit_identical': True,
                'added_correspondences': len(set(pools['revised'])-set(pools['original'])),
                'removed_correspondences': len(set(pools['original'])-set(pools['revised']))})
    frozen = read_json(root / 'data/manifest.json')
    require(headers['m0']['model_sha256'] == frozen['model_sha256'], 'M0 is original epoch173')
    comparisons = []
    for reference in references:
        for threshold in THRESHOLDS:
            comparisons.append({'reference': reference, 'box_confidence': threshold, 'primary': threshold == PRIMARY,
                'comparisons': {f'{new}_vs_{old}': comparison(computed_metrics[old, threshold][reference], computed_metrics[new, threshold][reference])
                                for new, old in COMPARISONS}})
    equivalent(official['comparisons'], comparisons, 'all model-comparison deltas')
    common = {}
    for reference, records in references.items():
        common[reference] = common_diagnostics_independent(records, endpoints[reference])
        subset(official['common_returned_endpoints'][reference], common[reference], reference+'/common-endpoint-and-pair-diagnostics')
    # These exact denominators include missed detections and missing model points.
    denominators = {name: {'objects': sum(len(r['objects']) for r in records.values()),
        'visible_endpoints': sum(p[2] == 2 for r in records.values() for g in r['objects'] for p in g['points']),
        'both_visible_objects': sum(all(p[2] == 2 for p in g['points']) for r in records.values() for g in r['objects']),
        'hidden_reference_sides': sum(p[2] == 0 for r in records.values() for g in r['objects'] for p in g['points'])}
        for name, records in references.items()}
    primary = {reference: {model: computed_metrics[model, PRIMARY][reference] for model in MODELS} for reference in references}
    output = {'schema_version': 1, 'kind': 'independent-annotation-comparison-numerical-audit', 'status': 'verified',
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'official_comparison_sha256': digest(official_path), 'official_comparison_path': str(official_path),
        'experiment': {key: official['experiment'][key] for key in ('recipe_id', 'recipe_sha256', 'candidate_manifest_sha256', 'training_runtime')},
        'inference_runtime': headers['m0']['runtime'],
        'unique_models': 3, 'thresholds': list(THRESHOLDS), 'primary_threshold': PRIMARY,
        'per_image_reference_evaluations_verified': per_image_verified,
        'reference_specific_aggregates_verified': 18,
        'original_saved_per_image_scores_reproduced': saved_score_verified,
        'original_saved_per_image_quality_records_reproduced': saved_quality_verified,
        'original_saved_score_aggregates_reproduced': 9, 'original_saved_quality_aggregates_reproduced': 9,
        'reference_denominators': denominators, 'primary': primary,
        'metrics': [computed_metrics[m, t] for m in MODELS for t in THRESHOLDS],
        'comparisons': comparisons, 'common_returned_endpoints': common,
        'reference_population_effects': populations, 'primary_object_match_identities': match_identities,
        'models': {model: {'model_sha256': headers[model]['model_sha256'], 'prediction_file_sha256': digest(evidence/model/'predictions.jsonl')} for model in MODELS},
        'method': {'implementation': 'Separate standard-library label parser, direct-area IoU, confidence-ordered greedy one-to-one matching, Euclidean endpoint errors and linearly interpolated quantiles. No production matching/scoring imports.',
            'matching_iou': 0.50, 'endpoint_confidence': 0.50, 'radii_px': [2, 5, 10],
            'all_count_identity_comparisons_exact': True, 'float_comparison_absolute_tolerance': 1e-10,
            'maximum_observed_float_difference': MAX_FLOAT_DIFFERENCE, 'float_comparisons': FLOAT_COMPARISONS,
            'both_corner_denominator': 'Every object with both reference corners locatable, including missed objects.',
            'hidden_side_denominator': 'Unlocatable reference sides on matched objects; coordinate accuracy cannot be inferred on these sides.',
            'reference_identity_scope': 'Model comparisons use object indices only within each named reference; cross-reference correspondence uses physical coordinate/side and prediction identity.'},
        'automatic_promotion': False,
        'limits': ['Predictions are verified numeric inputs; this script performs no inference, weight deserialization or training.',
                   'Numerical agreement does not certify all visual annotations.',
                   'One seed and reused development images do not establish statistical significance or independent-test generalization.',
                   'Ten pixels remains an original-image diagnostic radius, not a physical acceptance guarantee.']}
    for path, expected_hash in INPUT_HASHES.items():
        require(digest(Path(path)) == expected_hash, f'input changed while independently verifying: {path}')
    output['input_files_sha256'] = dict(sorted(INPUT_HASHES.items()))
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--reference-dir', type=Path, required=True)
    parser.add_argument('--official-comparison', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), f'output exists: {args.output}')
    result = audit(args.root.resolve(), args.evidence.resolve(), args.reference_dir.resolve(), args.official_comparison.resolve())
    result['command'] = [sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]]
    result['script_sha256'] = digest(Path(__file__))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x', encoding='utf-8') as stream:
        json.dump(result, stream, indent=2, allow_nan=False);stream.write('\n')
    print(json.dumps({'status': result['status'], 'output': str(args.output.resolve()),
        'per_image_reference_evaluations_verified': result['per_image_reference_evaluations_verified'],
        'reference_specific_aggregates_verified': result['reference_specific_aggregates_verified'],
        'maximum_observed_float_difference': MAX_FLOAT_DIFFERENCE,
        'primary': {reference: {model: {'fn': r['score']['fn'], 'fp': r['score']['fp'],
            'missing_endpoints': r['score']['missing_endpoints'],
            'median_px': r['score']['conditional_median_error_px'], 'p95_px': r['score']['conditional_p95_error_px'],
            'both5': next(x['both_visible_objects_within_radius'] for x in r['quality']['radii'] if x['radius_px']==5),
            'both10': next(x['both_visible_objects_within_radius'] for x in r['quality']['radii'] if x['radius_px']==10),
            'hidden_outputs': r['quality']['returned_on_unlocatable_reference']}
            for model, r in runs.items()} for reference, runs in result['primary'].items()}}, indent=2))


if __name__ == '__main__':
    main()
