#!/usr/bin/env python3
"""Trace independently scored seed46 changes and keep seed45 separate."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
from independent_annotation_score import (MODELS, PRIMARY, THRESHOLDS, digest,
    image_result, load_reference, load_revised, overlap, point_present, require)


PAIRS = (('m2', 'm1'), ('m2', 'm0'), ('m1', 'm0'))


def read(path):
    return json.loads(Path(path).read_text())


def scalars(view):
    score, quality = view['score'], view['quality']
    return {'fn': score['fn'], 'fp': score['fp'],
        'missing_visible_endpoints': score['missing_endpoints'],
        'median_error_px': score['conditional_median_error_px'],
        'p95_error_px': score['conditional_p95_error_px'],
        'both_eligible': quality['both_visible_objects'],
        'both5': next(r['both_visible_objects_within_radius'] for r in quality['radii'] if r['radius_px'] == 5),
        'both10': next(r['both_visible_objects_within_radius'] for r in quality['radii'] if r['radius_px'] == 10),
        'matched_hidden_sides': quality['unlocatable_on_matched_objects'],
        'hidden_side_outputs': quality['returned_on_unlocatable_reference'],
        'misses_by_locatable_corners': view['misses_by_locatable_corners']}


def delta(old, new):
    return {key: new[key] - value for key, value in old.items()
            if type(value) in (int, float) and type(new.get(key)) in (int, float)}


def differing_fields(old, new, prefix=''):
    if isinstance(old, dict) and isinstance(new, dict):
        rows = []
        for key in sorted(set(old) | set(new)):
            rows.extend(differing_fields(old.get(key), new.get(key), prefix + '/' + key))
        return rows
    return [] if old == new else [{'field': prefix, 'seed45': old, 'seed46': new}]


def analyze(root, evidence, reference_dir, audit_path, seed45_path):
    audit = read(audit_path)
    old_summary = read(seed45_path)
    require(audit['status'] == 'verified', 'independent score must pass before interpretation')
    original = load_reference(root)
    revised, _ = load_revised(root, original, reference_dir)
    references = {'original': original, 'revised': revised}
    raw = {}; headers = {}
    for model in MODELS:
        rows = [json.loads(line) for line in (evidence / model / 'predictions.jsonl').read_text().splitlines()]
        headers[model] = rows[0]
        raw[model] = {(r['threshold'], r['image_id']): r for r in rows[1:]}
    scored = {}; matched = {}; hidden = {}
    for ref, records in references.items():
        for threshold in THRESHOLDS:
            for model in MODELS:
                hidden[ref, threshold, model] = {}
                for image, record in records.items():
                    predictions = raw[model][threshold, image]['predictions']
                    result = image_result(record, predictions)
                    scored[ref, threshold, model, image] = result
                    matches = {m['gold_index']: m for m in result[0]['matches']}
                    matched[ref, threshold, model, image] = matches
                    for gi, match in matches.items():
                        for side, point in enumerate(record['objects'][gi]['points']):
                            if point[2] == 0:
                                predicted = predictions[match['prediction_index']]['keypoints'][side]
                                hidden[ref, threshold, model][image, gi, side] = point_present(predicted, record['width'], record['height'])

    def model_case(ref, image, gi, threshold, model):
        record = references[ref][image]
        predictions = raw[model][threshold, image]['predictions']
        match = matched[ref, threshold, model, image].get(gi)
        returned = scored[ref, threshold, model, image][2]
        eligible = []
        nearest = None
        for pi, pred in enumerate(predictions):
            iou = overlap(pred['bbox_xyxy'], record['objects'][gi]['box'])
            if nearest is None or iou > nearest['iou']:
                nearest = {'prediction_index': pi, 'iou': iou, 'confidence': pred['confidence'],
                    'bbox_xyxy': pred['bbox_xyxy'], 'keypoints': pred['keypoints']}
            if iou >= 0.50:
                owners = [g for g, m in matched[ref, threshold, model, image].items() if m['prediction_index'] == pi]
                eligible.append({'prediction_index': pi, 'confidence': pred['confidence'],
                    'iou': iou, 'matched_to_reference_rows': [record['objects'][g]['line'] for g in owners],
                    'bbox_xyxy': pred['bbox_xyxy'], 'keypoints': pred['keypoints']})
        matched_prediction = predictions[match['prediction_index']] if match else None
        return {'matched': match is not None,
            'highest_iou_prediction': nearest,
            'matched_prediction': ({'index': match['prediction_index'], 'iou': match['iou'], **matched_prediction}
                                   if matched_prediction else None),
            'visible_endpoint_errors_px': [returned.get((gi, side), {}).get('error_px') for side in (0, 1)],
            'all_predictions_with_matching_iou': sorted(eligible, key=lambda p: (-p['confidence'], p['prediction_index']))}

    def case(ref, image, gi):
        record = references[ref][image]
        obj = record['objects'][gi]
        return {'image_id': image, 'reference': ref, 'row_one_based': obj['line'],
            'image_sha256': record['image_sha256'], 'reference_bbox_xyxy': obj['box'],
            'reference_keypoints': obj['points'], 'locatable_corners': sum(p[2] == 2 for p in obj['points']),
            'models_by_threshold': {str(threshold): {model: model_case(ref, image, gi, threshold, model)
                for model in MODELS} for threshold in THRESHOLDS}}

    changes = []; case_keys = set()
    for ref, records in references.items():
        for threshold in THRESHOLDS:
            for new, old in PAIRS:
                gained = []; lost = []; fp_changes = []
                for image, record in records.items():
                    a = scored[ref, threshold, old, image][0]
                    b = scored[ref, threshold, new, image][0]
                    old_missed, new_missed = set(a['unmatched_gold_indices']), set(b['unmatched_gold_indices'])
                    for gi in sorted(old_missed - new_missed):
                        gained.append({'image_id': image, 'row_one_based': record['objects'][gi]['line']})
                        if threshold == PRIMARY or (new, old) == ('m2', 'm1'):
                            case_keys.add((ref, image, gi))
                    for gi in sorted(new_missed - old_missed):
                        lost.append({'image_id': image, 'row_one_based': record['objects'][gi]['line']})
                        if threshold == PRIMARY or (new, old) == ('m2', 'm1'):
                            case_keys.add((ref, image, gi))
                    if a['fp'] != b['fp']:
                        fp_changes.append({'image_id': image, 'old_fp': a['fp'], 'new_fp': b['fp'],
                            'delta': b['fp'] - a['fp'],
                            'old_unmatched_prediction_indices': a['unmatched_prediction_indices'],
                            'new_unmatched_prediction_indices': b['unmatched_prediction_indices']})
                changes.append({'reference': ref, 'confidence': threshold, 'comparison': f'{new}_vs_{old}',
                    'gained_rows': gained, 'lost_rows': lost, 'miss_delta': len(lost)-len(gained),
                    'per_image_extra_changes': fp_changes, 'extra_delta': sum(r['delta'] for r in fp_changes)})

    pairs = []; point_changes = []; hidden_changes = []; over10 = []
    for ref, records in references.items():
        for new, old in PAIRS:
            radius_rows = []
            for radius in (5, 10):
                gained = []; lost = []
                for image, record in records.items():
                    a = scored[ref, PRIMARY, old, image]
                    b = scored[ref, PRIMARY, new, image]
                    for target, indices in ((gained, b[3][radius]-a[3][radius]), (lost, a[3][radius]-b[3][radius])):
                        for gi in sorted(indices):
                            target.append({'image_id': image, 'row_one_based': record['objects'][gi]['line'],
                                'old_corner_errors_px': [a[2].get((gi, side), {}).get('error_px') for side in (0, 1)],
                                'new_corner_errors_px': [b[2].get((gi, side), {}).get('error_px') for side in (0, 1)]})
                            case_keys.add((ref, image, gi))
                radius_rows.append({'radius_px': radius, 'gained': gained, 'lost': lost})
            pairs.append({'reference': ref, 'comparison': f'{new}_vs_{old}', 'radius_transitions': radius_rows})
            gained = []; lost = []
            for image, record in records.items():
                a = scored[ref, PRIMARY, old, image][2];b = scored[ref, PRIMARY, new, image][2]
                for target, keys in ((gained, set(b)-set(a)), (lost, set(a)-set(b))):
                    for gi, side in sorted(keys):
                        target.append({'image_id': image, 'row_one_based': record['objects'][gi]['line'], 'side': ['left','right'][side]})
            point_changes.append({'reference': ref, 'comparison': f'{new}_vs_{old}', 'gained_visible_endpoints': gained, 'lost_visible_endpoints': lost})
            ah = hidden[ref, PRIMARY, old];bh = hidden[ref, PRIMARY, new];shared=set(ah)&set(bh)
            hidden_changes.append({'reference': ref, 'comparison': f'{new}_vs_{old}',
                'old_matched_hidden': len(ah), 'new_matched_hidden': len(bh),
                'old_returned_hidden': sum(ah.values()), 'new_returned_hidden': sum(bh.values()),
                'shared_matched_hidden': len(shared), 'old_returned_shared': sum(ah[k] for k in shared),
                'new_returned_shared': sum(bh[k] for k in shared),
                'old_only_matched_sides': [{'image_id': i, 'row_one_based': records[i]['objects'][g]['line'], 'side': ['left','right'][s], 'returned': ah[i,g,s]} for i,g,s in sorted(set(ah)-shared)],
                'new_only_matched_sides': [{'image_id': i, 'row_one_based': records[i]['objects'][g]['line'], 'side': ['left','right'][s], 'returned': bh[i,g,s]} for i,g,s in sorted(set(bh)-shared)]})
        for image, record in records.items():
            candidate = scored[ref, PRIMARY, 'm2', image][2]
            for (gi, side), error in sorted(candidate.items()):
                if error['error_px'] > 10:
                    case_keys.add((ref, image, gi))
                    obj = record['objects'][gi]
                    over10.append({'reference': ref, 'image_id': image, 'row_one_based': obj['line'],
                        'side': ['left','right'][side], 'locatable_corners': sum(p[2] == 2 for p in obj['points']),
                        'errors_px': {model: scored[ref, PRIMARY, model, image][2].get((gi,side),{}).get('error_px') for model in MODELS}})

    metrics = {45: {(r['model_id'],r['box_confidence']): r for r in old_summary['metrics']},
               46: {(r['model_id'],r['box_confidence']): r for r in audit['metrics']}}
    separate = []
    for seed in (45,46):
        for ref in references:
            for threshold in THRESHOLDS:
                values = {model: scalars(metrics[seed][model,threshold][ref]) for model in MODELS}
                separate.append({'seed':seed,'reference':ref,'confidence':threshold,'primary':threshold==PRIMARY,
                    'models':values,'candidate_minus_control':delta(values['m1'],values['m2']),
                    'candidate_minus_baseline':delta(values['m0'],values['m2'])})
    return {'schema_version':1,'kind':'independent-seed46-object-and-fixed-seed-interpretation',
        'status':'verified-numeric-interpretation','created_at_utc':datetime.now(timezone.utc).isoformat(),
        'input_files':{'seed46_audit':{'path':str(audit_path),'sha256':digest(audit_path)},
            'seed45_summary':{'path':str(seed45_path),'sha256':digest(seed45_path)},
            **{f'seed46_{m}_predictions':{'path':str(evidence/m/'predictions.jsonl'),'sha256':digest(evidence/m/'predictions.jsonl')} for m in MODELS}},
        'each_seed_reported_separately':separate,'object_match_transitions':changes,
        'primary_both_corner_transitions':pairs,'primary_visible_endpoint_membership':point_changes,
        'primary_hidden_side_membership':hidden_changes,'candidate_returned_visible_endpoints_over10px':over10,
        'case_details':[case(*key) for key in sorted(case_keys)],
        'training_runtime_changes_between_seeds':differing_fields(old_summary['experiment']['training_runtime'],audit['experiment']['training_runtime']),
        'inference_runtime_changes_between_seeds':differing_fields(old_summary['inference']['runtime'],audit['inference_runtime']),
        'limits':['All case descriptions here are numerical; no visual correctness judgment was made.',
            'Changed unmatched prediction counts do not establish a physical cause or ground-truth correctness.',
            'Seed45 and seed46 reuse the same development images and are not pooled as independent observations.',
            'The training GPU/runtime difference between seeds prevents attributing cross-seed differences solely to the random seed.',
            'Hidden-side outputs lack observable reference coordinates and cannot supply coordinate error.',
            'This analysis neither searches another seed nor automatically promotes a model.']}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('root','evidence','reference-dir','audit','seed45-summary','output'):
        parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args();require(not args.output.exists(),'output exists')
    result=analyze(args.root.resolve(),args.evidence.resolve(),args.reference_dir.resolve(),args.audit.resolve(),args.seed45_summary.resolve())
    result['command']=[sys.executable,str(Path(__file__).resolve()),*sys.argv[1:]]
    result['script_sha256']=digest(Path(__file__))
    args.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'status':result['status'],'primary': [r for r in result['each_seed_reported_separately'] if r['primary']],
        'candidate_control_changes': [r for r in result['object_match_transitions'] if r['comparison']=='m2_vs_m1'],
        'over10':result['candidate_returned_visible_endpoints_over10px'],
        'training_runtime_changes':result['training_runtime_changes_between_seeds']},indent=2))


if __name__=='__main__':
    main()
