"""Read-only AST comparison of the delivered notebook and Drive copy variant."""

import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(node):
    return ast.dump(node, include_attributes=False)


def assign(body, name):
    return next(node for node in body if isinstance(node, ast.Assign)
                and any(isinstance(target, ast.Name) and target.id == name for target in node.targets))


def main():
    notebooks = []
    identity = []
    for name, expected_blob in [('pr33-notebook.json', 'df9a8b593982447a9f1ee9737554b9f63189982b'),
                                ('pr34-notebook.json', '75db4f90fea22d43cc4f11a692222429a5ef73d9')]:
        path = ROOT / name
        data = path.read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert blob == expected_blob
        notebooks.append(json.loads(data))
        identity.append({'path': name, 'size_bytes': len(data), 'git_blob_sha': blob,
                         'sha256': sha(path)})
    old, new = notebooks
    assert len(old['cells']) == len(new['cells']) == 16
    trees = []
    changes = []
    for index, (a, b) in enumerate(zip(old['cells'], new['cells'])):
        assert a['cell_type'] == b['cell_type']
        if a['cell_type'] != 'code':
            continue
        before, after = ''.join(a['source']), ''.join(b['source'])
        compile(before, f'pr33-cell-{index}', 'exec')
        compile(after, f'pr34-cell-{index}', 'exec')
        assert b['execution_count'] is None and b['outputs'] == []
        trees.append((index, ast.parse(before), ast.parse(after)))
        if before != after:
            changes.append(index)
    assert changes == [2, 8, 12]
    by_index = {index: (before, after) for index, before, after in trees}
    setup_before, setup_after = by_index[2]
    constants = ['SOURCE_REVISION', 'RECIPE_ID', 'RECIPE_SHA256', 'CANDIDATE_MANIFEST',
                 'CANDIDATE_SHA256', 'RUN_BASE']
    for name in constants:
        assert dump(assign(setup_before.body, name)) == dump(assign(setup_after.body, name))
    bindings = {name: ast.literal_eval(assign(setup_after.body, name).value)
                for name in constants if name != 'RUN_BASE'}
    train_before = next(node for node in by_index[8][0].body if isinstance(node, ast.FunctionDef) and node.name == 'train_one')
    train_after = next(node for node in by_index[8][1].body if isinstance(node, ast.FunctionDef) and node.name == 'train_one')
    assert dump(assign(train_before.body, 'command')) == dump(assign(train_after.body, 'command'))
    receipt_pos = next(i for i, node in enumerate(train_before.body)
                       if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'receipt' for t in node.targets))
    old_checks = train_before.body[receipt_pos:-1]
    new_checks = next(node for node in train_after.body if isinstance(node, ast.FunctionDef) and node.name == 'assert_finished').body
    assert [dump(node) for node in old_checks] == [dump(node) for node in new_checks]
    old_command_pos = train_before.body.index(assign(train_before.body, 'command'))
    new_command_pos = train_after.body.index(assign(train_after.body, 'command'))
    assert [dump(node) for node in train_before.body[old_command_pos:receipt_pos]] == [
        dump(node) for node in train_after.body[new_command_pos:-3]]
    package_before, package_after = by_index[12]
    assert [dump(node) for node in package_before.body] == [dump(node) for node in package_after.body[:-1]]
    assert isinstance(package_after.body[-1], ast.Expr)
    assert ast.unparse(package_after.body[-1]) == 'save_to_drive(RESULTS_ZIP)'
    check = next(node for node in train_after.body[:new_command_pos] if isinstance(node, ast.If))
    assert isinstance(check.body[-1], ast.Return) and ast.unparse(check.body[-1].value) == 'output'
    assert not any(isinstance(node, ast.Call) and ast.unparse(node.func) == 'subprocess.Popen'
                   for node in ast.walk(check))
    result = {
        'schema_version': 1,
        'kind': 'seed46-notebook-drive-protocol-review',
        'status': 'verified-read-only',
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'pr33_revision': 'e4bb7019bcffd80b08cab28c4877dd562ee1d796',
        'pr34_revision': 'cf1ece5b45b5df9e8781d0ea0def4f74f84a4941',
        'notebooks': identity,
        'bindings': bindings,
        'code_cells_compiled_each': len(trees),
        'changed_code_cell_indices': changes,
        'unchanged_code_cell_indices': [i for i, _, _ in trees if i not in changes],
        'checks': {
            'same_source_recipe_candidate_bindings': True,
            'same_training_subprocess_command': True,
            'same_actual_subprocess_monitoring_and_failure_body': True,
            'same_completion_assertions_moved_into_helper': True,
            'same_input_download_and_preflight': True,
            'same_dependency_installation': True,
            'same_sequential_full_arm_calls': True,
            'same_packager_command_and_archive_digest_calculation': True,
            'restore_completed_branch_returns_before_subprocess_training': True,
            'drive_save_added_after_successful_training_or_packaging': True,
            'saved_notebook_has_no_execution_outputs': True,
        },
        'interpretation': [
            'PR34 adds persistence and restoration of completed runs; it does not add partial-training resume or change the pinned numerical experiment.',
            'The notebook-level completion assertions are prechecks; the unchanged packager and checkpoint auditor perform the stronger receipt, checkpoint-byte and paired-runtime checks.',
            'A later packaging session may use L4 while both receipts correctly identify the original A100 training runs; the current packager host is not the recorded training GPU.',
            'Failed historical attempts and Drive transport are described in PR text but are not independently attested by this unexecuted notebook snapshot.',
        ],
        'limits': ['No Colab, Drive mount, backup, restore, model loading, inference or training was executed by this review.',
                   'Returned archive and receipt verification is a separate next audit stage.',
                   'The complete-marker is a transfer-completion convention, not independent content or remote-execution attestation.'],
        'script_sha256': sha(Path(__file__)),
    }
    output = ROOT / 'notebook-protocol-review.json'
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'changed_code_cells': changes, 'output': str(output)}))


if __name__ == '__main__':
    main()
