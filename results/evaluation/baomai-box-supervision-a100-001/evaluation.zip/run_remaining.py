from pathlib import Path
import json
import subprocess
import time

BASE = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/e02731b2268d/dl-supervision')
PYTHON = '/workspace/scratch/ad3aa7140d65/eval-venv/bin/python'
records = []
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == '918b2fdb811bd595fc09de9a423df6c40258c55a'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip()

def run(name, command):
    log = BASE / (name + '.log')
    start = time.time()
    with log.open('x') as stream:
        result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    record = {'name': name, 'command': command, 'cwd': str(ROOT), 'exit_code': result.returncode,
              'started_at_unix': start, 'wall_seconds': time.time() - start, 'log': log.name}
    records.append(record)
    (BASE / 'evaluation-execution.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)

for name, arm in [('m1', 'reference'), ('m2', 'candidate')]:
    manifest = str(BASE / 'returned' / arm / 'checkpoint-manifest.json')
    run(name, [PYTHON, 'scripts/evaluate_pose.py', '--root', str(ROOT),
               '--checkpoint-manifest', manifest, '--output', str(BASE / 'evidence' / name),
               '--device', 'cpu', '--threads', '4', '--overlays', '0'])
for name, arm in [('m0', None), ('m1', 'reference'), ('m2', 'candidate')]:
    command = [PYTHON, 'scripts/diagnose_pose_quality.py', '--root', str(ROOT),
               '--predictions', str(BASE / 'evidence' / name / 'predictions.jsonl'),
               '--output', str(BASE / 'evidence' / (name + '-quality'))]
    if arm:
        command += ['--checkpoint-manifest', str(BASE / 'returned' / arm / 'checkpoint-manifest.json')]
    run(name + '-quality', command)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip()
