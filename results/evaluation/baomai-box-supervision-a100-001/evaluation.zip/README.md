# Box-supervision evaluation evidence

This capsule preserves the completed PR #23 evaluation. Its authoritative result is
`evidence/comparison.json`, produced from clean comparison source commit
`66ba9760935701694ce115b4b6c14ffeb146e5d9`.

**Decision: retain M0 (epoch173).** The corrected-box candidate M2 passes the five
primary metrics against M0, but fails the required matched-control comparison:
its conditional p95 endpoint error is 0.09207354213361985 pixels higher than M1.
Neither trained arm is approved for adoption by this result.

## Contents

- `evidence/m0`, `m1`, `m2`: complete original inference records, summaries,
  run status, and per-image JSON/CSV at box confidences 0.15, 0.25, and 0.40.
- `evidence/m0-quality`, `m1-quality`, `m2-quality`: complete saved quality
  diagnostics, including the illustrative 2/5/10-pixel radius measures.
- `evidence/checkpoints/{reference,candidate}`: original manifests, receipts,
  staging inventories, training logs, and epoch CSVs. Weights are omitted.
- `artifact-audit.json` and `audit_artifact.py`: prior full returned-artifact
  inspection, including the real checkpoint byte hashes and source/data checks.
- Original inference/quality/comparison execution receipts and logs, return
  download record, GPU package index, source commit record, historical parity.
- Independent numerical review, shared-endpoint details, scientific case review,
  original reviewer scripts, and `visual-review` figures/crops/metadata.
- `source/scripts`: the exact 11 replay source files from the published comparison
  commit. Every byte matches the hashes in the original comparison.
- `reference`: the pinned dataset manifest, model card, and box-candidate proposal.
- `manifest.json`: complete size/SHA-256 inventory and pinned provenance.
- `verify_capsule.py`: portable integrity check and optional exact numerical replay.

The final comparison and all original evidence bytes are preserved unchanged.
`comparison-precommit.json` and draft reviewer comparison summaries are excluded.
The refusal-test receipts under `review-checks` are explicitly historical tests
performed before publication; their wrapper hash matches the final published
script. They are supplementary audit records, not the final comparison.

## Verify and replay

The adjacent `evaluation.zip.sha256` and `verification.json` record this ZIP's
SHA-256. The ZIP cannot contain its own digest without a circular dependency.
With the ZIP and checksum file in the same directory:

```sh
sha256sum -c evaluation.zip.sha256
unzip evaluation.zip -d extracted-evaluation
cd extracted-evaluation
python3.12 -B verify_capsule.py --archive ../evaluation.zip
```

For the canonical replay, supply a materialized frozen source/data repository.
The original verification used source commit
`918b2fdb811bd595fc09de9a423df6c40258c55a`. Replay needs its original 20 validation
PNGs and labels, `data/manifest.json`, `metadata/model_card.json`, and the declared
candidate manifest. Git LFS pointer text is not an original PNG. Model weights and
training images are not required for saved-prediction replay.

Use Python 3.12, matching the original evaluator's Python 3.12.14 interpreter.
The replay itself uses the standard library and does not import an ML runtime.
Choose new output paths outside the immutable extracted capsule:

```sh
python3.12 -B verify_capsule.py \
  --archive ../evaluation.zip \
  --replay-root /path/to/materialized/dl \
  --replay-output /path/to/new/replayed-comparison.json \
  --verification-output /path/to/new/replay-verification.json
```

This verifies all archived/extracted bytes, invokes the exact archived comparison
source, and compares every scientific value and every source/input hash with the
final original result. The only excluded fields are the execution timestamp,
command, and the snapshot's Git revision/working-tree metadata. A source snapshot
has no Git repository, so a replay may record those Git fields as null; the
original comparison's clean published commit remains intact.

The equivalent direct command using the contained source is:

```sh
python3.12 -B source/scripts/summarize_box_comparison.py \
  --root /path/to/materialized/dl \
  --evidence evidence \
  --output /path/to/new/replayed-comparison.json
```

From a repository checkout containing the same pinned source, the ordinary
`python3.12 -B scripts/summarize_box_comparison.py --root ... --evidence ...
--output ...` command is equivalent. Do not overwrite `evidence/comparison.json`.
Some supplemental reviewer/rendering scripts preserve original workspace paths;
the portable replay commands above do not depend on those paths.

## Provenance and boundaries

Returned GPU artifact commit: `161f5f20f3aef543cbe2a291db8d510b1123e769`.
Both completed training runs and all three original inference runs record clean
source `918b2fdb811bd595fc09de9a423df6c40258c55a`. The final comparison records clean
source `66ba9760935701694ce115b4b6c14ffeb146e5d9`.

The original GPU ZIP is 39,775,283 bytes with SHA-256
`20d3138d5dcc35b03ab218f9cdd7e6e9b7cc327795f34f26be225a765b2c3009`.
Obtain that artifact separately to repeat its checkpoint-byte audit. This compact
capsule includes its index/audit/evidence, not its two weights or the large ZIP.
The original remote staged YAML/labels were not in that GPU ZIP; their recorded
digests were reconciled to pinned source bytes and deterministic YAML generation.

The fresh capsule check replays saved predictions and decisions. It does not
perform new inference, training, model deserialization, or checkpoint acceptance.
The 20 development-validation images are reused, one training seed was run, and
the 2/5/10-pixel radii are illustrative rather than deployment tolerances. The
physical precision of the frozen annotation coordinates is not certified by a
small computed change in model error. The final JSON retains all such limits.
