"""Focused saved-evidence refusal probes; never train, infer, or load weights."""
import copy
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
from unittest.mock import patch

CODE = Path('/workspace/scratch/470b9cd0057a/dl')
ROOT = Path('/workspace/scratch/e02731b2268d/dl-supervision')
EVIDENCE = Path('/workspace/scratch/470b9cd0057a/box-evaluation/evidence')
OUTPUT = Path(__file__).parent
sys.path.insert(0, str(CODE / 'scripts'))
import summarize_box_comparison as box
from pose_checkpoint import WARMUP_RECIPE_ID, recipe_identity

results = []

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')

def probe(name, mutate, expected):
    with tempfile.TemporaryDirectory() as directory:
        base = Path(directory)
        evidence = base / 'evidence'
        shutil.copytree(EVIDENCE, evidence)
        mutate(evidence)
        output = base / 'rejected.json'
        command = [sys.executable, '-B', str(CODE / 'scripts/summarize_box_comparison.py'),
                   '--root', str(ROOT), '--evidence', str(evidence), '--output', str(output)]
        run = subprocess.run(command, text=True, capture_output=True)
        log = run.stdout + run.stderr
        assert run.returncode == 1 and re.search(expected, log) and not output.exists(), log
        (OUTPUT / f'{name}.log').write_text(log)
        results.append({'name': name, 'command': command, 'exit_code': run.returncode,
                        'expected_refusal': expected, 'output_absent': True, 'passed': True})

def changed_score(evidence):
    path = evidence / 'm2/per_image.json'
    rows = json.loads(path.read_text())
    rows[0]['fn'] += 1
    write_json(path, rows)

def old_recipe(evidence):
    path = evidence / 'checkpoints/reference/checkpoint-manifest.json'
    value = json.loads(path.read_text())
    assert value['recipe_sha256'] == recipe_identity(WARMUP_RECIPE_ID)['recipe_sha256']
    value['recipe_id'] = WARMUP_RECIPE_ID
    write_json(path, value)

def changed_nms(evidence):
    path = evidence / 'm2/predictions.jsonl'
    lines = path.read_text().splitlines()
    header = json.loads(lines[0])
    header['inference']['iou'] = 0.68
    lines[0] = json.dumps(header)
    path.write_text('\n'.join(lines) + '\n')

probe('changed_saved_score', changed_score, 'saved per-image scores differ from replay')
probe('same_digest_wrong_recipe', old_recipe, 'recipe identity differs')
probe('unplanned_nms', changed_nms, 'inference configuration differs')

# Isolate the new wrapper's guard as well as the inherited bundle guard above.
# This is a mutation of a prevalidated audit result, not fabricated training evidence.
audited = box.audit_comparison(ROOT, EVIDENCE)
changed = copy.deepcopy(audited)
changed['models']['m1']['checkpoint_identity']['recipe_id'] = WARMUP_RECIPE_ID
with patch.object(box, 'audit_comparison', return_value=changed):
    try:
        box.summarize(ROOT, EVIDENCE)
    except ValueError as error:
        assert 'explicit recipe box-supervision-warmup-v1' in str(error), str(error)
        results.append({'name': 'wrapper_rejects_same_digest_old_experiment', 'passed': True,
                        'scope': 'isolated guard using altered prevalidated audit result', 'message': str(error)})
    else:
        raise AssertionError('wrapper accepted historical recipe identity')

actual = json.loads((OUTPUT / 'comparison-review.json').read_text())
assert actual['baseline_rule_passers'] == ['m1', 'm2']
assert actual['decision'] == 'retain-M0' and actual['predeclared_adoption_eligible'] == []
assert 'baseline_replacement_eligible' not in actual
primary = next(row['comparisons'] for row in actual['comparisons'] if row['primary'])
assert primary['m2_vs_m0']['passes'] and not primary['m2_vs_m1']['passes']
assert primary['m2_vs_m1']['new_minus_old']['conditional_p95_error_px'] == 0.09207354213361985
results.append({'name': 'actual_tradeoff_cannot_promote_candidate_or_control', 'passed': True,
                'decision': actual['decision'], 'p95_delta_vs_matched_reference_px':
                primary['m2_vs_m1']['new_minus_old']['conditional_p95_error_px']})

record = {'scope': 'three full copied-evidence refusal probes, one isolated wrapper guard, and actual decision assertion; no training, inference, or weight loading',
          'source_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=CODE, text=True).strip(),
          'script_sha256': hashlib.file_digest((CODE / 'scripts/summarize_box_comparison.py').open('rb'), 'sha256').hexdigest(),
          'results': results}
write_json(OUTPUT / 'negative-probes.json', record)
print(json.dumps(record, indent=2))
