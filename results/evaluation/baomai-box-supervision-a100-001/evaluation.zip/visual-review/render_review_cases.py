#!/usr/bin/env python3
"""Read-only figures from immutable saved predictions and original PNGs."""
import hashlib,json,math,sys
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import independent_review as ind
ROOT=Path('/workspace/scratch/e02731b2268d/dl-supervision')
EVIDENCE=Path('/workspace/scratch/470b9cd0057a/box-evaluation/evidence')
OUT=Path(__file__).resolve().parent
GOLD=ind.load_gold(ROOT)
ITEMS={arm:{i['image_id']:i for i in map(json.loads,(EVIDENCE/arm/'predictions.jsonl').read_text().splitlines()[1:]) if i['threshold']==.25} for arm in ('m0','m1','m2')}
RUNS={arm:{name:ind.recount(GOLD[name],i['predictions']) for name,i in rows.items()} for arm,rows in ITEMS.items()}
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
FONTB='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def font(size,bold=False):return ImageFont.truetype(FONTB if bold else FONT,size)
def wrap(draw,text,x,y,max_width,f,fill=(37,44,53),line=24):
 words=text.split();current=''
 for w in words:
  trial=(current+' '+w).strip()
  if draw.textlength(trial,font=f)>max_width and current:
   draw.text((x,y),current,font=f,fill=fill);y+=line;current=w
  else:current=trial
 if current:draw.text((x,y),current,font=f,fill=fill);y+=line
 return y
G=(39,150,86);C1=(194,81,9);C2=(39,95,204)
def cross(d,xy,color):
 x,y=xy;d.line((x-7,y-7,x+7,y+7),fill=color,width=3);d.line((x-7,y+7,x+7,y-7),fill=color,width=3)
def figure(name,row,crop,scale,kind,filename):
 source=ROOT/'data/images/val'/f'{name}.png';original=Image.open(source).convert('RGB');base=original.crop(crop).resize(((crop[2]-crop[0])*scale,(crop[3]-crop[1])*scale),Image.Resampling.NEAREST)
 pw,ph=base.size;gap=16;top=116;foot=156;cw=3*pw+4*gap;ch=top+ph+foot+16
 canvas=Image.new('RGB',(cw,ch),(248,249,251));d=ImageDraw.Draw(canvas)
 d.text((gap,12),f'{name} | original label row {row}',font=font(26,True),fill=(20,28,37))
 subtitle='A measured corner tradeoff on a shared matched object' if kind=='corner' else 'One additional matched object at the fixed confidence 0.25'
 d.text((gap,48),subtitle,font=font(20),fill=(51,61,72))
 obj=GOLD[name]['objects'][row-1];panels=[('Original pixels',None),('M1: original-label fine-tune','m1'),('M2: box-label candidate','m2')];meta={'image_id':name,'original_row':row,'crop_xyxy_px':crop,'scale':scale,'resampling':'nearest','source_image_sha256':ind.digest(source),'reference':obj,'panels':{}}
 for index,(title,arm) in enumerate(panels):
  x=gap+index*(pw+gap);d.text((x,87),title,font=font(18,True),fill=(20,28,37));canvas.paste(base,(x,top))
  xy=lambda p:(x+(p[0]-crop[0])*scale,top+(p[1]-crop[1])*scale)
  def rect(box,color):d.rectangle([*xy(box[:2]),*xy(box[2:])],outline=color,width=2)
  if arm is None:
   footer=f'Unmodified RGB crop. Original bounds {tuple(crop)}; {scale}x nearest-neighbor display.'
   wrap(d,footer,x,top+ph+12,pw,font(17),line=22)
   continue
  r=RUNS[arm][name];match=r['matches'].get(row-1);color=C1 if arm=='m1' else C2
  if match:
   pi=match['prediction_index'];p=r['predictions'][pi];status='Matched'
  else:
   pi=max(range(len(r['predictions'])),key=lambda i:ind.iou(r['predictions'][i]['bbox_xyxy'],obj['box']));p=r['predictions'][pi];status='Unmatched; best available overlap'
  overlap=ind.iou(p['bbox_xyxy'],obj['box']);record={'prediction_index':pi,'prediction':p,'matching_status':status,'iou':overlap}
  meta['panels'][arm]=record
  if kind=='corner':
   target=obj['points'][1];goldxy=xy(target);modelxy=xy(p['keypoints'][1]);rad=5*scale
   for angle in range(0,360,30):d.arc((goldxy[0]-rad,goldxy[1]-rad,goldxy[0]+rad,goldxy[1]+rad),angle,angle+16,fill=G,width=2)
   d.line((*goldxy,*modelxy),fill=color,width=2);d.ellipse((goldxy[0]-5,goldxy[1]-5,goldxy[0]+5,goldxy[1]+5),outline=G,width=3);cross(d,modelxy,color)
   errors=[r['endpoints'][(row-1,s)]['error_px'] for s in (0,1)];record['endpoint_errors_px']=errors
   text=f'Right-corner error: {errors[1]:.6f} px. Both errors: {errors[0]:.3f} / {errors[1]:.3f} px. Box IoU: {overlap:.6f}.'
  else:
   rect(obj['box'],G);rect(p['bbox_xyxy'],color)
   for pt in obj['points']:
    if pt[2]==2:
     gx,gy=xy(pt);d.ellipse((gx-5,gy-5,gx+5,gy+5),outline=G,width=3)
   for pt in p['keypoints']:
    if ind.valid_point(pt,GOLD[name]):cross(d,xy(pt),color)
   text=f'{status}. IoU {overlap:.6f}; confidence {p["confidence"]:.6f}. Fixed IoU gate: 0.50.'
  y=wrap(d,text,x,top+ph+12,pw,font(17),line=22)
  note='Green circle: frozen reference; colored cross: saved prediction. Dashed radius: illustrative 5 px.' if kind=='corner' else 'Green: frozen reference. Colored: saved output. Reference right point is unlocatable; its predicted location has no scored coordinate error.'
  wrap(d,note,x,y+4,pw,font(15),fill=(73,84,96),line=20)
 d.text((gap,ch-28),'Frozen labels and saved outputs are unchanged. Development-set illustration; no physical-accuracy or acceptance-tolerance claim.',font=font(15),fill=(64,75,89))
 canvas.save(OUT/filename)
 meta['rendered_file']=filename;meta['rendered_sha256']=ind.digest(OUT/filename);meta['prediction_file_sha256']={a:ind.digest(EVIDENCE/a/'predictions.jsonl') for a in ('m1','m2')}
 return meta
records=[figure('new_000007',53,(780,365,865,418),6,'corner','corner-regression.png'),figure('new_000009',52,(570,445,670,515),5,'box','object-gain.png')]
(OUT/'figure-data.json').write_text(json.dumps(records,indent=2,allow_nan=False)+'\n')
print(json.dumps([{'file':x['rendered_file'],'sha256':x['rendered_sha256']} for x in records],indent=2))
