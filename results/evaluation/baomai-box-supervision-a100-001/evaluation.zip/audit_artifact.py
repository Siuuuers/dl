#!/usr/bin/env python3
"""Audit the returned box-supervision ZIP without importing torch or loading models.

Read-only inputs: an extracted return bundle and a hydrated clean checkout of
918b2fd. This script only writes the requested JSON report. Recorded runtime
provenance is checked for consistency; it is not an independent replay of GPU
execution. Source data are hashed and the declared box overlays are verified.
"""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import stat
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
PIN = '918b2fdb811bd595fc09de9a423df6c40258c55a'
RETURN_COMMIT = '161f5f20f3aef543cbe2a291db8d510b1123e769'
EXPECTED_ZIP_SHA = '20d3138d5dcc35b03ab218f9cdd7e6e9b7cc327795f34f26be225a765b2c3009'
EXPECTED_ZIP_SIZE = 39775283
EXPECTED_CHECKPOINTS = {
    'reference': '5090f3cd4b064a48e188ffb6e00d0113f77f8910215c5fa5c006b2b62cefcb41',
    'candidate': 'da4a31ec6f468ca3503d786c0790d0e63b229a9a71d237eae60636895ef01bc5',
}
EXPECTED_EDITS = {'new_000012': 6, 'new_000030': 8, 'new_000128': 2}
CANDIDATE_PATH = 'data/candidates/box-refinement-2026-11-07/manifest.json'
SOURCE_FILES = {
    'scripts/train_pose_comparison.py', 'scripts/pose_checkpoint.py',
    'scripts/stage_pose_training.py', 'scripts/verify_pose_candidate.py',
    'scripts/verify_pose_box_candidate.py', 'scripts/evaluate_pose.py',
    'scripts/pose_scoring.py',
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args])


def git_bytes(root, revision, path):
    return git(root, 'show', f'{revision}:{path}')


def check(value, message):
    if not value:
        raise ValueError(message)


def canonical_hash(value):
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode())


def provenance_row(root, revision, relative, expected_sha, expected_size=None):
    blob = git_bytes(root, revision, relative)
    match = re.fullmatch(rb'version https://git-lfs.github.com/spec/v1\noid sha256:([0-9a-f]{64})\nsize ([0-9]+)\n', blob)
    if match:
        digest, size = match[1].decode(), int(match[2])
        kind = 'git_lfs_pointer'
    else:
        digest, size, kind = sha(blob), len(blob), 'git_blob'
    check(digest == expected_sha, f'pinned Git content identity differs: {revision}:{relative}')
    if expected_size is not None:
        check(size == expected_size, f'pinned Git size differs: {revision}:{relative}')
    return {'path': relative, 'git_representation': kind, 'sha256': digest,
            'size_bytes': size, 'git_revision': revision}


def audit(args):
    root, bundle, archive = args.source.resolve(), args.extracted.resolve(), args.archive.resolve()
    check(root.is_dir() and bundle.is_dir() and archive.is_file(), 'missing audit input')
    check(git(root, 'rev-parse', 'HEAD').decode().strip() == PIN, 'hydrated checkout is not pinned training revision')
    check(git(root, 'status', '--porcelain').decode() == '', 'hydrated source tree is not clean')
    sys.path.insert(0, str(root / 'scripts'))
    from evaluate_pose import preflight_dataset
    from package_gpu_results import collect_arm, check_pair, shared_settings, verify_archive, portable_relative
    from pose_checkpoint import _read_json, recipe_identity, check_training_settings
    from stage_pose_training import source_state, source_name, yaml_bytes
    from verify_pose_box_candidate import verify_box_candidate

    report = {
        'schema_version': 1, 'kind': 'baomai-box-supervision-return-artifact-audit',
        'status': 'in_progress', 'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'script': {'path': str(Path(__file__).resolve()), 'sha256': file_sha(__file__)},
        'inputs': {'archive': str(archive), 'extracted': str(bundle), 'source_root': str(root),
                   'returned_repository_commit': RETURN_COMMIT, 'training_source_commit': PIN},
        'scope': 'Read actual ZIP bytes, manifests, receipts, CSVs, logs, and pinned source/data bytes. No training, model deserialization, inference, or accuracy approval.',
    }
    check(archive.stat().st_size == EXPECTED_ZIP_SIZE and file_sha(archive) == EXPECTED_ZIP_SHA,
          'downloaded archive differs from expected PR artifact')
    index = _read_json(bundle / 'gpu-results-manifest.json')
    check(index['schema_version'] == 1 and index['kind'] == 'baomai-paired-training-results', 'unexpected index schema')
    declared = index['files']
    check(len(declared) == 12 and len({row['path'] for row in declared}) == 12, 'unexpected payload inventory')
    inventory = []
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
        check(len(names) == len(set(names)) == 13, 'archive has wrong member count or duplicate names')
        check(set(names) == {'gpu-results-manifest.json', *(row['path'] for row in declared)}, 'archive extras/missing')
        check(z.testzip() is None, 'archive CRC failure')
        for info in z.infolist():
            portable_relative(info.filename)
            mode = (info.external_attr >> 16) & 0xFFFF
            check(not info.is_dir() and not stat.S_ISLNK(mode), f'archive contains directory or link: {info.filename}')
            check(stat.S_IFMT(mode) in (0, stat.S_IFREG), f'archive has special file: {info.filename}')
            target = bundle / info.filename
            check(target.is_file() and not target.is_symlink(), f'extracted member missing/link: {info.filename}')
            check(not any(p.is_symlink() for p in target.parents if p != bundle and p.is_relative_to(bundle)), 'extracted parent symlink')
            with z.open(info) as stream:
                digest = hashlib.file_digest(stream, 'sha256').hexdigest()
            check(target.stat().st_size == info.file_size and file_sha(target) == digest, 'extracted bytes differ from archive')
            inventory.append({'path': info.filename, 'size_bytes': info.file_size,
                              'compressed_bytes': info.compress_size, 'sha256': digest, 'crc32': f'{info.CRC:08x}'})
    check({p.relative_to(bundle).as_posix() for p in bundle.rglob('*') if p.is_file()} == set(names), 'extracted bundle extras')
    verify_archive(archive, (bundle / 'gpu-results-manifest.json').read_bytes(), declared)
    report['archive'] = {'sha256': EXPECTED_ZIP_SHA, 'size_bytes': EXPECTED_ZIP_SIZE,
                         'unique_safe_regular_members': 13, 'crc_passed': True,
                         'all_indexed_sizes_and_hashes_passed': True,
                         'all_extracted_bytes_equal_archive': True, 'inventory': inventory}

    preflight = preflight_dataset(root, require_weights=True)
    proposal_path = root / CANDIDATE_PATH
    proposal = _read_json(proposal_path)
    candidate_check = verify_box_candidate(root, proposal_path)
    state = source_state(root, proposal_path)
    # source_state rehashes all original PNGs and all source/candidate labels,
    # checks PNG dimensions, parses label geometry, and derives both staged plans.
    reference_manifest = _read_json(root / 'data/manifest.json')
    card = _read_json(root / 'metadata/model_card.json')
    pinned_inputs = []
    for path in ['data/manifest.json', 'metadata/model_card.json', CANDIDATE_PATH,
                 proposal['annotation_policy']['path'],
                 (proposal_path.parent / proposal['review']['path']).relative_to(root).as_posix()]:
        pinned_inputs.append(provenance_row(root, PIN, path, file_sha(root / path), (root / path).stat().st_size))
    pinned_inputs.append(provenance_row(root, PIN, card['checkpoint'], card['sha256'], card['size_bytes']))
    for record in state['records']:
        for kind in ['image', 'label']:
            path = 'data/' + record[kind]
            pinned_inputs.append(provenance_row(root, PIN, path, record[kind + '_sha256'], (root/path).stat().st_size))
    for change in proposal['changes']:
        path = (proposal_path.parent / change['candidate_label']).relative_to(root).as_posix()
        pinned_inputs.append(provenance_row(root, PIN, path, change['candidate_label_sha256'], (root/path).stat().st_size))
    declared_source = proposal['source_revision']
    check(git(root, 'cat-file', '-t', declared_source).decode().strip() == 'commit', 'candidate declared source is not a known commit')
    check(sha(git_bytes(root, declared_source, 'data/manifest.json')) == preflight['manifest_sha256'], 'candidate declared source manifest differs')
    for record in state['records']:
        check(sha(git_bytes(root, declared_source, 'data/' + record['label'])) == record['label_sha256'], 'candidate source original label differs')
    overlay_rows = []
    for change in proposal['changes']:
        original = (root / 'data' / change['source_label']).read_bytes()
        result = original.splitlines(keepends=True)
        for row in change['rows']:
            pos = row['original_row'] - 1
            check(result[pos].rstrip(b'\r\n').decode() == row['source_row_text'], 'overlay original row mismatch')
            ending = result[pos][len(result[pos].rstrip(b'\r\n')):]
            result[pos] = row['candidate_row_text'].encode() + ending
        reconstructed = b''.join(result)
        target = proposal_path.parent / change['candidate_label']
        check(reconstructed == target.read_bytes() and sha(reconstructed) == change['candidate_label_sha256'], 'candidate row reconstruction differs')
        check(len(change['rows']) == EXPECTED_EDITS[change['image_id']], 'unexpected edit count')
        overlay_rows.append({'image_id': change['image_id'], 'source_label_sha256': change['source_label_sha256'],
                             'candidate_label_sha256': change['candidate_label_sha256'],
                             'edited_rows': len(change['rows']),
                             'edited_edges': sum(len(r['box_edges_changed']) for r in change['rows']),
                             'source_objects': change['source_objects'], 'candidate_objects': change['candidate_objects'],
                             'reconstructed_bytes_match_pinned_overlay': True,
                             'class_and_endpoint_tokens_retained': True})
    report['pinned_inputs'] = {'training_tree': git(root, 'rev-parse', PIN+'^{tree}').decode().strip(),
        'original_pngs_hashed_and_header_checked': 157, 'original_labels_hashed_and_parsed': 157,
        'candidate_overlay_labels_hashed_and_parsed': 3,
        'initial_checkpoint_bytes_sha256': preflight['model_sha256'], 'initial_checkpoint_bytes_verified': True,
        'candidate_declared_source': {'commit': declared_source, 'git_object_verified': True,
                                     'manifest_and_all_157_original_label_bytes_match': True},
        'candidate_mechanical_verification': candidate_check, 'overlays': overlay_rows,
        'pinned_git_identities': pinned_inputs}

    bundles = {arm: collect_arm(preflight, bundle / arm, arm) for arm in ['reference', 'candidate']}
    check_pair(bundles['reference'], bundles['candidate'])
    ref = bundles['reference']['receipt']; cand = bundles['candidate']['receipt']
    check(index['source'] == state['source'] == bundles['reference']['staging']['source'], 'index candidate source differs')
    check(index['training_source'] == ref['source'] and index['runtime'] == ref['runtime'], 'index runtime/source differs')
    check(index['shared_training_settings'] == shared_settings(ref), 'index shared settings differ')
    expected_rows = sorted([{k:v for k,v in f.items() if k != 'source_path'} for b in bundles.values() for f in b['files']], key=lambda x: x['path'])
    check(declared == expected_rows, 'archive index is not exactly derived from arm manifests')
    source_checks = []
    for relative in sorted(SOURCE_FILES):
        recorded = ref['source']['files_sha256'].get(relative)
        check(recorded == file_sha(root/relative) == sha(git_bytes(root, PIN, relative)), 'recorded training code differs from pinned published bytes')
        source_checks.append({'path': relative, 'sha256': recorded, 'git_blob_matches': True, 'hydrated_file_matches': True})
    check(set(ref['source']['files_sha256']) == SOURCE_FILES, 'training source file inventory differs')
    for relative in ['scripts/package_gpu_results.py']:
        check(file_sha(root/relative) == sha(git_bytes(root, PIN, relative)), 'local verifier differs from pin')
    report['source_and_runtime'] = {'recorded_clean_revision': ref['source']['revision'],
        'recorded_working_tree_status': ref['source']['working_tree_status'],
        'seven_source_files_match_pin': source_checks,
        'packager_sha256': file_sha(root/'scripts/package_gpu_results.py'),
        'both_arms_record_identical_runtime': True, 'runtime': ref['runtime'],
        'precision_note': 'amp=false; float32_matmul_precision=highest; CUDA matmul TF32 false; cuDNN TF32 true. Deterministic algorithms enabled with warn_only=true. These are recorded settings, not a bitwise reproducibility guarantee.'}
    check(ref['source']['revision'] == cand['source']['revision'] == PIN, 'wrong training source pin')
    settings_diff = {k: {'reference': ref['training_settings'][k], 'candidate': cand['training_settings'][k]}
                     for k in ref['training_settings'] if ref['training_settings'][k] != cand['training_settings'][k]}
    check(set(settings_diff) == {'data', 'project', 'save_dir'}, 'unintended settings differences')
    report['matched_recipe'] = {'identity': recipe_identity('box-supervision-warmup-v1'),
        'settings_verified_per_arm': 114, 'each_complete_settings_mapping': {a:b['receipt']['training_settings'] for a,b in bundles.items()},
        'only_different_settings': settings_diff, 'index_and_each_arm_identity_verified': True}

    report['arms'] = {}
    for arm, data in bundles.items():
        receipt, staging = data['receipt'], data['staging']
        check(index['arms'][arm] == {'checkpoint_manifest': f'{arm}/checkpoint-manifest.json',
                                    'checkpoint_identity': data['identity']}, 'index checkpoint identity differs')
        check(receipt['checkpoint']['sha256'] == EXPECTED_CHECKPOINTS[arm], 'unexpected returned checkpoint')
        check(receipt['completed_epochs'] == list(range(1,31)), 'incomplete epochs')
        check(receipt['batches_completed'] == 30*35 == 1050 and receipt['images_processed'] == 30*137 == 4110, 'wrong completion counters')
        check(receipt['optimizer_steps'] == 78, 'unexpected optimizer update count')
        check(len(receipt['batch_samples']) == 4 and len(receipt['optimizer_step_samples']) == 8, 'unexpected diagnostic samples')
        check(all(x['witness_parameter_changed'] for x in receipt['optimizer_step_samples']), 'sample lacks parameter change witness')
        check(staging['source'] == state['source'], 'staged source mismatches independent reconstruction')
        for relative, digest in staging['code_sha256'].items():
            check(relative in SOURCE_FILES and digest == sha(git_bytes(root,PIN,relative)), 'staging source code mismatch')
        variant_checks = {}
        for variant, inventory_data in staging['variants'].items():
            plan = state['plans'][variant]
            expected_files = [{'path': relative, 'source_path': source_name(item['source'],root),
                               'source_sha256': item['sha256'], 'output_sha256': item['sha256']}
                              for relative,item in sorted(plan.items())]
            actual_files = sorted(inventory_data['files'],key=lambda x:x['path'])
            check(actual_files == expected_files, 'recorded image/label inventory differs from pinned actual source')
            check(inventory_data['counts'] == state['counts'][variant], 'recorded dataset counts differ')
            derived = yaml_bytes(Path(staging['output_root']) / variant)
            check(sha(derived) == inventory_data['data_yaml_sha256'], 'derived deterministic YAML hash differs')
            variant_checks[variant] = {'recorded_file_entries': len(actual_files),
                'images': sum(x['path'].startswith('images/') for x in actual_files),
                'labels': sum(x['path'].startswith('labels/') for x in actual_files),
                'inventory_sha256': canonical_hash(actual_files), 'every_entry_reconciled_to_pinned_source_bytes': True,
                'counts': inventory_data['counts'], 'data_yaml_sha256': sha(derived),
                'data_yaml_derived_utf8': derived.decode(), 'original_yaml_in_return_zip': False,
                'deterministic_reconstruction_matches_recorded_hash': True}
        actual_ref = {x['path']:x['output_sha256'] for x in staging['variants']['reference']['files']}
        actual_cand = {x['path']:x['output_sha256'] for x in staging['variants']['candidate']['files']}
        differences = sorted(k for k in actual_ref if actual_ref[k] != actual_cand[k])
        check(differences == sorted('labels/train/'+x+'.txt' for x in EXPECTED_EDITS), 'unexpected staged differences')
        check(receipt['data_yaml_sha256'] == variant_checks[arm]['data_yaml_sha256'], 'receipt training YAML differs')
        loaders = receipt['loader_verification']
        check(loaders == [
            {'split':'train','images':137,'objects':3772,'visible_endpoints':6839,'batches':35,'batch_size':4},
            {'split':'val','images':20,'objects':664,'visible_endpoints':1227,'batches':3,'batch_size':8}], 'actual recorded loader counts differ')
        with (bundle / arm / receipt['results']['path']).open(newline='') as stream:
            reader = csv.DictReader(stream)
            rows = [{k.strip():v.strip() for k,v in row.items()} for row in reader]
        check(len(rows)==30 and [int(r['epoch']) for r in rows]==list(range(1,31)), 'CSV epoch count differs')
        check(all(math.isfinite(float(v)) for r in rows for v in r.values()), 'CSV nonfinite values')
        text = (bundle / arm / receipt['log']['path']).read_text()
        clean = re.sub(r'\x1b\[[0-9;]*[mKG]', '', text)
        lines = clean.splitlines()
        completion = [l for l in lines if re.match(r'^30 epochs completed in ',l)]
        check(len(completion)==1 and any('Optimizer stripped from ' in l and '/weights/last.pt' in l for l in lines), 'raw log lacks completion/finalization')
        warnings = list(dict.fromkeys(l for l in lines if re.search(r'\bwarning\b|\btraceback\b|^error',l,re.I)))
        sampled_epochs = {int(m.group(1)) for l in lines if (m := re.match(r'^\s*(\d+)/30\s+',l))}
        check(sampled_epochs == set(range(1,31)), 'raw log does not show all30epochs')
        edited_batches = [s for s in receipt['batch_samples'] if set(s['image_ids']) & set(EXPECTED_EDITS)]
        report['arms'][arm] = {'checkpoint_identity': data['identity'],
            'completion': {k:receipt[k] for k in ['status','purpose','completed_epochs','batches_completed','images_processed',
                'optimizer_steps','optimizer_parameter_change_observed','training_returned','finalization_completed',
                'validation_executed','checkpoint_selection','inputs_reverified_after_worker']},
            'execution': receipt['execution'], 'worker_wall_seconds': receipt['worker_wall_seconds'],
            'worker_peak_rss_mib': receipt['worker_peak_rss_mib'], 'recorded_loader_verification': loaders,
            'staging_variants': variant_checks, 'only_changed_staged_paths': differences,
            'all_original_images_and_validation_labels_identical_between_arms': True,
            'batch_samples': receipt['batch_samples'], 'optimizer_step_samples': receipt['optimizer_step_samples'],
            'sampled_batches_containing_edited_images': edited_batches,
            'results_csv': {'rows':len(rows),'finite_numeric_cells':True,'epochs':list(range(1,31)),
                'first_epoch': rows[0], 'final_epoch':rows[-1],
                'interpretation':'Trainer diagnostics only; no independent fixed-threshold acceptance decision.'},
            'log': {'raw_sha256': receipt['log']['sha256'], 'all_30_epochs_observed': True,
                'completion_line': completion[0], 'optimizer_stripped_last_checkpoint': True,
                'warning_or_traceback_lines': warnings}}
    check(ref['batch_samples'][0]['loss'] == cand['batch_samples'][0]['loss'] and
          ref['batch_samples'][1]['loss'] == cand['batch_samples'][1]['loss'], 'unexpected first two sample losses')
    check(ref['batch_samples'][2]['image_ids'] == cand['batch_samples'][2]['image_ids'] and
          {'new_000012','new_000030'} <= set(ref['batch_samples'][2]['image_ids']), 'edited-label sample not matched')
    report['changed_label_training_evidence'] = {
        'first_two_sampled_losses_identical': True, 'third_batch_same_image_ids': ref['batch_samples'][2]['image_ids'],
        'edited_images_in_third_batch':['new_000012','new_000030'],
        'reference_loss':ref['batch_samples'][2]['loss'],'candidate_loss':cand['batch_samples'][2]['loss'],
        'third_batch_optimizer_parameter_change_witness_both_arms': True,
        'interpretation':'Unlike the prior one-batch CPU smoke, these returned diagnostic samples include edited-label images and observe differing losses at the third optimizer update. This confirms the changed supervision reached training according to the matched receipts; it does not establish better generalization.'}
    report['limits'] = [
        'The ZIP archives 12 payload files plus its index. It does not archive staged images, staged label files, original data.yaml, fit/args.yaml, run configuration, separate progress JSON, or the GPU Python environment.',
        'All recorded image/label inventories were reconciled to independently hashed pinned source data, and deterministic YAML was reconstructed from the recorded output roots. This verifies compatibility with those bytes; it cannot directly re-inspect omitted files from the remote training machine.',
        'Clean-tree, source/runtime/backend settings, optimizer events, input rechecks, and completion are recorded by the verified runner and corroborated by raw log/CSV/manifest identities. Artifact hashing does not cryptographically attest the hardware execution itself.',
        'Only the first four batches and eight optimizer updates have detailed sample records; totals and completion are recorded for the full run. Per-update gradient tensors and all intermediate checkpoints are not returned.',
        'Both checkpoints are finalized last.pt files. Logs also mention best.pt, which is not included or selected. No checkpoint was deserialized by this audit.',
        'The frozen 20-image validation split is reused. No new independent scenes, deployment video, physical calibration, multi-seed study, or production accuracy evidence is provided by this training package.',
        'AMP is false, but cuDNN TF32 is recorded as enabled; deterministic warn-only is true. Do not describe the execution as a strict bitwise reproducibility guarantee or uniformly full IEEE FP32 math.',
        'Existing candidate review statements remain historical; this mechanical audit performs no new visual certification of box boundaries.',
        'Passing this audit establishes a coherent completed matched comparison ready for independent evaluation, not acceptance or promotion of either model.'
    ]
    check('torch' not in sys.modules and 'ultralytics' not in sys.modules, 'audit unexpectedly imported model runtime')
    check(git(root,'status','--porcelain').decode() == '', 'audit changed hydrated source tree')
    report['safety_of_audit'] = {'training_executed':False,'model_deserialized':False,'inference_executed':False,
                               'torch_imported':False,'ultralytics_imported':False,'source_modified':False}
    report['status'] = 'passed'
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive',type=Path,required=True)
    parser.add_argument('--extracted',type=Path,required=True)
    parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args = parser.parse_args()
    report = audit(args)
    args.output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'status':report['status'],'output':str(args.output.resolve()),
                      'output_sha256':file_sha(args.output),'output_bytes':args.output.stat().st_size,
                      'archive_sha256':report['archive']['sha256'],
                      'arms':{a:{'epochs':len(v['completion']['completed_epochs']),
                                 'batches':v['completion']['batches_completed'],
                                 'optimizer_updates':v['completion']['optimizer_steps']} for a,v in report['arms'].items()}},indent=2))

if __name__ == '__main__':
    main()
