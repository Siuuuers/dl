#!/usr/bin/env python3
"""Independent standard-library recount of frozen baomai predictions; no ML imports."""
import argparse
import hashlib
import json
import math
from pathlib import Path

FIELDS = ('fn', 'fp', 'missing_endpoints', 'conditional_median_error_px', 'conditional_p95_error_px')
THRESHOLDS = (0.15, 0.25, 0.4)

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def quantile(values, q):
    values = sorted(values)
    if not values:
        return None
    at = q * (len(values) - 1)
    lo, hi = math.floor(at), math.ceil(at)
    return values[lo] + (values[hi] - values[lo]) * (at - lo)

def stats(values):
    values = list(values)
    return {'count': len(values), 'mean': math.fsum(values)/len(values) if values else None,
            'median': quantile(values, .5), 'p95': quantile(values, .95)}

def load_gold(root):
    manifest = json.loads((root/'data/manifest.json').read_text())
    data = {}
    for r in manifest['records']:
        if r['split'] != 'val':
            continue
        image, label = root/'data'/r['image'], root/'data'/r['label']
        assert digest(image) == r['image_sha256'] and digest(label) == r['label_sha256']
        width, height = r['original_size']
        objs = []
        for text in label.read_text().splitlines():
            if not text.strip():
                continue
            row = list(map(float, text.split()))
            assert len(row) == 11 and row[0] == 0
            c, x, y, w, h, lx, ly, lv, rx, ry, rv = row
            objs.append({'class_id': 0,
                         'box': [(x-w/2)*width, (y-h/2)*height, (x+w/2)*width, (y+h/2)*height],
                         'points': [(lx*width, ly*height, lv), (rx*width, ry*height, rv)]})
        data[r['id']] = {'objects': objs, 'width': width, 'height': height}
    assert len(data) == 20
    assert sum(len(r['objects']) for r in data.values()) == 664
    return data

def iou(a, b):
    overlap = max(0, min(a[2], b[2])-max(a[0], b[0])) * max(0, min(a[3], b[3])-max(a[1], b[1]))
    if not overlap:
        return 0.
    area_a = (a[2]-a[0])*(a[3]-a[1]); area_b = (b[2]-b[0])*(b[3]-b[1])
    return overlap/(area_a+area_b-overlap)

def valid_point(p, rec):
    return p[2] >= .5 and all(v is not None and math.isfinite(v) for v in p[:2]) and 0 <= p[0] < rec['width'] and 0 <= p[1] < rec['height']

def recount(rec, preds):
    gold = rec['objects']; remaining = set(range(len(gold))); matches = {}; endpoints = {}; availability = [0, 0]
    for pi in sorted(range(len(preds)), key=lambda i: (-preds[i]['confidence'], i)):
        possibilities = [(iou(preds[pi]['bbox_xyxy'], gold[gi]['box']), gi) for gi in remaining if preds[pi]['class_id'] == gold[gi]['class_id']]
        possibilities = [(overlap, gi) for overlap, gi in possibilities if overlap >= .5]
        if not possibilities:
            continue
        overlap, gi = min(possibilities, key=lambda x: (-x[0], x[1]))
        remaining.remove(gi); matches[gi] = {'prediction_index': pi, 'iou': overlap}
        for side, (g, p) in enumerate(zip(gold[gi]['points'], preds[pi]['keypoints'])):
            returned = valid_point(p, rec)
            if g[2] == 0:
                availability[0] += 1; availability[1] += returned
            elif returned:
                endpoints[(gi, side)] = {'error_px': math.hypot(p[0]-g[0], p[1]-g[1]), 'dx_px': p[0]-g[0], 'dy_px': p[1]-g[1]}
    matched_preds = {m['prediction_index'] for m in matches.values()}
    unmatched = set(range(len(preds))) - matched_preds
    duplicate = sum(any(preds[pi]['class_id']==gold[gi]['class_id'] and iou(preds[pi]['bbox_xyxy'],gold[gi]['box'])>=.5 for gi in matches) for pi in unmatched)
    visible = sum(g[2] == 2 for obj in gold for g in obj['points'])
    both = {gi for gi,obj in enumerate(gold) if all(p[2]==2 for p in obj['points'])}
    both_returned = {gi for gi in both if (gi,0) in endpoints and (gi,1) in endpoints}
    pairs = {radius: {gi for gi in both_returned if all(endpoints[(gi,s)]['error_px']<=radius for s in (0,1))} for radius in (2,5,10)}
    counts = {'gold_count':len(gold),'prediction_count':len(preds),'tp':len(matches),'fn':len(remaining),'fp':len(unmatched),
              'duplicate_fp':duplicate,'other_fp':len(unmatched)-duplicate,'visible_endpoints':visible,
              'returned_endpoints':len(endpoints),'missing_endpoints':visible-len(endpoints),'both_visible_objects':len(both),
              'both_visible_objects_with_both_returned':len(both_returned),'unlocatable_reference_endpoints':2*len(gold)-visible,
              'unlocatable_on_matched_objects':availability[0],'returned_on_unlocatable_reference':availability[1]}
    return {'counts':counts,'matches':matches,'endpoints':endpoints,'pairs':pairs,'predictions':preds,
            'misses_by_point_availability':{n:sum(sum(p[2]==2 for p in gold[gi]['points'])==n for gi in remaining) for n in (0,1,2)}}

def main():
    a=argparse.ArgumentParser();a.add_argument('--root',type=Path,required=True);a.add_argument('--evidence',type=Path,required=True);a.add_argument('--output',type=Path,required=True);args=a.parse_args()
    gold=load_gold(args.root); runs={};out={'status':'independently-recounted','method':'Independent parser, confidence-ordered greedy IoU matching, endpoint filtering and pooled statistics; no repository scoring functions or weights imported.','file_sha256':{},'models':{},'comparisons':{},'limits':['One training seed on repeatedly used development data.','Quantiles condition on returned visible endpoints; missing cases remain in radius denominators.','Availability on reference-v0 points does not establish coordinate correctness or physical false positives.','No independent-test or deployment certification.']}
    headers={}
    for arm in ('m0','m1','m2'):
        p=args.evidence/arm/'predictions.jsonl';lines=[json.loads(x) for x in p.read_text().splitlines() if x.strip()];header,*items=lines
        assert len(items)==60 and {(i['image_id'],i['threshold']) for i in items}=={(name,t) for name in gold for t in THRESHOLDS}
        out['file_sha256'][str(p)]=digest(p);headers[arm]=header;runs[arm]={}
        status=json.loads((args.evidence/arm/'run_status.json').read_text()); assert status['status']=='complete' and status['exit_code']==0 and status['scored_image_threshold_pairs']==60
        saved={(x['image_id'],x['threshold']):x for x in json.loads((args.evidence/arm/'per_image.json').read_text())}
        for item in items:
            key=(item['image_id'],item['threshold']);r=recount(gold[key[0]],item['predictions']);runs[arm][key]=r
            for field in ('tp','fn','fp','duplicate_fp','other_fp','visible_endpoints','returned_endpoints','missing_endpoints'):
                assert r['counts'][field]==saved[key][field],(arm,key,field)
            assert {(gi,m['prediction_index']) for gi,m in r['matches'].items()}=={(m['gold_index'],m['prediction_index']) for m in saved[key]['matches']}
        per_threshold={}
        for t in THRESHOLDS:
            records=[r for (name,th),r in runs[arm].items() if th==t];counts={k:sum(r['counts'][k] for r in records) for k in records[0]['counts']};errors=[ep['error_px'] for r in records for ep in r['endpoints'].values()]
            counts.update(conditional_median_error_px=quantile(errors,.5),conditional_p95_error_px=quantile(errors,.95),precision=counts['tp']/counts['prediction_count'],recall=counts['tp']/counts['gold_count'],misses_by_point_availability={n:sum(r['misses_by_point_availability'][n] for r in records) for n in (0,1,2)},radii={radius:{'both_corners_success':sum(len(r['pairs'][radius]) for r in records),'both_corners_denominator':counts['both_visible_objects'],'visible_endpoint_success':sum(ep['error_px']<=radius for r in records for ep in r['endpoints'].values()),'visible_endpoint_denominator':counts['visible_endpoints']} for radius in (2,5,10)})
            per_threshold[t]=counts
        out['models'][arm]={'model_sha256':header['model_sha256'],'metrics':per_threshold,'empty_scenes':{name:{t:runs[arm][name,t]['counts']['prediction_count'] for t in THRESHOLDS} for name,r in gold.items() if not r['objects']}}
    for k in ('source','runtime','inference','images'):
        assert headers['m0'][k]==headers['m1'][k]==headers['m2'][k],k
    out['common_environment']=headers['m0']['runtime'];out['inference']=headers['m0']['inference'];out['inference_source']=headers['m0']['source']
    endpoints={arm:{(name,gi,side):ep for (name,t),r in rows.items() if t==.25 for (gi,side),ep in r['endpoints'].items()} for arm,rows in runs.items()}
    common=set.intersection(*(set(v) for v in endpoints.values()));out['all_model_common_returned_endpoints']={'count':len(common),'errors':{arm:stats(rows[key]['error_px'] for key in sorted(common)) for arm,rows in endpoints.items()}}
    for new,old in (('m1','m0'),('m2','m0'),('m2','m1')):
        detail={'criteria':{},'object_transitions':{'lost':[],'gained':[]},'per_image':[]}
        for t in THRESHOLDS:
            n=out['models'][new]['metrics'][t];o=out['models'][old]['metrics'][t];deltas={k:n[k]-o[k] if n[k] is not None and o[k] is not None else None for k in FIELDS}
            detail['criteria'][t]={'new_minus_old':deltas,'passes':all(v is not None and v<=0 for v in deltas.values()) and any(v is not None and v<0 for v in deltas.values())}
        shared=set(endpoints[new])&set(endpoints[old]);changes=[endpoints[new][k]['error_px']-endpoints[old][k]['error_px'] for k in sorted(shared)]
        detail['common_endpoint_changes']={'shared':len(shared),'only_old':len(set(endpoints[old])-shared),'only_new':len(set(endpoints[new])-shared),'better':sum(d<0 for d in changes),'worse':sum(d>0 for d in changes),'equal':sum(d==0 for d in changes),'error_new_minus_old_px':stats(changes)}
        for name,g in gold.items():
            n=runs[new][name,.25];o=runs[old][name,.25];detail['per_image'].append({'image_id':name,'fn_new_minus_old':n['counts']['fn']-o['counts']['fn'],'fp_new_minus_old':n['counts']['fp']-o['counts']['fp'],'pairs5_new_minus_old':len(n['pairs'][5])-len(o['pairs'][5]),'pairs5_became_success':sorted(gi+1 for gi in n['pairs'][5]-o['pairs'][5]),'pairs5_became_failure':sorted(gi+1 for gi in o['pairs'][5]-n['pairs'][5])})
            for label,indices,before,after in (('lost',set(o['matches'])-set(n['matches']),o,n),('gained',set(n['matches'])-set(o['matches']),n,o)):
                for gi in sorted(indices):
                    candidates=[(iou(p['bbox_xyxy'],g['objects'][gi]['box']),i,p) for i,p in enumerate(after['predictions']) if p['class_id']==g['objects'][gi]['class_id']]
                    best=max(candidates,key=lambda x:x[0]) if candidates else None
                    detail['object_transitions'][label].append({'image_id':name,'original_row':gi+1,'reference_visible_points':sum(p[2]==2 for p in g['objects'][gi]['points']),'qualifying_iou':before['matches'][gi]['iou'],'unmatched_model_best_iou':best[0] if best else None,'unmatched_model_best_confidence':best[2]['confidence'] if best else None,'unmatched_model_best_prediction_index':best[1] if best else None,'unmatched_model_best_assigned_elsewhere':best[1] in {m['prediction_index'] for m in after['matches'].values()} if best else False})
        out['comparisons'][new+'_vs_'+old]=detail
    out['candidate_meets_rule_against_both_controls']=out['comparisons']['m2_vs_m0']['criteria'][.25]['passes'] and out['comparisons']['m2_vs_m1']['criteria'][.25]['passes']
    out['decision']='candidate-eligible-for-bounded-adoption' if out['candidate_meets_rule_against_both_controls'] else 'retain-epoch173'
    args.output.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'decision':out['decision'],'primary_metrics':{a:m['metrics'][.25] for a,m in out['models'].items()}},indent=2))

if __name__=='__main__':
    main()
