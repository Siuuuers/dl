#!/usr/bin/env python3
"""Supplement the independent saved-output audit with precise diagnostic cohorts."""
import json,math
from pathlib import Path
import independent_review as ind
ROOT=Path('/workspace/scratch/e02731b2268d/dl-supervision')
BASE=Path(__file__).resolve().parent
EV=BASE/'evidence'
GOLD=ind.load_gold(ROOT)
AUDIT=json.loads((BASE/'independent-review.json').read_text())
RUNS={};ENDPOINTS={};RAW={}
for arm in ('m0','m1','m2'):
 RAW[arm]={i['image_id']:i for i in map(json.loads,(EV/arm/'predictions.jsonl').read_text().splitlines()[1:]) if i['threshold']==.25}
 RUNS[arm]={name:ind.recount(GOLD[name],i['predictions']) for name,i in RAW[arm].items()}
 ENDPOINTS[arm]={(name,gi,s):p for name,r in RUNS[arm].items() for (gi,s),p in r['endpoints'].items()}
parity=[]
for arm in ('m0','m1','m2'):
 s=json.loads((EV/arm/'summary.json').read_text())
 q=json.loads((EV/(arm+'-quality')/'quality-summary.json').read_text())
 assert s['matching_iou']==.5 and s['endpoint_confidence']==.5
 for sm,qm in zip(s['metrics'],q['metrics']):
  assert sm['threshold']==qm['box_confidence']
  nm=AUDIT['models'][arm]['metrics'][str(sm['threshold'])]
  for field in ('gold_count','prediction_count','tp','fn','fp','duplicate_fp','other_fp','visible_endpoints','returned_endpoints','missing_endpoints','conditional_median_error_px','conditional_p95_error_px'):
   assert nm[field]==sm[field],(arm,sm['threshold'],field)
  for field in ('gold_count','prediction_count','tp','fn','fp','visible_endpoints','both_visible_objects','both_visible_objects_with_both_returned','unlocatable_reference_endpoints','unlocatable_on_matched_objects','returned_on_unlocatable_reference'):
   assert nm[field]==qm[field],(arm,qm['box_confidence'],field)
  assert nm['returned_endpoints']==qm['returned_visible_endpoints']
  assert nm['precision']==qm['object_precision'] and nm['recall']==qm['object_recall']
  for radius in qm['radii']:
   nr=nm['radii'][str(radius['radius_px'])]
   assert nr['both_corners_success']==radius['both_visible_objects_within_radius']
   assert nr['visible_endpoint_success']==radius['visible_endpoints_within_radius']
  parity.append({'arm':arm,'box_confidence':sm['threshold'],'all_counts_quantiles_and_radius_counts_equal':True})

def ident(k):return {'image_id':k[0],'original_row':k[1]+1,'side':('left','right')[k[2]]}
def detail(k):
 name,gi,side=k;row={'endpoint':ident(k),'frozen_reference_xy':GOLD[name]['objects'][gi]['points'][side][:2],'models':{}}
 for arm in ('m0','m1','m2'):
  r=RUNS[arm][name];match=r['matches'].get(gi)
  if match:
   p=r['predictions'][match['prediction_index']]
   row['models'][arm]={'prediction_index':match['prediction_index'],'box_iou':match['iou'],'box_confidence':p['confidence'],'predicted_endpoint':p['keypoints'][side],'residual':ENDPOINTS[arm].get(k)}
  else:row['models'][arm]={'matched':False}
 return row
shared=set(ENDPOINTS['m1'])&set(ENDPOINTS['m2'])
above=[k for k in sorted(shared) if ENDPOINTS['m1'][k]['error_px']<=5<ENDPOINTS['m2'][k]['error_px']]
below=[k for k in sorted(shared) if ENDPOINTS['m2'][k]['error_px']<=5<ENDPOINTS['m1'][k]['error_px']]
extra=sorted(set(ENDPOINTS['m2'])-shared)
quantiles={}
for arm,points in ENDPOINTS.items():
 keys=sorted(points,key=lambda k:points[k]['error_px']);at=.95*(len(keys)-1);lo,hi=math.floor(at),math.ceil(at)
 quantiles[arm]={'returned_endpoint_count':len(keys),'fractional_zero_based_order_index':at,'interpolation_fraction':at-lo,'p95':ind.quantile([p['error_px'] for p in points.values()],.95),'lower_order_endpoint':{'zero_based_order_index':lo,**detail(keys[lo])},'upper_order_endpoint':{'zero_based_order_index':hi,**detail(keys[hi])}}
pairsets={arm:{(name,gi) for name,r in rows.items() for gi in r['pairs'][5]} for arm,rows in RUNS.items()}
object_flips={'became_failure':[{'image_id':name,'original_row':gi+1,'m1_errors':[ENDPOINTS['m1'][(name,gi,s)]['error_px'] for s in (0,1)],'m2_errors':[ENDPOINTS['m2'][(name,gi,s)]['error_px'] for s in (0,1)]} for name,gi in sorted(pairsets['m1']-pairsets['m2'])],'became_success':[{'image_id':name,'original_row':gi+1,'m1_errors':[ENDPOINTS['m1'][(name,gi,s)]['error_px'] for s in (0,1)],'m2_errors':[ENDPOINTS['m2'][(name,gi,s)]['error_px'] for s in (0,1)]} for name,gi in sorted(pairsets['m2']-pairsets['m1'])]}
summary={'status':'independently-recounted-and-visually-inspected','primary_decision':'Retain epoch173 under the predeclared rule requiring the corrected-label candidate to pass against both M0 and the fresh original-label arm.','core_finding':'The candidate improves all five primary metrics over M0 and four of five versus its matched reference, but its p95 endpoint error is higher than the matched reference.','isolated_label_effect':AUDIT['comparisons']['m2_vs_m1']['criteria']['0.25'],'saved_aggregate_parity':parity,'shared_endpoint_count':len(shared),'shared_endpoint_errors':{arm:ind.stats(ENDPOINTS[arm][k]['error_px'] for k in sorted(shared)) for arm in ('m1','m2')},'shared_endpoint_changes':AUDIT['comparisons']['m2_vs_m1']['common_endpoint_changes'],'additional_candidate_endpoints':[detail(k) for k in extra],'p95_order_statistics':quantiles,'illustrative_5px_shared_endpoint_flips':{'crossed_above_count':len(above),'crossed_below_count':len(below),'crossed_above':[detail(k) for k in above],'crossed_below':[detail(k) for k in below]},'illustrative_5px_two_corner_flips':object_flips,'object_match_transitions':AUDIT['comparisons']['m2_vs_m1']['object_transitions'],'figures':json.loads((BASE/'visual-review/figure-data.json').read_text()),'visual_observations':[{'case':'new_000007 row 53','observation':'A small lower-rack front has a soft/blurred right contour. Both models remain matched to this same frozen row. The candidate right endpoint moves left/down relative to the reference-arm endpoint; its error to the frozen reference increases from 3.6266752280953365 to 5.0591698402255325 px. This is a representative illustrative-radius regression, not by itself the cause or defining observation of the pooled p95.'},{'case':'new_000009 row 52','observation':'An exposed lower-front fragment sits immediately beside the gripper. Both models output boxes extending into occluder material, but the selected candidate box is narrower and passes the fixed IoU gate. Its confidence 0.2654355466365814 is just above the declared 0.25 operating threshold. The reference right corner is unlocatable; neither predicted right coordinate is treated as measurable ground truth.'},{'case':'p95 defining points','observation':'Candidate p95 interpolates the right endpoint of new_000059 row 3 and the right endpoint of new_000055 row 20. Both objects are near the upper image boundary; the cropped original contours were inspected. The two order statistics identify the percentile mathematically, without establishing that these two examples caused the shift.'}],'interpretation_limits':['The new endpoint has 3.485438640052279 px error, below the p95. The p95 regression remains on all 1190 shared endpoints, so it is not a harder-returned-cohort artifact.','The 5 px radius is a descriptive diagnostic, not a newly selected acceptance criterion. Its six failed objects and one recovered object explain 524 to 519 both-corner successes versus the fresh reference.','The approximately 0.092 px p95 difference is an exact measured difference under the existing rule. It is not evidence of physically meaningful subpixel precision, statistical significance, or across-seed regression.','Improvements against M0 combine fine-tuning with the annotation treatment. Only the matched candidate-versus-reference contrast isolates the declared label difference in this one experiment.','Unchanged reference annotations are not newly certified by inspecting these output-selected examples. No validation coordinate or policy was changed after evaluation.','No checkpoint adoption, threshold optimization, training, inference, or annotation mutation was performed by this independent review.'],'artifacts':{'numeric_audit':'independent-review.json','raw_endpoint_changes':'independent-common-endpoint-details.json','historical_prediction_parity':'independent-historical-parity.json','visual_metadata':'visual-review/figure-data.json'}}
summary['primary_per_image_detection_status']={arm:{'nonempty_images':sum(bool(r['counts']['gold_count']) for r in rows.values()),'nonempty_with_fn_or_fp':sum(bool(r['counts']['gold_count']) and bool(r['counts']['fn'] or r['counts']['fp']) for r in rows.values()),'perfect_nonempty_image_ids':[name for name,r in rows.items() if r['counts']['gold_count'] and not r['counts']['fn'] and not r['counts']['fp']]} for arm,rows in RUNS.items()}
(BASE/'independent-scientific-summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
print(json.dumps({'saved_aggregate_records_verified':len(parity),'common_endpoints':len(shared),'candidate_only_endpoints':len(extra),'crossed_above5':len(above),'crossed_below5':len(below),'two_corner_failures':len(object_flips['became_failure']),'two_corner_successes':len(object_flips['became_success']),'summary':str(BASE/'independent-scientific-summary.json')},indent=2))
