#!/usr/bin/env python3
"""Verify this evidence capsule and optionally replay its frozen comparison.

Use Python 3.12 for exact equality with the recorded evaluation. Model weights
are intentionally absent. Replay requires the original validation PNGs/labels
and source metadata at the separately supplied materialized repository root.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import platform
import stat
import subprocess
import sys
import time
import zipfile

sys.dont_write_bytecode = True


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load_json(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, f'duplicate JSON key: {key}')
            result[key] = value
        return result
    def invalid(value):
        raise ValueError(f'nonstandard JSON number: {value}')
    return json.loads(Path(path).read_text(), object_pairs_hook=unique, parse_constant=invalid)


def portable(name):
    require(isinstance(name, str) and name and '\\' not in name and ':' not in name
            and all(ord(c) >= 32 for c in name), f'nonportable member: {name!r}')
    path = PurePosixPath(name)
    require(not path.is_absolute() and '..' not in path.parts and str(path) == name
            and name != '.', f'unsafe member: {name!r}')
    return path


def scientific_projection(result):
    # Preserve every scientific value, all input hashes, and all source hashes.
    # Only execution metadata expected to change when replayed is excluded.
    projected = {key: value for key, value in result.items()
                 if key not in ('created_at_utc', 'command')}
    projected['source'] = {key: value for key, value in result['source'].items()
                           if key not in ('revision', 'working_tree_status')}
    return projected


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    allow_nan=False).encode()).hexdigest()


def verify(capsule, archive=None, replay_root=None, replay_output=None):
    capsule = capsule.resolve()
    manifest_path = capsule / 'manifest.json'
    manifest = load_json(manifest_path)
    require(manifest['schema_version'] == 1 and
            manifest['kind'] == 'baomai-box-supervision-evaluation-capsule', 'unsupported manifest')
    rows = manifest['files']
    require(len({row['path'] for row in rows}) == len(rows), 'duplicate manifest path')
    expected = {'manifest.json', *(row['path'] for row in rows)}
    for path in capsule.rglob('*'):
        require(not path.is_symlink(), f'symlink inside capsule: {path}')
        require(path.is_file() or path.is_dir(), f'special file inside capsule: {path}')
    actual = {p.relative_to(capsule).as_posix() for p in capsule.rglob('*') if p.is_file()}
    require(actual == expected, 'capsule has missing/extra files')
    for row in rows:
        portable(row['path'])
        path = capsule / row['path']
        require(path.is_file() and path.stat().st_size == row['size_bytes']
                and digest(path) == row['sha256'], f'payload differs: {row["path"]}')
    comparison = load_json(capsule / 'evidence/comparison.json')
    require(comparison['source']['revision'] == manifest['provenance']['comparison_source_commit']
            and comparison['source']['working_tree_status'] == '', 'original comparison source is not clean/pinned')
    for relative, recorded in comparison['source']['files_sha256'].items():
        require(digest(capsule / 'source' / relative) == recorded, f'source snapshot differs: {relative}')
    require(not any(p.suffix in ('.pt', '.pth', '.onnx', '.engine') for p in capsule.rglob('*')),
            'model weights must not be bundled')
    outcome = {'schema_version': 1, 'status': 'verified',
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'capsule': str(capsule), 'manifest_sha256': digest(manifest_path),
        'payload_files_verified': len(rows), 'total_files_verified': len(expected),
        'all_payload_sizes_and_sha256_match': True, 'no_links_or_extra_files': True,
        'original_comparison_clean_source_preserved': comparison['source']['revision'],
        'source_snapshot_file_count': len(comparison['source']['files_sha256']),
        'model_weights_in_capsule': False,
        'verification_runtime': {'python': platform.python_version(), 'executable': sys.executable}}
    if archive:
        archive = archive.resolve()
        with zipfile.ZipFile(archive) as z:
            names = z.namelist()
            require(len(names) == len(expected) and set(names) == expected, 'ZIP inventory differs')
            for info in z.infolist():
                portable(info.filename)
                mode = info.external_attr >> 16
                require(not info.is_dir() and stat.S_IFMT(mode) in (0, stat.S_IFREG), 'nonregular ZIP member')
            require(z.testzip() is None, 'ZIP CRC error')
            require(z.read('manifest.json') == manifest_path.read_bytes(), 'ZIP manifest differs')
            for row in rows:
                with z.open(row['path']) as stream:
                    actual_digest = hashlib.file_digest(stream, 'sha256').hexdigest()
                require(actual_digest == row['sha256'] and z.getinfo(row['path']).file_size == row['size_bytes'],
                        f'ZIP payload differs: {row["path"]}')
        outcome['archive'] = {'path': str(archive), 'sha256': digest(archive),
            'size_bytes': archive.stat().st_size, 'members': len(expected),
            'crc_passed': True, 'unique_safe_regular_members': True,
            'all_archived_and_extracted_bytes_equal': True}
    if replay_root is not None:
        require(replay_output is not None, '--replay-root requires --replay-output')
        require(sys.version_info[:2] == (3, 12), 'use Python 3.12 for the canonical exact replay')
        replay_root, replay_output = replay_root.resolve(), replay_output.resolve()
        require(not replay_output.exists() and not replay_output.is_symlink(), 'replay output already exists')
        require(not replay_output.is_relative_to(capsule), 'write replay output outside immutable capsule')
        command = [sys.executable, '-B', str(capsule / 'source/scripts/summarize_box_comparison.py'),
                   '--root', str(replay_root), '--evidence', str(capsule / 'evidence'),
                   '--output', str(replay_output)]
        started = time.perf_counter()
        result = subprocess.run(command, cwd=capsule, capture_output=True, text=True)
        seconds = time.perf_counter() - started
        require(result.returncode == 0, f'replay refused: {result.stdout}\n{result.stderr}')
        replayed = load_json(replay_output)
        original_projection = scientific_projection(comparison)
        replay_projection = scientific_projection(replayed)
        require(replay_projection == original_projection, 'scientific result differs from final original')
        require(canonical_hash(replay_projection) == canonical_hash(original_projection),
                'canonical exact replay digest differs')
        primary = next(row['comparisons'] for row in replayed['comparisons'] if row['primary'])
        outcome['replay'] = {'status': 'verified', 'command': command, 'cwd': str(capsule),
            'exit_code': result.returncode, 'wall_seconds': seconds,
            'stdout': result.stdout, 'stderr': result.stderr,
            'output': str(replay_output), 'output_sha256': digest(replay_output),
            'all_scientific_values_and_input_source_hashes_exactly_equal': True,
            'scientific_projection_sha256': canonical_hash(original_projection),
            'excluded_execution_metadata': ['created_at_utc', 'command', 'source.revision', 'source.working_tree_status'],
            'original_source': comparison['source'], 'replay_source': replayed['source'],
            'decision': replayed['decision'],
            'candidate_meets_rule_against_both_controls': replayed['candidate_meets_rule_against_both_controls'],
            'predeclared_adoption_eligible': replayed['predeclared_adoption_eligible'],
            'baseline_rule_passers': replayed['baseline_rule_passers'],
            'primary_comparisons': primary,
            'primary_metrics': {arm: next(row for row in value['metrics'] if row['threshold'] == .25)
                                for arm, value in replayed['models'].items()},
            'all_three_common_returned_endpoints': replayed['common_returned_endpoints']['count'],
            'matched_reference_candidate_shared_endpoints': replayed['paired_primary_diagnostics']['m2_vs_m1']['common_returned_endpoints'],
            'training_or_inference_executed': False,
            'scope': 'Exact saved-prediction, score, quality, receipt and decision replay; no model weights available or loaded.'}
        # The replay must leave all packaged payload bytes unchanged.
        require({p.relative_to(capsule).as_posix() for p in capsule.rglob('*') if p.is_file()} == expected,
                'replay wrote files into capsule')
        require(all(digest(capsule / row['path']) == row['sha256'] for row in rows), 'replay changed capsule inputs')
        outcome['replay']['capsule_inputs_unchanged'] = True
    else:
        require(replay_output is None, '--replay-output requires --replay-root')
    return outcome


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', type=Path, help='optional original ZIP for CRC/hash verification')
    parser.add_argument('--replay-root', type=Path, help='materialized pinned validation repository')
    parser.add_argument('--replay-output', type=Path, help='new replay JSON outside the extracted capsule')
    parser.add_argument('--verification-output', type=Path, help='new verification JSON outside the capsule')
    args = parser.parse_args()
    capsule = Path(__file__).resolve().parent
    try:
        if args.verification_output:
            require(not args.verification_output.exists() and not args.verification_output.is_symlink(), 'verification output exists')
            require(not args.verification_output.resolve().is_relative_to(capsule), 'verification output must be outside capsule')
        outcome = verify(capsule, args.archive, args.replay_root, args.replay_output)
        encoded = json.dumps(outcome, indent=2, allow_nan=False) + '\n'
        if args.verification_output:
            args.verification_output.parent.mkdir(parents=True, exist_ok=True)
            args.verification_output.write_text(encoded)
        print(encoded, end='')
        return 0
    except (ValueError, OSError, KeyError, TypeError, zipfile.BadZipFile) as error:
        print(f'Capsule verification refused: {error}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
