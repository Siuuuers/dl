"""Package and independently extract the completed seed45 text evidence."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess
import sys
import time
import zipfile


WORK = Path('/workspace/scratch/e8c6ed25e3ab/annotation-eval-work')
ROOT = Path('/workspace/scratch/e8c6ed25e3ab/dl-training')
REPLAY = Path('/workspace/scratch/e8c6ed25e3ab/dl-annotation-replay')
OUT = WORK / 'package'
PAYLOAD = OUT / 'payload'
EXTRACTED = OUT / 'fresh-extraction'
ARCHIVE = OUT / 'evaluation.zip'
SOURCE = 'ed4ee162738685bff93d6cad1402d95e128bceb4'
TREE = '3925bda1f492e1cc7b06027a3b230f09c70792b7'
RETURN = '074f4d28736fab8b82baf7e56e6ad551997ae3c6'
TRAINING = '1c5d2e48ab26c578c5f6660010d6ecfb33231eb8'
ALLOWED = {'.json', '.jsonl', '.csv', '.log', '.txt', '.md', '.py'}
commands = []


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def run(command, cwd=None, env=None):
    before = time.monotonic()
    started = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(command, cwd=cwd, env=env, text=True, capture_output=True)
    record = {'command': list(map(str, command)), 'cwd': str(cwd) if cwd else None,
              'started_at_utc': started, 'exit_code': result.returncode,
              'seconds': time.monotonic() - before, 'stdout': result.stdout,
              'stderr': result.stderr}
    commands.append(record)
    write(OUT / 'packaging-commands.json', commands)
    if result.returncode:
        raise RuntimeError(record)
    return result.stdout.strip()


def copy(source, relative):
    source = Path(source)
    relative = PurePosixPath(relative)
    assert source.is_file() and not source.is_symlink(), source
    assert not relative.is_absolute() and '..' not in relative.parts
    assert relative.suffix.lower() in ALLOWED, relative
    # Text-only payload: no camera pixels, model bytes, nested archives or caches.
    source.read_text(encoding='utf-8')
    destination = PAYLOAD / str(relative)
    destination.parent.mkdir(parents=True, exist_ok=True)
    assert not destination.exists()
    expected = sha(source)
    shutil.copyfile(source, destination)
    assert sha(source) == sha(destination) == expected


def semantic(value, root):
    """Normalize only explicit invocation/time/root-location fields."""
    value = json.loads(json.dumps(value))
    assert value['revised_reference']['root'] == str(root / 'data/references/visible-front-2026-11-10')
    assert value['procedure']['original_label_path_base'] == str(root)
    assert value['procedure']['revised_label_path_base'] == str(root / 'data/references/visible-front-2026-11-10')
    value['revised_reference']['root'] = '<REVISED_REFERENCE_ROOT>'
    value['procedure']['original_label_path_base'] = '<REPOSITORY_ROOT>'
    value['procedure']['revised_label_path_base'] = '<REVISED_REFERENCE_ROOT>'
    del value['created_at_utc']
    del value['command']
    return value


def main():
    assert not any(p.exists() for p in (OUT, REPLAY))
    OUT.mkdir()
    PAYLOAD.mkdir()
    original_path = WORK / 'evidence/seed-45/comparison-original-and-pr30.json'
    original = read(original_path)
    independent = read(WORK / 'analysis-work/independent-annotation-numeric-audit.json')
    assert original['status'] == 'verified-descriptive-only'
    assert original['source']['revision'] == SOURCE
    assert original['source']['working_tree_status'] == ''
    assert independent['status'] == 'verified'
    assert independent['per_image_reference_evaluations_verified'] == 360
    assert independent['reference_specific_aggregates_verified'] == 18
    assert independent['official_comparison_sha256'] == sha(original_path)
    execution = read(WORK / 'execution.json')
    assert all(row['exit_code'] == 0 for row in execution['commands'])
    for path in sorted((WORK / 'evidence').rglob('*')):
        if path.is_file() and path.suffix != '.pt':
            copy(path, path.relative_to(WORK).as_posix())
    for name in ['execution.json', 'baseline-continuity.json', 'archive-verification.json',
                 'method-review.json', 'original-pixel-review.json', 'interpretation-review.json']:
        copy(WORK / name, name)
    for path in sorted((WORK / 'audit').iterdir()):
        if path.is_file() and path.suffix in ALLOWED:
            copy(path, 'audit/' + path.name)
    for path in sorted((WORK / 'analysis-work').iterdir()):
        if path.is_file() and path.suffix in ALLOWED:
            copy(path, 'independent/' + path.name)
    for path in sorted(WORK.glob('*.log')):
        copy(path, 'logs/' + path.name)
    for path in sorted(WORK.glob('report-review-*.json')):
        copy(path, 'review/' + path.name)
    copy(WORK / 'run_evaluation.py', 'run_evaluation.py')
    copy(__file__, 'package_evidence.py')
    readme = '''# Reviewed-annotation seed45 evaluation evidence

Report date: 2026-11-11, Asia/Hong_Kong. Execution records use UTC.

This capsule preserves the completed three-model evaluation of PR32's matched
seed45 training pair. It does not contain a seed46 result. The working model
remains epoch173 while the predeclared seed46 confirmation is prepared.

## Identity

- GPU return: PR32, commit `074f4d28736fab8b82baf7e56e6ad551997ae3c6`.
- Return ZIP: 39,774,041 bytes; SHA-256 `598c6e1177401690e0057fcaafa260a41e798b216d1c59309b652a94d518293e`.
- Training source: `1c5d2e48ab26c578c5f6660010d6ecfb33231eb8`.
- Clean inference and replay source: `ed4ee162738685bff93d6cad1402d95e128bceb4`.
- Candidate manifest SHA-256: `28fc8f5da95605089d61fb062132200ed296c3a10b216f1a61dbda1798ea4ba7`.
- Recipe: `reviewed-annotations-seed45-v1`.
- Three fresh model runs, 180 unique image/model/threshold records, 360 per-image
  reference evaluations, and 18 reference-specific aggregates.
- Original and PR30 revised references are reported separately. The latter has
  661 objects, 1,228 visible endpoints and 584 two-corner-eligible objects.

All files inside this ZIP are text. `inventory.json` hashes every other payload
file and deliberately excludes itself. Original camera images, model weights
and the returned GPU ZIP are not duplicated. The returned weights remain in
PR32; their byte validation is recorded in the return audit. The separate
resource-trial receipt/log was not returned and is not independently verified.

## Replay the complete official summary

Use Python 3.12.14 for closest numerical reproduction. Saved-prediction scoring
needs no ML packages and performs no training, inference or weight loading.
Extract this ZIP into a fresh directory. Obtain a clean pinned checkout and its
original validation images through Git LFS:

```bash
GIT_LFS_SKIP_SMUDGE=1 git clone https://github.com/Siuuuers/dl.git dl-replay
GIT_LFS_SKIP_SMUDGE=1 git -C dl-replay checkout --detach ed4ee162738685bff93d6cad1402d95e128bceb4
git -C dl-replay lfs pull --include='data/images/val/*.png' --exclude=''
python dl-replay/scripts/rescore_annotation_comparison.py \\
  --root dl-replay \\
  --evidence /absolute/path/to/extracted/evidence/seed-45 \\
  --candidate data/candidates/annotations-2026-11-10/manifest.json \\
  --recipe reviewed-annotations-seed45-v1 \\
  --reference-dir dl-replay/data/references/visible-front-2026-11-10 \\
  --evaluation-revision ed4ee162738685bff93d6cad1402d95e128bceb4 \\
  --output /absolute/path/to/new-comparison.json
```

The output path must not exist. Use exactly this source for seed45 replay.
The later seed46 recipe registry changes `pose_checkpoint.py` bytes; the strict
source audit correctly refuses to replay these old receipts under that source.

Compare the complete output with
`evidence/seed-45/comparison-original-and-pr30.json`. Exclude only the top-level
`/created_at_utc` and `/command`. Check that these three fields identify your
new checkout, then normalize the original and new checkout locations:

- `/revised_reference/root`: `<REVISED_REFERENCE_ROOT>`.
- `/procedure/original_label_path_base`: `<REPOSITORY_ROOT>`.
- `/procedure/revised_label_path_base`: `<REVISED_REFERENCE_ROOT>`.

All other values must match exactly. No numerical tolerance, source identity,
stored runtime, prediction timing, training timestamp, or result field is
excluded. The external `verification.json` records the actual fresh extraction,
clean detached replay checkout, full semantic equality and exact exclusion rules.

## Independent numerical audit

`independent/independent_annotation_score.py` separately implements label parsing,
IoU, confidence-ordered one-to-one matching, endpoint availability, Euclidean
errors and quantiles using only the standard library. It imports no production
scoring or matching functions. Its command is:

```bash
python /absolute/path/to/extracted/independent/independent_annotation_score.py \\
  --root dl-replay \\
  --evidence /absolute/path/to/extracted/evidence/seed-45 \\
  --reference-dir dl-replay/data/references/visible-front-2026-11-10 \\
  --official-comparison /absolute/path/to/extracted/evidence/seed-45/comparison-original-and-pr30.json \\
  --output /absolute/path/to/new-independent-audit.json
```

The preserved independent audit agrees on all counts and identities. Its largest
floating-point difference from the production calculation is 1.11e-14. The
independent numerical comparison permits 1e-10 absolute arithmetic tolerance;
the official full-summary replay above requires exact numerical equality.

## Layout and limits

- `evidence/seed-45/`: saved predictions, scores, quality outputs, complete
  comparison, and small checkpoint evidence bundles with receipts and logs.
- `audit/`: independent return integrity, input, training and runtime audit.
- `independent/`: independent scorer, numerical audit and primary case records.
- `interpretation-review.json`: threshold/radius transitions, coordinates,
  common-endpoint diagnostics and separate reference effects.
- `original-pixel-review.json`: the three original-image inspection records.
- `execution.json`, `logs/`: actual command identities, exit codes and outputs.
- `baseline-continuity.json`: fresh M0 versus historical payload continuity.
- `run_evaluation.py`, `package_evidence.py`: exact orchestration sources.

Original scratch paths in execution records are preserved as provenance; the
commands above are the portable replay interface. The compact capsule alone
cannot repeat returned-weight byte checks. Recorded remote inventories are not
independent hardware attestation. One seed on a repeatedly used 20-image
development split does not establish statistical significance, independent-test
generalization or a physical acceptance tolerance. The 579/584 result applies only
to two-corner-eligible objects; nineteen of the candidate's 24 misses have fewer
than two locatable reference corners. Old box-only seeds are not pooled here.
'''
    (PAYLOAD / 'README.md').write_text(readme)
    inventory = {p.relative_to(PAYLOAD).as_posix(): {'size_bytes': p.stat().st_size, 'sha256': sha(p)}
                 for p in sorted(PAYLOAD.rglob('*')) if p.is_file()}
    write(PAYLOAD / 'inventory.json', {'schema_version': 1, 'payload_files': inventory,
          'inventory_self_excluded': True, 'all_payload_files_text': True,
          'model_weights_included': False, 'camera_images_included': False})
    with zipfile.ZipFile(ARCHIVE, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(PAYLOAD.rglob('*')):
            if path.is_file():
                info = zipfile.ZipInfo(path.relative_to(PAYLOAD).as_posix(), (2026, 11, 11, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.create_system = 3
                info.external_attr = (stat.S_IFREG | 0o644) << 16
                archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(ARCHIVE) as archive:
        infos = archive.infolist()
        names = [info.filename for info in infos]
        assert len(names) == len(set(names)) == len(inventory) + 1
        assert set(names) == set(inventory) | {'inventory.json'}
        assert archive.testzip() is None
        EXTRACTED.mkdir()
        for info in infos:
            relative = PurePosixPath(info.filename)
            assert not relative.is_absolute() and '..' not in relative.parts and '\\' not in info.filename
            assert stat.S_ISREG(info.external_attr >> 16) and not info.is_dir()
            assert relative.suffix.lower() in ALLOWED
            data = archive.read(info)
            data.decode('utf-8')
            if info.filename != 'inventory.json':
                assert len(data) == inventory[info.filename]['size_bytes']
                assert hashlib.sha256(data).hexdigest() == inventory[info.filename]['sha256']
            destination = EXTRACTED / info.filename
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open('xb') as stream:
                stream.write(data)
        assert read(EXTRACTED / 'inventory.json') == read(PAYLOAD / 'inventory.json')
    for relative, expected in inventory.items():
        assert sha(EXTRACTED / relative) == expected['sha256']
    run(['git', '-C', str(ROOT), 'worktree', 'add', '--detach', str(REPLAY), SOURCE],
        env={**os.environ, 'GIT_LFS_SKIP_SMUDGE': '1'})
    assert run(['git', '-C', str(REPLAY), 'rev-parse', 'HEAD']) == SOURCE
    assert run(['git', '-C', str(REPLAY), 'rev-parse', 'HEAD^{tree}']) == TREE
    hydrated = []
    for row in read(ROOT / 'data/manifest.json')['records']:
        relative = 'data/' + row['image']
        source, destination = ROOT / relative, REPLAY / relative
        assert sha(source) == row['image_sha256']
        destination.unlink()
        os.link(source, destination)
        assert sha(destination) == row['image_sha256']
        hydrated.append({'path': relative, 'sha256': row['image_sha256']})
    assert len(hydrated) == 157
    # Refresh the stat cache through the normal LFS clean filter after manual hydration.
    # The resulting index must remain the exact original tree; no data change is accepted.
    run(['git', '-C', str(REPLAY), 'add', '--renormalize', '--sparse', '--', 'data/images'])
    assert run(['git', '-C', str(REPLAY), 'write-tree']) == TREE
    before = run(['git', '-C', str(REPLAY), 'status', '--porcelain'])
    assert before == '', before
    output = OUT / 'replayed-comparison.json'
    run([sys.executable, str(REPLAY / 'scripts/rescore_annotation_comparison.py'),
         '--root', str(REPLAY), '--evidence', str(EXTRACTED / 'evidence/seed-45'),
         '--candidate', 'data/candidates/annotations-2026-11-10/manifest.json',
         '--recipe', 'reviewed-annotations-seed45-v1',
         '--reference-dir', str(REPLAY / 'data/references/visible-front-2026-11-10'),
         '--evaluation-revision', SOURCE, '--output', str(output)], cwd=REPLAY)
    assert semantic(original, ROOT) == semantic(read(output), REPLAY)
    after = run(['git', '-C', str(REPLAY), 'status', '--porcelain'])
    assert after == '', after
    sidecar = OUT / 'evaluation.zip.sha256'
    sidecar.write_text(sha(ARCHIVE) + '  evaluation.zip\n')
    verification = {'schema_version': 1, 'kind': 'reviewed-annotation-seed45-evidence-verification',
        'status': 'PASS', 'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'archive': {'path': 'evaluation.zip', 'size_bytes': ARCHIVE.stat().st_size,
            'sha256': sha(ARCHIVE), 'members': len(inventory) + 1,
            'verified_payload_files': len(inventory), 'safe_unique_regular_paths': True,
            'crc_valid': True, 'all_hashes_and_sizes_match': True, 'all_payloads_utf8_text': True,
            'camera_images_included': False, 'model_weights_included': False,
            'inventory_sha256': sha(PAYLOAD / 'inventory.json')},
        'return_revision': RETURN, 'training_source_revision': TRAINING,
        'source': original['source'], 'model_sha256': {k: v['model_sha256'] for k, v in original['models'].items()},
        'evaluation_scope': {'fresh_model_inferences': 3, 'unique_prediction_records': 180,
            'per_image_reference_evaluations': 360, 'reference_specific_aggregates': 18,
            'seed': 45, 'other_training_interventions_pooled': False},
        'fresh_extraction_and_replay': {'source_revision': SOURCE, 'source_tree': TREE,
            'working_tree_before': before, 'working_tree_after': after,
            'hydrated_original_pngs': len(hydrated),
            'hydration': 'Hash-verified original bytes, hardlinked without alteration.',
            'executions': 1, 'python': sys.version.split()[0], 'complete_semantics_equal': True,
            'numeric_tolerance': None, 'excluded_json_paths': ['/created_at_utc', '/command'],
            'normalized_checked_root_paths': ['/revised_reference/root',
                '/procedure/original_label_path_base', '/procedure/revised_label_path_base'],
            'original_comparison_sha256': sha(original_path), 'replayed_comparison_sha256': sha(output),
            'inference_or_weight_loading_performed': False},
        'independent_numerical_audit': {key: independent[key] for key in ['status',
            'per_image_reference_evaluations_verified', 'reference_specific_aggregates_verified', 'method']},
        'packaging_script_sha256': sha(__file__), 'commands': commands,
        'earlier_packaging_attempt': {'stopped_before_replay': True, 'reason': 'Manually hydrated LFS files had stale index stat entries; no content diff existed. Refreshed via canonical LFS clean filter and required exact original index tree before replay.'},
        'limits': ['A replay verifies saved evidence, not new model inference.',
            'Original weights remain in PR32; the preserved return audit checked their bytes.',
            'A single seed and reused development images do not establish independent-test performance.',
            'Seed46 preparation is separate and contains no completed training result.']}
    write(OUT / 'verification.json', verification)
    print(json.dumps({'status': 'PASS', 'archive_sha256': sha(ARCHIVE),
        'archive_size_bytes': ARCHIVE.stat().st_size, 'members': len(inventory) + 1,
        'complete_semantics_equal': True, 'verification_sha256': sha(OUT / 'verification.json')}))


if __name__ == '__main__':
    main()
