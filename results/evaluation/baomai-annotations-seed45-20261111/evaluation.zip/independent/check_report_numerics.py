from pathlib import Path
import json,hashlib,math,re
base=Path('/workspace/scratch/e8c6ed25e3ab/annotation-eval-work');repo=Path('/workspace/scratch/e8c6ed25e3ab/dl-annotation-eval');mdp=repo/'docs/annotation-comparison-2026-11-11.md';jsonp=mdp.with_suffix('.json')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
md=mdp.read_text();mdhash=sha(mdp);j=json.loads(jsonp.read_text());jhash=sha(jsonp)
a=json.loads((base/'analysis-work/independent-annotation-numeric-audit.json').read_text());fullp=base/'evidence/seed-45/comparison-original-and-pr30.json';full=json.loads(fullp.read_text());cases=json.loads((base/'analysis-work/independent-primary-details.json').read_text());interp=json.loads((base/'interpretation-review.json').read_text())
checks=[];leaves=0

def ck(name,cond,detail=None):
 checks.append({'check':name,'passed':bool(cond),'details':detail})

def eq(actual,expected,path):
 global leaves
 if isinstance(expected,dict):
  ck(path+' fields',isinstance(actual,dict) and set(expected)<=set(actual))
  for k,v in expected.items():eq(actual[k],v,path+'.'+k)
 elif isinstance(expected,list):
  ck(path+' length',len(actual)==len(expected))
  for i,(x,y) in enumerate(zip(actual,expected)):eq(x,y,path+f'[{i}]')
 elif isinstance(expected,float):
  leaves+=1;ck(path,type(actual) in (int,float) and abs(actual-expected)<=1e-10)
 else:
  leaves+=1;ck(path,type(actual)==type(expected) and actual==expected)

ck('full comparison hash retains independent audit binding',sha(fullp)==a['official_comparison_sha256']==j['complete_comparison']['sha256'])
idx={(r['model_id'],r['box_confidence']):r for r in a['metrics']}
for r in j['metrics']:
 original=idx[r['model_id'],r['box_confidence']]
 eq({k:r[k] for k in ['model_id','box_confidence','primary']},{k:original[k] for k in ['model_id','box_confidence','primary']},'metric identity')
 for reference in ['original','revised']:
  view=original[reference];s,q=view['score'],view['quality']
  empty=sum(x[reference]['score']['fp'] for x in full['per_image'] if x['model_id']==r['model_id'] and x['box_confidence']==r['box_confidence'] and x[reference]['score']['gold_count']==0)
  expected={'objects':s['gold_count'],'true_positives':s['tp'],'missed_objects':s['fn'],'extra_detections':s['fp'],'duplicate_extras':s['duplicate_fp'],'other_extras':s['other_fp'],'missing_visible_endpoints':s['missing_endpoints'],'visible_endpoints':s['visible_endpoints'],'conditional_median_error_px':s['conditional_median_error_px'],'conditional_p95_error_px':s['conditional_p95_error_px'],'both_corner_eligible_objects':q['both_visible_objects'],'both_corners_within_radius':{str(x['radius_px']):x['both_visible_objects_within_radius'] for x in q['radii']},'objects_by_locatable_corners':view['objects_by_locatable_corners'],'misses_by_locatable_corners':view['misses_by_locatable_corners'],'hidden_side_outputs':q['returned_on_unlocatable_reference'],'hidden_sides_on_matched_objects':q['unlocatable_on_matched_objects'],'empty_image_extras':empty}
  ck('condensed metric exact field inventory',set(r[reference])==set(expected));eq(r[reference],expected,f"condensed.{r['model_id']}.{r['box_confidence']}.{reference}")
ck('exactly nine model-threshold summaries',len(j['metrics'])==9 and len({(x['model_id'],x['box_confidence']) for x in j['metrics']})==9)
for ref,den in a['reference_denominators'].items():
 eq(j[ref+'_reference'],{'objects':den['objects'],'visible_endpoints':den['visible_endpoints'],'unlocatable_endpoints':den['hidden_reference_sides'],'both_corner_eligible_objects':den['both_visible_objects'],'images':20,'empty_images':3},'reference denominator '+ref)
 eq(j['common_returned_endpoints'][ref],a['common_returned_endpoints'][ref],'common '+ref)
for name in ['source','models','limits']:eq(j[name],full[name],'metadata '+name)
for key,val in j['experiment'].items():eq(val,full['experiment'][key],'experiment '+key)
# Read Markdown tables and compare displayed rounding, without rescoring anything.
tables=[];current=[]
for line in md.splitlines()+['']:
 if line.startswith('|'):current.append([re.sub(r'[*`]', '',x.strip()) for x in line.strip('|').split('|')])
 elif current:tables.append(current);current=[]
compact=lambda s:re.sub(r'\s+','',s).replace('−','-')
metricfields={'Missedobjects,lowerisbetter':'fn','Extradetections,lowerisbetter':'fp','Missingvisibleendpoints,lowerisbetter':'missing_endpoints','Conditionalmediancornererror,px':'conditional_median_error_px','Conditional95th-percentileerror,px':'conditional_p95_error_px','Missedobjects':'fn','Extradetections':'fp','Missingvisibleendpoints':'missing_endpoints','Conditionalmedianerror,px':'conditional_median_error_px'}
metric_table_cells=0
for table in tables:
 header=table[0]
 if compact(header[0]).startswith('Measureatconfidence'):
  ref='revised' if ':' in header[1] else 'original'
  for row in table[2:]:
   label=compact(row[0])
   for model,cell in zip(['m0','m1','m2'],row[1:]):
    value=a['primary'][ref][model];text=compact(cell)
    if label in metricfields:
     field=metricfields[label];v=value['score'][field];expected=f'{v:.4f}' if 'error_px' in field else str(v)
    elif label.startswith('Bothcornerswithin'):
     radius=5 if '5px' in label else 10;v=next(x['both_visible_objects_within_radius'] for x in value['quality']['radii'] if x['radius_px']==radius);expected=f'{v}/584'
    elif label=='Extradetectionsonthethreeemptyimages':expected='0'
    else:raise ValueError('Unknown displayed metric '+label)
    ck(f'Markdown {ref} {model} {label}',text==expected,{'actual':text,'expected':expected});metric_table_cells+=1
 if compact(header[0])=='Boxconfidence':
  for row in table[2:]:
   t=float(re.search(r'0\.(?:15|25|40)',row[0]).group())
   for model,cell in zip(['m0','m1','m2'],row[1:4]):
    s=idx[model,t]['revised']['score'];ck(f'Markdown threshold{t} {model}',compact(cell)==f"{s['fn']}/{s['fp']}")
   delta=idx['m2',t]['revised']['score']['fn']-idx['m1',t]['revised']['score']['fn'];ck(f'Markdown threshold{t} delta',int(compact(row[4]))==delta)
 if compact(header[0])=='Locatablereferencecorners':
  for row,n in zip(table[2:5],['0','1','2']):
   expected=[a['primary']['revised']['m0']['objects_by_locatable_corners'][n]]+[a['primary']['revised'][m]['misses_by_locatable_corners'][n] for m in ['m0','m1','m2']]
   ck('Markdown visibility bin '+n,[int(compact(c)) for c in row[1:]]==expected)
  ck('Markdown visibility total',[int(compact(c)) for c in table[-1][1:]]==[661,27,25,24])
 if compact(header[0])=='Model' and 'Matchingdetectionconfidence'==compact(header[1]):
  for row,model in zip(table[2:],['m0','m1','m2']):
   d=next(x for x in cases['primary_gain_candidate_vs_control']['prediction_presence_by_threshold'] if x['model']==model and x['threshold']==.15)
   ck('Markdown case confidence '+model,row[1]==f"{d['confidence']:.6f}");ck('Markdown case IoU '+model,row[2]==f"{d['iou']:.6f}");ck('Markdown case match '+model,row[3]==('No' if model=='m1' else 'Yes'))
 if compact(header[0])=='Model' and 'EvaluatedcheckpointSHA-256'==compact(header[1]):
  for row,model in zip(table[2:],['m0','m1','m2']):ck('Markdown checkpoint hash '+model,row[1]==a['models'][model]['model_sha256'])
# Receipt and provenance numbers stated in prose/tables.
receipts={arm:json.loads((base/f'evidence/seed-45/checkpoints/{arm}/training-receipt.json').read_text()) for arm in ['reference','candidate']}
for arm,r in receipts.items():
 ck('completion facts '+arm,len(r['completed_epochs'])==30 and r['batches_completed']==1050 and r['images_processed']==4110 and r['optimizer_steps']==78 and r['status']=='complete' and r['checkpoint_selection']=='final_epoch')
 ck('success without budget stop '+arm,r['execution']['exit_code']==0 and r['execution']['stop_reason'] is None)
 eq(j['experiment']['training_runtime'],r['runtime'],'recorded runtime '+arm)
 ck('first batch matching data/loss '+arm,r['batch_samples'][0]['image_ids']==receipts['reference']['batch_samples'][0]['image_ids'] and r['batch_samples'][0]['objects']==59 and r['batch_samples'][0]['loss']==receipts['reference']['batch_samples'][0]['loss'])
ck('batch2 supervision witness',receipts['reference']['batch_samples'][1]['image_ids']==receipts['candidate']['batch_samples'][1]['image_ids'] and 'new_000072' in receipts['reference']['batch_samples'][1]['image_ids'] and [receipts[x]['batch_samples'][1]['objects'] for x in ['reference','candidate']]==[82,80])
archive=json.loads((base/'archive-verification.json').read_text());continuity=json.loads((base/'baseline-continuity.json').read_text())
ck('archive description',archive['archive_bytes']==39774041 and archive['members']==13 and archive['indexed_payloads']==12 and archive['archive_sha256'] in md)
ck('baseline continuity description',continuity['unchanged_prediction_records']==60 and continuity['excluded_record_fields']==['stage_ms','predict_call_wall_ms'])
ck('primary deltas and conditional limits stated','one fewer' in md and 'three fewer' in md and 'denominator' in md and 'not overall system accuracy' in md and 'correlated' in md and 'independent test' in md and 'not additional model learning' in md)
# Verify the newly added single-corner caveat directly from an already audited match.
gold_tokens=list(map(float,(Path('/workspace/scratch/e8c6ed25e3ab/dl-training/data/labels/val/new_000008.txt')).read_text().splitlines()[33].split()))
single_corner_errors={}
for model in ['m0','m1','m2']:
 saved=json.loads((base/f'evidence/seed-45/{model}/per_image.json').read_text());score=next(r for r in saved if r['image_id']=='new_000008' and r['threshold']==.25)
 match=next(x for x in score['matches'] if x['gold_index']==33)
 items=[json.loads(line) for line in (base/f'evidence/seed-45/{model}/predictions.jsonl').read_text().splitlines()][1:]
 item=next(r for r in items if r['image_id']=='new_000008' and r['threshold']==.25);point=item['predictions'][match['prediction_index']]['keypoints'][0]
 error=math.hypot(point[0]-gold_tokens[5]*1280,point[1]-gold_tokens[6]*720);single_corner_errors[model]=error
 ck('single-corner caveat '+model,f'{error:.3f} px' in md)
ck('timing label corrected','Monitored run wall times' in md and 'Full worker wall times' not in md)
ck('report remained unchanged during this review',sha(mdp)==mdhash and sha(jsonp)==jhash)
out={'schema_version':1,'kind':'read-only-seed45-report-numerical-review','report_path':str(mdp),'report_sha256':mdhash,'condensed_json_path':str(jsonp),'condensed_json_sha256':jhash,'independent_audit_path':str(base/'analysis-work/independent-annotation-numeric-audit.json'),'independent_audit_sha256':sha(base/'analysis-work/independent-annotation-numeric-audit.json'),'checked_numeric_leaves':leaves,'markdown_metric_table_cells_checked':metric_table_cells,'checks_total':len(checks),'checks_passed':sum(x['passed'] for x in checks),'failures':[x for x in checks if not x['passed']],'known_in_progress':['Capsule verification and seed46 links are being completed by root, not counted as missing.','One-corner caveat, timing label and spacing corrections completed in this reviewed snapshot.'],'wording_note':{'current_uses_full_worker_wall_times':'Full worker wall times' in md,'published_values_are_execution_wall_seconds':[receipts[x]['execution']['wall_seconds'] for x in ['reference','candidate']],'worker_internal_wall_seconds':[receipts[x]['worker_wall_seconds'] for x in ['reference','candidate']],'recommendation':'Use monitored run wall times for463.460/456.203; worker_internal values are460.095/452.906.'},'scope':'Report/condensed-result comparison against completed independent audit and unchanged recorded evidence. No new inference, training, or broad numerical rerun. No repository edits.','checks':checks}
(base/'analysis-work/report-review-numerical-details.json').write_text(json.dumps(out,indent=2)+'\n')
out.pop('checks');out['status']='approved_numerically' if not out['failures'] else 'changes_required';out['single_corner_caveat_verified_px']=single_corner_errors;out['wording_note']['status']='resolved';out['wording_note'].pop('recommendation');out['causal_and_limit_review']=['Candidate versus control is correctly separated from further-training-versus-baseline effects.','The one threshold-crossing detection gain is not presented as recovery of a baseline miss.','Both-corner fractions retain all584 eligible objects, and the separate one-corner regression is explicitly disclosed.','Same-point mean error, hidden-side availability, reference effects, threshold sensitivity, single-seed scope and development-data limits are correctly qualified.'];out['detailed_check_record']='analysis-work/report-review-numerical-details.json';out['pending_link_completion_excluded_from_numerical_scope']=True
(base/'report-review-numerical.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k] for k in ['status','report_sha256','condensed_json_sha256','checks_total','checks_passed','failures','single_corner_caveat_verified_px']},indent=2))
