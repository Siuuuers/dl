#!/usr/bin/env python3
"""Read-only independent audit of the PR32 seed45 training return.

No checkpoint is deserialized and no training/inference is performed. The
output is an analysis artifact outside the source checkout and returned bundle.
"""

import sys
sys.dont_write_bytecode = True

import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import stat
import subprocess
import zipfile


ROOT = Path('/workspace/scratch/e8c6ed25e3ab/dl-training')
WORK = Path('/workspace/scratch/e8c6ed25e3ab/annotation-eval-work')
ARCHIVE = WORK / 'return.zip'
RETURNED = WORK / 'evidence' / 'seed-45' / 'checkpoints'
OUTPUT = WORK / 'audit' / 'seed45-return-audit.json'
EXPECTED_ARCHIVE_SIZE = 39774041
EXPECTED_ARCHIVE_HASH = '598c6e1177401690e0057fcaafa260a41e798b216d1c59309b652a94d518293e'
EXPECTED_AUDIT_REVISION = 'ed4ee162738685bff93d6cad1402d95e128bceb4'
EXPECTED_TRAINING_REVISION = '1c5d2e48ab26c578c5f6660010d6ecfb33231eb8'
CANDIDATE = 'data/candidates/annotations-2026-11-10/manifest.json'
EXPECTED_CANDIDATE_HASH = '28fc8f5da95605089d61fb062132200ed296c3a10b216f1a61dbda1798ea4ba7'
EXPECTED_RECIPE_HASH = '34b8eda9e9b986a2ba19d9ba07661eef1792027ef8d4465d10763a8eb2cd2850'

sys.path.insert(0, str(ROOT / 'scripts'))
from evaluate_pose import file_sha256, preflight_dataset
from package_gpu_results import (INDEX_NAME, check_pair, collect_arm, portable_relative,
                                 shared_settings, verify_archive)
from pose_checkpoint import ANNOTATION_RECIPE_ID, _read_json, _same, recipe_identity
from stage_pose_training import code_hashes, source_state
from train_pose_comparison import SOURCE_FILES
from verify_pose_annotation_candidate import verify_annotation_candidate


def require(condition, message):
    if not condition:
        raise ValueError(message)


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()


def csv_rows(path):
    with path.open(newline='', encoding='utf-8') as stream:
        return [{key.strip(): float(value.strip()) for key, value in row.items()}
                for row in csv.DictReader(stream)]


def run():
    require(git('rev-parse', 'HEAD') == EXPECTED_AUDIT_REVISION, 'audit source revision differs')
    require(git('status', '--porcelain') == '', 'audit source must remain clean')
    require(ARCHIVE.stat().st_size == EXPECTED_ARCHIVE_SIZE, 'archive size differs from PR32')
    require(file_sha256(ARCHIVE) == EXPECTED_ARCHIVE_HASH, 'archive hash differs from PR32')
    index_path = RETURNED / INDEX_NAME
    index = _read_json(index_path)
    require(index['schema_version'] == 1 and index['kind'] == 'baomai-paired-training-results',
            'unexpected return index kind/schema')
    require(len(index['files']) == 12, 'expected six returned artifacts for each of two arms')
    with zipfile.ZipFile(ARCHIVE) as archive:
        infos = archive.infolist()
        names = [info.filename for info in infos]
        require(len(names) == len(set(names)) == 13, 'ZIP inventory must contain 13 unique members')
        for info in infos:
            portable_relative(info.filename)
            require(not info.is_dir() and stat.S_IFMT(info.external_attr >> 16) in (0, stat.S_IFREG),
                    f'nonregular ZIP member: {info.filename}')
            require(not (info.flag_bits & 1), f'encrypted ZIP member: {info.filename}')
        require(archive.read(INDEX_NAME) == index_path.read_bytes(), 'extracted index differs from ZIP')
    verify_archive(ARCHIVE, index_path.read_bytes(), index['files'])
    extracted = set()
    for path in RETURNED.rglob('*'):
        require(not path.is_symlink(), f'extracted symlink: {path}')
        if path.is_file():
            extracted.add(path.relative_to(RETURNED).as_posix())
    require(extracted == set(names), 'extracted file inventory differs from ZIP')
    for row in index['files']:
        portable_relative(row['path'])
        path = RETURNED / row['path']
        require(path.stat().st_size == row['size_bytes'] and file_sha256(path) == row['sha256'],
                f'extracted artifact differs: {row["path"]}')

    require(file_sha256(ROOT / CANDIDATE) == EXPECTED_CANDIDATE_HASH, 'current candidate hash differs')
    candidate_verified = verify_annotation_candidate(ROOT, ROOT / CANDIDATE)
    preflight = preflight_dataset(ROOT, require_weights=True)
    state = source_state(ROOT, ROOT / CANDIDATE)
    identity = recipe_identity(ANNOTATION_RECIPE_ID)
    require(identity['recipe_sha256'] == EXPECTED_RECIPE_HASH, 'registered recipe hash differs')
    arms = {arm: collect_arm(preflight, RETURNED / arm, arm) for arm in ('reference', 'candidate')}
    check_pair(arms['reference'], arms['candidate'])
    regenerated_files = sorted(({key: value for key, value in row.items() if key != 'source_path'}
                                 for arm in arms.values() for row in arm['files']), key=lambda row: row['path'])
    require(_same(index['files'], regenerated_files), 'index descriptors differ from verified bundle artifacts')
    for field, actual in (
        ('source', arms['reference']['staging']['source']),
        ('training_source', arms['reference']['receipt']['source']),
        ('runtime', arms['reference']['receipt']['runtime']),
        ('shared_training_settings', shared_settings(arms['reference']['receipt'])),
    ):
        require(_same(index[field], actual), f'index {field} differs from returned receipts')
    expected_arms = {arm: {'checkpoint_manifest': f'{arm}/checkpoint-manifest.json',
                           'checkpoint_identity': bundle['identity']} for arm, bundle in arms.items()}
    require(_same(index['arms'], expected_arms), 'index arm identities differ')

    current_sources = {name: file_sha256(ROOT / name) for name in SOURCE_FILES}
    pinned_sources = {name: hashlib.sha256(subprocess.check_output(
        ['git', '-C', str(ROOT), 'show', f'{EXPECTED_TRAINING_REVISION}:{name}'])).hexdigest()
                      for name in SOURCE_FILES}
    require(current_sources == pinned_sources, 'audit and pinned training implementation bytes differ')
    expected_stage_code = code_hashes()
    reports = {}
    all_validation_hashes = []
    for arm, bundle in arms.items():
        receipt, staging = bundle['receipt'], bundle['staging']
        require(all(receipt.get(key) == value for key, value in identity.items()), f'{arm}: wrong recipe identity')
        require(receipt['source']['revision'] == EXPECTED_TRAINING_REVISION,
                f'{arm}: training revision differs from notebook pin')
        require(receipt['source']['files_sha256'] == current_sources, f'{arm}: training implementation hashes differ')
        require(staging['code_sha256'] == expected_stage_code, f'{arm}: staging implementation hashes differ')
        require(staging['source']['candidate_manifest'] == CANDIDATE
                and staging['source']['candidate_manifest_sha256'] == EXPECTED_CANDIDATE_HASH
                and staging['source']['candidate_id'] == 'annotations-2026-11-10', f'{arm}: wrong candidate')
        for variant, view in staging['variants'].items():
            observed_files = {row['path']: row['output_sha256'] for row in view['files']}
            expected_files = {name: item['sha256'] for name, item in state['plans'][variant].items()}
            require(observed_files == expected_files and view['counts'] == state['counts'][variant],
                    f'{arm}/{variant}: recorded staging inputs differ from verified current originals/overlay')
            val = {name: digest for name, digest in observed_files.items()
                   if name.startswith(('images/val/', 'labels/val/'))}
            require(len(val) == 40, f'{arm}/{variant}: incomplete validation inventory')
            all_validation_hashes.append(val)
        require(receipt['batches_completed'] == 1050 and receipt['images_processed'] == 4110,
                f'{arm}: completed full-data training batch/image counts differ')
        loaders = {item['split']: item for item in receipt['loader_verification']}
        require(set(loaders) == {'train', 'val'}, f'{arm}: incomplete loader witness')
        for split, loader in loaders.items():
            expected = state['counts'][arm][split]
            require(all(loader[key] == expected[key] for key in ('images', 'objects', 'visible_endpoints')),
                    f'{arm}/{split}: loader counts differ')
        samples = receipt['batch_samples']
        updates = receipt['optimizer_step_samples']
        require(len(samples) == 4 and len(updates) == 8, f'{arm}: expected four batch/eight optimizer witnesses')
        require([entry['optimizer_step'] for entry in updates] == list(range(1, 9)),
                f'{arm}: optimizer sample sequence differs')
        rows = csv_rows(RETURNED / arm / receipt['results']['path'])
        reports[arm] = {
            'checkpoint_identity': bundle['identity'],
            'receipt_created_at_utc': receipt['created_at_utc'],
            'receipt_file_sha256': file_sha256(RETURNED / arm / 'training-receipt.json'),
            'initial_checkpoint_sha256': receipt['initial_checkpoint_sha256'],
            'selected_checkpoint_path': receipt['checkpoint']['path'],
            'training_settings': receipt['training_settings'],
            'completed_epochs': receipt['completed_epochs'],
            'optimizer_steps': receipt['optimizer_steps'],
            'batches_completed': receipt['batches_completed'],
            'images_processed': receipt['images_processed'],
            'optimizer_parameter_change_observed': receipt['optimizer_parameter_change_observed'],
            'training_returned': receipt['training_returned'],
            'finalization_completed': receipt['finalization_completed'],
            'validation_executed': receipt['validation_executed'],
            'inputs_reverified_after_worker': receipt['inputs_reverified_after_worker'],
            'execution': receipt['execution'],
            'loader_verification': receipt['loader_verification'],
            'batch_samples': samples, 'optimizer_step_samples': updates,
            'trainer_csv_rows': len(rows), 'trainer_csv_first_epoch': rows[0], 'trainer_csv_final_epoch': rows[-1],
            'trainer_metric_interpretation': 'Training bookkeeping only; not the prescribed fresh M0/control/candidate accuracy comparison.',
        }
    require(all(value == all_validation_hashes[0] for value in all_validation_hashes),
            'original validation images/labels differ between recorded staged variants')
    require(arms['reference']['identity']['checkpoint_sha256'] != arms['candidate']['identity']['checkpoint_sha256'],
            'both returned arms identify the same final checkpoint')
    require(git('status', '--porcelain') == '', 'audit changed the source checkout')
    total_wall = sum(report['execution']['wall_seconds'] for report in reports.values())
    return {
        'schema_version': 1, 'status': 'verified-training-return-not-accuracy-approval',
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'archive': {'path': str(ARCHIVE), 'sha256': EXPECTED_ARCHIVE_HASH,
                    'size_bytes': EXPECTED_ARCHIVE_SIZE, 'members': len(names),
                    'index_sha256': file_sha256(index_path), 'index_created_at_utc': index['created_at_utc'],
                    'files': index['files']},
        'audit': {'script': str(Path(__file__).resolve()), 'script_sha256': file_sha256(Path(__file__).resolve()),
                  'clean_source_revision': EXPECTED_AUDIT_REVISION,
                  'source_files_sha256': current_sources,
                  'read_only_source_and_returned_evidence': True, 'weights_deserialized': False,
                  'new_training_or_inference': False},
        'candidate': candidate_verified,
        'reference_preflight': {key: value for key, value in preflight.items() if key != 'records'},
        'protocol': {**identity, 'training_source_revision': EXPECTED_TRAINING_REVISION,
                     'paired_runtime': index['runtime'], 'paired_nonpath_settings_equal': True,
                     'original_validation_identical_in_all_four_recorded_variants': True,
                     'original_validation_file_hashes': dict(sorted(all_validation_hashes[0].items())),
                     'verified_original_pngs': len(state['records']), 'expected_counts': state['counts'],
                     'total_full_run_wall_seconds': total_wall,
                     'gpu_model_requirement': 'A matched CUDA device/runtime satisfying the declared protocol; no A100-specific requirement.'},
        'arms': reports,
        'limits': [
            'The return contains both completed training bundles, not the separate resource-trial receipt/log; trial execution is not independently reconstructed here.',
            'The staged image/label copies are not returned. Their recorded hashes and loader/input witnesses bind to independently verified current frozen inputs and candidate files.',
            'This is artifact-integrity and protocol consistency, not cryptographic attestation of remote execution or machine clocks.',
            'Trainer losses/mAP do not establish performance under the fixed post-training miss/FP/5px/10px evaluation.',
            'One seed on repeatedly used development validation does not establish independent-scene generalization.',
        ],
    }


if __name__ == '__main__':
    result = run()
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    with OUTPUT.open('x', encoding='utf-8') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'status': result['status'], 'output': str(OUTPUT),
                      'gpu': result['protocol']['paired_runtime']['device_name'],
                      'total_full_run_wall_seconds': result['protocol']['total_full_run_wall_seconds'],
                      'optimizer_steps': {arm: report['optimizer_steps'] for arm, report in result['arms'].items()},
                      'checkpoint_sha256': {arm: report['checkpoint_identity']['checkpoint_sha256']
                                            for arm, report in result['arms'].items()}}, indent=2))
