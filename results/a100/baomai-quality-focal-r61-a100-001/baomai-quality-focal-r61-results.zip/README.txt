Quality focal comparison: native BCE reference versus beta=2 candidate.
Both arms use identical 142-photo training supervision and independent epoch173 initialization.
Read evaluation/summary.json and retain all modelparts and return-manifest.json.
The supplied-model original view is the report baseline; all annotation references are development views.
