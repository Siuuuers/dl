R46 cassette-front annotation review, 27 November 2026 (Asia/Hong_Kong).
proposals contains all 12 review label files, including held images.
Only complete-candidates/labels passes the recorded whole-image annotation gate.
These files do not overwrite the original 137 training / 20 development split.
PR133 actually trained frame_0383; this review is separate and does not train.
Source row IDs are stable; TXT line order can differ after a historical deletion.
Bright edges/shadows support contour interpretation, not automatic snapping.
The existing HTML stays at its R44 snapshot; consult this PDF/manifest for R46.
Offline check: python scripts/build_front_review_r46.py --check-output .
Quick TXT preview (Pillow): python scripts/preview_pose_labels.py --image originals/frame_0001.jpg --labels proposals/frame_0001.txt --output preview.png
Preview row numbers are TXT lines. Stable source IDs and any output-row changes are in manifest.json.
