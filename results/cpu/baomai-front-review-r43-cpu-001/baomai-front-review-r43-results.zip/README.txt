Open review.html: all rows of one frame appear together; Previous/Next navigates frames.
Original pixels, working baseline, previous R42 and latest R43 labels are shown together.
All 508 identities remain: 507 current fronts plus the earlier deleted identity.
Ten requested rows were reviewed this round. See amendments.json for exact decisions.
The history/r42 directory preserves earlier evidence; original images and figures are shared without duplication.
The five prediction figures are historical R42 diagnostics, not updated R43 scores.
Complete candidates remain frame_0146, frame_0371 and frame_0383; nine whole frames remain held.
No training split, human approval, inference or training is created by this package.
Offline check: python review.py --check-capsule PATH_TO_THIS_ZIP
