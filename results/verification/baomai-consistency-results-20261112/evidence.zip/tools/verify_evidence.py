#!/usr/bin/env python3
"""Verify the PR47 capsule and optionally replay saved predictions without models."""

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True
ROLES = ("old_reviewed", "consistency_reviewed", "current")
SOURCE = "14561b7f01cc89c4472e11ffb37b3943ea3e34f9"
PROTOCOL_SHA = "da692f2261fae441dfa7d68b3f86ed850acbb861c75e86e8c54f40b7184e540b"


def require(ok, message):
    if not ok:
        raise ValueError(message)


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, f"duplicate JSON key in {path}: {key}")
            result[key] = value
        return result
    def invalid(value):
        raise ValueError(f"nonfinite JSON value: {value}")
    return json.loads(Path(path).read_text(), object_pairs_hook=unique, parse_constant=invalid)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def safe(name):
    path = PurePosixPath(name)
    require(name and not path.is_absolute() and ".." not in path.parts and
            "\\" not in name and ":" not in name and path.as_posix() == name,
            f"unsafe capsule path: {name}")
    return Path(name)


def verify(root):
    inventory = read(root / "inventory.json")
    require(inventory["kind"] == "baomai-consistency-result-evidence" and
            inventory["inventory_self_excluded"] is True, "wrong capsule identity")
    files = inventory["payload_files"]
    require(not any(p.is_symlink() for p in root.rglob("*")), "capsule contains symlinks")
    actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    require(actual == set(files) | {"inventory.json"}, "missing or additional capsule files")
    for name, item in files.items():
        path = root / safe(name)
        require(path.stat().st_size == item["size_bytes"] and sha(path) == item["sha256"], name)
    run, source = root / "run-001", root / "source"
    identity = read(run / "identity.json")
    require(identity["source"]["revision"] == SOURCE and
            identity["source"]["working_tree_status"] == "", "recorded source differs")
    require(identity["driver_sha256"] == sha(root / "tools/evaluate_comparison.py"), "driver differs")
    require(identity["protocol_sha256"] == PROTOCOL_SHA == sha(run / "protocol.json"), "protocol differs")
    for name, digest in identity["source_helpers_sha256"].items():
        require(sha(source / safe(name)) == digest, name)
    for name, item in read(run / "inventory.json").items():
        path = run / safe(name)
        require(sha(path) == item["sha256"] and path.stat().st_size == item["size_bytes"], name)
    status = read(run / "status.json")
    require(status["status"] == "complete" and status["mode"] == "fresh_inference" and
            status["fresh_image_prediction_calls"] == 120 and
            status["scored_image_reference_threshold_pairs"] == 240, "incomplete evaluation")
    sys.path.insert(0, str(source / "scripts"))
    from package_consistency_results import validate_protocol, check_reviewed_pair
    from pose_checkpoint import select_checkpoint
    from evaluate_pose import INFERENCE
    context = validate_protocol(source)
    require(context["sha256"] == PROTOCOL_SHA, "candidate/protocol validation differs")
    card = read(source / "metadata/model_card.json")
    # Only identities and included labels are available here. This is deliberately
    # not an actual-PNG or checkpoint-byte preflight.
    metadata = {"root": str(source), "weights": str(source / card["checkpoint"]),
                "model_sha256": card["sha256"], "manifest_sha256": sha(source / "data/manifest.json"),
                "model_card_sha256": sha(source / "metadata/model_card.json")}
    bundles = {}
    report = read(run / "comparison.json")
    require(set(report["roles"]) == set(ROLES), "report roles differ")
    for role in ROLES:
        base = root / "training" / role
        chosen = select_checkpoint(metadata, base / "checkpoint-manifest.json", require_weights=False)
        require(chosen["weights_verified"] is False and
                chosen["checkpoint_identity"] == identity["checkpoints"][role], f"{role} identity differs")
        header = json.loads((run / f"predictions-{role}.jsonl").read_text().splitlines()[0])
        require(header["record_type"] == "run" and header["role"] == role and
                header["model_sha256"] == chosen["model_sha256"] and
                header["checkpoint_identity"] == chosen["checkpoint_identity"] and
                header["identities"] == identity and header["inference"] == INFERENCE and
                header["thresholds"] == [0.13, 0.15] and
                header["runtime"] == report["roles"][role]["runtime"] and
                header["model_state_before_prediction"] == report["roles"][role]["model_state_before_prediction"],
                f"{role} prediction header differs from its declared model/settings/run")
        if role != "current":
            receipt, staging = read(base / "training-receipt.json"), read(base / "staging-manifest.json")
            require(receipt["source"]["revision"] == SOURCE, f"{role} training source differs")
            require(all(staging["source"][key] == value
                        for key, value in context["document"]["roles"][role].items()), "role swapped")
            bundles[role] = {"receipt": receipt, "staging": staging,
                             "identity": chosen["checkpoint_identity"]}
    check_reviewed_pair(bundles, context)
    require(report["experiment_id"] == "consistency-seed46-v1" and
            report["network_events_blocked"] == [], "unexpected evaluation identity/network event")
    summary = read(root / "summary.json")
    require(summary["comparison_sha256"] == sha(run / "comparison.json"), "summary source differs")
    require(set(summary["metrics"]) == set(ROLES), "summary roles are incomplete or unexpected")
    for role, references in summary["metrics"].items():
        require(set(references) == {"primary", "original"}, "summary reference set differs")
        for reference, thresholds in references.items():
            require(set(thresholds) == {"0.13", "0.15"}, "summary threshold set differs")
            for threshold, metrics in thresholds.items():
                row = report["metrics"][role][reference][threshold]
                expected = {key: row["score"][key] for key in
                            ("prediction_count", "tp", "fn", "fp", "duplicate_fp", "other_fp")}
                expected["corner_pairs"] = {str(r["radius_px"]): r["both_visible_objects_within_radius"]
                                            for r in row["quality"]["radii"]}
                expected["miss_free_nonempty_images"] = row["miss_free_nonempty_image_ids"]
                expected["empty_image_predictions"] = row["empty_image_predictions"]
                require(metrics == expected, "summary metrics differ")
    return {"status": "verified", "payload_files": len(files), "protocol_and_labels_verified": True,
            "completed_training_metadata_verified": True, "model_weights_reverified": False,
            "original_pngs_reverified": False, "training_executed": False, "inference_executed": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("capsule", type=Path)
    parser.add_argument("--replay", action="store_true")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root, output = args.capsule.resolve(), args.output.resolve()
    require(not output.exists() and not output.is_relative_to(root), "choose a new output outside the capsule")
    result = verify(root)
    output.parent.mkdir(parents=True, exist_ok=True)
    if args.replay:
        with tempfile.TemporaryDirectory(prefix="consistency-replay-", dir=output.parent) as work:
            work = Path(work)
            independent, cross = work / "independent.json", work / "cross-check.json"
            common = ["--root", str(root / "source"), "--predictions", str(root / "run-001")]
            subprocess.run([sys.executable, "-B", str(root / "tools/independent_metrics.py"),
                            *common, "--output", str(independent)], check=True)
            subprocess.run([sys.executable, "-B", str(root / "tools/compare_official.py"),
                            *common, "--independent", str(independent), "--output", str(cross)], check=True)
            result["independent_numerical_replay"] = read(cross)
            result["independent_numerical_replay"]["temporary_result_retained"] = False
    with output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"status": result["status"], "payload_files": result["payload_files"],
                      "numerical_replay": args.replay, "output": str(output)}))


if __name__ == "__main__":
    main()
