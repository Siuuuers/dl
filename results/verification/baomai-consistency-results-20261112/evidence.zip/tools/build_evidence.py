#!/usr/bin/env python3
"""Build the fixed PR47 evidence capsule; omit weights and full original PNGs."""

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
from verify_evidence import safe, sha, verify

SOURCE = "14561b7f01cc89c4472e11ffb37b3943ea3e34f9"
HERE = Path(__file__).resolve().parent


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + "\n").encode()


def assemble(work, capsule, readme):
    source, run = work / "source", work / "run-001"
    assert subprocess.check_output(["git", "-C", str(source), "rev-parse", "HEAD"], text=True).strip() == SOURCE
    assert subprocess.check_output(["git", "-C", str(source), "status", "--porcelain"], text=True).strip() == ""
    assert sha(work / "baomai-consistency-seed46-results.zip") == "bdae4de69b3560d4fc8821dcd6f364c77eef2ed4c624c3720eae696eaa5ee5cb"
    assert sha(work / "pr35-results.zip") == "df53683ccf6f266a605b2844f42a98e808f75686cfab09f14d680c9d061e8a91"
    files = {}
    def add(name, path):
        safe(name)
        assert name not in files and Path(path).is_file() and not Path(path).is_symlink()
        assert Path(name).suffix.lower() not in {".pt", ".pth", ".onnx", ".zip"}
        files[name] = Path(path)
    for path in sorted(run.glob("*.json*")):
        add("run-001/" + path.name, path)
    for path in sorted((work / "audit").rglob("*")):
        if path.is_file() and path.suffix in {".json", ".py", ".png", ".md"}:
            add("audit/" + path.relative_to(work / "audit").as_posix(), path)
    for name in ("evaluate_comparison.py", "verify_evidence.py", "build_evidence.py"):
        add("tools/" + name, HERE / name)
    for name in ("independent_metrics.py", "compare_official.py"):
        add("tools/" + name, work / "audit/metrics" / name)
    for name in ("requirements-inference.lock.txt", "runtime-verification.json", "lock-provenance.json"):
        add("runtime/" + name, work / "runtime" / name)
    for role in ("old_reviewed", "consistency_reviewed", "current"):
        base = work / "pr35/candidate" if role == "current" else work / "unpacked" / role
        for name in ("checkpoint-manifest.json", "training-receipt.json", "staging-manifest.json", "train.log", "fit/results.csv"):
            add(f"training/{role}/{name}", base / name)
    add("training/returned-archive-manifest.json", work / "unpacked/gpu-results-manifest.json")
    add("training/current-archive-manifest.json", work / "pr35/gpu-results-manifest.json")
    identity = json.loads((run / "identity.json").read_text())
    source_paths = set(identity["source_helpers_sha256"])
    source_paths.update({"docs/annotation-policy.md", "experiments/consistency-2026-11-12.json",
                         "data/manifest.json", "data/data.yaml", "metadata/model_card.json",
                         "weights/cassette_lower_epoch173.json",
                         "results/review/baomai-training-consistency-20261111/adjudication.json"})
    source_paths.update(p.relative_to(source).as_posix() for p in (source / "data/labels").rglob("*.txt"))
    for relative in ("data/candidates/annotations-2026-11-10", "data/candidates/consistency-2026-11-11",
                     "data/references/visible-front-2026-11-11"):
        source_paths.update(p.relative_to(source).as_posix() for p in (source / relative).rglob("*")
                            if p.is_file() and p.suffix in {".json", ".txt", ".md"})
    for name in sorted(source_paths):
        add("source/" + name, source / name)
    add("README.md", readme)
    add("summary.json", work / "summary.json")
    capsule.mkdir(parents=True, exist_ok=False)
    for name, path in files.items():
        target = capsule / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
    inventory = {"schema_version": 1, "kind": "baomai-consistency-result-evidence",
                 "source_revision": SOURCE, "inventory_self_excluded": True,
                 "payload_files": {name: {"sha256": sha(path), "size_bytes": path.stat().st_size}
                                   for name, path in sorted(files.items())},
                 "external_inputs": {
                     "returned": {"revision": "24e43a407da01b1e26834b6dee60a51e1ec54577",
                                  "path": "results/gpu/baomai-consistency-l4-001/baomai-consistency-seed46-results.zip",
                                  "sha256": "bdae4de69b3560d4fc8821dcd6f364c77eef2ed4c624c3720eae696eaa5ee5cb",
                                  "size_bytes": 39776445},
                     "current": {"revision": "8e8bb99cabcb44ed0ec0acd14db911aa44013fd8",
                                 "path": "results/gpu/baomai-reviewed-annotations-seed46-l4-001/baomai-reviewed-annotations-seed46-results.zip",
                                 "sha256": "df53683ccf6f266a605b2844f42a98e808f75686cfab09f14d680c9d061e8a91",
                                 "size_bytes": 39776456}},
                 "limits": ["Full original PNGs and model binaries remain in the pinned external inputs.",
                            "Included cropped figures preserve original pixel evidence; they are not new observations.",
                            "Saved-prediction replay does not freshly rehash excluded external bytes or run inference."]}
    (capsule / "inventory.json").write_bytes(encoded(inventory))


def archive(capsule, destination):
    verify(capsule)
    destination.mkdir(parents=True, exist_ok=False)
    output = destination / "evidence.zip"
    with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
        for path in sorted(p for p in capsule.rglob("*") if p.is_file()):
            info = zipfile.ZipInfo(path.relative_to(capsule).as_posix(), (1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            bundle.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)
    with zipfile.ZipFile(output) as bundle:
        assert bundle.testzip() is None
        assert set(bundle.namelist()) == {p.relative_to(capsule).as_posix() for p in capsule.rglob("*") if p.is_file()}
        for name in bundle.namelist():
            assert hashlib.sha256(bundle.read(name)).hexdigest() == sha(capsule / name)
    (destination / "evidence.zip.sha256").write_text(f"{sha(output)}  evidence.zip\n")
    for name in ("README.md", "summary.json", "inventory.json"):
        shutil.copyfile(capsule / name, destination / name)
    shutil.copyfile(capsule / "tools/evaluate_comparison.py", destination / "evaluate_comparison.py")
    print(json.dumps({"status": "verified", "archive": str(output), "sha256": sha(output),
                      "size_bytes": output.stat().st_size,
                      "members": len(list(p for p in capsule.rglob("*") if p.is_file()))}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", type=Path, help="Restored PR47 work root with source, run, audit and runtime")
    parser.add_argument("--readme", type=Path)
    parser.add_argument("--capsule", type=Path, required=True)
    parser.add_argument("--destination", type=Path, required=True)
    parser.add_argument("--repack", action="store_true", help="Repack an existing verified capsule unchanged")
    args = parser.parse_args()
    if not args.repack:
        assert args.work and args.readme
        assemble(args.work.resolve(), args.capsule.resolve(), args.readme.resolve())
    archive(args.capsule.resolve(), args.destination.resolve())


if __name__ == "__main__":
    main()
