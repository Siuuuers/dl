#!/usr/bin/env python3
"""Compare independent arithmetic with the complete saved official PR47 scores."""
from pathlib import Path
import argparse
import importlib.util
import json
import math
import sys

sys.dont_write_bytecode=True

HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument("--root",type=Path,required=True,help="Frozen source/reference root")
parser.add_argument("--predictions",type=Path,required=True,help="Directory containing predictions and official scoring reports")
parser.add_argument("--independent",type=Path,required=True,help="Fresh independently recomputed metrics JSON")
parser.add_argument("--output",type=Path,required=True,help="New verification JSON; choose a path outside the evidence capsule")
args=parser.parse_args()
ROOT=args.root.resolve()
RUN=args.predictions.resolve()
assert not args.output.exists(),"Choose a new verification output path."
spec=importlib.util.spec_from_file_location("independent_metrics",HERE/"independent_metrics.py")
ind=importlib.util.module_from_spec(spec);spec.loader.exec_module(ind)
own=ind.read(args.independent)
official=ind.read(RUN/"comparison.json")
original={r["id"]:r for r in ind.read(ROOT/"data/manifest.json")["records"] if r["split"]=="val"}
primary={r["image_id"]:r for r in ind.read(ROOT/ind.REFERENCE)["files"]}
scalars={"gold":"gold_count","predictions":"prediction_count","matched":"tp","misses":"fn","extras":"fp","duplicate_extras":"duplicate_fp","other_extras":"other_fp","visible_endpoints":"visible_endpoints","returned_visible_endpoints":"returned_endpoints","conditional_median_error_px":"conditional_median_error_px","conditional_p95_error_px":"conditional_p95_error_px"}
quality_keys=("returned_visible_endpoints","unlocatable_reference_endpoints","unlocatable_on_matched_objects","returned_on_unlocatable_reference","both_visible_objects","both_visible_objects_with_both_returned")
def equal(a,b):
    if isinstance(a,float) and isinstance(b,(int,float)):
        return math.isclose(a,b,rel_tol=0,abs_tol=1e-9)
    return a==b
counts={"aggregate_role_reference_threshold_cases":0,"image_reference_threshold_cases":0,"object_states":0,"comparison_reference_threshold_cases":0}
for role in ind.ROLES:
    predictions=[json.loads(line) for line in (RUN/f"predictions-{role}.jsonl").read_text().splitlines()][1:]
    for reference in ("primary","original"):
        reports=ind.read(RUN/f"scoring-{role}-{reference}.json")
        for threshold in ind.THRESHOLDS:
            key=str(threshold);mine=own["metrics"][role][reference][key];theirs=reports[key]
            for own_key,other_key in scalars.items():
                assert equal(mine[own_key],theirs["score"][other_key]),(role,reference,key,own_key,mine[own_key],theirs["score"][other_key])
            for field in quality_keys:
                assert equal(mine[field],theirs["quality"][field]),(role,reference,key,field)
            for radius in theirs["quality"]["radii"]:
                r=str(radius["radius_px"])
                assert mine["pairs"][r]==radius["both_visible_objects_within_radius"]
                assert mine["endpoints_within_radius"][r]==radius["visible_endpoints_within_radius"]
            for corners,group in mine["groups"].items():
                theirs_group=theirs["groups_by_locatable_corners"][corners]
                for own_key,other_key in (("objects","reference_objects"),("matched","matched_objects"),("misses","missed_objects"),("returned_visible_endpoints","returned_visible_endpoints")):
                    assert group[own_key]==theirs_group[other_key]
            for field in ("miss_free_nonempty_image_ids","empty_image_predictions"):
                assert mine[field]==theirs[field]
            counts["aggregate_role_reference_threshold_cases"]+=1
            for image in theirs["per_image"]:
                image_id=image["image_id"]
                row=primary[image_id] if reference=="primary" else original[image_id]
                label=(ROOT/ind.REFERENCE).parent/row["label_path"] if reference=="primary" else ROOT/"data"/row["label"]
                gold=ind.label_objects(label,row["label_sha256"])
                pred=next(p["predictions"] for p in predictions if p["threshold"]==threshold and p["image_id"]==image_id)
                ours=ind.image_scores(image_id,gold,pred)
                for own_key,other_key in list(scalars.items())[:7]:
                    assert ours[own_key]==image["score"][other_key]
                for a,b in zip(ours["states"],image["objects"]):
                    assert a["object_id"]==f'{image_id}:{b["reference_row_one_based"]}'
                    assert a["matched"]==b["matched"]
                    assert a["prediction_index_zero_based"]==b["prediction_index_zero_based"]
                    assert equal(a["matching_iou"],b["matching_iou"])
                    assert a["visible"]==b["reference_endpoint_visible"] and a["returned"]==b["endpoint_returned"]
                    assert all(equal(x,y) for x,y in zip(a["errors_px"],b["visible_endpoint_errors_px"]))
                    assert a["pairs"]==b["both_visible_within_radius"]
                    counts["object_states"]+=1
                assert len(ours["states"])==len(image["objects"])
                counts["image_reference_threshold_cases"]+=1
for reference in own["comparisons"]:
    for pair in own["comparisons"][reference]:
        for threshold,a in own["comparisons"][reference][pair].items():
            b=official["comparisons"][reference][pair][threshold]
            for field in ("gained_object_ids","lost_object_ids"):
                assert a[field]==b[field]
            for r in ("2","5","10"):
                for field in ("gained","lost"):
                    assert a["both_corner_changes"][r][field]==b["both_corner_changes"][r][field]
            counts["comparison_reference_threshold_cases"]+=1
record={"status":"passed","independent_arithmetic_matches_saved_official_reports":True,**counts,
        "absolute_numeric_tolerance":1e-9,"independent_script_sha256":ind.sha(HERE/"independent_metrics.py"),
        "cross_check_script_sha256":ind.sha(__file__),
        "independent_result_sha256":ind.sha(args.independent),"comparison_report_sha256":ind.sha(RUN/"comparison.json"),
        "method":"Reference parsing and confidence-ordered greedy matching recomputed without importing repository scoring helpers; all object assignments, per-side availability/errors and 2/5/10 px pair states compared.",
        "model_loaded":False,"inference_run":False,"training_run":False}
args.output.write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record,indent=2))
