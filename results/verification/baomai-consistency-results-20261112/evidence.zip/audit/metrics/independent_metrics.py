#!/usr/bin/env python3
"""Independently recompute fixed PR47 scores from saved predictions; no model code."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path


ROLES = ("old_reviewed", "consistency_reviewed", "current")
THRESHOLDS = (0.13, 0.15)
RADII = (2, 5, 10)
REFERENCE = "data/references/visible-front-2026-11-11/manifest.json"
REFERENCE_SHA = "2e60b3e81195448cc565a1000b4305e3215baba2bf0ee0c976e6551c2e64937c"
ORIGINAL_SHA = "72ae8365d5abf0b45b75d400a2e6d22119c0e31b54ee33035feb8edc1f967926"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def label_objects(path, expected):
    assert sha(path) == expected, f"Label hash differs: {path}"
    objects = []
    for line in Path(path).read_text().splitlines():
        fields = [float(value) for value in line.split()]
        assert len(fields) == 11 and fields[0] == 0
        _, x, y, w, h, *points = fields
        assert w > 0 and h > 0
        keypoints = [[points[n] * 1280, points[n+1] * 720, points[n+2]] for n in (0, 3)]
        assert all(p[2] in (0, 2) for p in keypoints)
        objects.append({"class_id": 0, "bbox_xyxy": [(x-w/2)*1280, (y-h/2)*720,
                                                       (x+w/2)*1280, (y+h/2)*720],
                        "keypoints": keypoints})
    return objects


def iou(a, b):
    overlap = max(0, min(a[2], b[2]) - max(a[0], b[0])) * max(0, min(a[3], b[3]) - max(a[1], b[1]))
    return overlap / ((a[2]-a[0])*(a[3]-a[1]) + (b[2]-b[0])*(b[3]-b[1]) - overlap)


def available(point):
    x, y, confidence = point
    return x is not None and y is not None and math.isfinite(x) and math.isfinite(y) and confidence >= .5 and 0 <= x < 1280 and 0 <= y < 720


def quantile(values, q):
    if not values:
        return None
    values = sorted(values)
    index = q * (len(values)-1)
    lo, hi = math.floor(index), math.ceil(index)
    return values[lo] + (values[hi]-values[lo]) * (index-lo)


def state(image_id, row, gold, predicted, prediction_index, overlap):
    visibility = [p[2] == 2 for p in gold["keypoints"]]
    returned = [available(p) for p in predicted["keypoints"]] if predicted else [False, False]
    errors = [math.hypot(predicted["keypoints"][side][0]-gold["keypoints"][side][0],
                         predicted["keypoints"][side][1]-gold["keypoints"][side][1])
              if visibility[side] and returned[side] else None for side in (0, 1)]
    return {"object_id": f"{image_id}:{row}", "matched": predicted is not None,
            "prediction_index_zero_based": prediction_index, "matching_iou": overlap,
            "visible": visibility, "returned": returned, "errors_px": errors,
            "pairs": {str(r): all(visibility) and all(e is not None and e <= r for e in errors) for r in RADII}}


def image_scores(image_id, gold, predictions):
    free = set(range(len(gold)))
    assigned = {}
    for pi in sorted(range(len(predictions)), key=lambda n: (-predictions[n]["confidence"], n)):
        candidates = [(iou(predictions[pi]["bbox_xyxy"], gold[gi]["bbox_xyxy"]), gi)
                      for gi in free if gold[gi]["class_id"] == predictions[pi]["class_id"]]
        candidates = [(overlap, gi) for overlap, gi in candidates if overlap >= .5]
        if candidates:
            overlap, gi = min(candidates, key=lambda v: (-v[0], v[1]))
            assigned[gi] = (pi, overlap)
            free.remove(gi)
    matched_predictions = {pair[0] for pair in assigned.values()}
    extras = [pi for pi in range(len(predictions)) if pi not in matched_predictions]
    duplicates = [pi for pi in extras if any(gold[gi]["class_id"] == predictions[pi]["class_id"]
                  and iou(gold[gi]["bbox_xyxy"], predictions[pi]["bbox_xyxy"]) >= .5 for gi in assigned)]
    states = []
    for gi, target in enumerate(gold):
        pi, overlap = assigned.get(gi, (None, None))
        states.append(state(image_id, gi+1, target, predictions[pi] if pi is not None else None, pi, overlap))
    return {"image_id": image_id, "gold": len(gold), "predictions": len(predictions),
            "matched": len(assigned), "misses": len(free), "extras": len(extras),
            "duplicate_extras": len(duplicates), "other_extras": len(extras)-len(duplicates),
            "extra_prediction_indices_zero_based": extras, "states": states}


def summarize(rows):
    states = [s for row in rows for s in row["states"]]
    errors = [e for s in states for e in s["errors_px"] if e is not None]
    result = {key: sum(row[key] for row in rows) for key in
              ("gold", "predictions", "matched", "misses", "extras", "duplicate_extras", "other_extras")}
    result.update(visible_endpoints=sum(sum(s["visible"]) for s in states),
                  returned_visible_endpoints=len(errors),
                  unlocatable_reference_endpoints=sum(2-sum(s["visible"]) for s in states),
                  unlocatable_on_matched_objects=sum(2-sum(s["visible"]) for s in states if s["matched"]),
                  returned_on_unlocatable_reference=sum(not v and ret for s in states for v, ret in zip(s["visible"], s["returned"])),
                  both_visible_objects=sum(all(s["visible"]) for s in states),
                  both_visible_objects_with_both_returned=sum(all(s["visible"]) and all(s["returned"]) for s in states),
                  conditional_median_error_px=quantile(errors,.5), conditional_p95_error_px=quantile(errors,.95),
                  pairs={str(r):sum(s["pairs"][str(r)] for s in states) for r in RADII},
                  endpoints_within_radius={str(r):sum(e <= r for e in errors) for r in RADII},
                  miss_free_nonempty_image_ids=[row["image_id"] for row in rows if row["gold"] and not row["misses"]],
                  empty_image_predictions={row["image_id"]:row["predictions"] for row in rows if not row["gold"]})
    result["groups"] = {}
    for corners in (0,1,2):
        group = [s for s in states if sum(s["visible"]) == corners]
        result["groups"][str(corners)] = {"objects":len(group), "matched":sum(s["matched"] for s in group),
            "misses":sum(not s["matched"] for s in group), "returned_visible_endpoints":sum(e is not None for s in group for e in s["errors_px"])}
    return result


def alternatives(object_id, gold, predictions, radius=None):
    image_id, row = object_id.split(":")
    target = gold[image_id][int(row)-1]
    result = []
    for pi, predicted in enumerate(predictions[image_id]):
        overlap = iou(target["bbox_xyxy"], predicted["bbox_xyxy"])
        s = state(image_id, int(row), target, predicted, pi, overlap)
        if radius is None or overlap >= .5 and s["pairs"][str(radius)]:
            result.append({"prediction_index_zero_based":pi, "iou":overlap,
                           "confidence":predicted["confidence"], "bbox_xyxy":predicted["bbox_xyxy"],
                           "errors_px":s["errors_px"]})
    return sorted(result,key=lambda p:(-p["iou"],-p["confidence"],p["prediction_index_zero_based"]))[:4]


def compare(before_rows, after_rows, gold, before_predictions, after_predictions, uncertainty):
    before={s["object_id"]:s for row in before_rows for s in row["states"]}
    after={s["object_id"]:s for row in after_rows for s in row["states"]}
    assert before.keys() == after.keys()
    gains=[key for key in before if not before[key]["matched"] and after[key]["matched"]]
    losses=[key for key in before if before[key]["matched"] and not after[key]["matched"]]
    changes=[]
    for key in gains+losses:
        changes.append({"object_id":key,"change":"gain" if key in gains else "loss", "before":before[key],"after":after[key],
                        "uncertainty":uncertainty.get(key), "before_nearest":alternatives(key,gold,before_predictions),
                        "after_nearest":alternatives(key,gold,after_predictions)})
    pairs={}
    for r in RADII:
        gained=[key for key in before if not before[key]["pairs"][str(r)] and after[key]["pairs"][str(r)]]
        lost=[key for key in before if before[key]["pairs"][str(r)] and not after[key]["pairs"][str(r)]]
        pairs[str(r)]={"gained":gained,"lost":lost,"details":[{"object_id":key,"before":before[key],"after":after[key],
                         "before_accurate_alternatives":alternatives(key,gold,before_predictions,r),
                         "after_accurate_alternatives":alternatives(key,gold,after_predictions,r)} for key in gained+lost]}
    common=[key for key in before if before[key]["matched"] and after[key]["matched"]]
    common_unlocatable=[]
    for key in common:
        for side in (0,1):
            if not before[key]["visible"][side]:
                common_unlocatable.append({"object_id":key,"side":side,"before":before[key]["returned"][side],"after":after[key]["returned"][side]})
    return {"gained_object_ids":gains,"lost_object_ids":losses,"object_changes":changes,"both_corner_changes":pairs,
            "common_matched_objects":len(common), "common_unlocatable_opportunities":len(common_unlocatable),
            "common_unlocatable_returned_before":sum(s["before"] for s in common_unlocatable),
            "common_unlocatable_returned_after":sum(s["after"] for s in common_unlocatable),
            "common_unlocatable_output_changes":[s for s in common_unlocatable if s["before"] != s["after"]]}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--root",type=Path,required=True)
    parser.add_argument("--predictions",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args(); root=args.root.resolve()
    assert sha(root/"data/manifest.json")==ORIGINAL_SHA and sha(root/REFERENCE)==REFERENCE_SHA
    original={r["id"]:r for r in read(root/"data/manifest.json")["records"] if r["split"]=="val"}
    amended=read(root/REFERENCE); primary={r["image_id"]:r for r in amended["files"]}
    assert set(original)==set(primary) and len(primary)==20
    gold={"primary":{},"original":{}}; uncertainty={}
    for image_id, row in original.items():
        item=primary[image_id]
        gold["original"][image_id]=label_objects(root/"data"/row["label"],row["label_sha256"])
        gold["primary"][image_id]=label_objects((root/REFERENCE).parent/item["label_path"],item["label_sha256"])
    for reference, expected in (("primary", (663,1228,584,3)),("original",(664,1227,584,3))):
        images=gold[reference]
        actual=(sum(len(objects) for objects in images.values()),
                sum(point[2]==2 for objects in images.values() for obj in objects for point in obj["keypoints"]),
                sum(all(point[2]==2 for point in obj["keypoints"]) for objects in images.values() for obj in objects),
                sum(not objects for objects in images.values()))
        assert actual==expected,(reference,actual,expected)
    for item in amended["queue_dispositions"]:
        if item["disposition"]=="retained_unresolved":
            mapped=primary[item["image_id"]]["retained_source_to_revised_row_one_based"][item["source_row_one_based"]-1]
            assert mapped is not None
            uncertainty[f'{item["image_id"]}:{mapped}']=item
    assert len(uncertainty)==19
    uncertainty["new_000011:61"]={"additional_caveat":"Inherited boundary/identity uncertainty remains unresolved."}
    all_predictions={}; headers={}; input_hashes={}; computed={}; all_rows={}
    for role in ROLES:
        path=args.predictions/f"predictions-{role}.jsonl"
        lines=[json.loads(line) for line in path.read_text().splitlines()]
        header,items=lines[0],lines[1:]
        assert header["role"]==role and header["thresholds"]==list(THRESHOLDS) and len(items)==40
        assert {(item["threshold"],item["image_id"]) for item in items}=={(t,image_id) for t in THRESHOLDS for image_id in original}
        for item in items:
            assert item["width"]==1280 and item["height"]==720
            assert item["image_sha256"]==original[item["image_id"]]["image_sha256"]
            assert item["original_label_sha256"]==original[item["image_id"]]["label_sha256"]
        headers[role]=header;input_hashes[path.name]=sha(path)
        all_predictions[role]={str(t):{item["image_id"]:item["predictions"] for item in items if item["threshold"]==t} for t in THRESHOLDS}
        computed[role]={};all_rows[role]={}
        for reference, images in gold.items():
            computed[role][reference]={};all_rows[role][reference]={}
            for t in THRESHOLDS:
                rows=[image_scores(image_id,objects,all_predictions[role][str(t)][image_id]) for image_id,objects in images.items()]
                computed[role][reference][str(t)]=summarize(rows)
                all_rows[role][reference][str(t)]=rows
    assert all(headers[role]["runtime"]==headers[ROLES[0]]["runtime"] for role in ROLES)
    comparisons={reference:{} for reference in gold}
    for reference in gold:
        for before,after in (("old_reviewed","consistency_reviewed"),("current","old_reviewed"),("current","consistency_reviewed")):
            comparisons[reference][f"{after}-vs-{before}"]={str(t):compare(all_rows[before][reference][str(t)],all_rows[after][reference][str(t)],gold[reference],all_predictions[before][str(t)],all_predictions[after][str(t)],uncertainty if reference=="primary" else {}) for t in THRESHOLDS}
    exact_prediction_pairs={f"{a}-vs-{b}":sum(all_predictions[a][str(t)][image_id]==all_predictions[b][str(t)][image_id] for t in THRESHOLDS for image_id in original) for a,b in (("old_reviewed","current"),("consistency_reviewed","old_reviewed"),("consistency_reviewed","current"))}
    output={"status":"independently_computed","created_at_utc":datetime.now(timezone.utc).isoformat(),
            "method":"Standard-library reference parser and independent confidence-ordered greedy matcher; no repository scoring helper imported, no model loaded, no inference or training.",
            "script_sha256":sha(__file__),"prediction_files_sha256":input_hashes,
            "reference_manifest_sha256":{"original":ORIGINAL_SHA,"primary":REFERENCE_SHA},
            "all_inference_runtime_metadata_identical":True,"ordered_prediction_arrays_identical_out_of_40":exact_prediction_pairs,
            "metrics":computed,"comparisons":comparisons,"reference_uncertainty":uncertainty}
    assert not args.output.exists()
    args.output.write_text(json.dumps(output,indent=2,allow_nan=False)+"\n")
    print(json.dumps({"output":str(args.output),"primary_013":{role:computed[role]["primary"]["0.13"] for role in ROLES},"ordered_prediction_arrays_identical_out_of_40":exact_prediction_pairs},indent=2))


if __name__=="__main__":
    main()
