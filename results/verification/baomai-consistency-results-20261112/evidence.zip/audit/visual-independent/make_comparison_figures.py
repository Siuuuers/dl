#!/usr/bin/env python3
"""Plot fixed PR47 case evidence over original nearest-neighbor image crops."""

import argparse
import hashlib
import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, __version__ as pillow_version


REFERENCE_COLOR = "#e2ad00"
PREDICTION_COLOR = "#007fa8"
MISSING_SIDE_COLOR = "#c01864"
TEXT_COLOR = "#17232d"
MUTED_COLOR = "#43535e"
BACKGROUND = "#ffffff"
FONT_PATH = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")
BOLD_PATH = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")
CASES = {
    "new_000056:14": {
        "crop_xyxy": [392, 625, 548, 710],
        "scale": 3,
        "title": "056:14 — Existing proposal crosses the matching cutoff",
        "output": "consistency-056-14-comparison.png",
    },
    "new_000090:43": {
        "crop_xyxy": [386, 650, 494, 716],
        "scale": 4,
        "title": "090:43 — The front proposal remains present below the cutoff",
        "output": "consistency-090-43-comparison.png",
    },
}
ROLES = [None, "current", "old_reviewed", "consistency_reviewed"]
ROLE_LABELS = {
    None: "Original (unaltered)",
    "current": "PR35 (current)",
    "old_reviewed": "L4 control",
    "consistency_reviewed": "Consistency candidate",
}


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def font(size, bold=False):
    return ImageFont.truetype(str(BOLD_PATH if bold else FONT_PATH), size)


def dashed_line(draw, a, b, color, width=3, dash=10, gap=6):
    ax, ay = a
    bx, by = b
    distance = ((bx - ax) ** 2 + (by - ay) ** 2) ** 0.5
    if distance == 0:
        return
    step = 0
    while step < distance:
        end = min(step + dash, distance)
        draw.line([(ax + (bx - ax) * step / distance,
                    ay + (by - ay) * step / distance),
                   (ax + (bx - ax) * end / distance,
                    ay + (by - ay) * end / distance)], fill=color, width=width)
        step += dash + gap


def dashed_box(draw, box, color):
    x1, y1, x2, y2 = box
    for a, b in [((x1, y1), (x2, y1)), ((x2, y1), (x2, y2)),
                 ((x2, y2), (x1, y2)), ((x1, y2), (x1, y1))]:
        dashed_line(draw, a, b, color)


def cross(draw, x, y, radius=8):
    draw.line([(x - radius, y - radius), (x + radius, y + radius)],
              fill=MISSING_SIDE_COLOR, width=3)
    draw.line([(x - radius, y + radius), (x + radius, y - radius)],
              fill=MISSING_SIDE_COLOR, width=3)


def plot_panel(crop, gold, proposal, xyxy, scale):
    panel = crop.resize((crop.width * scale, crop.height * scale), Image.Resampling.NEAREST)
    if proposal is None:
        return panel
    draw = ImageDraw.Draw(panel)
    left, top = xyxy[:2]
    position = lambda x, y: ((x - left) * scale, (y - top) * scale)
    convert_box = lambda box: (*position(*box[:2]), *position(*box[2:]))
    dashed_box(draw, convert_box(gold["bbox_xyxy"]), REFERENCE_COLOR)
    draw.rectangle(convert_box(proposal["bbox_xyxy"]), outline=PREDICTION_COLOR, width=3)
    for x, y, visible in gold["keypoints"]:
        if visible == 2:
            px, py = position(x, y)
            draw.ellipse((px - 7, py - 7, px + 7, py + 7),
                         outline=REFERENCE_COLOR, width=3)
    for side, (x, y, confidence) in enumerate(proposal["keypoints"]):
        if confidence < 0.50 or not (0 <= x < 1280 and 0 <= y < 720):
            continue
        px, py = position(x, y)
        if gold["keypoints"][side][2] == 0:
            cross(draw, px, py)
        else:
            draw.ellipse((px - 4, py - 4, px + 4, py + 4), fill=PREDICTION_COLOR)
    return panel


def make_figure(base, output, case_id, spec, case, adjudication):
    image_id, _ = case_id.split(":")
    relative = f"source/data/images/val/{image_id}.png"
    image_path = base / relative
    assert digest(image_path) == adjudication["files_sha256"][relative]
    source = Image.open(image_path).convert("RGB")
    assert source.size == (1280, 720)
    xyxy, scale = spec["crop_xyxy"], spec["scale"]
    crop = source.crop(xyxy)
    width, height = crop.width * scale, crop.height * scale
    margin, gap, image_y = 24, 16, 190
    footer_y = image_y + height + 84
    canvas = Image.new("RGB", (2 * margin + 4 * width + 3 * gap, footer_y + 74), BACKGROUND)
    draw = ImageDraw.Draw(canvas)
    draw.text((margin, 18), spec["title"], font=font(30, True), fill=TEXT_COLOR)
    draw.text((margin, 65), "Box confidence 0.13 · Fixed matching IoU ≥ 0.50 · Same original crop in every panel",
              font=font(21), fill=MUTED_COLOR)
    legend_y = 113
    dashed_line(draw, (margin, legend_y), (margin + 38, legend_y), REFERENCE_COLOR)
    draw.text((margin + 49, legend_y - 14), "Fixed reference + locatable point", font=font(21), fill=TEXT_COLOR)
    legend2_x = 670
    draw.line([(legend2_x, legend_y), (legend2_x + 38, legend_y)], fill=PREDICTION_COLOR, width=3)
    draw.text((legend2_x + 49, legend_y - 14), "Model box + visible-side point", font=font(21), fill=TEXT_COLOR)
    legend3_x = 1235
    cross(draw, legend3_x + 9, legend_y, 7)
    draw.text((legend3_x + 29, legend_y - 14), "Model point on the missing right side", font=font(21), fill=TEXT_COLOR)

    selected = {}
    for column, role in enumerate(ROLES):
        x = margin + column * (width + gap)
        draw.text((x, 151), ROLE_LABELS[role], font=font(24, True), fill=TEXT_COLOR)
        if role is None:
            panel = plot_panel(crop, case["reference"], None, xyxy, scale)
            captions = [f"Crop x{xyxy[0]}–{xyxy[2]}, y{xyxy[1]}–{xyxy[3]}",
                        f"{scale}× nearest-neighbor enlargement"]
        else:
            observation = case["thresholds"]["0.13"][role]
            relevant = observation["highest_overlaps"][0]
            proposal = relevant["prediction"]
            panel = plot_panel(crop, case["reference"], proposal, xyxy, scale)
            matched = observation["state"]["matched"]
            captions = [f"Proposal #{relevant['index']} · confidence {proposal['confidence']:.6f}",
                        f"Reference IoU {relevant['iou']:.6f} · {'matched' if matched else 'unmatched'}"]
            selected[role] = relevant
        canvas.paste(panel, (x, image_y))
        draw.rectangle((x - 1, image_y - 1, x + width, image_y + height), outline="#d7dde1", width=1)
        for line, text in enumerate(captions):
            assert draw.textlength(text, font=font(22)) <= width, (role, text)
            draw.text((x, image_y + height + 12 + line * 30), text, font=font(22), fill=TEXT_COLOR)
    draw.text((margin, footer_y), "The right reference corner is hidden (v=0). Its predicted coordinate lies on hand material; no hidden-coordinate error is measured.",
              font=font(19), fill=MUTED_COLOR)
    draw.text((margin, footer_y + 28), "Reference rows are one-based; proposal indices are zero-based. Confidence 0.15 gives the same displayed proposals and assignments.",
              font=font(19), fill=MUTED_COLOR)
    destination = output / spec["output"]
    canvas.save(destination, compress_level=9)
    return {
        "case_id": case_id, "figure": destination.name, "figure_sha256": digest(destination),
        "figure_size_px": list(canvas.size), "source_image": relative,
        "source_image_sha256": digest(image_path), "source_size_px": list(source.size),
        "crop_xyxy_px": xyxy, "nearest_neighbor_scale": scale,
        "reference_geometry": case["reference"], "displayed_predictions": selected,
        "confidence": 0.13, "matching_iou": 0.50, "endpoint_confidence": 0.50,
        "colors": {"reference": REFERENCE_COLOR, "prediction": PREDICTION_COLOR,
                   "prediction_on_reference_missing_side": MISSING_SIDE_COLOR},
        "text_outside_source_image_panels": True,
        "unannotated_panel_preserves_nearest_neighbor_original_crop": True,
        "synthetic_image_generation": False,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    base, output = args.base.resolve(), args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    numeric_path = Path(__file__).resolve().parent / "case-numerics.json"
    adjudication_path = Path(__file__).resolve().parent / "visual-adjudication.json"
    numeric = json.loads(numeric_path.read_text())
    adjudication = json.loads(adjudication_path.read_text())
    assert digest(numeric_path) == adjudication["files_sha256"]["audit/visual-independent/case-numerics.json"]
    figures = [make_figure(base, output, name, spec, numeric[name], adjudication)
               for name, spec in CASES.items()]
    metadata = {"schema_version": 1, "kind": "pr47-actual-pixel-comparison-figures",
                "generator_sha256": digest(__file__), "pillow_version": pillow_version,
                "fonts_sha256": {str(p): digest(p) for p in (FONT_PATH, BOLD_PATH)},
                "case_numerics_sha256": digest(numeric_path),
                "adjudication_sha256": digest(adjudication_path), "figures": figures}
    (output / "comparison-figure-sources.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(json.dumps({"figures": [{k: f[k] for k in ("figure", "figure_sha256", "figure_size_px", "nearest_neighbor_scale")}
                                  for f in figures]}, indent=2))


if __name__ == "__main__":
    main()
