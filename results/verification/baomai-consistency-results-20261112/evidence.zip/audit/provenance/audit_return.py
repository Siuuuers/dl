#!/usr/bin/env python3
"""Independently inspect the frozen PR47 return without loading model code."""

import argparse
import csv
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import subprocess
import zipfile

SOURCE = "14561b7f01cc89c4472e11ffb37b3943ea3e34f9"
PROTOCOL_SHA = "da692f2261fae441dfa7d68b3f86ed850acbb861c75e86e8c54f40b7184e540b"
ARCHIVE_SHA = "bdae4de69b3560d4fc8821dcd6f364c77eef2ed4c624c3720eae696eaa5ee5cb"
ARCHIVE_GIT_BLOB = "544104dba0eef59092fa2005524dac43ff59ee2e"
INITIAL_SHA = "e0aab1b377491700318e0b14cd4c558ec3c1684087a13b7dde2298ebdbf2847e"
RECIPE_SHA = "f18e0a813a1057e1b3ab3a44ea3ce9b2a3e7673cc2bf04ca09b394bfdd8c51b8"
ROLES = ("old_reviewed", "consistency_reviewed")
DELTA = {"new_000018": [24, 25, 26, 32, 33, 34],
         "new_000034": [55, 56, 57], "new_000049": [9, 14, 24, 25, 26]}


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def git(source, *args):
    return subprocess.check_output(["git", "-C", str(source), *args], text=True).strip()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--unpacked", type=Path, required=True)
    parser.add_argument("--pr35", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    source, archive, unpacked = args.source.resolve(), args.archive.resolve(), args.unpacked.resolve()
    assert git(source, "rev-parse", "HEAD") == SOURCE
    assert git(source, "status", "--porcelain") == ""
    assert archive.stat().st_size == 39776445 and digest(archive) == ARCHIVE_SHA
    git_hash = hashlib.sha1(b"blob " + str(archive.stat().st_size).encode() + b"\0")
    with archive.open("rb") as stream:
        for chunk in iter(lambda: stream.read(2**20), b""):
            git_hash.update(chunk)
    assert git_hash.hexdigest() == ARCHIVE_GIT_BLOB

    index = read(unpacked / "gpu-results-manifest.json")
    expected = {entry["path"]: entry for entry in index["files"]}
    assert len(expected) == len(index["files"]) == 12
    with zipfile.ZipFile(archive) as z:
        infos = z.infolist()
        assert len(infos) == 13 and len({i.filename for i in infos}) == 13
        assert {i.filename for i in infos} == set(expected) | {"gpu-results-manifest.json"}
        for info in infos:
            p = PurePosixPath(info.filename)
            assert not p.is_absolute() and ".." not in p.parts and str(p) == info.filename
            assert "\\" not in info.filename and ":" not in info.filename
            assert not stat.S_ISLNK(info.external_attr >> 16) and not info.is_dir()
            payload = z.read(info)
            local = unpacked / info.filename
            assert local.is_file() and not local.is_symlink() and local.read_bytes() == payload
            if info.filename in expected:
                spec = expected[info.filename]
                assert len(payload) == spec["size_bytes"]
                assert hashlib.sha256(payload).hexdigest() == spec["sha256"]
        assert z.testzip() is None
    assert {p.relative_to(unpacked).as_posix() for p in unpacked.rglob("*") if p.is_file()} == set(expected) | {"gpu-results-manifest.json"}
    assert index["kind"] == "baomai-consistency-comparison-results"
    assert index["experiment_id"] == "consistency-seed46-v1"
    protocol_path = source / "experiments/consistency-2026-11-12.json"
    assert digest(protocol_path) == PROTOCOL_SHA
    protocol = read(protocol_path)
    assert index["protocol"] == {"path": protocol_path.relative_to(source).as_posix(), "sha256": PROTOCOL_SHA}
    assert digest(source / "scripts/package_consistency_results.py") == index["packager_sha256"]
    assert index["delta_train_rows_1based"] == protocol["delta_train_rows_1based"] == DELTA
    assert index["recipe_sha256"] == protocol["recipe_sha256"] == RECIPE_SHA
    assert index["initial_checkpoint_sha256"] == protocol["initial_checkpoint_sha256"] == INITIAL_SHA

    original = read(source / "data/manifest.json")
    records = {r["id"]: r for r in original["records"]}
    proposals = {role: read(source / protocol["roles"][role]["candidate_manifest"]) for role in ROLES}
    proposal_dirs = {role: (source / protocol["roles"][role]["candidate_manifest"]).parent for role in ROLES}
    for role in ROLES:
        assert digest(source / protocol["roles"][role]["candidate_manifest"]) == protocol["roles"][role]["candidate_manifest_sha256"]
        assert digest(proposal_dirs[role] / proposals[role]["review"]["path"]) == proposals[role]["review"]["sha256"]
    assert digest(source / "data/manifest.json") == protocol["reference_manifest_sha256"]
    changes = {role: {c["image_id"]: c for c in proposals[role]["changes"]} for role in ROLES}
    old, new = (changes[role] for role in ROLES)
    assert len(old) == 8 and len(new) == 11 and set(new) - set(old) == set(DELTA)
    for image_id, change in old.items():
        assert new[image_id] == change
        assert (proposal_dirs[ROLES[0]] / change["candidate_label"]).read_bytes() == (proposal_dirs[ROLES[1]] / change["candidate_label"]).read_bytes()
    reviews = {role: read(proposal_dirs[role] / proposals[role]["review"]["path"]) for role in ROLES}
    old_decisions = {d["id"]: d for d in reviews[ROLES[0]]["decisions"]}
    new_decisions = {d["id"]: d for d in reviews[ROLES[1]]["decisions"]}
    assert len(old_decisions) == 12 and len(new_decisions) == 26
    assert all(new_decisions[k] == v for k, v in old_decisions.items())
    observed_delta = {}
    preserved_corner_triples = 0
    for image_id, wanted_rows in DELTA.items():
        record, change = records[image_id], new[image_id]
        before = (source / "data" / record["label"]).read_bytes().splitlines(keepends=True)
        after = (proposal_dirs[ROLES[1]] / change["candidate_label"]).read_bytes().splitlines(keepends=True)
        assert len(before) == len(after) == record["instances"]
        changed = []
        for number, (a, b) in enumerate(zip(before, after), 1):
            x, y = a.split(), b.split()
            assert len(x) == len(y) == 11 and x[0] == y[0] and x[5:] == y[5:]
            preserved_corner_triples += 2
            if a != b:
                assert x[1:5] != y[1:5]
                changed.append(number)
        assert changed == wanted_rows
        assert change["additions"] == change["deletions"] == []
        assert [r["original_row"] for r in change["replacements"]] == wanted_rows
        assert all(r["changed_fields"] == ["bbox"] and r["donor_endpoints"] == [] for r in change["replacements"])
        observed_delta[image_id] = changed
    assert proposals[ROLES[0]]["expected_counts"] == proposals[ROLES[1]]["expected_counts"]

    receipts = {role: read(unpacked / role / "training-receipt.json") for role in ROLES}
    stages = {role: read(unpacked / role / "staging-manifest.json") for role in ROLES}
    assert receipts[ROLES[0]]["runtime"] == receipts[ROLES[1]]["runtime"] == index["runtime"]
    assert receipts[ROLES[0]]["source"] == receipts[ROLES[1]]["source"] == index["training_source"]
    run_summaries = {}
    inventories = {}
    for role in ROLES:
        r, stage = receipts[role], stages[role]
        assert r["source"]["revision"] == SOURCE and r["source"]["working_tree_status"] == ""
        assert all(digest(source / name) == sha for name, sha in r["source"]["files_sha256"].items())
        assert r["status"] == "complete" and r["purpose"] == "paired-finetune" and r["arm"] == "candidate"
        assert r["completed_epochs"] == list(range(1, 31))
        assert r["checkpoint_selection"] == "final_epoch" and r["checkpoint"]["path"] == "fit/weights/last.pt"
        assert all(r[key] is True for key in ("training_returned", "finalization_completed", "validation_executed", "optimizer_parameter_change_observed", "inputs_reverified_after_worker"))
        assert r["execution"]["exit_code"] == 0 and r["execution"]["stop_reason"] is None
        assert r["initial_checkpoint_sha256"] == INITIAL_SHA and r["training_settings"]["resume"] is False
        assert r["batches_completed"] == 1050 and r["images_processed"] == 4110 and r["optimizer_steps"] == 78
        assert r["runtime"]["device"] == "cuda:0" and r["runtime"]["device_name"] == "NVIDIA L4"
        assert r["runtime"]["ultralytics"] == "8.4.182" and r["recipe_sha256"] == RECIPE_SHA
        spec = protocol["roles"][role]
        assert all(stage["source"][key] == value for key, value in spec.items())
        actual = {f["path"]: f["output_sha256"] for f in stage["variants"]["candidate"]["files"]}
        expected_inventory = {}
        for image_id, record in records.items():
            expected_inventory[record["image"]] = record["image_sha256"]
            expected_inventory[record["label"]] = changes[role].get(image_id, {}).get("candidate_label_sha256", record["label_sha256"])
        assert actual == expected_inventory
        inventories[role] = actual
        assert stage["variants"]["candidate"]["counts"] == proposals[role]["expected_counts"]
        with (unpacked / role / "fit/results.csv").open(newline="") as stream:
            rows = [{k.strip(): v.strip() for k, v in row.items()} for row in csv.DictReader(stream)]
        assert [int(row["epoch"]) for row in rows] == list(range(1, 31))
        run_summaries[role] = {key: r[key] for key in ("status", "purpose", "arm", "initial_checkpoint_sha256", "recipe_id", "recipe_sha256", "checkpoint_selection", "batches_completed", "images_processed", "optimizer_steps", "worker_wall_seconds", "worker_peak_rss_mib", "checkpoint", "created_at_utc")}
        run_summaries[role]["completed_epochs"] = 30
        run_summaries[role]["results_csv_rows"] = len(rows)
        run_summaries[role]["training_counts"] = stage["variants"]["candidate"]["counts"]
    changed_paths = sorted(p for p in inventories[ROLES[0]] if inventories[ROLES[0]][p] != inventories[ROLES[1]][p])
    assert changed_paths == sorted(records[image_id]["label"] for image_id in DELTA)
    for record in records.values():
        if record["split"] == "val":
            assert digest(source / "data" / record["image"]) == record["image_sha256"]
    primary_reference_path = source / protocol["evaluation"]["primary_reference"]
    assert digest(primary_reference_path) == protocol["evaluation"]["primary_reference_sha256"]
    primary_reference = read(primary_reference_path)
    assert primary_reference["counts"] == {"images": 20, "objects": 663, "visible_endpoints": 1228, "missing_endpoints": 98, "empty_images": 3}
    pr35 = read(args.pr35 / "candidate/training-receipt.json")
    runtime_differences = {k: {"pr35": pr35["runtime"].get(k), "pr47": index["runtime"].get(k)} for k in set(pr35["runtime"]) | set(index["runtime"]) if pr35["runtime"].get(k) != index["runtime"].get(k)}
    assert git(source, "status", "--porcelain") == ""
    result = {"schema_version": 1, "status": "verified", "source_revision": SOURCE, "source_clean_before_and_after": True,
        "archive": {"sha256": ARCHIVE_SHA, "git_blob_sha": ARCHIVE_GIT_BLOB, "size_bytes": archive.stat().st_size, "members": 13, "all_member_hashes_sizes_and_crc_verified": True, "unpacked_payloads_equal_archive": True},
        "protocol_sha256": PROTOCOL_SHA, "experiment_id": index["experiment_id"],
        "delta": {"rows": observed_delta, "box_replacements": 14, "inherited_files_and_change_objects_exact": 8, "inherited_decisions_exact": 12, "preserved_corner_triples_in_three_delta_images": preserved_corner_triples, "held_and_other_rows_byte_unchanged": True, "changed_staged_paths": changed_paths, "counts_identical": True},
        "runtime": index["runtime"], "runs": run_summaries,
        "original_validation": {"images_locally_rehashed": 20, "objects": 664, "visible_endpoints": 1227, "missing_slots": 101, "empty_images": 3},
        "post_training_reference": {"path": protocol["evaluation"]["primary_reference"], "sha256": protocol["evaluation"]["primary_reference_sha256"], "counts": primary_reference["counts"], "objects_by_locatable_corners": primary_reference["objects_by_locatable_corners"], "used_as_training_validation": False},
        "pr35_training_runtime_differences": runtime_differences,
        "limits": ["No model deserialization, inference, training or accuracy scoring by this auditor.", "Full-run eligibility and initialization are verified from the hash-bound source, receipts, settings, manifests, logs and results; this audit did not observe GPU execution live.", "The resource-trial bundle is not included in this 13-member return, so the return alone does not independently prove that trial's execution.", "All 157 original-image staging hashes and effective label hashes are checked; this return audit directly rehashes the 20 hydrated validation originals, not all 137 training PNGs.", "The original epoch173 identity is checked against frozen source metadata and both full-run receipts; its model bytes are not loaded by this audit.", "PR35 was trained on A100, while PR47 uses L4. Do not assume the new control exactly reproduces PR35; compare all three models in one inference environment."],
        "training_executed": False, "inference_executed": False, "model_loaded": False}
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "archive_members": 13, "delta_rows": observed_delta, "both_runs": "30 completed epochs; 1050 batches; 4110 presentations; 78 optimizer updates", "source_clean": True, "output": str(args.output)}, indent=2))


if __name__ == "__main__":
    main()
