# Training mechanism audit — 2026-11-11

## Conclusion

**No active missing-corner or flip-configuration defect was established.** The pinned trainer has the required path for a positive cassette front whose two lower corners are unavailable: box supervision remains active, unavailable corners receive no coordinate/RLE target, and their availability targets are zero. Changing their `0 0 0` flags to visible points would corrupt this contract.

The strongest immediate intervention remains a bounded review of **previously unreviewed training images for omitted identifiable fronts and gripper-only/duplicate targets**, preserving the existing model and recipe. This is more directly supported than changing architecture or augmentation settings. A separate **availability-loss balancing** experiment is a plausible later hypothesis for the frequent returned hidden corners, but this audit does not establish that it will improve detection recall. Do not present it as a bug fix or a measured improvement.

## Active settings, traced beyond the metadata description

The seed46 reference and candidate training receipts both record Ultralytics **8.4.182**, recipe `reviewed-annotations-seed46-v1`, recipe SHA `f18e0a813a1057e1b3ab3a44ea3ce9b2a3e7673cc2bf04ca09b394bfdd8c51b8`, and completed 30-epoch training. Both training logs identify the **Pose26** head and the same augmentation settings.

| Setting | Actual receipt / active source interpretation |
|---|---|
| `kpt_shape` / `flip_idx` | `[2,3]` / `[1,0]`, explicitly written and checked by `scripts/stage_pose_training.py::yaml_bytes` and staging verification |
| Horizontal / vertical flip | `fliplr=0.5`, `flipud=0`; the active horizontal transform mirrors coordinates then swaps both complete keypoint slots, including visibility flags |
| Mosaic / MixUp / CutMix / copy-paste | All `0.0`; rectangular mode additionally forces the first three off |
| Rotation / translation / scale | `degrees=5`, `translate=0.05`, `scale=0.15` — active affine augmentation, including possible image-edge clipping |
| Shear / perspective / multiscale | All zero |
| HSV | `0.01 / 0.2 / 0.2` |
| Albumentations | Logs confirm default Blur, MedianBlur, ToGray, and CLAHE, each with probability 0.01; no spatial crop/erase transform is in that default list |
| `augment=False` in receipt | This shared setting does **not** disable training transforms: `build_yolo_dataset` passes `augment=mode == "train"` |
| `auto_augment=randaugment`, `erasing=0.4` | Shared defaults printed in receipt, but used by the classification augmentation path, not this pose dataset's `v8_transforms`; disabling them would not fix an active pose-occlusion problem |
| Loss gains | `pose=12`, `kobj=1`, `rle=1`, with ordinary unweighted availability BCE |

Sources in installed package: `data/build.py:239–303`, `data/dataset.py:325–350`, `data/augment.py:2833–2912`, `data/augment.py:1531–1635`, `data/augment.py:2127–2207`. The source root is `/workspace/scratch/b2268c0c3452/work/runtime/venv/lib/python3.12/site-packages/ultralytics`.

## Missing-corner handling

1. The 11-field pose loader retains the three-dimensional visibility flags, including both-zero objects (`data/utils.py::verify_image_label`). There is no loader rule excluding an object solely because both endpoints are unavailable.
2. `nn/tasks.py::PoseModel.init_criterion` selects `PoseLoss26` for the logged Pose26 head, with the end-to-end wrapper when the one-to-one branch exists.
3. `PoseLoss26.loss` passes padded per-image keypoints to `PoseTaskAlignedAssigner`. That assigner uses `(IoU + OKS) / 2` when a reference has visible keypoints, **and explicitly falls back to box IoU when it has none** (`utils/tal.py:396–418`). Thus the all-zero case is not assigned zero overlap merely because no keypoint is visible.
4. Coordinate loss uses `kpt_mask = gt_kpt[..., 2] != 0`; RLE indexes only this mask. Availability BCE uses this same mask as its binary target (`utils/loss.py:931–979`). A missing corner's transformed x/y numbers are irrelevant to the coordinate loss while its visibility remains zero.
5. The affine transform sets visibility to zero for points leaving the transformed image, and clipping preserves that status. It does not turn an originally missing endpoint into a visible one (`data/augment.py:1325–1360`; `utils/instance.py:382–441`).

## Augmentation limits and possible opportunities

The active affine pipeline removes an entire object when the transformed/clipped box fails width >2 px, height >2 px, aspect ratio <100, or retained area ratio >0.10 (`data/augment.py:1237–1260,1410–1454`). This can suppress extreme clipped slivers. It is an intended filtering rule, not proof of a defect. The current candidate has 18 zero-corner objects whose original height is at most 8 px, including one at about 1.88 px. Their actual training retention was not logged or simulated in this audit, and some such legacy strips have uncertain physical identity. There is no basis here to loosen the filter or invent fuller hidden boxes.

The pipeline does not generate newly occluded interior fronts with a synthetic hand/gripper. Adding random cutout would require updating endpoint availability **and** observed-front extent/identity consistently. It is not a safe one-parameter use of the printed classification `erasing` setting.

## Measured supervision imbalance — hypothesis, not causal proof

Counts were recomputed from all 137 original training label files, substituting only the eight candidate overlay files specified by the frozen candidate manifest.

| Training arm | Zero-corner objects | One-corner objects | Two-corner objects | Missing endpoint targets | Visible endpoint targets |
|---|---:|---:|---:|---:|---:|
| Original | 121 | 463 | 3,188 | 705 | 6,839 |
| Annotation candidate | 119 | 463 | 3,189 | 701 | 6,841 |

In the candidate, unavailable endpoint targets are **9.2946%** of the raw endpoint slots, and zero-corner objects are **119/3,771**. Zero-corner targets occur in 55 images; simply oversampling every such full image would also repeat many already abundant fully visible fronts.

For context, fixed seed46 M2 at confidence 0.25 on the amended development reference misses **10/19 zero-corner**, **10/60 one-corner**, and **6/584 two-corner** objects. The reused reference contains unresolved cases, so this grouping describes the observed failure concentration rather than independent accuracy.

Unweighted BCE plus this raw imbalance makes **balanced availability supervision** a defensible hypothesis for reducing returned hidden corners. However, the actual loss operates over assigned foreground anchors, not equally weighted raw objects, and assignment frequencies/gradients were not saved. Raw counts alone do not prove why the model outputs those points. Increasing `kobj` globally scales both positive and negative availability terms and is not equivalent to class balancing.

If this hypothesis is pursued later, first log matched availability-target counts and positive/negative BCE contributions on existing training batches; then freeze one bounded comparison changing only the availability weighting. Report visible-corner coverage as a cost alongside hidden-side output reduction, and preserve detection misses as the primary objective. No such run or weighting change was made here.

## Evidence identities and limits

- Candidate manifest SHA: `28fc8f5da95605089d61fb062132200ed296c3a10b216f1a61dbda1798ea4ba7`.
- Seed46 evaluation capsule SHA: `3dfe3415841b47a605e2fd4b9e490b2c12b348b0014c6c2a8c78c06f323ffc1a`.
- Reference training-receipt member SHA: `a125821289752e1446cc066c1de3369ee1e274050f0e98fc9549ccec4e7b5c9f`.
- Candidate training-receipt member SHA: `da9e4c9614ac0fd198fcc3124745de855047dd8cd78a0d84344692b73bc3e49d`.
- Installed `utils/loss.py`: `f8db64a3093ef310b23cb83d587dd5c8aa3db20a27da94d95a62a734a6c055d2`.
- Installed `utils/tal.py`: `7fc3127e4b094247ccbbcf8af9829972295f96fc53027313ef51b076d27274cd`.
- Installed `data/augment.py`: `802333ea359def55e88f61d6726e35c29d28a6491110840a5e912ec1fafd1de3`.

Read-only code/receipt/label analysis. No model loaded, inference performed, augmentation experiment run, training started, or repository file changed for this mechanism audit. The local installed source version matches the receipt's pinned package version; the original CUDA environment's individual package-source file hashes were not recorded, so byte-for-byte CUDA-package provenance beyond that version is not asserted.
