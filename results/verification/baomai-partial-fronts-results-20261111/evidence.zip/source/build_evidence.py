#!/usr/bin/env python3
"""Package completed PR40 evidence without loading models or changing its scores.

Run --plan first. Final packaging requires the completed numerical and case reviews.
No existing output is overwritten. ZIP member metadata is fixed for reproducibility.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import tempfile
import zipfile

SOURCE = '19459913c8be2f08978d8eee93387a6087407444'
DRIVER = 'results/verification/baomai-partial-fronts-results-20261111/evaluate_comparison.py'
PROTOCOL = 'experiments/partial-fronts-2026-11-11.json'
ROLES = ('old_reviewed', 'extended_reviewed', 'current')
THRESHOLDS = ('0.15', '0.25', '0.4')
ARCHIVES = {
    'returned': {'local': 'baomai-partial-fronts-seed46-results.zip',
        'revision': 'fd1cb723a0be8859a50382b8903f0b2556103df3',
        'path': 'results/gpu/baomai-partial-fronts-a100-001/baomai-partial-fronts-seed46-results.zip',
        'sha256': '717781a642c1ac5597eb76d17e5b9c07e9306f64baed6ba82759007ebcd8379c', 'size_bytes': 39776611},
    'current': {'local': 'current-seed46-results.zip',
        'revision': '8e8bb99cabcb44ed0ec0acd14db911aa44013fd8',
        'path': 'results/gpu/baomai-reviewed-annotations-seed46-l4-001/baomai-reviewed-annotations-seed46-results.zip',
        'sha256': 'df53683ccf6f266a605b2844f42a98e808f75686cfab09f14d680c9d061e8a91', 'size_bytes': 39776456},
}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def safe(name):
    p = PurePosixPath(name)
    need(name and not p.is_absolute() and '..' not in p.parts and '\\' not in name and ':' not in name
         and p.as_posix() == name, f'unsafe member: {name}')
    need(p.suffix.lower() not in {'.pt', '.pth', '.onnx', '.engine', '.zip'}, f'weight/archive payload forbidden: {name}')


def sources(args):
    work, repo = args.work.resolve(), args.repo.resolve()
    entries = {}
    def add(name, path):
        safe(name)
        need(name not in entries, f'duplicate capsule name: {name}')
        entries[name] = Path(path)
    for name in ('comparison.json', 'identity.json', 'inventory.json', 'protocol.json', 'reference-review-notes.json', 'status.json'):
        add('run/' + name, work / 'run-001' / name)
    for role in ROLES:
        add(f'run/predictions-{role}.jsonl', work / 'run-001' / f'predictions-{role}.jsonl')
        for reference in ('primary', 'original'):
            name = f'scoring-{role}-{reference}.json'
            add('run/' + name, work / 'run-001' / name)
    add('run/execution.json', work / 'run-001-execution.json')
    add('run/console.log', work / 'run-001.log')
    add('source/evaluate_comparison.py', repo / DRIVER)
    add('source/protocol.json', repo / PROTOCOL)
    add('source/build_evidence.py', Path(__file__).resolve())
    for name in ('audit-provenance.json', 'source-input-verification.json', 'package-verification.json',
                 'package-verification.stdout', 'package-verification.stderr', 'uncertainty-map.json',
                 'independent-replay-audit.json', 'independent_replay_audit.py', 'replay-verification.json'):
        add('verification/' + name, work / name)
    add('verification/replay-console.log', work / 'replay-001.log')
    for name in ('identity.json', 'inventory.json', 'status.json'):
        add('verification/replay/' + name, work / 'replay-001' / name)
    for name in ('package-verification.json', 'package-verification.stdout', 'package-verification.stderr'):
        add('attempts/package-001/' + name, work / 'attempts/package-001' / name)
    for role in ROLES:
        base = work / ('current-unpacked/candidate' if role == 'current' else 'unpacked/' + role)
        for name in ('checkpoint-manifest.json', 'training-receipt.json', 'staging-manifest.json', 'train.log', 'fit/results.csv'):
            add(f'training/{role}/{name}', base / name)
    for role, parent in (('returned', 'unpacked'), ('current', 'current-unpacked')):
        add(f'training/{role}-archive-manifest.json', work / parent / 'gpu-results-manifest.json')
    add('review/case-review.json', args.case_review)
    for path in args.review_artifact:
        add('review/' + path.name, path)
    return entries


def validate(args, entries):
    for name, path in entries.items():
        need(path.is_file() and not path.is_symlink(), f'missing or symlink input: {name}: {path}')
    work, repo = args.work.resolve(), args.repo.resolve()
    run = work / 'run-001'
    status, execution, identity = (read(run / 'status.json'), read(work / 'run-001-execution.json'), read(run / 'identity.json'))
    need(status['status'] == execution['status'] == 'complete' and execution['exit_code'] == 0, 'real run did not complete')
    need(status['fresh_image_prediction_calls'] == 180 and status['scored_image_reference_threshold_pairs'] == 360, 'run scope differs')
    need(execution['source_revision'] == identity['source']['revision'] == SOURCE
         and execution['source_clean'] and identity['source']['working_tree_status'] == '', 'run source differs')
    need(sha(repo / DRIVER) == identity['driver_sha256'], 'executed driver changed')
    need(sha(repo / PROTOCOL) == identity['protocol_sha256'] == sha(run / 'protocol.json'), 'protocol changed')
    for name, metadata in read(run / 'inventory.json').items():
        p = run / name
        need(p.is_file() and p.stat().st_size == metadata['size_bytes'] and sha(p) == metadata['sha256'], f'run inventory mismatch: {name}')
    for spec in ARCHIVES.values():
        p = work / spec['local']
        need(p.stat().st_size == spec['size_bytes'] and sha(p) == spec['sha256'], f'archive identity differs: {p.name}')
    audit, replay = read(work / 'independent-replay-audit.json'), read(work / 'replay-verification.json')
    need(audit['status'] == 'passed' and replay['status'] == 'verified' and replay['exit_code'] == 0, 'numerical reviews are incomplete')
    need(audit['run_identity_sha256'] == sha(run / 'identity.json') and audit['script_sha256'] == sha(work / 'independent_replay_audit.py'), 'independent audit identity differs')
    need(audit['old_current_exact_ordered_prediction_calls'] == 60 and audit['old_current_tensor_lists_identical'] is True, 'operational equivalence is not established')
    need(audit['verified_counts']['per_image_scores'] == audit['verified_counts']['per_image_quality_records'] == 360, 'audit scope differs')
    need(replay['model_loads'] == replay['fresh_image_prediction_calls'] == 0, 'replay incorrectly records inference')
    for entry in replay['byte_identical_scoring_files']:
        need(sha(run / entry['path']) == entry['sha256'] == sha(work / 'replay-001' / entry['path']), 'replay score bytes differ')
    need(len(replay['byte_identical_scoring_files']) == 6, 'replay score count differs')
    provenance = read(work / 'audit-provenance.json')
    package = read(work / 'package-verification.json')
    need(provenance['status'] == 'passed' and package['exit_code'] == 0 and package['archive_unchanged'], 'package verification is incomplete')
    uncertainty = read(work / 'uncertainty-map.json')
    need(uncertainty['legacy_unresolved_count'] == len(uncertainty['legacy_unresolved']) == 19, 'inherited uncertainty count changed')
    need([r['case_id'] for r in uncertainty['separate_caveats']] == ['011:61'], 'separate reference caveat changed')
    case = read(args.case_review)
    need(case.get('kind') == 'bounded_original_pixel_review'
         and {row['case_id'] for row in case.get('cases', [])} == {'008:33', '009:57', '011:56', '055:23', '057:2', '058:1', '090:48'}
         and len(case['cases']) == 7 and all(row.get('pixel_observation') and row.get('outcome') for row in case['cases']),
         'case review does not contain the seven completed pixel observations/outcomes')
    need(case['labels_changed'] is False and case['scoring_changed'] is False
         and case['inference_run_by_this_review'] is False, 'case review changed the fixed experiment')
    figure = case['evidence_figure']
    need(sha(figure['path']) == figure['sha256'] and sha(figure['provenance_path']) == figure['provenance_sha256'],
         'review figure identity differs')
    return read(run / 'comparison.json'), audit, uncertainty, case


def compact_summary(comparison, audit, uncertainty, case):
    def metrics(role, reference, threshold):
        data = comparison['metrics'][role][reference][threshold]
        score, quality = data['score'], data['quality']
        independent = audit['metrics'][f'{role}/{reference}/{threshold}']
        for key in ('gold_count', 'prediction_count', 'tp', 'fn', 'fp', 'duplicate_fp', 'other_fp', 'visible_endpoints', 'returned_endpoints', 'missing_endpoints'):
            need(score[key] == independent[key], f'summary versus audit differs: {role}/{reference}/{threshold}/{key}')
        corners = {str(row['radius_px']): row['both_visible_objects_within_radius'] for row in quality['radii']}
        need(corners == independent['both_corners'], 'summary corner results differ from audit')
        return {**{k: score[k] for k in ('gold_count', 'prediction_count', 'tp', 'fn', 'fp', 'duplicate_fp', 'other_fp',
                    'visible_endpoints', 'returned_endpoints', 'missing_endpoints', 'conditional_median_error_px', 'conditional_p95_error_px')},
                'both_visible_reference_objects': quality['both_visible_objects'], 'both_corners_within_radius_px': corners,
                'returned_on_unlocatable_reference': quality['returned_on_unlocatable_reference'],
                'unlocatable_on_matched_objects': quality['unlocatable_on_matched_objects'],
                'miss_free_nonempty_image_ids': data['miss_free_nonempty_image_ids'],
                'empty_image_predictions': data['empty_image_predictions']}
    return {
        'schema_version': 1, 'kind': 'partial-fronts-return-summary', 'status': 'measured_and_independently_verified',
        'evaluation_source_revision': SOURCE,
        'protocol_sha256': '428cd853e0991ba138def8ba9ba9b74909bc654ab2d0c9c49e32a5b598479726',
        'primary_reference': {'manifest_sha256': '2e60b3e81195448cc565a1000b4305e3215baba2bf0ee0c976e6551c2e64937c',
            'objects': 663, 'visible_endpoints': 1228, 'confidence': .15,
            'results': {r: metrics(r, 'primary', '0.15') for r in ROLES}},
        'diagnostics_on_primary_reference': {t: {r: metrics(r, 'primary', t) for r in ROLES} for t in THRESHOLDS[1:]},
        'original_reference_results': {'manifest_sha256': '72ae8365d5abf0b45b75d400a2e6d22119c0e31b54ee33035feb8edc1f967926',
            'objects': 664, 'visible_endpoints': 1227,
            'by_confidence': {t: {r: metrics(r, 'original', t) for r in ROLES} for t in THRESHOLDS}},
        'extended_vs_old_reviewed_object_changes': {reference: {t: {k: comparison['comparisons'][reference]['extended_reviewed-vs-old_reviewed'][t][k]
            for k in ('gained_object_ids', 'lost_object_ids', 'both_corner_changes')} for t in THRESHOLDS} for reference in ('primary', 'original')},
        'primary_focus': {r: {obj: {k: value[k] for k in ('matched', 'matching_iou', 'max_proposal_iou', 'locatable_corners')}
            for obj, value in comparison['metrics'][r]['primary']['0.15']['focus'].items()} for r in ROLES},
        'operational_equivalence': {'evidence': 'verification/independent-replay-audit.json',
            'current_vs_old_reviewed_ordered_prediction_calls_exact': audit['old_current_exact_ordered_prediction_calls'],
            'current_vs_old_reviewed_loaded_tensor_lists_identical': audit['old_current_tensor_lists_identical'],
            'model_state_digests': audit['model_state_digests'], 'extended_changed_tensors': audit['extended_changed_tensors'],
            'tensor_count': audit['tensor_count'],
            'scope': 'Loaded pre-prediction tensor identity and these 60 ordered image-threshold outputs; checkpoint archive bytes differ.'},
        'reference_uncertainty': {'legacy_count': 19, 'legacy_case_ids': [r['case_id'] for r in uncertainty['legacy_unresolved']],
            'separate_caveat_ids': ['011:61'], 'all_rows_remain_in_scores': True,
            'case_review': 'review/case-review.json', 'case_review_completed_observation_and_outcome_count': len(case['cases']),
            'rule': 'A measured match does not resolve inherited identity/extent uncertainty; absent registry membership does not certify a row.'},
        'verification': audit['verified_counts'], 'model_promotion_by_this_builder': False,
        'limits': comparison['limits'],
    }


def verification_instructions():
    return {
        'kind': 'partial-fronts-evidence-reproduction', 'source_revision': SOURCE,
        'source_url': f'https://github.com/Siuuuers/dl/tree/{SOURCE}',
        'driver': DRIVER, 'frozen_protocol': PROTOCOL,
        'external_archives': {key: {**{k:v for k,v in spec.items() if k != 'local'},
            'url': f"https://raw.githubusercontent.com/Siuuuers/dl/{spec['revision']}/{spec['path']}"} for key, spec in ARCHIVES.items()},
        'steps': [
            'Check the outer ZIP SHA-256, then verify every payload size/hash against inventory.json and run ZIP CRC validation.',
            'Use the exact published source revision. Hydrate the original validation PNGs through Git LFS; retain the repository labels, manifests and metadata unchanged.',
            'Download and hash-check both external result archives. Extract them safely to separate new folders; keep the complete role bundles including their external weights.',
            'For the independent numerical audit, invoke verification/independent_replay_audit.py with --root pointing to the pinned repository, --run to capsule/run, --returned-root to the PR40 extraction, --current-manifest to the old archive candidate/checkpoint-manifest.json, and --output to a new JSON file.',
            'For the driver replay, invoke the pinned evaluate_comparison.py with the same root/bundle arguments, --replay-directory pointing to capsule/run and --output pointing to a new directory outside the source checkout. Replay loads no model and performs no inference, but verifies external checkpoint bytes.',
            'Compare the six replay scoring-file hashes against verification/replay-verification.json. Keep original and corrected-reference results separate.',
        ],
        'exclusions': ['Original images', 'All model weights and original result ZIPs', 'Python environment',
            'Duplicate replay scoring JSONs and replay comparison (the retained replay verification binds their equality)',
            'Historical current archive reference-arm files unused by this comparison'],
        'retained_failure': 'attempts/package-001 records a missing sparse metadata file, before model inference; the corrected verification is retained separately.',
        'notes': ['Training logs, receipts and CSVs are unchanged returned evidence. Packaging does not make a new training/accuracy claim.',
            'The current archive index names both of its original arms; only the selected candidate small artifacts are copied into this capsule.',
            'The exact driver is already published, so no private/local source Git bundle is needed.'],
    }


def package(args):
    entries = sources(args)
    missing = [str(path) for path in entries.values() if not path.is_file()]
    if args.plan:
        print(json.dumps({'payload_source_files': len(entries), 'missing': missing,
            'optional_review_artifacts': [str(p) for p in args.review_artifact],
            'outputs': ['evidence.zip', 'evidence.zip.sha256', 'evidence-inventory.json', 'summary.json'],
            'destination': str(args.destination.resolve()), 'packaged': False}, indent=2))
        return
    need(not missing, 'missing final evidence: ' + ', '.join(missing))
    comparison, audit, uncertainty, case = validate(args, entries)
    summary = compact_summary(comparison, audit, uncertainty, case)
    payload = {name: path.read_bytes() for name, path in entries.items()}
    payload['summary.json'] = encoded(summary)
    payload['verification.json'] = encoded(verification_instructions())
    descriptions = {name: {'sha256': hashlib.sha256(data).hexdigest(), 'size_bytes': len(data)} for name,data in sorted(payload.items())}
    inner = {'schema_version': 1, 'kind': 'partial-fronts-result-evidence-inventory',
        'evaluation_source_revision': SOURCE, 'payload_files': descriptions,
        'inventory_self_excluded': True, 'zip_member_timestamp': '2026-11-11T00:00:00',
        'scope': 'Completed experiment, exact predictions/scoring, package/training provenance, independent numerical and case reviews; original images and weights excluded.'}
    inner_bytes = encoded(inner)
    destination = args.destination.resolve()
    destination.mkdir(parents=True, exist_ok=True)
    outputs = ['evidence.zip', 'evidence.zip.sha256', 'evidence-inventory.json', 'summary.json']
    need(all(not (destination/name).exists() and not (destination/name).is_symlink() for name in outputs), 'an output already exists; preserve it and choose a new destination')
    with tempfile.TemporaryDirectory(prefix='.evidence-build-', dir=destination) as temporary:
        temp = Path(temporary)
        archive = temp/'evidence.zip'
        with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for name,data in sorted({**payload, 'inventory.json': inner_bytes}.items()):
                safe(name)
                info=zipfile.ZipInfo(name, date_time=(2026,11,11,0,0,0));info.create_system=3
                info.external_attr=0o100644 << 16;info.compress_type=zipfile.ZIP_DEFLATED
                z.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=6)
        with zipfile.ZipFile(archive) as z:
            need(z.testzip() is None, 'ZIP CRC failed')
            names=z.namelist();need(len(names)==len(set(names))==len(payload)+1, 'ZIP member inventory differs')
            need(set(names)==set(payload)|{'inventory.json'}, 'unexpected ZIP member')
            for info in z.infolist():
                safe(info.filename);need(not stat.S_ISLNK(info.external_attr>>16), 'ZIP symlink forbidden')
                actual=z.read(info)
                expected=inner_bytes if info.filename=='inventory.json' else payload[info.filename]
                need(actual==expected, f'ZIP readback differs: {info.filename}')
        digest=sha(archive)
        outer={**inner,'archive':{'filename':'evidence.zip','sha256':digest,'size_bytes':archive.stat().st_size,
            'member_count':len(payload)+1,'payload_member_count':len(payload),'inner_inventory_sha256':hashlib.sha256(inner_bytes).hexdigest()},
            'verification':{'all_payload_sizes_and_hashes_verified':True,'exact_byte_readback':True,'crc_all_passed':True,'safe_unique_members':True,
                'models_deserialized':False,'new_inference':False,'new_training':False},
            'summary_sha256':descriptions['summary.json']['sha256']}
        (temp/'summary.json').write_bytes(payload['summary.json'])
        (temp/'evidence-inventory.json').write_bytes(encoded(outer))
        (temp/'evidence.zip.sha256').write_text(digest+'  evidence.zip\n')
        for name in outputs:
            os.link(temp/name,destination/name)
    print(json.dumps({'status':'packaged_and_verified','destination':str(destination),'archive_sha256':digest,
        'archive_size_bytes':outer['archive']['size_bytes'],'payload_files':len(payload),'members':len(payload)+1,
        'summary_sha256':outer['summary_sha256']},indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--work',type=Path,required=True)
    parser.add_argument('--repo',type=Path,required=True)
    parser.add_argument('--destination',type=Path,required=True)
    parser.add_argument('--case-review',type=Path,required=True)
    parser.add_argument('--review-artifact',type=Path,action='append',default=[])
    parser.add_argument('--plan',action='store_true')
    package(parser.parse_args())
