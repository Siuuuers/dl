# Box-supervision execution evidence

This capsule preserves two failed four-batch reference attempts and a newly completed **one-batch candidate smoke test**. The candidate loaded all 137 training and 20 validation records, performed one parameter-changing optimizer update, and stopped without completing an epoch, validation, or checkpoint finalization. Its batch contains none of the three edited images. It does not demonstrate a changed-label gradient, learning gain, successful four-batch GPU trial, or complete 30-epoch comparison.

The first reference attempt exceeded its 6,000 MiB supervisor limit. The second ended with SIGKILL at a 7,500 MiB budget, with no recorded supervisor stop reason; the external cause is unknown. Their raw receipts are retained exactly.

## Verify without ML dependencies

Extract the capsule and run:

```sh
python -B verify_evidence.py /path/to/execution.zip
```

The standard-library verifier checks unique safe regular paths, archive CRC, every inventoried payload and a fresh extraction, receipt log/staging/YAML links, exact source hashes through stored Git commit/tree objects, final notebook compilation and pin, and rejection of the actual smoke receipt as a completed model. The portable rejection replay uses an extracted copy and leaves its receipt unchanged. The original-source rejection probe is separately preserved under `recovery/`.

The 63 focused checks, two setup-cell probes, synthetic pair-packaging probe, and 157-image input preflight are preserved in `review/`. The packaging probe uses synthetic complete-model fixtures; it is not evidence of real completed training. The raw review report predates the notebook pin and therefore records the earlier placeholder blocker. The final notebook snapshot replaces only that placeholder with immutable source `918b2fdb811bd595fc09de9a423df6c40258c55a`; all seven final code cells compile and contain no placeholder. This verifier validates existing check evidence; it does not rerun training or the complete original review harness.

The historical trials record `aa75df96abc31cf9f15fa23136dce342504b9cc7`. Its Git tree is identical to the published `918b2fdb811bd595fc09de9a423df6c40258c55a` tree. Raw commits and the relevant root/scripts tree objects establish that relationship and bind the seven preserved executed source files. Receipts retain their original source IDs.

Raw configs and logs contain machine-local provenance paths. Those paths are not needed for this integrity replay. Images, weights, data-loader caches and training checkpoints are omitted. The adjacent `verification.json` records the whole-archive hash and the fresh verification result.
