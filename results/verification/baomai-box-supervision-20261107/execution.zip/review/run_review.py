#!/usr/bin/env python3
"""Scratch-only independent source review; no training or model deserialization."""
import ast
import copy
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
from types import SimpleNamespace
from unittest.mock import patch
import zipfile

sys.dont_write_bytecode = True
ROOT = Path('/workspace/scratch/e02731b2268d/dl-supervision')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert revision == '918b2fdb811bd595fc09de9a423df6c40258c55a'
status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True)
assert not status
record = {'created_at_utc': datetime.now(timezone.utc).isoformat(), 'source_revision': revision,
          'source_root': str(ROOT), 'working_tree_status_before': status, 'checks': [],
          'scope': 'Independent source review; synthetic fixtures and actual input preflight. No new training or inference.'}

def save_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf-8')

for name in ('check_pose_box_candidate.py', 'check_pose_checkpoint.py', 'check_train_pose_comparison.py',
             'check_package_gpu_results.py', 'check_warmup_results.py', 'check_warmup_notebook.py'):
    command = [sys.executable, '-B', 'scripts/' + name]
    p = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
    log = OUT / (name.removesuffix('.py') + '.log')
    log.write_text(p.stdout + p.stderr, encoding='utf-8')
    count = re.search(r'Ran (\d+) tests?', p.stderr)
    record['checks'].append({'name': name, 'command': command, 'cwd': str(ROOT), 'exit_code': p.returncode,
                             'tests': int(count[1]) if count else None, 'log': log.name})
    assert p.returncode == 0, name

notebook = json.loads((ROOT / 'notebooks/baomai_box_supervision.ipynb').read_text())
cells = {cell['id']: ''.join(cell['source']) for cell in notebook['cells'] if cell['cell_type'] == 'code'}
for name, source in cells.items():
    compile(source, name, 'exec')
record['notebook_compilation'] = {'code_cells': len(cells), 'passed': True,
    'placeholder_occurrences': (ROOT / 'notebooks/baomai_box_supervision.ipynb').read_text().count('SOURCE_COMMIT_TO_PIN')}

module = ast.parse(cells['baomai-box-supervision-04'])
assign = next(node for node in module.body if isinstance(node, ast.Assign) and
              any(isinstance(target, ast.Name) and target.id == 'input_preflight' for target in node.targets))
preflight_source = ast.literal_eval(assign.value)
(OUT / 'notebook_input_preflight.py').write_text(preflight_source, encoding='utf-8')
command = [sys.executable, '-B', str(OUT / 'notebook_input_preflight.py'),
           'data/candidates/box-refinement-2026-11-07/manifest.json', 'box-supervision-warmup-v1']
p = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
(OUT / 'notebook_input_preflight.log').write_text(p.stdout + p.stderr, encoding='utf-8')
record['input_preflight'] = {'command': command, 'cwd': str(ROOT), 'exit_code': p.returncode,
                            'source_cell': 'baomai-box-supervision-04', 'log': 'notebook_input_preflight.log'}
assert p.returncode == 0
preflight_result = json.loads(p.stdout)
save_json(OUT / 'notebook_input_preflight.json', preflight_result)

setup_results = []
for missing in (False, True):
    commands = []
    with tempfile.TemporaryDirectory(prefix='review-box-notebook-') as temporary:
        base = Path(temporary)
        expected = b'torch==2.14.1+cu130\ntorchvision==0.29.1+cu130\n'
        def lookup(name):
            if missing and name == 'torchvision':
                raise importlib.metadata.PackageNotFoundError(name)
            return {'torch': '2.14.1+cu130', 'torchvision': '0.29.1+cu130'}[name]
        def run(command):
            if command[:5] == [sys.executable, '-m', 'pip', 'install', '-c']:
                assert Path(command[5]).read_bytes() == expected
                assert command[6:] == ['ultralytics==8.4.182', 'psutil']
            else:
                assert command[:2] == [sys.executable, '-c']
                compile(command[2], 'new-box-notebook-inline', 'exec')
            commands.append(list(map(str, command)))
        scope = {'RUN_BASE': base, 'sys': sys, 'run': run}
        memory = SimpleNamespace(virtual_memory=lambda: SimpleNamespace(available=20 * 2**30))
        with patch('importlib.metadata.version', side_effect=lookup), patch.dict(sys.modules, {'psutil': memory}):
            try:
                exec(compile(cells['baomai-box-supervision-06'], 'actual-box-setup-cell', 'exec'), scope)
                assert not missing
            except importlib.metadata.PackageNotFoundError:
                assert missing
        if missing:
            assert commands == [] and not (base / 'torch-constraints.txt').exists()
        else:
            assert len(commands) == 2 and scope['HOST_RSS_LIMIT_MIB'] == 12000
        setup_results.append({'case': 'missing_torchvision_stops_before_install' if missing else
                              'installed_cuda_pins_exist_before_pip', 'passed': True,
                              'source_cell': 'baomai-box-supervision-06', 'command_count': len(commands)})
record['new_notebook_setup_checks'] = setup_results

from check_pose_checkpoint import bundle_fixture, write_json
from evaluate_pose import file_sha256
from package_gpu_results import package_results
from pose_checkpoint import BOX_RECIPE_ID, select_checkpoint, write_checkpoint_manifest
from train_pose_comparison import descriptor
with tempfile.TemporaryDirectory(prefix='review-box-packaging-') as temporary:
    base = Path(temporary)
    root, reference, preflight, receipt, staging, manifest = bundle_fixture(base, 'reference', recipe_id=BOX_RECIPE_ID)
    candidate = base / 'candidate-run'
    shutil.copytree(reference, candidate)
    staging = copy.deepcopy(staging)
    staging['output_root'] = str(candidate / 'staged-data')
    write_json(candidate / 'staging-manifest.json', staging)
    receipt = copy.deepcopy(receipt)
    receipt.update(arm='candidate', staging_manifest_sha256=file_sha256(candidate / 'staging-manifest.json'),
                   data_yaml_sha256=staging['variants']['candidate']['data_yaml_sha256'])
    receipt['training_settings'].update(data=str(candidate / 'staged-data/candidate/data.yaml'),
                                        project=str(candidate), save_dir=str(candidate / 'fit'))
    checkpoint = candidate / 'fit/weights/last.pt'
    checkpoint.write_bytes(b'synthetic box candidate; never deserialize\n')
    receipt['checkpoint'] = descriptor(checkpoint, candidate, checkpoint=True)
    write_json(candidate / 'training-receipt.json', receipt)
    (candidate / 'checkpoint-manifest.json').unlink()
    write_checkpoint_manifest(candidate, preflight)
    output = base / 'results.zip'
    result = package_results(root, reference, candidate, output)
    with zipfile.ZipFile(output) as archive:
        assert len(archive.namelist()) == 13 and archive.testzip() is None
        archive.extractall(base / 'restored')
    identities = {}
    for arm in ('reference', 'candidate'):
        identity = select_checkpoint(preflight, base / 'restored' / arm / 'checkpoint-manifest.json')['checkpoint_identity']
        assert identity['arm'] == arm and identity['recipe_id'] == BOX_RECIPE_ID
        identities[arm] = {'recipe_id': identity['recipe_id'], 'arm': identity['arm'],
                           'completed_epochs': identity['completed_epochs']}
    record['new_box_pair_packaging_probe'] = {'passed': True, 'synthetic_only': True,
        'archive_members': result['files'], 'roundtrip_identities': identities,
        'scope': 'Completed-bundle validator and existing return packer accept matching schema-2 box experiment identities. No actual completed training or weights.'}

record['working_tree_status_after'] = subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True)
assert not record['working_tree_status_after']
record['conclusion'] = {
    'training_source_blockers_found': [],
    'handoff_blocker': 'Replace SOURCE_COMMIT_TO_PIN in the notebook with immutable source revision 918b2fdb811bd595fc09de9a423df6c40258c55a before publishing a ready-to-run handoff.',
    'notebook_notes': [
        'Source checkout and LFS inventory are checked before input preflight; actual input preflight passed on all 157 original images and original weight bytes.',
        'CUDA PyTorch is constrained before trainer installation. Valid-version and missing-version paths were executed with safe install/GPU substitutes.',
        'A four-batch resource trial uses the same 30-epoch schedule; it remains ineligible as a model and does not certify full training/finalization resources.',
        'Both complete runs use the same new recipe, explicit candidate manifest, fixed initialization, source and runtime; the existing packer accepts a synthetic matched box pair.',
        'No Colab GPU runtime, network source fetch, new training, accuracy evaluation, or image-semantic review was performed by this review.'
    ]}
save_json(OUT / 'review_verification.json', record)
print(json.dumps({'source_revision': revision, 'focused_tests': sum(item['tests'] for item in record['checks']),
                  'new_notebook_setup_checks': len(setup_results), 'new_box_pair_packaging_probe': 'passed',
                  'input_preflight': preflight_result['status'], 'report': str(OUT / 'review_verification.json')}, indent=2))
