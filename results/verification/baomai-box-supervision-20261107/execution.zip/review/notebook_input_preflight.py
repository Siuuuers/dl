
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
root = Path.cwd()
sys.path.insert(0, str(root / 'scripts'))
from evaluate_pose import preflight_dataset
from stage_pose_training import source_state
from pose_checkpoint import get_recipe, recipe_identity
candidate = root / sys.argv[1]
recipe_id = sys.argv[2]
proposal = json.loads(candidate.read_text())
assert proposal['kind'] == 'training_box_overlay'
assert proposal['candidate_id'] == 'box-refinement-2026-11-07'
edge_counts = {change['image_id']: sum(len(row['box_edges_changed']) for row in change['rows'])
               for change in proposal['changes']}
assert edge_counts == {'new_000030': 8, 'new_000012': 6, 'new_000128': 2}, edge_counts
state = source_state(root, candidate)
initial = preflight_dataset(root, require_weights=True)
assert len(state['records']) == 157
assert state['counts']['reference'] == state['counts']['candidate']
assert state['counts']['reference']['train']['images'] == 137
assert state['counts']['reference']['val']['images'] == 20
assert state['source']['initial_checkpoint_sha256'] == initial['model_sha256']
assert Path(initial['weights']) == root / 'weights/cassette_lower_epoch173.pt'
assert get_recipe(recipe_id) == get_recipe('warmup-bias-lr-1e-4-v1')
print(json.dumps({'status': 'verified', 'original_images': len(state['records']),
                  'box_edge_corrections': edge_counts, 'label_counts': state['counts'],
                  'initial_checkpoint_sha256': initial['model_sha256'],
                  'weights_verified': initial['weights_verified'],
                  **recipe_identity(recipe_id)}, indent=2))
