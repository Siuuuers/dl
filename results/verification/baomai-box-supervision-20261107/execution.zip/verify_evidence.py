#!/usr/bin/env python3
"""Verify this execution capsule with Python's standard library; run no training."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tempfile
import zipfile

sys.dont_write_bytecode = True
EXPECTED_SOURCE = '918b2fdb811bd595fc09de9a423df6c40258c55a'
EXPECTED_LEGACY = 'aa75df96abc31cf9f15fa23136dce342504b9cc7'
REJECTION = 'only a completed paired-finetune qualifies; resource trials are ineligible'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git_hash(kind, data):
    return hashlib.sha1(kind.encode() + b' ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def tree_entries(data):
    result = {}
    offset = 0
    while offset < len(data):
        space = data.index(b' ', offset)
        end = data.index(b'\0', space)
        mode = data[offset:space].decode()
        name = data[space + 1:end].decode()
        assert name not in result
        result[name] = {'mode': mode, 'sha': data[end + 1:end + 21].hex()}
        offset = end + 21
    assert offset == len(data)
    return result


def read_json(path):
    return json.loads(path.read_bytes())


def verify(archive):
    archive = Path(archive).resolve()
    with zipfile.ZipFile(archive) as z:
        members = z.infolist()
        names = [item.filename for item in members]
        assert len(names) == len(set(names)), 'duplicate member names'
        for item in members:
            path = PurePosixPath(item.filename)
            assert str(path) == item.filename and not path.is_absolute()
            assert all(part not in ('', '.', '..') for part in path.parts)
            assert '\\' not in item.filename and ':' not in item.filename
            assert stat.S_ISREG(item.external_attr >> 16), 'nonregular file'
            assert path.suffix.lower() not in ('.pt', '.png', '.jpg', '.jpeg'), 'excluded model or image payload'
        assert z.testzip() is None, 'CRC failure'
        inventory = json.loads(z.read('evidence-manifest.json'))
        files = {entry['path']: entry for entry in inventory['files']}
        assert len(files) == len(inventory['files'])
        assert set(files) | {'evidence-manifest.json'} == set(names)
        for path, entry in files.items():
            data = z.read(path)
            assert len(data) == entry['size_bytes'] and sha(data) == entry['sha256'], path
        with tempfile.TemporaryDirectory(prefix='box-execution-verify-') as temporary:
            base = Path(temporary)
            z.extractall(base)
            assert {p.relative_to(base).as_posix() for p in base.rglob('*') if p.is_file()} == set(names)
            for path, entry in files.items():
                data = (base / path).read_bytes()
                assert len(data) == entry['size_bytes'] and sha(data) == entry['sha256'], path
            result = verify_payloads(base, inventory)
    result['archive'] = {
        'member_count': len(names), 'inventoried_payload_count': len(files),
        'size_bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes()),
        'crc_passed': True, 'unique_safe_regular_paths': True,
        'all_payload_sizes_and_hashes_passed': True,
        'fresh_extraction_file_set_and_hashes_passed': True,
        'no_weights_or_images': True,
        'manifest_sha256': sha(json.dumps(inventory).encode()) if False else None,
    }
    with zipfile.ZipFile(archive) as z:
        result['archive']['manifest_sha256'] = sha(z.read('evidence-manifest.json'))
    return result


def verify_payloads(base, inventory):
    proof = read_json(base / 'source/source-proof.json')
    assert proof['source_revision'] == EXPECTED_SOURCE and proof['legacy_trial_revision'] == EXPECTED_LEGACY
    commit_trees = {}
    for revision in (EXPECTED_SOURCE, EXPECTED_LEGACY):
        data = (base / f'source/git/commits/{revision}.txt').read_bytes()
        assert git_hash('commit', data) == revision
        commit_trees[revision] = data.split(b'\n', 1)[0].decode().split(' ', 1)[1]
    assert len(set(commit_trees.values())) == 1
    root_tree = next(iter(commit_trees.values()))
    assert root_tree == proof['common_tree']
    tree_data = (base / f'source/git/trees/{root_tree}.bin').read_bytes()
    assert git_hash('tree', tree_data) == root_tree
    scripts_tree = tree_entries(tree_data)['scripts']['sha']
    assert scripts_tree == proof['scripts_tree']
    scripts_data = (base / f'source/git/trees/{scripts_tree}.bin').read_bytes()
    assert git_hash('tree', scripts_data) == scripts_tree
    entries = tree_entries(scripts_data)
    source_hashes = {}
    for row in proof['files']:
        relative = row['repository_path']
        assert relative.startswith('scripts/')
        data = (base / 'source' / relative).read_bytes()
        assert git_hash('blob', data) == entries[Path(relative).name]['sha'] == row['git_blob_sha1']
        assert sha(data) == row['sha256']
        source_hashes[relative] = sha(data)
    assert len(source_hashes) == 7

    spec = importlib.util.spec_from_file_location('capsule_pose_checkpoint', base / 'source/scripts/pose_checkpoint.py')
    checkpoint = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checkpoint)
    recipe = checkpoint.recipe_identity('box-supervision-warmup-v1')
    summaries = {}
    file_inventories = []
    for name in inventory['trials']:
        run = base / 'trials' / name
        receipt = read_json(run / 'training-receipt.json')
        config = read_json(run / 'run-config.json')
        staging = read_json(run / 'staging-manifest.json')
        progress = read_json(run / 'training-progress.json')
        assert receipt['source']['working_tree_status'] == ''
        assert receipt['source']['files_sha256'] == source_hashes
        expected_revision = EXPECTED_SOURCE if name == 'candidate-smoke-001' else EXPECTED_LEGACY
        assert receipt['source']['revision'] == expected_revision
        assert all(receipt[key] == value for key, value in recipe.items())
        assert receipt['purpose'] == 'resource-trial' and receipt['completed_epochs'] == []
        assert receipt['checkpoint_selection'] == 'none'
        assert not receipt['validation_executed'] and not receipt['finalization_completed']
        assert receipt['inputs_reverified_after_worker']
        assert receipt['batches_completed'] == receipt['optimizer_steps'] == 1
        assert receipt['images_processed'] == 4 and receipt['optimizer_parameter_change_observed']
        assert receipt['optimizer_step_samples'][0]['witness_parameter_changed']
        assert receipt['batches_completed'] == progress['batches_completed']
        assert sha((run / 'train.log').read_bytes()) == receipt['log']['sha256']
        stage_bytes = (run / 'staging-manifest.json').read_bytes()
        assert sha(stage_bytes) == receipt['staging_manifest_sha256']
        assert stage_bytes == (run / 'staged-data/staging-manifest.json').read_bytes()
        assert receipt['initial_checkpoint_sha256'] == staging['source']['initial_checkpoint_sha256']
        assert receipt['reference_manifest_sha256'] == staging['source']['reference_manifest_sha256']
        assert receipt['model_card_sha256'] == staging['source']['model_card_sha256']
        variants = {}
        for arm in ('reference', 'candidate'):
            variant = staging['variants'][arm]
            yaml = (run / 'staged-data' / variant['data_yaml']).read_bytes()
            assert sha(yaml) == variant['data_yaml_sha256']
            if receipt['arm'] == arm:
                assert sha(yaml) == receipt['data_yaml_sha256']
            variants[arm] = {item['path']: item['output_sha256'] for item in variant['files']}
        assert set(variants['reference']) == set(variants['candidate'])
        changed = sorted(key for key in variants['reference'] if variants['reference'][key] != variants['candidate'][key])
        assert changed == ['labels/train/new_000012.txt', 'labels/train/new_000030.txt', 'labels/train/new_000128.txt']
        file_inventories.append(variants)
        if name == 'candidate-smoke-001':
            assert receipt['arm'] == 'candidate' and config['trial_batches'] == 1
            assert receipt['status'] == 'trial-complete' and receipt['execution']['exit_code'] == 0
        else:
            assert receipt['arm'] == 'reference' and config['trial_batches'] == 4
            assert receipt['status'] == 'failed'
        checkpoint.check_training_settings(receipt['training_settings'], receipt['recipe_id'],
            model=config['initial_weights'], data=receipt['training_settings']['data'],
            device=config['device'], project=config['output'])
        assert receipt['training_settings']['epochs'] == 30
        summaries[name] = {
            'arm': receipt['arm'], 'status': receipt['status'],
            'requested_batches': config['trial_batches'],
            'batches_completed': receipt['batches_completed'], 'images_processed': receipt['images_processed'],
            'optimizer_steps': receipt['optimizer_steps'], 'parameter_change_observed': receipt['optimizer_parameter_change_observed'],
            'completed_epochs': len(receipt['completed_epochs']), 'source_revision': receipt['source']['revision'],
            'source_tree_clean_at_execution': True, 'execution': receipt['execution'],
            'loader_verification': receipt['loader_verification'],
            'batch_image_ids': receipt['batch_samples'][0]['image_ids'],
            'threads': config['threads'], 'inputs_reverified_after_worker': True,
            'log_staging_and_both_yaml_hashes_match': True,
        }
    assert all(item == file_inventories[0] for item in file_inventories)
    assert summaries['reference-trial-001']['execution']['stop_reason'] == 'process RSS limit exceeded'
    assert summaries['reference-trial-001']['execution']['exit_code'] == -15
    assert summaries['reference-trial-002']['execution']['stop_reason'] is None
    assert summaries['reference-trial-002']['execution']['exit_code'] == -9
    candidate = base / 'trials/candidate-smoke-001'
    receipt_path = candidate / 'training-receipt.json'
    before = sha(receipt_path.read_bytes())
    assert not (candidate / 'checkpoint-manifest.json').exists()
    try:
        checkpoint.write_checkpoint_manifest(candidate, {})
    except ValueError as error:
        assert str(error) == REJECTION
    else:
        raise AssertionError('resource trial incorrectly accepted as a complete model')
    assert sha(receipt_path.read_bytes()) == before and not (candidate / 'checkpoint-manifest.json').exists()
    original_probe = read_json(base / 'recovery/actual-candidate-rejection.json')
    assert original_probe['receipt_sha256_before'] == original_probe['receipt_sha256_after'] == before
    assert original_probe['exception_message'] == REJECTION
    assert original_probe['checkpoint_manifest_before'] is False and original_probe['checkpoint_manifest_after'] is False
    edited_ids = {'new_000012', 'new_000030', 'new_000128'}
    assert not edited_ids.intersection(summaries['candidate-smoke-001']['batch_image_ids'])

    notebook_bytes = (base / 'handoff/baomai_box_supervision.ipynb').read_bytes()
    assert b'SOURCE_COMMIT_TO_PIN' not in notebook_bytes
    notebook = json.loads(notebook_bytes)
    code = {cell['id']: ''.join(cell['source']) for cell in notebook['cells'] if cell['cell_type'] == 'code'}
    assert len(code) == 7
    for name, source in code.items():
        compile(source, name, 'exec')
    pins = []
    for source in code.values():
        for node in ast.walk(ast.parse(source)):
            if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'SOURCE_REVISION' for target in node.targets):
                pins.append(ast.literal_eval(node.value))
    assert pins == [EXPECTED_SOURCE]
    module = ast.parse(code['baomai-box-supervision-04'])
    assign = next(node for node in module.body if isinstance(node, ast.Assign) and any(
        isinstance(target, ast.Name) and target.id == 'input_preflight' for target in node.targets))
    assert ast.literal_eval(assign.value).encode() == (base / 'review/notebook_input_preflight.py').read_bytes()
    review = read_json(base / 'review/review_verification.json')
    assert review['source_revision'] == EXPECTED_SOURCE
    counts = {}
    for check in review['checks']:
        assert check['exit_code'] == 0
        log = (base / 'review' / check['log']).read_text()
        match = re.search(r'Ran (\d+) tests?', log)
        assert match and int(match[1]) == check['tests'] and re.search(r'\nOK\b', log)
        counts[check['name']] = check['tests']
    assert sum(counts.values()) == 63
    assert len(review['new_notebook_setup_checks']) == 2 and all(row['passed'] for row in review['new_notebook_setup_checks'])
    synthetic = review['new_box_pair_packaging_probe']
    assert synthetic['passed'] and synthetic['synthetic_only']
    preflight = read_json(base / 'review/notebook_input_preflight.json')
    assert preflight['status'] == 'verified' and preflight['original_images'] == 157 and preflight['weights_verified']
    assert preflight == json.loads((base / 'review/notebook_input_preflight.log').read_bytes())
    return {
        'source_provenance': {
            'source_revision': EXPECTED_SOURCE, 'legacy_trial_revision': EXPECTED_LEGACY,
            'common_tree': root_tree, 'commit_objects_rehashed': True, 'tree_objects_rehashed': True,
            'seven_source_files_proven_through_git_tree': True,
            'all_trial_recorded_source_hashes_match_published_source': True,
        },
        'trials': summaries,
        'staged_file_identities_equal_across_attempts': True,
        'original_vs_candidate_only_differ_in_three_training_label_files': True,
        'candidate_trial_rejection_replayed': {
            'passed': True, 'error': REJECTION, 'receipt_unchanged': True, 'no_checkpoint_manifest_created': True,
        },
        'candidate_first_batch_contains_edited_images': False,
        'notebook': {'sha256': sha(notebook_bytes), 'code_cells_compiled': 7,
            'source_pin': EXPECTED_SOURCE, 'placeholder_occurrences': 0,
            'embedded_preflight_matches_executed_harness': True},
        'preserved_checks': {'existing_focused_checks': counts, 'total': 63,
            'new_notebook_setup_probes': review['new_notebook_setup_checks'],
            'synthetic_box_pair_packaging_probe': synthetic,
            'input_preflight': preflight,
            'scope': 'Preserved successful check evidence; verifier rehashes it and validates its counts, not reruns the complete harness.'},
    }


if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('Usage: python -B verify_evidence.py /path/to/execution.zip')
    print(json.dumps(verify(sys.argv[1]), indent=2, sort_keys=True, allow_nan=False))
