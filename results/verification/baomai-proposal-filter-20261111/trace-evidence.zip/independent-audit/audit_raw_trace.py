import hashlib,json,sys,math
from pathlib import Path
import numpy as np
root=Path('/workspace/scratch/b2268c0c3452/dl')
base=Path('/workspace/scratch/234c4cdb06aa/raw-proposal-trace/run-001')
out=Path('/workspace/scratch/234c4cdb06aa/audit-pr40')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def iou(a,b):
    inter=max(0,min(a[2],b[2])-max(a[0],b[0]))*max(0,min(a[3],b[3])-max(a[1],b[1]))
    union=(a[2]-a[0])*(a[3]-a[1])+(b[2]-b[0])*(b[3]-b[1])-inter
    return inter/union if union>0 else 0.0
def suppress(boxes,scores,gate):
    active=np.flatnonzero(scores>gate)
    active=active[np.argsort(-scores[active],kind='stable')]
    kept=[]
    areas=(boxes[:,2]-boxes[:,0])*(boxes[:,3]-boxes[:,1])
    while len(active) and len(kept)<300:
        i=active[0];kept.append(int(i));rest=active[1:]
        xy1=np.maximum(boxes[i,:2],boxes[rest,:2]);xy2=np.minimum(boxes[i,2:],boxes[rest,2:])
        ext=np.maximum(0,xy2-xy1);inter=ext[:,0]*ext[:,1]
        overlaps=inter/(areas[i]+areas[rest]-inter)
        active=rest[overlaps<=.7]
    return kept
summary=read(base/'trace-summary.json')
inv=read(base/'inventory.json')
for name,entry in inv.items():
    p=base/name;assert p.stat().st_size==entry['size_bytes'];assert sha(p)==entry['sha256']
assert sha(base.parent/'trace_raw_proposals.py')==summary['script_sha256']
for module,v in summary['runtime_source_files'].items():assert sha(Path(v['path']))==v['sha256'],module
frozen={p['image_id']:p['predictions'] for p in read(base/'current-final-predictions.json')}
archived={}
for line in (out/'extracted/run/predictions-current.jsonl').read_text().splitlines():
    p=json.loads(line)
    if p.get('record_type')=='prediction' and p['threshold']==.15:archived[p['image_id']]=p['predictions']
refs=read(root/'data/references/visible-front-2026-11-11/manifest.json')
refs={r['image_id']:r for r in refs['files']}
results=[]
for t in summary['targets']:
    image=t['image_id'];z=np.load(base/f'{image}-raw.npz',allow_pickle=False)
    raw=z['decoded_pre_nms_bcn'];assert raw.shape==(1,11,19320);assert list(z['input_shape'])==[1,3,736,1280]
    d=raw[0].T
    boxes=np.empty((len(d),4),dtype=np.float32)
    boxes[:,0]=d[:,0]-d[:,2]/2;boxes[:,1]=d[:,1]-d[:,3]/2
    boxes[:,2]=d[:,0]+d[:,2]/2;boxes[:,3]=d[:,1]+d[:,3]/2
    orig=boxes.copy();orig[:,[1,3]]-=8
    orig[:,[0,2]]=np.clip(orig[:,[0,2]],0,1280);orig[:,[1,3]]=np.clip(orig[:,[1,3]],0,720)
    assert np.array_equal(orig,z['boxes_xyxy_original'])
    points=d[:,5:].reshape(-1,2,3).copy();points[:,:,1]-=8
    points[:,:,0]=np.clip(points[:,:,0],0,1280);points[:,:,1]=np.clip(points[:,:,1],0,720)
    assert np.array_equal(points,z['keypoints_original'])
    refpath=root/'data/references/visible-front-2026-11-11'/refs[image]['label_path']
    assert sha(refpath)==t['reference_label_sha256']
    fields=list(map(float,refpath.read_text().splitlines()[t['reference_row_one_based']-1].split()))
    _,cx,cy,w,h,*_=fields
    target=[(cx-w/2)*1280,(cy-h/2)*720,(cx+w/2)*1280,(cy+h/2)*720]
    assert target==t['target_reference']['bbox_xyxy']
    overlaps=np.array([iou(target,b) for b in orig.tolist()])
    
    max_iou_error=float(np.max(np.abs(overlaps-z['target_iou_original'])))
    assert np.allclose(overlaps,z['target_iou_original'],rtol=0,atol=1e-15)
    assert np.array_equal(overlaps>=.5,z['target_iou_original']>=.5)
    scores=d[:,4];geometry=np.flatnonzero(overlaps>=.5)
    assert len(geometry)==t['raw_iou_ge_0_50_count']
    assert int(np.sum(scores>.15))==t['raw_confidence_gt_0_15_count']
    assert int(np.sum((overlaps>=.5)&(scores>.15)))==0
    kept=suppress(boxes,scores,.15)
    assert kept==z['retained_raw_indices'].tolist()
    def records(indices):
        return [{'class_id':0,'bbox_xyxy':orig[i].tolist(),'confidence':float(scores[i]),'keypoints':points[i].tolist()} for i in indices]
    got=records(kept);assert got==frozen[image]==archived[image]
    high=int(np.argmax(overlaps));assert high==t['maximum_iou_proposal']['raw_index_zero_based']
    high_score=int(geometry[np.argmax(scores[geometry])]) if len(geometry) else None
    r={'image_id':image,'raw_proposals':len(d),'geometry_at_least_0_50':len(geometry),'confidence_above_0_15':int(np.sum(scores>.15)),
       'eligible_geometry':0,'retained_count':len(kept),'baseline_exact_from_independent_numpy_nms':True,
       'manual_letterbox_transform_exact':True,'independent_iou_max_abs_error':max_iou_error,'iou_0_50_membership_exact':True,
       'max_iou_index':high,'max_iou':float(overlaps[high]),'max_iou_score':float(scores[high]),
       'highest_score_qualifying_index':high_score,'highest_score_qualifying_score':float(scores[high_score]) if high_score is not None else None}
    if image=='new_000008':
        sys.path.insert(0,str(root/'scripts'));from pose_scoring import score_image;from evaluate_pose import parse_pose_labels
        gold=parse_pose_labels(refpath.read_text(),1280,720,str(refpath))
        alternate=suppress(boxes,scores,.13);a=score_image(gold,got,1280,720,.5,.5);b=score_image(gold,records(alternate),1280,720,.5,.5)
        old_matched={m['gold_index'] for m in a['matches']};new_matched={m['gold_index'] for m in b['matches']}
        r['exploratory_0_13_same_raw']={'count':len(alternate),'new_raw_indices':[i for i in alternate if i not in kept],
          'old_count':len(kept),'old_tp_fn_fp':[a[k] for k in ('tp','fn','fp')],'new_tp_fn_fp':[b[k] for k in ('tp','fn','fp')],
          'gained_rows_one_based':[i+1 for i in sorted(new_matched-old_matched)],'lost_rows_one_based':[i+1 for i in sorted(old_matched-new_matched)],
          'highest_score_geometry_survives':high_score in alternate}
    results.append(r)
result={'status':'passed','summary_sha256':sha(base/'trace-summary.json'),'script_sha256':sha(Path(__file__)),
        'payload_files_verified':len(inv),'runtime_source_files_verified':len(summary['runtime_source_files']),
        'method':'Independent NumPy float32 letterbox/clip transform, Python-float IoU, NumPy greedy NMS, exact archived post-filter array equality; no trace module imports or model loads.',
        'fresh_inference':False,'checkpoint_deserialization':False,'results':results}
p=out/'raw-trace-independent-audit.json';p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
