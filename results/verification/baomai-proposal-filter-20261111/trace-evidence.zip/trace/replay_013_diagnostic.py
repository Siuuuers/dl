#!/usr/bin/env python3
"""One post-hoc 0.13 counterfactual on stored 008 proposals, without inference."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys

os.environ.update(YOLO_OFFLINE="true", YOLO_AUTOINSTALL="false")
sys.dont_write_bytecode = True


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, required=True)
    p.add_argument("--trace", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    os.environ["YOLO_CONFIG_DIR"] = str(a.output / "runtime-config")
    sys.path.insert(0, str(a.root / "scripts"))
    from pose_scoring import _box_iou, score_image
    from evaluate_pose import parse_pose_labels
    import numpy as np
    import torch
    import torchvision
    from ultralytics.utils import nms, ops
    from PIL import Image, ImageDraw, ImageFont

    trace = json.loads((a.trace / "trace-summary.json").read_text())
    previous = trace["targets"][0]
    assert previous["image_id"] == "new_000008"
    raw_file = a.trace / previous["raw_archive"]["path"]
    assert sha(raw_file) == previous["raw_archive"]["sha256"]
    stored = np.load(raw_file, allow_pickle=False)
    raw = torch.from_numpy(stored["decoded_pre_nms_bcn"])
    target = previous["target_reference"]
    input_shape = stored["input_shape"].tolist()
    candidate_index = previous["maximum_confidence_geometrically_qualifying_proposal"]["raw_index_zero_based"]
    assert candidate_index == 17038
    out, ids = nms.non_max_suppression(raw.clone(), .13, .70, max_det=300, nc=1,
                                      end2end=False, return_idxs=True)
    original_output = out[0].clone()
    ops.scale_boxes(input_shape[2:], original_output[:, :4], (720, 1280))
    ops.scale_coords(input_shape[2:], original_output[:, 6:].view(-1, 2, 3), (720, 1280))
    retained = ids[0].tolist()
    previous_retained = stored["retained_raw_indices"].tolist()
    additions = [i for i in retained if i not in set(previous_retained)]
    removals = [i for i in previous_retained if i not in set(retained)]
    predictions = [{"class_id": int(row[5]), "bbox_xyxy": row[:4],
                    "confidence": row[4], "keypoints": [row[6:9], row[9:12]]}
                   for row in original_output.tolist()]
    labels = a.root / "data/references/visible-front-2026-11-11/labels/val/new_000008.txt"
    assert sha(labels) == previous["reference_label_sha256"]
    gold = parse_pose_labels(labels.read_text(), 1280, 720, str(labels))
    score = score_image(gold, predictions, 1280, 720, .5, .5)
    matches = [pair for pair in score["matches"] if pair["gold_index"] == 32]
    candidate = predictions[retained.index(candidate_index)] if candidate_index in retained else None
    result = {
        "schema_version": 1, "kind": "post_hoc_single_case_counterfactual", "status": "complete",
        "scope": "008 only; confidence 0.13 selected after the raw trace; all other settings fixed. No dataset-wide claim.",
        "source_trace_summary_sha256": sha(a.trace / "trace-summary.json"),
        "raw_archive_sha256": sha(raw_file), "source_script_sha256": sha(__file__),
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "command": [sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]],
        "image_id": "new_000008", "target_reference_row_one_based": 33,
        "counterfactual_confidence": .13, "nms_iou": .70, "max_det": 300, "matching_iou": .50,
        "model_loads": 0, "image_predictions": 0,
        "inspected_raw_index_zero_based": candidate_index,
        "inspected_candidate_retained": candidate_index in retained,
        "inspected_candidate": candidate,
        "inspected_candidate_iou_with_target": _box_iou(candidate["bbox_xyxy"], target["bbox_xyxy"]) if candidate else None,
        "target_match_after_full_image_one_to_one_scoring": matches,
        "final_prediction_count_before": len(previous_retained), "final_prediction_count_after": len(retained),
        "added_raw_indices": additions, "removed_raw_indices": removals,
        "all_added_predictions": [{"raw_index_zero_based": i, "prediction": predictions[retained.index(i)]} for i in additions],
        "full_image_score_counts_at_013": {k: score[k] for k in ("gold_count", "prediction_count", "tp", "fn", "fp", "duplicate_fp", "other_fp")},
        "retained_raw_indices_at_013": retained,
        "nms_source_sha256": sha(nms.__file__),
        "torch": torch.__version__, "torchvision": torchvision.__version__,
        "caveat": "This tests a single already-inspected development image. It does not set a new operational threshold or measure review workload on the full set.",
    }
    write(a.output / "counterfactual-013.json", result)

    font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    font = ImageFont.truetype(font_path, 18)
    small = ImageFont.truetype(font_path, 15)
    cases = [
        ("new_000008", 33, 17038, (1070, 350, 1280, 520),
         "008:33 | score 0.13315 | clipped IoU 0.60516"),
        ("new_000009", 57, 10342, (745, 450, 885, 550),
         "009:57 | score 0.00103 | maximum IoU 0.49046"),
    ]
    panels = []
    figure_provenance = []
    for image_id, row, index, crop, title in cases:
        t = next(t for t in trace["targets"] if t["image_id"] == image_id)
        data = np.load(a.trace / t["raw_archive"]["path"], allow_pickle=False)
        image_path = a.root / "data/images/val" / f"{image_id}.png"
        assert sha(image_path) == t["image_sha256"]
        original = Image.open(image_path).convert("RGB")
        area = original.crop(crop)
        scale = 3
        plain = area.resize((area.width * scale, area.height * scale), Image.Resampling.NEAREST)
        overlay = plain.copy()
        draw = ImageDraw.Draw(overlay)

        def transform_box(box):
            return [(box[0] - crop[0]) * scale, (box[1] - crop[1]) * scale,
                    (box[2] - crop[0]) * scale, (box[3] - crop[1]) * scale]

        draw.rectangle(transform_box(t["target_reference"]["bbox_xyxy"]), outline="#31ff80", width=3)
        draw.rectangle(transform_box(data["boxes_xyxy_original"][index].tolist()), outline="#ff62e7", width=3)
        for x, y, visibility in t["target_reference"]["keypoints"]:
            if visibility:
                xx, yy = (x - crop[0]) * scale, (y - crop[1]) * scale
                draw.ellipse((xx-5, yy-5, xx+5, yy+5), outline="#31ff80", width=2)
        for x, y, confidence in data["keypoints_original"][index].tolist():
            xx, yy = (x - crop[0]) * scale, (y - crop[1]) * scale
            draw.line((xx-5, yy-5, xx+5, yy+5), fill="#ff62e7", width=2)
            draw.line((xx-5, yy+5, xx+5, yy-5), fill="#ff62e7", width=2)
        panel = Image.new("RGB", (max(1300, plain.width * 2 + 36), plain.height + 85), "#10161e")
        pd = ImageDraw.Draw(panel)
        pd.text((12, 8), title, font=font, fill="white")
        pd.text((12, 36), "Original pixels", font=small, fill="#d2dce9")
        pd.text((plain.width+24, 36), "Green: fixed reference | Magenta: raw proposal (crosses are predictions)", font=small, fill="#d2dce9")
        panel.paste(plain, (12, 65)); panel.paste(overlay, (plain.width+24, 65))
        panels.append(panel)
        figure_provenance.append({"image_id": image_id, "image_sha256": sha(image_path),
                                  "crop_xyxy": crop, "display_scale": scale,
                                  "resampling": "nearest", "raw_index_zero_based": index,
                                  "reference_row_one_based": row})
    figure = Image.new("RGB", (max(p.width for p in panels), sum(p.height for p in panels) + 48), "#10161e")
    y = 0
    for panel in panels:
        figure.paste(panel, (0, y)); y += panel.height
    fd = ImageDraw.Draw(figure)
    fd.text((12, y+8), "Original-image geometry only. Predicted hidden-side crosses do not certify visible or usable corners.", font=small, fill="#d2dce9")
    figure.save(a.output / "raw-proposal-review.png")
    write(a.output / "raw-proposal-review.provenance.json", {"cases": figure_provenance,
          "source_script_sha256": sha(__file__), "figure_sha256": sha(a.output / "raw-proposal-review.png")})
    write(a.output / "inventory.json", {p.name: {"sha256": sha(p), "size_bytes": p.stat().st_size}
          for p in sorted(a.output.iterdir()) if p.is_file()})
    print(json.dumps({k: result[k] for k in ("inspected_candidate_retained", "target_match_after_full_image_one_to_one_scoring", "final_prediction_count_before", "final_prediction_count_after", "added_raw_indices", "removed_raw_indices")}, indent=2))


if __name__ == "__main__":
    main()
