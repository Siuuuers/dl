# Current-model raw proposal trace

The two selected residual targets have different immediate failure mechanisms. At the fixed confidence 0.15, neither has a geometrically qualifying proposal available to NMS. This supports keeping NMS 0.70 unchanged for this bounded problem.

| Fixed target | Raw boxes with reference IoU >= 0.50 | Strongest qualifying box score | Maximum raw reference IoU | Observation |
| --- | ---: | ---: | ---: | --- |
| `new_000008:33` | 21 | 0.133154839 | 0.656487394 | Qualifying box geometries exist, but all fail the 0.15 confidence gate. |
| `new_000009:57` | 0 | None | 0.490461924 | No decoded raw box meets the fixed matching criterion; the closest has score 0.001025405. |

The strongest qualifying box for `008:33` has IoU 0.605158784. Its score is 0.133154839; it is not the maximum-IoU box. The strongest proposal that overlaps `009:57` at all has score 0.025030576 and IoU 0.183195645.

These statements concern box geometry against the unchanged reference. They do not establish that a raw proposal represents the physical cassette or that the current 0.15 threshold is globally optimal. The 0.49046 result must not be described as an absence of nearby geometry. The initial trace made no threshold or NMS counterfactual; the separately recorded follow-up below tests one post-hoc threshold on one case.

## Execution and evidence

The run used the current PR35 candidate with SHA-256 `420c00f73eeba24e587342400878b7d96371d3e745772113809aa705ec8163b1` from clean source revision `c064b564f79a41578f07084b185946d33fe05024`. The external script's executed SHA-256 is `20374ad6c55243b204212333b3a56f98bc8a8bafadb46eddd5aa56205ef66448`.

Two original-image predictions and one excluded blank warmup completed with exit code 0. Each image yielded a decoded pre-confidence/NMS tensor of shape `1 x 11 x 19320` from a `1 x 3 x 736 x 1280` input. The normal letterbox has eight pixels of vertical padding on each side. Ordinary NMS, FP32 CPU inference, four PyTorch threads, imgsz 1280 and all existing settings were preserved. Network access was blocked; no network attempt was recorded.

All ordered final box, confidence, class and keypoint values exactly match the archived current-model predictions, with no tolerance: 40 detections for `008`, 74 for `009`. Replaying the unchanged NMS on the captured tensors reproduces the boxes and keypoints exactly and preserves the raw candidate indices. PyTorch inter-op threads were 9 in this trace versus 1 in the original archived run; the complete runtime record preserves that difference, while exact output equality establishes comparability for these two images.

`run-001/trace-summary.json` records the full diagnosis, original/reference identities, runtime and installed source hashes. The two NPZ files preserve every decoded proposal, original-coordinate boxes/keypoints, target IoUs and retained candidate indices. Input-coordinate boxes can be reconstructed from the preserved raw tensor; representative proposals record both input and original coordinates. IoUs used to diagnose reference matching are computed after the same scaling and clipping as the ordinary final outputs. Suppression diagnostics use unclipped model-input coordinates, because clipping can change overlap.

`run-001/inventory.json` hashes all five run payloads. Readback verifies all five sizes/hashes and the executed script hash. The two NPZ files total 2,816,775 bytes. The trace changes no trained model, inference default, label or frozen evaluation.

## Reproduce

Use the pinned existing inference environment with Ultralytics 8.4.182, PyTorch 2.10.0+cpu and torchvision 0.25.0+cpu. Hydrate the original two PNGs and verify/extract the complete PR35 candidate bundle. Obtain `predictions-current.jsonl` from the completed PR40 evaluation evidence capsule; its required hash is enforced in the script.

```bash
python -B trace_raw_proposals.py \
  --root /path/to/dl-at-c064b56 \
  --current-manifest /path/to/pr35/candidate/checkpoint-manifest.json \
  --archived-predictions /path/to/partial-front-evidence/run/predictions-current.jsonl \
  --output /path/to/new-trace-output
```

The new output path must not already exist and must be outside the source checkout. The script requires clean committed source, verifies the checkpoint/reference/archive identities, writes its fixed protocol before inference, and aborts if final outputs do not exactly match the archived baseline.

## One post-hoc filter counterfactual

After the trace, `replay_013_diagnostic.py` tests confidence **0.13 on image 008 only**, using the saved raw tensor and unchanged NMS IoU 0.70 and max detections 300. This performs zero model loads and zero fresh image predictions. It is an exploratory single-case diagnostic, not a predeclared primary result or a dataset-wide threshold recommendation.

The score-0.133154839 proposal at raw index 17038 survives NMS and is matched one-to-one to reference row 33 with IoU 0.605158784. The image gains two outputs, 40 to 42, without removing any prior retained raw index. The other addition is raw index 19064 at score 0.141025856. Full-image counts at 0.13 are 35 matches, one miss and seven extras against 36 reference objects. See `counterfactual-013/counterfactual-013.json` for complete output identities and geometry.

Original-pixel inspection of `counterfactual-013/raw-proposal-review.png` supports association with the intended right-clipped front. The box also extends about 20 px below its reference into the next-front region. Its left endpoint is about 6.93 px from the visible reference point, and its right endpoint has confidence 0.835 at the clipped image edge despite that reference side being unlocatable. Thus the result supplies a reviewable detection proposal, not a precise box or a usable pair of physical corners. The figure also shows the nearest raw geometry for `009:57`, which remains below the fixed IoU criterion and has very low confidence.

Any threshold decision still needs a separately declared whole-set comparison that measures recovered matches and added review burden on the same frozen reference. Operational settings remain unchanged.
