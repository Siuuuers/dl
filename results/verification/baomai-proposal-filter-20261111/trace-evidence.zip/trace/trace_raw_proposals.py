#!/usr/bin/env python3
"""Trace two preselected misses without changing the prediction pipeline."""

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import inspect
import json
import os
from pathlib import Path
import sys
import time

sys.dont_write_bytecode = True
TARGETS = {"new_000008": 33, "new_000009": 57}
MODEL_SHA256 = "420c00f73eeba24e587342400878b7d96371d3e745772113809aa705ec8163b1"
REFERENCE_SHA256 = "2e60b3e81195448cc565a1000b4305e3215baba2bf0ee0c976e6551c2e64937c"
ARCHIVE_SHA256 = "e08f5dee7f4f08377f97982acb362fe6f7d97066e6b9b4de623d9c598366b465"


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--current-manifest", type=Path, required=True)
    parser.add_argument("--archived-predictions", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root, output = args.root.resolve(), args.output.resolve()
    require(not output.is_relative_to(root), "Output must be outside source")
    output.mkdir(parents=True, exist_ok=False)
    os.environ.update(YOLO_CONFIG_DIR=str(output / "runtime-config"),
                      YOLO_OFFLINE="true", YOLO_AUTOINSTALL="false")
    network_attempts = []

    def offline(event, payload):
        if event in {"socket.connect", "socket.getaddrinfo", "socket.sendto"}:
            network_attempts.append(event)
            raise PermissionError(f"Offline trace forbids {event}")

    sys.addaudithook(offline)
    sys.path.insert(0, str(root / "scripts"))
    from evaluate_pose import (INFERENCE, _prediction_records, _runtime_and_model,
                               _source_identity, parse_pose_labels, preflight_dataset)
    from pose_checkpoint import select_checkpoint
    from pose_scoring import _box_iou
    import numpy as np
    import torch
    from ultralytics.models.yolo.pose.predict import PosePredictor
    from ultralytics.utils import nms, ops

    source = _source_identity(root)
    require(source["working_tree_status"] == "", "Trace requires unchanged committed source")
    ref_path = root / "data/references/visible-front-2026-11-11/manifest.json"
    require(sha(ref_path) == REFERENCE_SHA256, "Reference identity differs")
    require(sha(args.archived_predictions) == ARCHIVE_SHA256, "Archive identity differs")
    ref = json.loads(ref_path.read_text())
    ref_files = {item["image_id"]: item for item in ref["files"]}
    archived_lines = [json.loads(line) for line in args.archived_predictions.read_text().splitlines()]
    archive_header = archived_lines[0]
    archived = {item["image_id"]: item for item in archived_lines[1:]
                if item["threshold"] == .15 and item["image_id"] in TARGETS}
    require(set(archived) == set(TARGETS), "Archived focus images differ")
    preflight = select_checkpoint(preflight_dataset(root, list(TARGETS), require_weights=False),
                                  args.current_manifest.resolve(), require_weights=True)
    require(preflight["model_sha256"] == MODEL_SHA256, "Current model identity differs")

    class CapturePosePredictor(PosePredictor):
        capture = False

        def postprocess(self, preds, img, orig_imgs, **kwargs):
            if self.capture:
                raw = preds[0] if isinstance(preds, (list, tuple)) else preds
                self.raw_capture = raw.detach().cpu().clone()
                self.input_shape_capture = list(img.shape)
            return super().postprocess(preds, img, orig_imgs, **kwargs)

    protocol = {
        "schema_version": 1,
        "purpose": "Diagnose fixed current-model misses at the decoded pre-confidence/NMS boundary",
        "targets": TARGETS, "model_sha256": MODEL_SHA256,
        "reference_sha256": REFERENCE_SHA256,
        "confidence": .15, "nms_iou": .70, "matching_iou": .50,
        "endpoint_cutoff": .50, "inference": INFERENCE,
        "fresh_image_predictions_planned": 2, "warmups_planned": 1,
        "constraints": ["No training", "No threshold search", "No reference edit", "No model promotion"],
        "classification": "For fixed reference geometry: count raw IoU>=.50 boxes; inspect their scores and retained NMS indices. Baseline output must exactly equal archived predictions.",
        "source": source, "script_sha256": sha(__file__),
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "command": [sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]],
    }
    write(output / "protocol.json", protocol)
    model, runtime = _runtime_and_model(preflight, "cpu", 4)
    started = time.perf_counter()
    model.predict(source=np.zeros((720, 1280, 3), dtype=np.uint8), device="cpu",
                  conf=.15, predictor=CapturePosePredictor, **INFERENCE)
    warmup_seconds = time.perf_counter() - started
    torch.set_num_threads(4)
    backend = model.predictor.model
    require(not backend.end2end and not backend.fp16 and str(backend.device) == "cpu",
            "Ordinary NMS/FP32/CPU contract differs")
    require(isinstance(model.predictor, CapturePosePredictor), "Capture predictor not installed")
    require(not model.predictor.args.augment, "Augmentation differs")
    model.predictor.capture = True
    runtime.update(device_actual=str(backend.device), backend_end2end=bool(backend.end2end),
                   backend_fp16=bool(backend.fp16), torch_threads=torch.get_num_threads(),
                   torch_interop_threads=torch.get_num_interop_threads(),
                   mkldnn_enabled=torch.backends.mkldnn.enabled,
                   deterministic_algorithms_enabled=torch.are_deterministic_algorithms_enabled(),
                   float32_matmul_precision=torch.get_float32_matmul_precision(),
                   resolved_prediction_args_after_warmup={key: getattr(model.predictor.args, key) for key in
                       ("imgsz", "conf", "iou", "rect", "batch", "nms", "max_det", "quantize", "augment")})
    runtime_files = {}
    for module in ("ultralytics.nn.tasks", "ultralytics.nn.modules.head", "ultralytics.nn.autobackend",
                   "ultralytics.engine.predictor", "ultralytics.engine.results",
                   "ultralytics.models.yolo.detect.predict", "ultralytics.models.yolo.pose.predict",
                   "ultralytics.utils.nms", "ultralytics.utils.ops"):
        imported = __import__(module, fromlist=["__file__"])
        runtime_files[module] = {"path": imported.__file__, "sha256": sha(imported.__file__)}
    rows, saved_predictions = [], []
    for record in preflight["records"]:
        image_id = record["id"]
        started = time.perf_counter()
        result = model.predict(source=record["image_path"], device="cpu", conf=.15, **INFERENCE)[0]
        elapsed_seconds = time.perf_counter() - started
        predictions = _prediction_records(result)
        require(predictions == archived[image_id]["predictions"], f"Archived output differs for {image_id}")
        require(record["image_sha256"] == archived[image_id]["image_sha256"], "Archived image identity differs")
        raw = model.predictor.raw_capture
        input_shape = model.predictor.input_shape_capture
        require(raw.ndim == 3 and raw.shape[0] == 1 and raw.shape[1] == 11, "Unexpected decoded raw shape")
        require(torch.isfinite(raw).all().item(), "Nonfinite raw proposal values")
        require(tuple(result.orig_shape) == (720, 1280), "Original shape differs")
        nms_result, nms_indices = nms.non_max_suppression(raw.clone(), .15, .70,
            classes=model.predictor.args.classes, agnostic=model.predictor.args.agnostic_nms,
            max_det=300, nc=1, end2end=False, rotated=False, return_idxs=True)
        retained = nms_indices[0].tolist()
        replay = nms_result[0].clone()
        ops.scale_boxes(input_shape[2:], replay[:, :4], result.orig_shape)
        replay_kpts = replay[:, 6:].view(-1, 2, 3)
        ops.scale_coords(input_shape[2:], replay_kpts, result.orig_shape)
        require(torch.equal(replay[:, :6], result.boxes.data.cpu()), "NMS box replay differs")
        require(torch.equal(replay_kpts, result.keypoints.data.cpu()), "NMS keypoint replay differs")
        decoded = raw[0].transpose(0, 1)
        boxes_input = ops.xywh2xyxy(decoded[:, :4]).clone()
        boxes_original = ops.scale_boxes(input_shape[2:], boxes_input.clone(), result.orig_shape)
        keypoints_original = ops.scale_coords(input_shape[2:], decoded[:, 5:].clone().view(-1, 2, 3), result.orig_shape)
        labels = ref_path.parent / ref_files[image_id]["label_path"]
        require(sha(labels) == ref_files[image_id]["label_sha256"], "Reference label hash differs")
        gold = parse_pose_labels(labels.read_text(), 1280, 720, str(labels))
        target = gold[TARGETS[image_id] - 1]
        ious = np.asarray([_box_iou(target["bbox_xyxy"], box) for box in boxes_original.tolist()])
        confidence = decoded[:, 4].numpy()
        geometry_indices = np.flatnonzero(ious >= .50).tolist()
        eligible_indices = np.flatnonzero(confidence > .15).tolist()
        eligible_geometry = [i for i in geometry_indices if confidence[i] > .15]
        retained_set = set(retained)
        kept_geometry = [i for i in geometry_indices if i in retained_set]

        def proposal(index):
            if index is None:
                return None
            return {"raw_index_zero_based": int(index), "iou_with_target": float(ious[index]),
                    "confidence": float(confidence[index]),
                    "bbox_xyxy_original": boxes_original[index].tolist(),
                    "bbox_xyxy_model_input": boxes_input[index].tolist(),
                    "keypoints_original": keypoints_original[index].tolist(),
                    "passes_confidence": bool(confidence[index] > .15),
                    "retained_by_fixed_nms": index in retained_set}

        highest_iou = int(np.argmax(ious))
        highest_geometry_score = max(geometry_indices, key=lambda i: float(confidence[i]), default=None)
        overlapping = np.flatnonzero(ious > 0).tolist()
        highest_overlap_score = max(overlapping, key=lambda i: float(confidence[i]), default=None)
        above_threshold = max(eligible_indices, key=lambda i: float(ious[i]), default=None)
        suppressions = []
        for index in eligible_geometry:
            if index in retained_set:
                continue
            suppressors = [{"raw_index_zero_based": int(i),
                            "iou_with_removed_box_in_model_input": _box_iou(boxes_input[index].tolist(), boxes_input[i].tolist()),
                            "confidence": float(confidence[i])}
                           for i in retained if confidence[i] >= confidence[index]
                           and _box_iou(boxes_input[index].tolist(), boxes_input[i].tolist()) > .70]
            suppressions.append({"proposal": proposal(index), "retained_possible_suppressors_in_order": suppressors})
        if not geometry_indices:
            classification = "no_decoded_raw_box_reaches_reference_iou_0.50"
        elif not eligible_geometry:
            classification = "all_geometrically_qualifying_raw_boxes_fail_confidence_0.15"
        elif not kept_geometry:
            classification = "qualifying_confident_proposals_removed_by_postprocessing"
        else:
            classification = "qualifying_proposal_retained_requires_matching_identity_review"
        npz = output / f"{image_id}-raw.npz"
        np.savez_compressed(npz, decoded_pre_nms_bcn=raw.numpy(),
                            input_shape=np.asarray(input_shape),
                            boxes_xyxy_original=boxes_original.numpy(),
                            keypoints_original=keypoints_original.numpy(),
                            target_iou_original=ious,
                            retained_raw_indices=np.asarray(retained, dtype=np.int64))
        row = {
            "image_id": image_id, "reference_row_one_based": TARGETS[image_id],
            "image_sha256": record["image_sha256"], "reference_label_sha256": sha(labels),
            "target_reference": target, "input_tensor_shape": input_shape,
            "decoded_pre_nms_shape": list(raw.shape),
            "raw_proposal_count": int(raw.shape[-1]), "raw_iou_ge_0_50_count": len(geometry_indices),
            "raw_confidence_gt_0_15_count": len(eligible_indices),
            "raw_iou_ge_0_50_and_confidence_gt_0_15_count": len(eligible_geometry),
            "retained_raw_iou_ge_0_50_count": len(kept_geometry),
            "final_prediction_count": len(predictions),
            "final_predictions_exactly_equal_archived": True,
            "same_nms_replay_exactly_matches_boxes_and_keypoints": True,
            "classification": classification,
            "maximum_iou_proposal": proposal(highest_iou),
            "maximum_confidence_geometrically_qualifying_proposal": proposal(highest_geometry_score),
            "maximum_confidence_overlapping_proposal": proposal(highest_overlap_score),
            "maximum_iou_above_confidence_gate": proposal(above_threshold),
            "eligible_geometry_suppression_diagnostics": suppressions,
            "all_geometrically_qualifying_raw_proposals": [proposal(i) for i in geometry_indices],
            "raw_archive": {"path": npz.name, "sha256": sha(npz), "size_bytes": npz.stat().st_size},
            "prediction_wall_seconds": elapsed_seconds,
        }
        rows.append(row)
        saved_predictions.append({"image_id": image_id, "predictions": predictions})
        print(json.dumps({key: row[key] for key in ("image_id", "classification", "raw_proposal_count", "raw_iou_ge_0_50_count", "final_prediction_count")}), flush=True)
    report = {
        "schema_version": 1, "status": "complete", "protocol_sha256": sha(output / "protocol.json"),
        "source": source, "script_sha256": sha(__file__),
        "current_manifest_sha256": sha(args.current_manifest), "checkpoint_sha256": MODEL_SHA256,
        "archive_predictions_sha256": ARCHIVE_SHA256, "reference_manifest_sha256": REFERENCE_SHA256,
        "runtime": runtime, "runtime_source_files": runtime_files,
        "fresh_image_prediction_calls": 2, "warmup_calls_excluded": 1,
        "warmup_seconds_excluded": warmup_seconds, "network_attempts": network_attempts,
        "scope": "Two already selected development cases only, current checkpoint only, fixed settings.",
        "caveats": [
            "Decoded dense proposals are candidate box geometries, not independently verified physical cassette identities.",
            "IoU is computed after the same scaling and clipping used for final predictions against the unchanged reference.",
            "No assertion of unseen-scene accuracy, global optimal threshold, physical grasp accuracy or learned improvement follows.",
            "No counterfactual threshold or NMS trial is performed. Geometry below threshold does not prove it would survive NMS or match uniquely.",
        ],
        "targets": rows,
    }
    write(output / "trace-summary.json", report)
    write(output / "current-final-predictions.json", saved_predictions)
    inventory = {path.name: {"sha256": sha(path), "size_bytes": path.stat().st_size}
                 for path in sorted(output.iterdir()) if path.is_file()}
    write(output / "inventory.json", inventory)


if __name__ == "__main__":
    main()
