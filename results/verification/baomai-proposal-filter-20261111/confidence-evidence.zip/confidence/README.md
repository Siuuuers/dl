# Fixed confidence 0.13 comparison

The current PR35 seed46 checkpoint recovers **one additional reference cassette** at confidence 0.13 versus 0.15, while producing **nine additional scored extras** across the same twenty development images. This is a proposal-collection tradeoff. It does not measure a training improvement or establish unseen-scene reliability.

The protocol was written before this full-set run. Its hypothesis came from the earlier inspected `008:33` raw-proposal trace, so this is explicitly a targeted follow-up on reused development data. There is no further threshold search in this study.

## Corrected 663-object reference

| Measure | Confidence 0.15 | Confidence 0.13 |
| --- | ---: | ---: |
| Total output proposals | 718 | 728 |
| Matched reference objects | 642 | 643 |
| Missed reference objects | 21 | 20 |
| Scored extras | 76 | 85 |
| Duplicate / other extras | 28 / 48 | 31 / 54 |
| Returned visible endpoints / 1,228 | 1,207 | 1,208 |
| Both corners within 5 px / 584 | 529 | 529 |
| Both corners within 10 px / 584 | 577 | 577 |
| Returned points on unlocatable sides | 69 | 69 |
| Unlocatable sides among matched objects | 76 | 77 |
| Miss-free nonempty scenes / 17 | 3 | 3 |
| Detections on three empty scenes | 0 | 0 |

`new_000008:33` is the sole gained match. No existing match is lost, and all prior retained high-confidence predictions are exactly unchanged. The one-corner group gains that match; the zero- and two-corner groups are unchanged. All fixed numerical acceptance checks pass. The protocol's physical-support and review-workload gate still requires the original-image review of the exported queue; the script does not promote a threshold automatically.

Ten proposals are added across six images: one new reference match, three duplicate extras and six other extras. This is **ten additional proposals to inspect for one additional matched cassette**, including nine scored extras. The workflow burden is counted in proposals; review time was not measured. No extra is silently relabeled or removed from the comparison.

The conditional median corner error changes 1.563011→1.563073 px and p95 changes 5.120129→5.130618 px as the recovered visible endpoint enters the distribution. These small conditional changes accompany the same 5/10 px two-corner success counts; a physical tolerance has not been established.

## What the recovered proposal means

The new `008:33` proposal has score 0.133154839 and fixed-reference IoU 0.605158784. Earlier original-pixel review supports its association with the intended right-clipped front. Its box extends about 20 px below the reference into the next-front region. Its visible left endpoint is 6.932759 px from the reference point. The predicted right endpoint has confidence 0.834875 at x=1280 even though the corresponding reference side is unlocatable; the scorer's strict in-image criterion excludes this boundary coordinate from returned endpoint counts. Thus an additional reviewable object proposal is gained, without certifying a precise boundary or a usable pair of physical corners.

`009:57` remains missed. The earlier raw trace found no decoded box meeting the fixed IoU 0.50 criterion for that reference; the nearest geometry was IoU 0.490462 with very low score. This confidence change does not solve that remaining supported fragment.

## Original 664-object reference stays separate

The original-reference scores are retained in `scoring-original.json` and the summary. At confidence 0.15 the current model has 33 misses and 87 extras; at 0.13 it has 32 misses and 96 extras. Only the corresponding original-reference `008:33` object is gained. These counts must not be mixed with the corrected 663-object reference or the earlier PR30 661-object snapshot.

## Evidence and reproduction

The checkpoint remains SHA-256 `420c00f73eeba24e587342400878b7d96371d3e745772113809aa705ec8163b1`. The run used clean source `c064b564f79a41578f07084b185946d33fe05024`, CPU FP32, Ultralytics 8.4.182, PyTorch 2.10.0+cpu, four intra-op threads and one inter-op thread. Image size 1280, rectangular preprocessing, NMS IoU 0.70, endpoint cutoff 0.50, matching IoU 0.50 and max detections 300 were fixed.

- `protocol.json` was written at 11:34:13 UTC, before the fresh run began at 11:34:14 UTC on 2026-11-11.
- `run_evaluation.py` calls the unchanged `scripts/evaluate_pose.py`; `execution.json` records the exact command, clean source, launcher/protocol hashes, runtime settings, exit code 0 and zero network attempts.
- The run performed 40 original-image predictions and one excluded blank warmup. No training occurred.
- All twenty fresh 0.15 ordered prediction arrays exactly equal the archived current-model arrays. Both full original/corrected-reference 0.15 scoring records exactly reproduce the archived results, including aggregates and per-image detail.
- `compare_confidences.py` uses the existing comparison helper and unchanged matching/quality scorers. It records all object changes, 0/1/2-corner groups, pair counts, unavailable-side outputs, scenes and per-image workload.
- `added-proposals.json` exports every new proposal with exact image/prediction identities, scores, coordinates and fixed-reference scoring associations. All entries initially retain `pending_original_image_review`; later reviewer decisions should be preserved separately.
- `render_review.py` creates all ten original-image sheets in `visual-review/`. Each contains full-scene context, original pixels and exact box overlays; nearest-neighbor enlargement preserves the original evidence. `visual-review/provenance.json` records source/figure hashes, crops and scale.

With the verified PR35 bundle extracted, run the existing pinned environment:

```bash
python -B run_evaluation.py \
  --root /path/to/dl-at-c064b56 \
  --checkpoint-manifest /path/to/pr35/candidate/checkpoint-manifest.json \
  --device cpu --threads 4 --conf 0.15 0.13 \
  --endpoint-conf 0.50 --matching-iou 0.50 --overlays 0 \
  --output /path/to/study/run-001
```

Copy the fixed `protocol.json` to `/path/to/study/` before executing. The output directory must be new. Afterward, replay both frozen references without model loading:

```bash
python -B compare_confidences.py \
  --root /path/to/dl-at-c064b56 \
  --study /path/to/study \
  --archive /path/to/partial-front-evidence/run

python -B render_review.py \
  --root /path/to/dl-at-c064b56 \
  --study /path/to/study
```

The archive argument is the extracted completed PR40 evaluation capsule containing the current-model baseline predictions and frozen reference-review notes. The comparison verifies the relevant archived file hashes. `verification.json` records the final payload readback. No model weights, annotations, generic runtime defaults or live inference settings were changed by this study.
