#!/usr/bin/env python3
"""Run the existing evaluator with fixed historical CPU thread settings."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import time

sys.dont_write_bytecode = True
root = Path(sys.argv[sys.argv.index("--root") + 1]).resolve()
output = Path(sys.argv[sys.argv.index("--output") + 1]).resolve()
os.environ.update(YOLO_CONFIG_DIR=str(output.parent / "runtime-config"),
                  YOLO_OFFLINE="true", YOLO_AUTOINSTALL="false")
attempts = []


def offline(event, arguments):
    if event in {"socket.connect", "socket.getaddrinfo", "socket.sendto"}:
        attempts.append(event)
        raise PermissionError(f"Offline evaluation forbids {event}")


sys.addaudithook(offline)
sys.path.insert(0, str(root / "scripts"))
import torch
import evaluate_pose

torch.set_num_interop_threads(1)
source = evaluate_pose._source_identity(root)
if source["working_tree_status"] != "":
    raise RuntimeError("Expected clean source")
record = {"command": [sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]],
          "source": source, "launcher_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          "protocol_sha256": hashlib.sha256((output.parent / "protocol.json").read_bytes()).hexdigest(),
          "started_at_utc": datetime.now(timezone.utc).isoformat(), "status": "running"}
execution_path = output.parent / "execution.json"
execution_path.write_text(json.dumps(record, indent=2) + "\n")
start = time.perf_counter()
code = evaluate_pose.main()
record.update(status="complete" if code == 0 else "failed", exit_code=code,
              finished_at_utc=datetime.now(timezone.utc).isoformat(),
              elapsed_seconds=time.perf_counter() - start,
              torch_threads=torch.get_num_threads(), torch_interop_threads=torch.get_num_interop_threads(),
              mkldnn_enabled=torch.backends.mkldnn.enabled,
              deterministic_algorithms_enabled=torch.are_deterministic_algorithms_enabled(),
              float32_matmul_precision=torch.get_float32_matmul_precision(), network_attempts=attempts)
execution_path.write_text(json.dumps(record, indent=2) + "\n")
raise SystemExit(code)
