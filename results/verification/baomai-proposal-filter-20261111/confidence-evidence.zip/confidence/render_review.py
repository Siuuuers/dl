#!/usr/bin/env python3
"""Render exact original-pixel crops for every added proposal; no inference."""

import argparse
import hashlib
import json
from pathlib import Path
import sys


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, required=True)
    p.add_argument("--study", type=Path, required=True)
    a = p.parse_args()
    sys.path.insert(0, str(a.root / "scripts"))
    from evaluate_pose import parse_pose_labels
    from PIL import Image, ImageDraw, ImageFont
    additions = json.loads((a.study / "added-proposals.json").read_text())
    predictions = [json.loads(line) for line in (a.study / "run-001/predictions.jsonl").read_text().splitlines()]
    old = {r["image_id"]: r["predictions"] for r in predictions[1:] if r["threshold"] == .15}
    output = a.study / "visual-review"
    output.mkdir(exist_ok=False)
    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 18)
    small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 15)
    records = []
    for addition in additions:
        image_id = addition["image_id"]
        index = addition["prediction_index_zero_based_at_013"]
        image_path = a.root / "data/images/val" / f"{image_id}.png"
        assert sha(image_path) == addition["original_image_sha256"]
        original = Image.open(image_path).convert("RGB")
        box = addition["prediction"]["bbox_xyxy"]
        cx, cy = (box[0] + box[2]) / 2, (box[1] + box[3]) / 2
        w, h = max(200, box[2] - box[0] + 100), max(150, box[3] - box[1] + 100)
        crop = [max(0, int(cx-w/2)), max(0, int(cy-h/2)), min(1280, int(cx+w/2+1)), min(720, int(cy+h/2+1))]
        area = original.crop(crop)
        scale = max(1, min(3, 660 // area.width))
        plain = area.resize((area.width*scale, area.height*scale), Image.Resampling.NEAREST)
        overlay = plain.copy()
        d = ImageDraw.Draw(overlay)

        def transformed(b):
            return ((b[0]-crop[0])*scale, (b[1]-crop[1])*scale,
                    (b[2]-crop[0])*scale, (b[3]-crop[1])*scale)

        def overlaps(b):
            return b[0]<crop[2] and b[1]<crop[3] and b[2]>crop[0] and b[3]>crop[1]

        label_path = a.root / "data/references/visible-front-2026-11-11/labels/val" / f"{image_id}.txt"
        gold = parse_pose_labels(label_path.read_text(), 1280, 720)
        for i,g in enumerate(gold):
            if overlaps(g["bbox_xyxy"]):
                bb = transformed(g["bbox_xyxy"])
                d.rectangle(bb, outline="#45e28b", width=1)
                d.text((max(0,bb[0]+2), max(0,bb[1]+2)), str(i+1), font=small, fill="#45e28b")
        for pred in old[image_id]:
            if overlaps(pred["bbox_xyxy"]):
                d.rectangle(transformed(pred["bbox_xyxy"]), outline="#ffdf65", width=2)
        d.rectangle(transformed(box), outline="#ff42d3", width=3)
        for x,y,conf in addition["prediction"]["keypoints"]:
            xx,yy = (x-crop[0])*scale,(y-crop[1])*scale
            d.line((xx-5,yy-5,xx+5,yy+5),fill="#ff42d3",width=2)
            d.line((xx-5,yy+5,xx+5,yy-5),fill="#ff42d3",width=2)
        thumb = original.resize((640,360),Image.Resampling.NEAREST)
        td=ImageDraw.Draw(thumb)
        td.rectangle(tuple(v/2 for v in crop),outline="#ff42d3",width=2)
        width=max(1280,plain.width*2+36)
        canvas=Image.new("RGB",(width,440+plain.height),"#10161e")
        cd=ImageDraw.Draw(canvas)
        title=f"{image_id} / added prediction {index} / score {addition['prediction']['confidence']:.6f} / {addition['scored_disposition']}"
        cd.text((12,8),title,font=font,fill="white")
        canvas.paste(thumb,(12,40))
        cd.text((680,60),"Full-scene context above; crop below",font=small,fill="#d2dce9")
        cd.text((680,90),"Green: fixed references (one-based row)",font=small,fill="#45e28b")
        cd.text((680,120),"Yellow: retained 0.15 boxes",font=small,fill="#ffdf65")
        cd.text((680,150),"Magenta: added 0.13 proposal",font=small,fill="#ff42d3")
        cd.text((680,185),"All crosses are predicted coordinates.",font=small,fill="#d2dce9")
        cd.text((680,210),"They do not certify hidden corners.",font=small,fill="#d2dce9")
        cd.text((12,410),"Original pixels",font=small,fill="#d2dce9")
        cd.text((plain.width+24,410),"Reference / retained / added boxes",font=small,fill="#d2dce9")
        canvas.paste(plain,(12,440)); canvas.paste(overlay,(plain.width+24,440))
        path=output/f"{image_id}-prediction-{index:02d}.png"
        canvas.save(path)
        records.append({"image_id":image_id,"added_prediction_index_zero_based":index,
                        "source_image_sha256":sha(image_path),"reference_label_sha256":sha(label_path),
                        "crop_xyxy":crop,"crop_scale":scale,"resampling":"nearest",
                        "figure_path":path.name,"figure_sha256":sha(path),"size_bytes":path.stat().st_size})
    (output/"provenance.json").write_text(json.dumps({"renderer_sha256":sha(__file__),"figures":records},indent=2)+"\n")
    print(f"Rendered {len(records)} original-image review sheets without inference.")


if __name__=="__main__":
    main()
