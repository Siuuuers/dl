#!/usr/bin/env python3
"""Replay the two fixed confidence outputs on both frozen references."""

import argparse
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, required=True)
    p.add_argument("--study", type=Path, required=True)
    p.add_argument("--archive", type=Path, required=True)
    a = p.parse_args()
    root, study, archive = a.root.resolve(), a.study.resolve(), a.archive.resolve()
    sys.path.insert(0, str(root / "scripts"))
    from evaluate_pose import parse_pose_labels, preflight_dataset
    from pose_scoring import _box_iou, _percentile, aggregate_scores, score_image
    from diagnose_pose_quality import _returned, aggregate_quality, quality_for_image
    helper = root / "results/verification/baomai-partial-fronts-results-20261111/evaluate_comparison.py"
    spec = importlib.util.spec_from_file_location("existing_comparison", helper)
    existing = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(existing)
    assert sha(helper) == "8fdbd6cd37ee5ef40f6e5a6e8d844c37c1bc5e5be1e8895c39cbe0b2a9667814"
    protocol = read(study / "protocol.json")
    execution = read(study / "execution.json")
    assert execution["status"] == "complete" and execution["exit_code"] == 0
    assert sha(study / "protocol.json") == execution["protocol_sha256"]
    assert protocol["thresholds_in_order"] == [.15, .13]
    lines = [json.loads(line) for line in (study / "run-001/predictions.jsonl").read_text().splitlines()]
    header, items = lines[0], lines[1:]
    assert header["model_sha256"] == protocol["model_sha256"]
    assert header["box_confidences"] == [.15, .13] and len(items) == 40
    old_path = archive / "predictions-current.jsonl"
    assert sha(old_path) == "e08f5dee7f4f08377f97982acb362fe6f7d97066e6b9b4de623d9c598366b465"
    archived_lines = [json.loads(line) for line in old_path.read_text().splitlines()]
    archived = {row["image_id"]: row for row in archived_lines[1:] if row["threshold"] == .15}
    by_threshold = {conf: {row["image_id"]: row for row in items if row["threshold"] == conf}
                    for conf in (.15, .13)}
    assert all(len(rows) == 20 and set(rows) == set(archived) for rows in by_threshold.values())
    for image_id, baseline in by_threshold[.15].items():
        assert baseline["predictions"] == archived[image_id]["predictions"], image_id
        assert baseline["image_sha256"] == archived[image_id]["image_sha256"], image_id
        lower = by_threshold[.13][image_id]["predictions"]
        assert [p for p in lower if p["confidence"] > .15] == baseline["predictions"], image_id
    original = preflight_dataset(root, require_weights=False)["records"]
    ref_path = root / "data/references/visible-front-2026-11-11/manifest.json"
    assert sha(ref_path) == protocol["corrected_reference_sha256"]
    ref = read(ref_path)
    ref_files = {row["image_id"]: row for row in ref["files"]}
    primary = []
    for source in original:
        entry = ref_files[source["id"]]
        label = ref_path.parent / entry["label_path"]
        assert sha(label) == entry["label_sha256"]
        assert source["image_sha256"] == entry["image_sha256"]
        primary.append({**source, "label_path": str(label), "label_sha256": sha(label),
                        "gold": parse_pose_labels(label.read_text(), 1280, 720, str(label))})
    assert sum(len(r["gold"]) for r in primary) == 663
    assert sum(len(r["gold"]) for r in original) == 664
    notes_path = archive / "reference-review-notes.json"
    assert sha(notes_path) == "ae9ec727285f1d782ad62af2b71d005bf1b64b8ff45d7dfe0bce5ec6246c41a3"
    notes = read(notes_path)
    api = {"iou": _box_iou, "percentile": _percentile, "score": score_image,
           "aggregate": aggregate_scores, "returned": _returned,
           "quality": quality_for_image, "aggregate_quality": aggregate_quality}
    scored, comparison = {}, {}
    for name, records in (("primary", primary), ("original", original)):
        scored[name] = {str(conf): existing.score_records(records, list(by_threshold[conf].values()), api, name == "primary")
                        for conf in (.15, .13)}
        previous = read(archive / f"scoring-current-{name}.json")["0.15"]
        assert scored[name]["0.15"] == previous, name
        comparison[name] = existing.compare_reports(scored[name]["0.15"], scored[name]["0.13"], notes if name == "primary" else {})
        write(study / f"scoring-{name}.json", scored[name])
    additions, workload = [], []
    primary_by_id = {record["id"]: record for record in primary}
    new_scores = {row["image_id"]: row for row in scored["primary"]["0.13"]["per_image"]}
    old_scores = {row["image_id"]: row for row in scored["primary"]["0.15"]["per_image"]}
    for image_id, item in by_threshold[.13].items():
        gold = primary_by_id[image_id]["gold"]
        score = new_scores[image_id]["score"]
        matches = {pair["prediction_index"]: pair for pair in score["matches"]}
        before_count = len(by_threshold[.15][image_id]["predictions"])
        workload.append({"image_id": image_id, "before_predictions": before_count,
                         "after_predictions": len(item["predictions"]),
                         "added_predictions": len(item["predictions"]) - before_count})
        for index, pred in enumerate(item["predictions"]):
            if pred["confidence"] > .15:
                continue
            pair = matches.get(index)
            kind = ("reference_match" if pair else "duplicate_extra" if index in score["duplicate_prediction_indices"] else "other_extra")
            overlaps = sorted([{"reference_row_one_based": i + 1, "iou": _box_iou(pred["bbox_xyxy"], g["bbox_xyxy"])}
                               for i, g in enumerate(gold)], key=lambda x: x["iou"], reverse=True)
            top = overlaps[0] if overlaps and overlaps[0]["iou"] > 0 else None
            target_id = f"{image_id}:{pair['gold_index']+1}" if pair else None
            additions.append({"image_id": image_id, "prediction_index_zero_based_at_013": index,
                              "prediction": pred, "scored_disposition": kind,
                              "matched_reference_object_id": target_id,
                              "match": pair, "maximum_reference_overlap": top,
                              "reference_review_notes": notes.get(target_id, {}) if target_id else {},
                              "original_image_sha256": item["image_sha256"],
                              "physical_review_status": "pending_original_image_review"})
    def compact(row):
        s, q = row["score"], row["quality"]
        return {**{k: s[k] for k in ("gold_count", "prediction_count", "tp", "fn", "fp", "duplicate_fp", "other_fp", "visible_endpoints", "returned_endpoints", "missing_endpoints", "conditional_median_error_px", "conditional_p95_error_px")},
                "two_corner_success": {str(r["radius_px"]): r["both_visible_objects_within_radius"] for r in q["radii"]},
                "returned_on_unlocatable_reference": q["returned_on_unlocatable_reference"],
                "unlocatable_on_matched_objects": q["unlocatable_on_matched_objects"],
                "miss_free_nonempty_image_ids": row["miss_free_nonempty_image_ids"],
                "empty_image_predictions": row["empty_image_predictions"],
                "groups_by_locatable_corners": row["groups_by_locatable_corners"]}
    primary_delta = comparison["primary"]
    before, after = scored["primary"]["0.15"], scored["primary"]["0.13"]
    summary = {"schema_version": 1, "status": "measured_pending_visual_review", "protocol_sha256": sha(study / "protocol.json"),
               "comparison_script_sha256": sha(__file__), "existing_comparison_helper_sha256": sha(helper),
               "fresh_image_prediction_calls": 40, "excluded_warmups": 1, "inference_exit_code": 0,
               "baseline_exact_archived_prediction_arrays": 20, "baseline_complete_score_records_exactly_replayed": 40,
               "all_retained_high_confidence_predictions_exactly_unchanged": True,
               "summary_by_reference": {name: {key: compact(v) for key, v in rows.items()} for name, rows in scored.items()},
               "changes_by_reference": comparison,
               "added_proposal_count": len(additions), "added_proposals_by_scored_disposition": dict(Counter(a["scored_disposition"] for a in additions)),
               "images_with_additions": sum(w["added_predictions"] > 0 for w in workload), "workload_by_image": workload,
               "fixed_numeric_acceptance": {
                   "008_33_formally_recovered": "new_000008:33" in primary_delta["gained_object_ids"],
                   "no_lost_existing_matches": not primary_delta["lost_object_ids"],
                   "no_5px_pair_count_reduction": not primary_delta["both_corner_changes"]["5"]["lost"],
                   "no_10px_pair_count_reduction": not primary_delta["both_corner_changes"]["10"]["lost"],
                   "no_new_empty_scene_detections": before["empty_image_predictions"] == after["empty_image_predictions"] == {"new_000146": 0, "new_000147": 0, "new_000148": 0},
               }, "visual_supported_recovery_and_review_workload_assessment": "Pending original-pixel review of every added proposal. No automatic promotion.",
               "limits": protocol["limits"]}
    write(study / "added-proposals.json", additions)
    write(study / "comparison-summary.json", summary)
    inventory = {str(path.relative_to(study)): {"sha256": sha(path), "size_bytes": path.stat().st_size}
                 for path in sorted(study.rglob("*")) if path.is_file()
                 and "runtime-config" not in path.parts and path.name != "inventory.json" and path.suffix != ".log"}
    write(study / "inventory.json", inventory)
    print(json.dumps({"primary": {key: {k: v for k,v in compact(val).items() if k != 'groups_by_locatable_corners'} for key,val in scored['primary'].items()},
                      "gained":primary_delta['gained_object_ids'],"lost":primary_delta['lost_object_ids'],
                      "added":summary['added_proposal_count'],"added_dispositions":summary['added_proposals_by_scored_disposition'],
                      "numeric_acceptance":summary['fixed_numeric_acceptance']},indent=2))


if __name__ == "__main__":
    main()
