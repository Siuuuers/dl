#!/usr/bin/env python3
"""Independent saved-prediction audit; never load a model or call inference."""

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROLES = ("old_reviewed", "extended_reviewed", "current")
THRESHOLDS = (0.15, 0.25, 0.4)
RADII = (2, 5, 10)
SOURCE = "19459913c8be2f08978d8eee93387a6087407444"
MODELS = {
    "old_reviewed": "024022f1ffb20370413c2d99660f44d729fc312b8921dd89e8c68554a348a15b",
    "extended_reviewed": "debf6b07a6188f9061df4b308e7ebcdf7a21ba85de0fb6602d8f3a1ac952734d",
    "current": "420c00f73eeba24e587342400878b7d96371d3e745772113809aa705ec8163b1",
}


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    def unique(items):
        result = {}
        for key, value in items:
            assert key not in result, (path, "duplicate key", key)
            result[key] = value
        return result
    def reject(value):
        raise ValueError(value)
    return json.loads(Path(path).read_text(), object_pairs_hook=unique, parse_constant=reject)


def same(a, b, context):
    assert a == b, context


def parse_labels(path):
    objects = []
    for line in path.read_text().splitlines():
        assert line.strip()
        fields = list(map(float, line.split()))
        assert len(fields) == 11 and fields[0] == 0
        cx, cy, w, h = fields[1:5]
        points = [[fields[k] * 1280, fields[k + 1] * 720, int(fields[k + 2])] for k in (5, 8)]
        objects.append({"class_id": 0, "bbox_xyxy": [(cx - w/2)*1280, (cy - h/2)*720,
                        (cx + w/2)*1280, (cy + h/2)*720], "keypoints": points})
    return objects


def overlap(a, b):
    area = max(0, min(a[2], b[2]) - max(a[0], b[0])) * max(0, min(a[3], b[3]) - max(a[1], b[1]))
    return area / ((a[2]-a[0])*(a[3]-a[1]) + (b[2]-b[0])*(b[3]-b[1]) - area)


def returned(point):
    x, y, confidence = point
    return (confidence >= .5 and x is not None and y is not None and math.isfinite(x)
            and math.isfinite(y) and 0 <= x < 1280 and 0 <= y < 720)


def percentile(values, q):
    values = sorted(values)
    if not values:
        return None
    index = (len(values) - 1) * q
    lo, hi = math.floor(index), math.ceil(index)
    return values[lo] + (values[hi] - values[lo]) * (index - lo)


def independent_objects(gold, predictions, score):
    available = set(range(len(gold)))
    assignment = {}
    for pi in sorted(range(len(predictions)), key=lambda i: (-predictions[i]["confidence"], i)):
        choices = [(overlap(predictions[pi]["bbox_xyxy"], gold[gi]["bbox_xyxy"]), gi)
                   for gi in available if predictions[pi]["class_id"] == gold[gi]["class_id"]]
        choices = [(iou, gi) for iou, gi in choices if iou >= .5]
        if choices:
            _, gi = min(choices, key=lambda pair: (-pair[0], pair[1]))
            available.remove(gi)
            assignment[gi] = pi
    same(assignment, {r["gold_index"]: r["prediction_index"] for r in score["matches"]}, "independent matching")
    matched_pi = set(assignment.values())
    extra = [i for i in range(len(predictions)) if i not in matched_pi]
    duplicates = [pi for pi in extra if any(overlap(predictions[pi]["bbox_xyxy"], gold[gi]["bbox_xyxy"]) >= .5
                  and predictions[pi]["class_id"] == gold[gi]["class_id"] for gi in assignment)]
    same(extra, score["unmatched_prediction_indices"], "independent extra IDs")
    same(duplicates, score["duplicate_prediction_indices"], "independent duplicate IDs")
    pairs = {r["gold_index"]: r for r in score["matches"]}
    rows = []
    for gi, target in enumerate(gold):
        visible = [p[2] == 2 for p in target["keypoints"]]
        flags, errors = [False, False], [None, None]
        if gi in assignment:
            points = predictions[assignment[gi]]["keypoints"]
            for side in (0, 1):
                flags[side] = returned(points[side])
                if visible[side] and flags[side]:
                    errors[side] = math.hypot(points[side][0] - target["keypoints"][side][0],
                                              points[side][1] - target["keypoints"][side][1])
        rows.append({"reference_row_one_based": gi+1, "locatable_corners": sum(visible),
                     "reference_endpoint_visible": visible, "matched": gi in assignment,
                     "prediction_index_zero_based": assignment.get(gi),
                     "matching_iou": pairs[gi]["iou"] if gi in pairs else None,
                     "endpoint_returned": flags, "visible_endpoint_errors_px": errors,
                     "both_visible_within_radius": {str(r): all(visible) and all(e is not None and e <= r for e in errors) for r in RADII}})
    return rows


def groups(rows):
    result = {}
    for n in (0, 1, 2):
        group = [row for row in rows if row["locatable_corners"] == n]
        errors = [e for row in group for e in row["visible_endpoint_errors_px"] if e is not None]
        matched = sum(row["matched"] for row in group)
        result[str(n)] = {"reference_objects": len(group), "matched_objects": matched,
            "missed_objects": len(group)-matched, "visible_endpoints": n*len(group),
            "returned_visible_endpoints": len(errors), "missing_visible_endpoints": n*len(group)-len(errors),
            "unlocatable_on_matched_objects": (2-n)*matched,
            "returned_on_unlocatable_reference": sum(not v and ret for row in group for v, ret in
                zip(row["reference_endpoint_visible"], row["endpoint_returned"])),
            "conditional_median_error_px": percentile(errors, .5), "conditional_p95_error_px": percentile(errors, .95),
            "radii": [{"radius_px": r, "visible_endpoints_within_radius": sum(e <= r for e in errors),
                       "both_visible_objects_within_radius": sum(row["both_visible_within_radius"][str(r)] for row in group)} for r in RADII]}
    return result


def audit(args):
    root, run = args.root.resolve(), args.run.resolve()
    status = read(run / "status.json")
    assert status["status"] == "complete" and status["mode"] == "fresh_inference"
    assert status["fresh_image_prediction_calls"] == 180 and status["scored_image_reference_threshold_pairs"] == 360
    inventory = read(run / "inventory.json")
    for name, spec in inventory.items():
        assert sha(run/name) == spec["sha256"] and (run/name).stat().st_size == spec["size_bytes"]
    identity = read(run / "identity.json")
    assert identity["source"]["revision"] == SOURCE and identity["source"]["working_tree_status"] == ""
    assert sha(root / "results/verification/baomai-partial-fronts-results-20261111/evaluate_comparison.py") == identity["driver_sha256"]
    for path, digest in identity["source_helpers_sha256"].items():
        assert sha(root/path) == digest
    sys.path.insert(0, str(root / "scripts"))
    from pose_scoring import score_image, aggregate_scores
    from diagnose_pose_quality import quality_for_image, aggregate_quality
    original = read(root / "data/manifest.json")
    primary_path = root / "data/references/visible-front-2026-11-11/manifest.json"
    primary = read(primary_path)
    assert sha(primary_path) == identity["primary_reference_sha256"]
    assert sha(root / "data/manifest.json") == identity["original_reference_sha256"]
    assert sha(run / "protocol.json") == identity["protocol_sha256"]
    records = sorted((r for r in original["records"] if r["split"] == "val"), key=lambda r:r["id"])
    ids = [r["id"] for r in records]
    primary_files = {r["image_id"]:r for r in primary["files"]}
    references = {"original": {}, "primary": {}}
    for record in records:
        assert sha(root / "data" / record["image"]) == record["image_sha256"]
        for reference, path, digest in (
            ("original", root / "data" / record["label"], record["label_sha256"]),
            ("primary", primary_path.parent / primary_files[record["id"]]["label_path"], primary_files[record["id"]]["label_sha256"])):
            assert sha(path) == digest
            references[reference][record["id"]] = parse_labels(path)
    denominators = {name:dict(sorted(Counter(sum(p[2] == 2 for p in obj["keypoints"]) for rows in ref.values() for obj in rows).items())) for name, ref in references.items()}
    same(denominators["primary"], {0:19, 1:60, 2:584}, "primary denominator")
    headers, raw, recomputed, reports, compact = {}, {}, {}, {}, {}
    for role in ROLES:
        lines = (run/f"predictions-{role}.jsonl").read_text().splitlines()
        data = [json.loads(line) for line in lines]
        header, items = data[0], data[1:]
        headers[role] = header
        assert header["role"] == role and header["record_type"] == "run" and len(items) == 60
        same(header["identities"], identity, "raw identity")
        assert header["model_sha256"] == MODELS[role]
        assert header["checkpoint_identity"] == identity["checkpoints"][role]
        manifest_path = args.current_manifest if role == "current" else args.returned_root / role / "checkpoint-manifest.json"
        manifest = read(manifest_path)
        assert sha(manifest_path) == header["checkpoint_identity"]["manifest_sha256"]
        assert sha(manifest_path.parent / manifest["checkpoint"]["path"]) == MODELS[role]
        assert header["thresholds"] == list(THRESHOLDS)
        same(header["inference"], headers[ROLES[0]]["inference"], "inference settings")
        same(header["runtime"], headers[ROLES[0]]["runtime"], "inference runtime")
        runtime = header["runtime"]
        assert runtime["device_actual"] == "cpu" and runtime["backend_end2end"] is False and runtime["backend_fp16"] is False
        assert runtime["torch_threads"] == 4 and runtime["torch_interop_threads"] == 1
        assert header["inference"]["imgsz"] == 1280 and header["inference"]["iou"] == .7 and header["inference"]["nms"] is True
        state = header["model_state_before_prediction"]
        state_bytes = json.dumps(state["tensors"], sort_keys=True, separators=(",", ":")).encode()
        assert hashlib.sha256(state_bytes).hexdigest() == state["sha256"]
        assert len(state["tensors"]) == state["tensor_count"] and sum(t["bytes"] for t in state["tensors"]) == state["tensor_bytes"]
        same([(i["threshold"], i["image_id"]) for i in items], [(t,i) for t in THRESHOLDS for i in ids], "raw call sequence")
        raw[role] = {(i["threshold"],i["image_id"]):i["predictions"] for i in items}
        record_map = {r["id"]:r for r in records}
        for item in items:
            source = record_map[item["image_id"]]
            assert item["role"] == role and item["record_type"] == "prediction"
            assert item["image_sha256"] == source["image_sha256"] and item["original_label_sha256"] == source["label_sha256"]
            assert (item["width"],item["height"]) == (1280,720) and item["predict_call_wall_ms"] > 0
            assert all(p["confidence"] >= item["threshold"] for p in item["predictions"])
        for reference, ref in references.items():
            saved = read(run/f"scoring-{role}-{reference}.json")
            for threshold in THRESHOLDS:
                report = saved[str(threshold)]
                reports[role,reference,threshold] = report
                scores, qualities, states = [], [], {}
                same([r["image_id"] for r in report["per_image"]], ids, "score image ordering")
                for image, entry in zip(ids, report["per_image"]):
                    predictions, gold = raw[role][threshold,image], ref[image]
                    score = score_image(gold,predictions,1280,720,.5,.5)
                    quality = quality_for_image(gold,predictions,1280,720,RADII)
                    same(score,entry["score"],(role,reference,threshold,image,"score"))
                    same(quality,entry["quality"],(role,reference,threshold,image,"quality"))
                    states[image] = independent_objects(gold,predictions,score)
                    same(states[image],entry["objects"],(role,reference,threshold,image,"object states"))
                    scores.append(score); qualities.append(quality)
                same(aggregate_scores(scores),report["score"],"aggregate score")
                same(aggregate_quality(qualities),report["quality"],"aggregate quality")
                pooled = groups([r for rows in states.values() for r in rows])
                same(pooled,report["groups_by_locatable_corners"],"independent corner groups")
                same({int(k):v["reference_objects"] for k,v in pooled.items()},denominators[reference],"all-reference group denominators")
                for r in RADII:
                    q = next(q for q in report["quality"]["radii"] if q["radius_px"] == r)
                    same(pooled["2"]["radii"][RADII.index(r)]["both_visible_objects_within_radius"],q["both_visible_objects_within_radius"],"independent all-eligible both-corner count")
                subsets = {"empty":[i for i in ids if not ref[i]], "nonempty":[i for i in ids if ref[i]]}
                subsets.update({f"{a:03d}_{b:03d}":[i for i in ids if a <= int(i.split('_')[-1]) <= b] for a,b in [(7,11),(53,59),(86,90),(146,148)]})
                for name, image_ids in subsets.items():
                    target = report["by_scene" if name in ("empty","nonempty") else "by_filename_range"][name]
                    positions = [ids.index(i) for i in image_ids]
                    same(aggregate_scores([scores[i] for i in positions]),target["score"],"subset score")
                    same(aggregate_quality([qualities[i] for i in positions]),target["quality"],"subset quality")
                miss_free = [i for i,s in zip(ids,scores) if ref[i] and s["fn"] == 0]
                same(miss_free,report["miss_free_nonempty_image_ids"],"miss-free scenes")
                same({i:len(raw[role][threshold,i]) for i in ids if not ref[i]},report["empty_image_predictions"],"empty scenes")
                recomputed[role,reference,threshold] = {f"{image}:{r['reference_row_one_based']}":r for image,rows in states.items() for r in rows}
                compact[f"{role}/{reference}/{threshold}"] = {k:report["score"][k] for k in ("gold_count","prediction_count","tp","fn","fp","duplicate_fp","other_fp","visible_endpoints","returned_endpoints","missing_endpoints")}
                compact[f"{role}/{reference}/{threshold}"].update(both_corners={str(r):pooled['2']['radii'][RADII.index(r)]['both_visible_objects_within_radius'] for r in RADII},miss_free_nonempty_images=miss_free)
    comparison = read(run/"comparison.json")
    changes = {}
    for reference in references:
        for before,after in (("old_reviewed","extended_reviewed"),("current","old_reviewed"),("current","extended_reviewed")):
            for threshold in THRESHOLDS:
                a,b = recomputed[before,reference,threshold],recomputed[after,reference,threshold]
                expected = comparison["comparisons"][reference][f"{after}-vs-{before}"][str(threshold)]
                gained = [i for i in a if not a[i]["matched"] and b[i]["matched"]]
                lost = [i for i in a if a[i]["matched"] and not b[i]["matched"]]
                corners = {str(r):{change:[i for i in a if a[i]["both_visible_within_radius"][str(r)] == (change == "lost") and b[i]["both_visible_within_radius"][str(r)] == (change == "gained")] for change in ("gained","lost")} for r in RADII}
                same(gained,expected["gained_object_ids"],"gained object identities")
                same(lost,expected["lost_object_ids"],"lost object identities")
                same(corners,expected["both_corner_changes"],"corner gain/loss identities")
                changes[f"{after}-vs-{before}/{reference}/{threshold}"] = {"gained":gained,"lost":lost,"both_corner_changes":corners,
                    "availability_changes":[{"object_id":i,"before":a[i]["endpoint_returned"],"after":b[i]["endpoint_returned"]} for i in a if a[i]["endpoint_returned"] != b[i]["endpoint_returned"]]}
    identical_calls = sum(raw["old_reviewed"][key] == raw["current"][key] for key in raw["current"])
    same(identical_calls,60,"old/current ordered prediction identity")
    same(headers["old_reviewed"]["model_state_before_prediction"],headers["current"]["model_state_before_prediction"],"old/current full tensor-list identity")
    old_tensors = headers["old_reviewed"]["model_state_before_prediction"]["tensors"]
    new_tensors = headers["extended_reviewed"]["model_state_before_prediction"]["tensors"]
    same([(t['name'],t['shape'],t['dtype']) for t in old_tensors],[(t['name'],t['shape'],t['dtype']) for t in new_tensors],"tensor layout")
    changed_tensors = [a['name'] for a,b in zip(old_tensors,new_tensors) if a['sha256'] != b['sha256']]
    assert changed_tensors
    result = {"schema_version":1,"kind":"independent-partial-fronts-result-replay-audit","status":"passed",
        "created_at_utc":datetime.now(timezone.utc).isoformat(),"run_identity_sha256":sha(run/'identity.json'),
        "script_sha256":sha(__file__),"source_revision":SOURCE,"source_driver_sha256":identity['driver_sha256'],
        "command":[sys.executable,*sys.argv],"verified_counts":{"fresh_image_calls":180,"per_image_scores":360,"per_image_quality_records":360,"full_aggregates":18,"subset_aggregates":108,"independent_object_group_summaries":18},
        "reference_corner_group_denominators":denominators,"runtime":headers['old_reviewed']['runtime'],
        "model_hashes":MODELS,"model_state_digests":{r:headers[r]['model_state_before_prediction']['sha256'] for r in ROLES},
        "old_current_exact_ordered_prediction_calls":identical_calls,"old_current_tensor_lists_identical":True,
        "extended_changed_tensors":len(changed_tensors),"tensor_count":len(old_tensors),"changed_tensor_names":changed_tensors,
        "metrics":compact,"changes":changes,"method":"The new evaluation driver is not imported or replayed. Original score/quality helpers are rerun directly, and a separate greedy matcher, per-object endpoint computation, group denominator/radius aggregation and object-change construction check the driver outputs independently.",
        "limits":["No model loading or new inference. Model bytes are hashed; state tensor hashes are verified for internal consistency and compared from recorded evidence.","All eligible reference objects, including misses, remain in group and both-corner denominators.","Reference-v0 availability disagreements do not establish hidden-coordinate error."]}
    args.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({"status":"passed","output":str(args.output),"sha256":sha(args.output),"verified_counts":result['verified_counts'],"old_current_exact_ordered_prediction_calls":identical_calls,"extended_changed_tensors":len(changed_tensors),"tensor_count":len(old_tensors)}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('root','run','returned-root','current-manifest','output'):
        parser.add_argument('--'+name,type=Path,required=True)
    audit(parser.parse_args())
