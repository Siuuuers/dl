import hashlib,json,sys,importlib.util
from pathlib import Path
from datetime import datetime
root=Path('/workspace/scratch/b2268c0c3452/dl')
base=Path('/workspace/scratch/234c4cdb06aa/confidence-013')
auditroot=Path('/workspace/scratch/234c4cdb06aa/audit-pr40')
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
sys.dont_write_bytecode=True
sys.path.insert(0,str(root/'scripts'))
from evaluate_pose import preflight_dataset
from pose_scoring import score_image,aggregate_scores
from diagnose_pose_quality import quality_for_image,aggregate_quality
helper=auditroot/'extracted/verification/independent_replay_audit.py'
spec=importlib.util.spec_from_file_location('independent_prior_audit',helper)
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
protocol=read(base/'protocol.json');execution=read(base/'execution.json');summary=read(base/'comparison-summary.json')
assert sha(base/'protocol.json')==execution['protocol_sha256']==summary['protocol_sha256']
assert sha(base/'run_evaluation.py')==protocol['source_script_sha256']==execution['launcher_sha256']
assert datetime.fromisoformat(protocol['created_at_utc'])<datetime.fromisoformat(execution['started_at_utc'])<datetime.fromisoformat(execution['finished_at_utc'])
assert (execution['exit_code'],execution['torch_threads'],execution['torch_interop_threads'])==(0,4,1)
for p,h in execution['source']['files_sha256'].items():assert sha(root/p)==h
for p,v in read(base/'inventory.json').items():assert sha(base/p)==v['sha256'] and (base/p).stat().st_size==v['size_bytes']
assert sha(root/'data/manifest.json')==protocol['original_manifest_sha256']
refroot=root/'data/references/visible-front-2026-11-11';assert sha(refroot/'manifest.json')==protocol['corrected_reference_sha256']
original=preflight_dataset(root,require_weights=False)['records'];ids=[r['id'] for r in original]
refs={'original':{r['id']:a.parse_labels(Path(r['label_path'])) for r in original},'primary':{}}
for f in read(refroot/'manifest.json')['files']:
    path=refroot/f['label_path'];assert sha(path)==f['label_sha256'];refs['primary'][f['image_id']]=a.parse_labels(path)
lines=[json.loads(l) for l in (base/'run-001/predictions.jsonl').read_text().splitlines()]
header,rows=lines[0],lines[1:]
assert len(rows)==40 and len({(r['threshold'],r['image_id']) for r in rows})==40
assert header['model_sha256']==protocol['model_sha256']
assert header['box_confidences']==[.15,.13]
new={(r['threshold'],r['image_id']):r for r in rows}
archive={}
for l in (auditroot/'extracted/run/predictions-current.jsonl').read_text().splitlines():
    r=json.loads(l)
    if r.get('record_type')=='prediction' and r['threshold']==.15:archive[r['image_id']]=r
for ident in ids:
    old=new[.15,ident];lower=new[.13,ident]
    assert old['image_sha256']==lower['image_sha256']==archive[ident]['image_sha256']
    assert old['predictions']==archive[ident]['predictions']
    assert [p for p in lower['predictions'] if p['confidence']>.15]==old['predictions']
results={};states={};counts={'score_records':0,'quality_records':0,'aggregates':0,'subset_pairs':0}
for name,golds in refs.items():
    saved=read(base/f'scoring-{name}.json');results[name]={}
    for conf in (.15,.13):
        allscores=[];allquality=[];allobjects={}
        rec=saved[str(conf)]
        for ident,per in zip(ids,rec['per_image']):
            assert per['image_id']==ident
            gold=golds[ident];pred=new[conf,ident]['predictions']
            score=score_image(gold,pred,1280,720,.5,.5)
            quality=quality_for_image(gold,pred,1280,720,(2,5,10))
            assert score==per['score'];assert quality==per['quality']
            objects=a.independent_objects(gold,pred,score);assert objects==per['objects']
            allobjects.update({f'{ident}:{o["reference_row_one_based"]}':o for o in objects})
            allscores.append(score);allquality.append(quality)
            counts['score_records']+=1;counts['quality_records']+=1
        assert aggregate_scores(allscores)==rec['score']
        assert aggregate_quality(allquality)==rec['quality']
        assert a.groups(list(allobjects.values()))==rec['groups_by_locatable_corners']
        counts['aggregates']+=1
        for group,indices in [('empty',[i for i,k in enumerate(ids) if not golds[k]]),('nonempty',[i for i,k in enumerate(ids) if golds[k]])]+[(f'{lo:03d}_{hi:03d}',[i for i,k in enumerate(ids) if lo<=int(k.split('_')[-1])<=hi]) for lo,hi in ((7,11),(53,59),(86,90),(146,148))]:
            savedgroup=rec['by_scene' if group in ('empty','nonempty') else 'by_filename_range'][group]
            assert aggregate_scores([allscores[i] for i in indices])==savedgroup['score']
            assert aggregate_quality([allquality[i] for i in indices])==savedgroup['quality']
            counts['subset_pairs']+=1
        assert [k for k,s in zip(ids,allscores) if golds[k] and s['fn']==0]==rec['miss_free_nonempty_image_ids']
        assert {k:len(new[conf,k]['predictions']) for k in ids if not golds[k]}==rec['empty_image_predictions']
        states[name,conf]=allobjects
        results[name][str(conf)]={k:rec['score'][k] for k in ('gold_count','prediction_count','tp','fn','fp','returned_endpoints','missing_endpoints')}
        results[name][str(conf)].update(pairs={str(q['radius_px']):q['both_visible_objects_within_radius'] for q in rec['quality']['radii']},hidden_outputs=rec['quality']['returned_on_unlocatable_reference'],empty=rec['empty_image_predictions'])
    before,after=states[name,.15],states[name,.13]
    changes={'gained':[k for k in before if not before[k]['matched'] and after[k]['matched']],'lost':[k for k in before if before[k]['matched'] and not after[k]['matched']]}
    assert changes['gained']==summary['changes_by_reference'][name]['gained_object_ids']
    assert changes['lost']==summary['changes_by_reference'][name]['lost_object_ids']
    results[name]['changes']=changes
queue=read(base/'added-proposals.json');added=[]
for ident in ids:
    for i,p in enumerate(new[.13,ident]['predictions']):
        if p['confidence']<=.15:added.append((ident,i,p))
assert len(added)==len(queue)==10
for x,q in zip(added,queue):assert x==(q['image_id'],q['prediction_index_zero_based_at_013'],q['prediction'])
result={'status':'passed','source_revision':execution['source']['revision'],'audit_script_sha256':sha(Path(__file__)),
        'protocol_sha256':sha(base/'protocol.json'),'prediction_jsonl_sha256':sha(base/'run-001/predictions.jsonl'),
        'comparison_summary_sha256':sha(base/'comparison-summary.json'),'independent_prior_audit_sha256':sha(helper),
        'counts':counts,'baseline_exact_arrays':20,'high_confidence_arrays_unchanged':20,'additional_proposals':10,'addition_images':len({x[0] for x in added}),
        'results':results,'model_loads':0,'fresh_inference':False}
p=auditroot/'confidence-013-independent-audit.json';p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
