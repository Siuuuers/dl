#!/usr/bin/env python3
"""Verify an extracted capsule; optionally replay numbers without weights or PNGs.

Only Python's standard library is needed. This does not claim to re-observe
images or verify the omitted model binaries. Full external-input verification
uses the unchanged original driver/auditor included alongside this script.
"""
import argparse
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import sys

sys.dont_write_bytecode = True
ROLES = ("old_reviewed", "extended_reviewed", "current")
THRESHOLDS = (0.13, 0.15)
RADII = (2, 5, 10)


def read(path):
    def unique(items):
        result = {}
        for key, value in items:
            assert key not in result, (str(path), "duplicate key", key)
            result[key] = value
        return result
    def invalid(value):
        raise ValueError(value)
    return json.loads(Path(path).read_text(), object_pairs_hook=unique, parse_constant=invalid)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def safe(name):
    p = PurePosixPath(name)
    assert name and not p.is_absolute() and ".." not in p.parts
    assert "\\" not in name and ":" not in name and p.as_posix() == name
    return p


def inventory_check(root):
    inventory = read(root / "inventory.json")
    files = inventory["payload_files"]
    assert inventory["inventory_self_excluded"] is True
    actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    assert actual == set(files) | {"inventory.json"}, "missing or additional capsule files"
    assert not any(p.is_symlink() for p in root.rglob("*")), "capsule symlink"
    for name, metadata in files.items():
        path = root / safe(name)
        assert path.stat().st_size == metadata["size_bytes"] and sha(path) == metadata["sha256"], name
    return inventory


def replay(root):
    source, run = root / "source", root / "run-001"
    identity = read(run / "identity.json")
    assert identity["source"]["revision"] == "d43a58b9456a782ace14e20f0bf7ed2da3572ca1"
    assert identity["source"]["working_tree_status"] == ""
    assert sha(root / "tools/evaluate_comparison.py") == identity["driver_sha256"]
    for name, digest in identity["source_helpers_sha256"].items():
        assert sha(source / safe(name)) == digest, name
    for name, metadata in read(run / "inventory.json").items():
        assert sha(run / safe(name)) == metadata["sha256"] and (run / name).stat().st_size == metadata["size_bytes"]
    status = read(run / "status.json")
    assert status["status"] == "complete" and status["mode"] == "fresh_inference"
    assert status["fresh_image_prediction_calls"] == 120 and status["scored_image_reference_threshold_pairs"] == 240
    audit_spec = importlib.util.spec_from_file_location("capsule_original_audit", root / "tools/independent_replay_audit.py")
    audit = importlib.util.module_from_spec(audit_spec)
    audit_spec.loader.exec_module(audit)
    sys.path.insert(0, str(source / "scripts"))
    from pose_scoring import score_image, aggregate_scores
    from diagnose_pose_quality import quality_for_image, aggregate_quality
    from package_visible_extent_results import validate_protocol
    context = validate_protocol(source)
    assert context["sha256"] == identity["protocol_sha256"] == sha(run / "protocol.json")
    original = read(source / "data/manifest.json")
    primary_path = source / "data/references/visible-front-2026-11-11/manifest.json"
    primary = read(primary_path)
    assert sha(primary_path) == identity["primary_reference_sha256"]
    assert sha(source / "data/manifest.json") == identity["original_reference_sha256"]
    records = sorted((r for r in original["records"] if r["split"] == "val"), key=lambda r: r["id"])
    ids = [r["id"] for r in records]
    primary_files = {r["image_id"]: r for r in primary["files"]}
    references = {"original": {}, "primary": {}}
    for row in records:
        entry = primary_files[row["id"]]
        for reference, path, expected in (
            ("original", source / "data" / row["label"], row["label_sha256"]),
            ("primary", primary_path.parent / entry["label_path"], entry["label_sha256"]),
        ):
            assert sha(path) == expected
            references[reference][row["id"]] = audit.parse_labels(path)
    denominators = {name: dict(sorted(Counter(sum(p[2] == 2 for p in obj["keypoints"])
                    for rows in ref.values() for obj in rows).items())) for name, ref in references.items()}
    assert denominators == {"original": {0: 21, 1: 59, 2: 584}, "primary": {0: 19, 1: 60, 2: 584}}
    comparison = read(run / "comparison.json")
    historical_audit = read(root / "verification/independent-replay-audit.json")
    assert historical_audit["status"] == "passed"
    assert historical_audit["run_identity_sha256"] == sha(run / "identity.json")
    assert historical_audit["script_sha256"] == sha(root / "tools/independent_replay_audit.py")
    summary = read(root / "summary.json")
    assert summary["derivation"]["script_sha256"] == sha(root / "tools/build_report_summary.py")
    for key, path in (("comparison", run / "comparison.json"), ("identity", run / "identity.json"),
                      ("independent_numerical_audit", root / "verification/independent-replay-audit.json"),
                      ("returned_training_audit", root / "verification/audit-provenance.json")):
        assert summary["input_evidence"][key]["sha256"] == sha(path)
    review = read(root / "review/visual-review.json")
    assert review["status"] == "complete_with_root_concurrence"
    assert review["root_concurrence"]["status"] == "concurred_after_independent_review"
    for name, expected in review["source_hashes"].items():
        assert sha(run / safe(name)) == expected
    for name, metadata in read(root / "review/visual-review-inventory.json").items():
        path = root / "review" / safe(name)
        assert sha(path) == metadata["sha256"] and path.stat().st_size == metadata["size_bytes"]
    for entry in review["original_image_review_inventory"]:
        record = next(row for row in records if row["id"] == entry["image_id"])
        assert entry["image_sha256"] == record["image_sha256"]
        assert entry["primary_label_sha256"] == primary_files[entry["image_id"]]["label_sha256"]
    primary_changes = comparison["comparisons"]["primary"]["extended_reviewed-vs-old_reviewed"]["0.13"]
    assert review["primary_gained_object_ids"] == primary_changes["gained_object_ids"]
    assert review["primary_lost_object_ids"] == primary_changes["lost_object_ids"]
    headers, raw, states, compact = {}, {}, {}, {}
    for role in ROLES:
        items = [json.loads(line) for line in (run / f"predictions-{role}.jsonl").read_text().splitlines()]
        header, items = items[0], items[1:]
        assert header["identities"] == identity and header["role"] == role and len(items) == 40
        assert header["thresholds"] == list(THRESHOLDS)
        assert [(i["threshold"], i["image_id"]) for i in items] == [(t, i) for t in THRESHOLDS for i in ids]
        manifest_path = root / "training" / role / "checkpoint-manifest.json"
        manifest = read(manifest_path)
        assert sha(manifest_path) == header["checkpoint_identity"]["manifest_sha256"]
        assert manifest["checkpoint"]["sha256"] == header["model_sha256"] == historical_audit["model_hashes"][role]
        for descriptor in (manifest["training_receipt"], manifest["staging_manifest"]):
            assert sha(manifest_path.parent / safe(descriptor["path"])) == descriptor["sha256"]
        state = header["model_state_before_prediction"]
        assert hashlib.sha256(json.dumps(state["tensors"], sort_keys=True, separators=(",", ":")).encode()).hexdigest() == state["sha256"]
        assert len(state["tensors"]) == state["tensor_count"] == 879
        assert sum(t["bytes"] for t in state["tensors"]) == state["tensor_bytes"]
        headers[role] = header
        raw[role] = {(i["threshold"], i["image_id"]): i["predictions"] for i in items}
        by_id = {r["id"]: r for r in records}
        for item in items:
            record = by_id[item["image_id"]]
            assert item["image_sha256"] == record["image_sha256"] and item["original_label_sha256"] == record["label_sha256"]
            assert [item["width"], item["height"]] == [1280, 720]
        for reference, labels in references.items():
            saved = read(run / f"scoring-{role}-{reference}.json")
            for threshold in THRESHOLDS:
                report = saved[str(threshold)]
                scores, qualities, object_rows = [], [], {}
                assert [r["image_id"] for r in report["per_image"]] == ids
                for image_id, entry in zip(ids, report["per_image"]):
                    gold, predictions = labels[image_id], raw[role][threshold, image_id]
                    score = score_image(gold, predictions, 1280, 720, .5, .5)
                    quality = quality_for_image(gold, predictions, 1280, 720, RADII)
                    assert score == entry["score"] and quality == entry["quality"]
                    rows = audit.independent_objects(gold, predictions, score)
                    assert rows == entry["objects"]
                    object_rows[image_id] = rows
                    scores.append(score)
                    qualities.append(quality)
                assert aggregate_scores(scores) == report["score"] and aggregate_quality(qualities) == report["quality"]
                assert audit.groups([row for rows in object_rows.values() for row in rows]) == report["groups_by_locatable_corners"]
                assert [i for i, s in zip(ids, scores) if labels[i] and s["fn"] == 0] == report["miss_free_nonempty_image_ids"]
                assert {i: len(raw[role][threshold, i]) for i in ids if not labels[i]} == report["empty_image_predictions"]
                subsets = {"empty": [i for i in ids if not labels[i]], "nonempty": [i for i in ids if labels[i]]}
                subsets.update({f"{a:03d}_{b:03d}": [i for i in ids if a <= int(i.split('_')[-1]) <= b]
                                for a, b in [(7, 11), (53, 59), (86, 90), (146, 148)]})
                for name, image_ids in subsets.items():
                    expected = report["by_scene" if name in ("empty", "nonempty") else "by_filename_range"][name]
                    positions = [ids.index(i) for i in image_ids]
                    assert aggregate_scores([scores[i] for i in positions]) == expected["score"]
                    assert aggregate_quality([qualities[i] for i in positions]) == expected["quality"]
                states[role, reference, threshold] = {f"{image}:{row['reference_row_one_based']}": row
                    for image, rows in object_rows.items() for row in rows}
                compact[f"{role}/{reference}/{threshold}"] = {key: report["score"][key]
                    for key in ("gold_count", "prediction_count", "tp", "fn", "fp", "duplicate_fp", "other_fp", "visible_endpoints", "returned_endpoints", "missing_endpoints")}
                compact[f"{role}/{reference}/{threshold}"].update(
                    both_corners={str(row["radius_px"]): row["both_visible_objects_within_radius"] for row in report["quality"]["radii"]},
                    miss_free_nonempty_images=report["miss_free_nonempty_image_ids"])
                assert compact[f"{role}/{reference}/{threshold}"] == historical_audit["metrics"][f"{role}/{reference}/{threshold}"]
                assert comparison["metrics"][role][reference][str(threshold)] == {key: report[key]
                    for key in ("score", "quality", "groups_by_locatable_corners", "miss_free_nonempty_image_ids", "empty_image_predictions", "focus")}
    for reference in references:
        for before, after in (("old_reviewed", "extended_reviewed"), ("current", "old_reviewed"), ("current", "extended_reviewed")):
            for threshold in THRESHOLDS:
                a, b = states[before, reference, threshold], states[after, reference, threshold]
                expected = comparison["comparisons"][reference][f"{after}-vs-{before}"][str(threshold)]
                assert [i for i in a if not a[i]["matched"] and b[i]["matched"]] == expected["gained_object_ids"]
                assert [i for i in a if a[i]["matched"] and not b[i]["matched"]] == expected["lost_object_ids"]
                corners = {str(r): {change: [i for i in a if a[i]["both_visible_within_radius"][str(r)] == (change == "lost")
                    and b[i]["both_visible_within_radius"][str(r)] == (change == "gained")] for change in ("gained", "lost")} for r in RADII}
                assert corners == expected["both_corner_changes"]
    assert raw["old_reviewed"] == raw["current"]
    assert headers["old_reviewed"]["model_state_before_prediction"] == headers["current"]["model_state_before_prediction"]
    old = headers["old_reviewed"]["model_state_before_prediction"]["tensors"]
    new = headers["extended_reviewed"]["model_state_before_prediction"]["tensors"]
    assert [(r["name"], r["shape"], r["dtype"]) for r in old] == [(r["name"], r["shape"], r["dtype"]) for r in new]
    assert sum(a["sha256"] != b["sha256"] for a, b in zip(old, new)) == historical_audit["extended_changed_tensors"] == 705
    audit.check_review_map(primary, read(run / "reference-review-notes.json"), comparison)
    prior = [json.loads(line) for line in (root / "prior-current/predictions.jsonl").read_text().splitlines()]
    assert sha(root / "prior-current/predictions.jsonl") == historical_audit["prior_current_prediction_comparison"]["member_sha256"]
    assert {(r["threshold"], r["image_id"]): r["predictions"] for r in prior[1:]} == raw["current"]
    return {"status": "passed", "mode": "saved_prediction_replay_without_weights_or_pngs",
        "verified_counts": {"per_image_scores": 240, "per_image_quality_records": 240, "full_aggregates": 12,
                            "subset_aggregates": 72, "independent_object_group_summaries": 12},
        "candidate_composition": {"exact_inherited_files": 8, "delta_train_image_ids": context["delta_train_image_ids"]},
        "old_current_ordered_prediction_arrays_exact": 40, "current_prior_ordered_prediction_arrays_exact": 40,
        "recorded_old_current_model_state_tensors_exact": 879, "recorded_extended_changed_model_state_tensors": 705,
        "visual_review_inventory_and_source_bindings_verified": True,
        "metrics": compact, "models_loaded": 0, "inference_calls": 0, "training_runs": 0,
        "limits": ["Checks the recorded predictions, small input bytes and recorded provenance; omitted model binaries and original image pixels are not reverified here.",
                   "Recorded model-state hashes are internally checked, not freshly derived by this replay.",
                   "Image-based review judgements remain distinct from numerical scoring; no labels or thresholds are changed."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("capsule", type=Path)
    parser.add_argument("--replay", action="store_true")
    parser.add_argument("--output", type=Path, help="optional new JSON file outside the capsule")
    args = parser.parse_args()
    root = args.capsule.resolve()
    inventory = inventory_check(root)
    result = replay(root) if args.replay else {"status": "passed", "mode": "inventory_only"}
    result["payload_files_verified"] = len(inventory["payload_files"])
    if args.output:
        output = args.output.resolve()
        assert not output.is_relative_to(root), "keep replay output outside the immutable capsule"
        with output.open("x") as stream:
            stream.write(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key != "metrics"}, indent=2))


if __name__ == "__main__":
    main()
