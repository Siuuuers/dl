#!/usr/bin/env python3
"""Derive a compact publication summary from the already audited PR43 records."""

import argparse
import hashlib
import json
from pathlib import Path


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def descriptor(path):
    path = Path(path)
    return {"filename": path.name, "sha256": sha(path), "size_bytes": path.stat().st_size}


def compact_metrics(report):
    focus_keys = ("reference_row_one_based", "locatable_corners", "reference_endpoint_visible",
                  "matched", "prediction_index_zero_based", "matching_iou", "endpoint_returned",
                  "visible_endpoint_errors_px", "both_visible_within_radius", "max_proposal_iou")
    return {
        "score": {key: value for key, value in report["score"].items() if key != "endpoint_errors_px"},
        "quality": report["quality"],
        "groups_by_locatable_corners": report["groups_by_locatable_corners"],
        "miss_free_nonempty_image_ids": report["miss_free_nonempty_image_ids"],
        "empty_image_predictions": report["empty_image_predictions"],
        "focus": {key: {field: row[field] for field in focus_keys}
                  for key, row in report["focus"].items()},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("run", "audit", "provenance", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    comparison_path = args.run / "comparison.json"
    identity_path = args.run / "identity.json"
    protocol_path = args.run / "protocol.json"
    comparison, identity, protocol = map(read, (comparison_path, identity_path, protocol_path))
    audit, provenance = read(args.audit), read(args.provenance)
    assert comparison["status"] == "complete" and audit["status"] == provenance["status"] == "passed"
    assert audit["run_identity_sha256"] == sha(identity_path)
    roles = ("old_reviewed", "extended_reviewed", "current")
    references = {}
    for reference in ("primary", "original"):
        example = comparison["metrics"]["old_reviewed"][reference]["0.13"]
        references[reference] = {
            "manifest_sha256": identity["primary_reference_sha256" if reference == "primary" else "original_reference_sha256"],
            "images": example["score"]["image_count"], "nonempty_images": 17,
            "empty_images": len(example["empty_image_predictions"]),
            "objects": example["score"]["gold_count"],
            "visible_endpoints": example["score"]["visible_endpoints"],
            "missing_reference_endpoints": example["quality"]["unlocatable_reference_endpoints"],
            "objects_by_locatable_corners": audit["reference_corner_group_denominators"][reference],
        }
    comparisons = {}
    for reference, pairs in comparison["comparisons"].items():
        comparisons[reference] = {}
        for pair, thresholds in pairs.items():
            comparisons[reference][pair] = {
                threshold: {
                    "gained_object_ids": row["gained_object_ids"],
                    "lost_object_ids": row["lost_object_ids"],
                    "both_corner_changes": {radius: row["both_corner_changes"][radius] for radius in ("5", "10")},
                    "score_delta": row["score_delta"],
                    "quality_delta": row["quality_delta"],
                }
                for threshold, row in thresholds.items()
            }
    state_comparisons = {
        pair: {key: value for key, value in row.items() if key != "changed_tensor_names"}
              | {"changed_tensor_count": len(row["changed_tensor_names"])}
        for pair, row in audit["tensor_comparisons"].items()
    }
    summary = {
        "schema_version": 1,
        "kind": "baomai-visible-extent-result-summary",
        "experiment_id": comparison["experiment_id"],
        "status": "derived_from_completed_independently_audited_evidence",
        "source_created_at_utc": identity["created_at_utc"],
        "derivation": {"script_sha256": sha(__file__), "new_inference": False, "new_training": False,
                       "method": "Copy the audited aggregate metrics and identity lists, omitting long per-endpoint arrays and per-tensor names. Original and corrected references remain separate."},
        "input_evidence": {"comparison": descriptor(comparison_path), "identity": descriptor(identity_path),
                           "independent_numerical_audit": descriptor(args.audit),
                           "returned_training_audit": descriptor(args.provenance)},
        "returned_archive": {key: provenance["archive"][key] for key in ("filename", "sha256", "size_bytes")},
        "source_revision": identity["source"]["revision"],
        "driver_sha256": identity["driver_sha256"],
        "protocol": {"path": "experiments/visible-extent-2026-11-11.json", "sha256": identity["protocol_sha256"]},
        "candidate_roles": protocol["roles"],
        "training_delta_image_ids": protocol["delta_train_image_ids"],
        "evaluation": {
            "primary_box_confidence": comparison["primary_confidence"], "thresholds": comparison["thresholds"],
            "diagnostic_box_confidences": protocol["evaluation"]["diagnostic_box_confidences"],
            "imgsz": 1280, "rect": True, "batch": 1, "precision": "FP32", "device": "cpu",
            "nms_iou": 0.70, "matching_iou": 0.50, "endpoint_confidence": 0.50, "radii_px": [2, 5, 10],
            "intra_op_threads": 4, "inter_op_threads": 1,
            "fresh_image_prediction_calls": comparison["fresh_image_prediction_calls"],
            "warmup_calls_excluded": comparison["warmup_calls_excluded"],
            "network_events_blocked": comparison["network_events_blocked"],
            "verified_counts": audit["verified_counts"],
        },
        "references": references,
        "models": {role: {"checkpoint_identity": identity["checkpoints"][role],
                          "loaded_model_state_sha256": audit["model_state_digests"][role]} for role in roles},
        "control_identity": {
            "comparison_scope": "Loaded pre-prediction state tensors and ordered postprocessed arrays; final checkpoint archive bytes have their own distinct identities.",
            "loaded_state_tensor_count": audit["tensor_count"],
            "model_comparisons": state_comparisons,
            "fresh_current_vs_prior_saved_current": audit["prior_current_prediction_comparison"],
        },
        "results": {
            reference: {str(threshold): {role: compact_metrics(comparison["metrics"][role][reference][str(threshold)])
                                        for role in roles} for threshold in comparison["thresholds"]}
            for reference in ("primary", "original")
        },
        "comparisons": comparisons,
        "v0_availability_decomposition": audit["v0_availability_decomposition"],
        "reference_uncertainty": audit["reference_uncertainty"],
        "model_promotion_by_this_summary": False,
        "limits": comparison["limits"] + [
            "Scored match loss does not establish that a physical front disappeared from the detector output; inspect raw predictions and original pixels.",
            "A row absent from the frozen uncertainty registry is not thereby physically certified.",
            "Five- and ten-pixel pair identities are included separately; a favorable net count at one radius does not cancel losses at another.",
            "The reference-v0 denominator is conditioned on matched objects; common-match output changes are separated from match gains/losses.",
            "The original and corrected-reference gains/losses use their respective row-number identities and must not be pooled.",
        ],
    }
    args.output.write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"output": str(args.output), "sha256": sha(args.output), "size_bytes": args.output.stat().st_size}))


if __name__ == "__main__":
    main()
