#!/usr/bin/env python3
"""Build a deterministic PR43 evidence capsule without training or inference.

Stage-only assemblies may precede visual review. A final archive requires an
explicit completed review JSON. Existing destination files are never replaced.
An extracted, verified capsule can be repacked without any external inputs.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import stat
import tempfile
import zipfile

HERE = Path(__file__).resolve().parent
SOURCE_REVISION = "d43a58b9456a782ace14e20f0bf7ed2da3572ca1"
ARCHIVES = {
    "returned": {"revision": "a964b9bc5437c47fe76a11cfd02e15c467e4da0d",
        "path": "results/gpu/baomai-visible-extent-a100-001/baomai-visible-extent-seed46-results.zip",
        "sha256": "e415c0ccbd07806851e9221ced6df6cd43d2ae54857ae7e3a6d7938ec56dcfca", "size_bytes": 39776639},
    "current": {"revision": "8e8bb99cabcb44ed0ec0acd14db911aa44013fd8",
        "path": "results/gpu/baomai-reviewed-annotations-seed46-l4-001/baomai-reviewed-annotations-seed46-results.zip",
        "sha256": "df53683ccf6f266a605b2844f42a98e808f75686cfab09f14d680c9d061e8a91", "size_bytes": 39776456},
    "prior_current_predictions": {"revision": SOURCE_REVISION,
        "path": "results/verification/baomai-proposal-filter-20261111/confidence-evidence.zip",
        "sha256": "baf48d2e52ef3571ef500de74c0f2a1b5a25e990ba290e4692f440d457d0bcb3"},
}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + "\n").encode()


def safe(name):
    p = PurePosixPath(name)
    need(name and not p.is_absolute() and ".." not in p.parts and "\\" not in name and ":" not in name
         and p.as_posix() == name, f"unsafe member: {name}")
    need(p.suffix.lower() not in {".pt", ".pth", ".onnx", ".engine", ".zip"}, f"weights/archive payload forbidden: {name}")
    need(not name.startswith("source/data/images/"), "original full PNGs are excluded")


def sources(args):
    source, evaluation, returned, current, numerical = args.source, args.evaluation, args.returned, args.current, args.numerical
    files = {}
    def add(name, path):
        safe(name)
        need(name not in files, f"duplicate payload path: {name}")
        files[name] = Path(path)
    for path in sorted((evaluation / "run-001").rglob("*")):
        if path.is_file() and path.suffix in {".json", ".jsonl"}:
            add("run-001/" + path.relative_to(evaluation / "run-001").as_posix(), path)
    add("run-001.stdout.log", evaluation / "run-001.log")
    for name in ("evaluate_comparison.py", "prepare_driver.py", "driver-binding.json"):
        add("tools/" + name, evaluation / name)
    for name in ("build_evidence.py", "verify_evidence.py"):
        add("tools/" + name, HERE / name)
    add("README.md", HERE / "README.md")
    add("tools/requirements-inference.lock.txt", args.requirements)
    add("tools/audit_returned_training.py", returned / "audit_returned_training.py")
    add("tools/independent_replay_audit.py", numerical / "independent_replay_audit.py")
    add("tools/build_report_summary.py", numerical / "build_report_summary.py")
    add("summary.json", numerical / "report-summary.json")
    for name in ("audit-provenance.json", "package-verification.stdout", "package-verification.stderr"):
        add("verification/" + name, returned / name)
    for name in ("independent-replay-audit.json", "source-provenance.json"):
        add("verification/" + name, numerical / name)
    for role in ("old_reviewed", "extended_reviewed", "current"):
        base = current / "candidate" if role == "current" else returned / "unpacked" / role
        for name in ("checkpoint-manifest.json", "training-receipt.json", "staging-manifest.json", "train.log", "fit/results.csv"):
            add(f"training/{role}/{name}", base / name)
    add("training/returned-archive-manifest.json", returned / "unpacked/gpu-results-manifest.json")
    add("training/current-archive-manifest.json", current / "gpu-results-manifest.json")
    identity = read(evaluation / "run-001/identity.json")
    source_paths = set(identity["source_helpers_sha256"])
    source_paths.update({"docs/annotation-policy.md", "experiments/visible-extent-2026-11-11.json", "data/manifest.json",
                         "data/data.yaml", "metadata/model_card.json", "weights/cassette_lower_epoch173.json", "requirements.txt"})
    source_paths.update(path.relative_to(source).as_posix() for path in (source / "data/labels").rglob("*.txt"))
    for relative in ("data/references/visible-front-2026-11-11", "data/candidates/annotations-2026-11-10", "data/candidates/visible-extent-2026-11-11"):
        source_paths.update(path.relative_to(source).as_posix() for path in (source / relative).rglob("*")
                            if path.is_file() and path.suffix in {".txt", ".json", ".md"})
    for name in sorted(source_paths):
        add("source/" + name, source / name)
    for path in sorted(args.review_dir.rglob("*")):
        if path.is_file() and path.suffix in {".json", ".png", ".py", ".md", ".txt"}:
            add("review/" + path.relative_to(args.review_dir).as_posix(), path)
    if args.decisions is not None and not args.decisions.resolve().is_relative_to(args.review_dir.resolve()):
        add("review/" + args.decisions.name, args.decisions)
    for path in args.review_artifact:
        if path.resolve().is_relative_to(args.review_dir.resolve()):
            continue
        add("review/" + path.name, path)
    return files


def assemble(args):
    entries = sources(args)
    missing = [str(path) for path in entries.values() if not path.is_file()]
    if args.plan:
        print(json.dumps({"source_files": len(entries), "missing": missing, "destination": str(args.destination),
                          "visual_review_frozen": bool(args.decisions and args.decisions.is_file()), "packaged": False}, indent=2))
        return None
    need(not missing, "missing capsule inputs: " + ", ".join(missing))
    need(all(not p.is_symlink() for p in entries.values()), "symlink input")
    if not args.stage_only:
        need(args.decisions is not None and args.decisions.is_file(), "final freeze needs completed visual-review decisions")
        decisions = read(args.decisions)
        need(isinstance(decisions, dict) and bool(decisions), "completed review must be a nonempty JSON object")
        need("pending" not in str(decisions.get("status", "")).lower()
             and "not_yet" not in str(decisions.get("status", "")).lower(), "visual review is still pending")
        need(decisions["status"] == "complete_with_root_concurrence"
             and decisions["root_concurrence"]["status"] == "concurred_after_independent_review", "completed root concurrence required")
        for name, expected in decisions["source_hashes"].items():
            need(sha(args.evaluation / "run-001" / name) == expected, "review source differs: " + name)
        visual_inventory = read(args.review_dir / "visual-review-inventory.json")
        need("visual-review.json" in visual_inventory, "visual decisions are not inventoried")
        for name, metadata in visual_inventory.items():
            safe("review/" + name)
            path = args.review_dir / name
            need(sha(path) == metadata["sha256"] and path.stat().st_size == metadata["size_bytes"], "visual member changed: " + name)
    provenance = read(args.returned / "audit-provenance.json")
    audit = read(args.numerical / "independent-replay-audit.json")
    identity = read(args.evaluation / "run-001/identity.json")
    comparison = read(args.evaluation / "run-001/comparison.json")
    need(provenance["status"] == audit["status"] == "passed", "audits incomplete")
    need(audit["run_identity_sha256"] == sha(args.evaluation / "run-001/identity.json"), "audit belongs to another run")
    need(audit["script_sha256"] == sha(args.numerical / "independent_replay_audit.py"), "auditor changed")
    need(identity["driver_sha256"] == sha(args.evaluation / "evaluate_comparison.py"), "driver changed")
    need(identity["source"]["revision"] == SOURCE_REVISION and identity["source"]["working_tree_status"] == "", "source differs")
    for name, metadata in read(args.evaluation / "run-001/inventory.json").items():
        path = args.evaluation / "run-001" / name
        need(sha(path) == metadata["sha256"] and path.stat().st_size == metadata["size_bytes"], "run changed: " + name)
    for name, expected in identity["source_helpers_sha256"].items():
        need(sha(args.source / name) == expected, "source helper changed: " + name)
    returned_zip = args.returned / "baomai-visible-extent-seed46-results.zip"
    need(sha(returned_zip) == ARCHIVES["returned"]["sha256"] and returned_zip.stat().st_size == ARCHIVES["returned"]["size_bytes"], "returned archive differs")
    need(sha(args.current_zip) == ARCHIVES["current"]["sha256"] and args.current_zip.stat().st_size == ARCHIVES["current"]["size_bytes"], "current archive differs")
    need(sha(args.prior_current_zip) == ARCHIVES["prior_current_predictions"]["sha256"], "prior prediction archive differs")
    payload = {name: path.read_bytes() for name, path in entries.items()}
    with zipfile.ZipFile(args.prior_current_zip) as archive:
        prediction = archive.read("confidence/run-001/predictions.jsonl")
        prior_inventory = archive.read("confidence/inventory.json")
        descriptor = json.loads(prior_inventory)["run-001/predictions.jsonl"]
        need(hashlib.sha256(prediction).hexdigest() == descriptor["sha256"]
             and len(prediction) == descriptor["size_bytes"], "prior predictions differ")
        payload["prior-current/predictions.jsonl"] = prediction
        payload["prior-current/inventory.json"] = prior_inventory
    summary = json.loads(payload["summary.json"])
    need(summary["derivation"]["script_sha256"] == sha(args.numerical / "build_report_summary.py"), "summary builder changed")
    for key, path in (("comparison", args.evaluation / "run-001/comparison.json"),
                      ("identity", args.evaluation / "run-001/identity.json"),
                      ("independent_numerical_audit", args.numerical / "independent-replay-audit.json"),
                      ("returned_training_audit", args.returned / "audit-provenance.json")):
        need(summary["input_evidence"][key]["sha256"] == sha(path), "summary input differs: " + key)
    payload["external-inputs.json"] = encoded({
        "repository": "https://github.com/Siuuuers/dl.git", "source_revision": SOURCE_REVISION,
        "notebook_revision": "dedee7042e541da7415276e0dbbe95e0f554fcb4",
        "archives": ARCHIVES, "models": audit["model_hashes"],
        "omitted_original_images": "source/data/manifest.json binds all 157 original image SHA256s; only review crops/figures are included.",
        "initial_checkpoint": {"path": "weights/cassette_lower_epoch173.pt", "sha256": "e0aab1b377491700318e0b14cd4c558ec3c1684087a13b7dde2298ebdbf2847e", "size_bytes": 106838542},
        "source_helpers_sha256": identity["source_helpers_sha256"],
        "full_driver_sha256": identity["driver_sha256"],
        "no_training_required": True,
    })
    descriptions = {name: {"sha256": hashlib.sha256(data).hexdigest(), "size_bytes": len(data)} for name, data in sorted(payload.items())}
    inventory = {"schema_version": 1, "kind": "visible-extent-result-evidence-inventory", "source_revision": SOURCE_REVISION,
        "status": "provisional_assembly" if args.stage_only else "frozen_complete", "payload_files": descriptions,
        "inventory_self_excluded": True, "zip_member_timestamp": "2026-11-11T00:00:00",
        "scope": "Numerical replay, provenance, exact prediction/scoring evidence, small source inputs, training receipts/logs and completed visual review. Model weights and original full PNGs are external hash-bound inputs."}
    return {**payload, "inventory.json": encoded(inventory)}


def package(payload, destination):
    destination.mkdir(parents=True, exist_ok=True)
    outputs = ("evidence.zip", "evidence.zip.sha256", "evidence-inventory.json", "summary.json", "README.md")
    need(not any((destination / name).exists() or (destination / name).is_symlink() for name in outputs), "choose a new destination; outputs already exist")
    inner = json.loads(payload["inventory.json"])
    need(inner["status"] == "frozen_complete", "a provisional assembly cannot be published as final")
    with tempfile.TemporaryDirectory(prefix=".evidence-build-", dir=destination) as temporary:
        temp = Path(temporary)
        archive = temp / "evidence.zip"
        with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zipped:
            for name, data in sorted(payload.items()):
                safe(name)
                info = zipfile.ZipInfo(name, date_time=(2026, 11, 11, 0, 0, 0))
                info.create_system = 3
                info.external_attr = 0o100644 << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                zipped.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)
        with zipfile.ZipFile(archive) as zipped:
            names = zipped.namelist()
            need(zipped.testzip() is None and len(names) == len(set(names)) == len(payload), "ZIP CRC/member failure")
            need(set(names) == set(payload), "ZIP member set differs")
            for info in zipped.infolist():
                safe(info.filename)
                need(not stat.S_ISLNK(info.external_attr >> 16), "ZIP symlink")
                need(zipped.read(info) == payload[info.filename], "ZIP byte readback differs")
        digest = sha(archive)
        outer = {**inner, "archive": {"filename": "evidence.zip", "sha256": digest, "size_bytes": archive.stat().st_size,
            "member_count": len(payload), "payload_member_count": len(payload) - 1,
            "inner_inventory_sha256": hashlib.sha256(payload["inventory.json"]).hexdigest()},
            "verification": {"exact_byte_readback": True, "crc_all_passed": True, "safe_unique_members": True,
                             "models_deserialized": False, "new_inference": False, "new_training": False}}
        (temp / "evidence-inventory.json").write_bytes(encoded(outer))
        (temp / "evidence.zip.sha256").write_text(digest + "  evidence.zip\n")
        for name in ("summary.json", "README.md"):
            (temp / name).write_bytes(payload[name])
        for name in outputs:
            os.link(temp / name, destination / name)
    print(json.dumps({"status": "packaged_and_verified", "destination": str(destination), "archive_sha256": digest,
                      "archive_size_bytes": outer["archive"]["size_bytes"], "members": len(payload)}, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--destination", type=Path, required=True)
    parser.add_argument("--source", type=Path, default=Path("/workspace/scratch/11398f9f3638/pr43-return/source"))
    parser.add_argument("--evaluation", type=Path, default=Path("/workspace/scratch/11398f9f3638/pr43-evaluation"))
    parser.add_argument("--returned", type=Path, default=Path("/workspace/scratch/11398f9f3638/pr43-return"))
    parser.add_argument("--current", type=Path, default=Path("/workspace/scratch/b2268c0c3452/work/partial-fronts-return/current-unpacked"))
    parser.add_argument("--current-zip", type=Path, default=Path("/workspace/scratch/b2268c0c3452/work/partial-fronts-return/current-seed46-results.zip"))
    parser.add_argument("--prior-current-zip", type=Path, default=Path("/workspace/scratch/234c4cdb06aa/dl-publication/results/verification/baomai-proposal-filter-20261111/confidence-evidence.zip"))
    parser.add_argument("--numerical", type=Path, default=Path("/workspace/scratch/11398f9f3638/pr43-independent-audit"))
    parser.add_argument("--requirements", type=Path, default=Path("/workspace/scratch/b2268c0c3452/work/partial-fronts-return/inference-requirements.txt"))
    parser.add_argument("--review-dir", type=Path, default=Path("/workspace/scratch/11398f9f3638/pr43-evaluation/visual-review"))
    parser.add_argument("--decisions", type=Path)
    parser.add_argument("--review-artifact", type=Path, action="append", default=[])
    parser.add_argument("--plan", action="store_true")
    parser.add_argument("--stage-only", action="store_true")
    parser.add_argument("--repack", type=Path, help="rebuild ZIP from an existing extracted, verified capsule")
    args = parser.parse_args()
    if args.repack:
        spec = importlib.util.spec_from_file_location("capsule_verifier", HERE / "verify_evidence.py")
        verifier = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(verifier)
        verifier.inventory_check(args.repack.resolve())
        payload = {p.relative_to(args.repack).as_posix(): p.read_bytes() for p in args.repack.rglob("*") if p.is_file()}
    else:
        payload = assemble(args)
        if payload is None:
            return
    if args.stage_only:
        args.destination.mkdir(parents=True, exist_ok=False)
        for name, data in payload.items():
            path = args.destination / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
        print(json.dumps({"status": "provisional_assembly", "destination": str(args.destination), "members": len(payload)}, indent=2))
    else:
        package(payload, args.destination.resolve())


if __name__ == "__main__":
    main()
