#!/usr/bin/env python3
"""Read-only PR43 input/training audit; no model loading or inference.

Run beside the preserved ZIP, its unpacked/ payloads and pinned source/ checkout.
The existing published packager has already independently verified this archive.
"""
from datetime import datetime, timezone, timedelta
from pathlib import Path
import csv
import hashlib
import json
import math
import re
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
SOURCE = BASE / "source"
UNPACKED = BASE / "unpacked"
CURRENT = Path("/workspace/scratch/b2268c0c3452/work/partial-fronts-return/current-unpacked/candidate")
SOURCE_SHA = "d43a58b9456a782ace14e20f0bf7ed2da3572ca1"
NOTEBOOK_SHA = "dedee7042e541da7415276e0dbbe95e0f554fcb4"
RESULT_SHA = "a964b9bc5437c47fe76a11cfd02e15c467e4da0d"
ARCHIVE_NAME = "baomai-visible-extent-seed46-results.zip"
ARCHIVE_SHA = "e415c0ccbd07806851e9221ced6df6cd43d2ae54857ae7e3a6d7938ec56dcfca"
ARCHIVE_PATH = "results/gpu/baomai-visible-extent-a100-001/" + ARCHIVE_NAME
ROLES = ("old_reviewed", "extended_reviewed")
DELTA = ("new_000061", "new_000079", "new_000082", "new_000094")


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def git(*args):
    return subprocess.check_output(["git", *args], cwd=SOURCE, text=True).strip()


def tensor_storage_inventory(path):
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        return {name.split("/", 1)[1]: hashlib.sha256(archive.read(name)).hexdigest()
                for name in archive.namelist() if "/data/" in name}


def csv_rows(path):
    with Path(path).open() as stream:
        return list(csv.DictReader(stream))


def main():
    archive_path = BASE / ARCHIVE_NAME
    assert archive_path.stat().st_size == 39776639 and digest(archive_path) == ARCHIVE_SHA
    checksum = (BASE / (ARCHIVE_NAME + ".sha256")).read_text().split()
    assert checksum == [ARCHIVE_SHA, ARCHIVE_NAME]
    with zipfile.ZipFile(archive_path) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)) == 13 and archive.testzip() is None
        for name in names:
            member = Path(name)
            assert not member.is_absolute() and ".." not in member.parts
            assert "\\" not in name and ":" not in name and member.as_posix() == name
            assert (archive.getinfo(name).external_attr >> 16) & 0o170000 != 0o120000
            assert archive.read(name) == (UNPACKED / name).read_bytes()
        index = read(UNPACKED / "gpu-results-manifest.json")
        assert set(names) == {"gpu-results-manifest.json", *(item["path"] for item in index["files"])}
        for item in index["files"]:
            path = UNPACKED / item["path"]
            assert digest(path) == item["sha256"] and path.stat().st_size == item["size_bytes"]

    assert git("rev-parse", "HEAD") == SOURCE_SHA and git("status", "--porcelain") == ""
    assert git("write-tree") == git("rev-parse", "HEAD^{tree}")
    source = index["training_source"]
    assert source["revision"] == SOURCE_SHA and source["working_tree_status"] == ""
    for name, expected in source["files_sha256"].items():
        assert digest(SOURCE / name) == expected
    assert digest(SOURCE / "scripts/package_visible_extent_results.py") == index["packager_sha256"]
    assert digest(SOURCE / index["protocol"]["path"]) == index["protocol"]["sha256"]
    assert index["protocol"]["sha256"] == "42aa275a5d2ed1ccabb786c07b537a8f0d515b27b7804fec2b71e942d6c9022b"
    protocol = read(SOURCE / index["protocol"]["path"])
    assert protocol["delta_train_image_ids"] == list(DELTA) == index["delta_train_image_ids"]
    assert protocol["reviewed_unchanged_train_image_ids"] == ["new_000062", "new_000063"]
    original = read(SOURCE / "data/manifest.json")
    records = {row["id"]: row for row in original["records"]}
    assert len(records) == 157
    for row in records.values():
        assert digest(SOURCE / "data" / row["image"]) == row["image_sha256"]
        assert digest(SOURCE / "data" / row["label"]) == row["label_sha256"]
    assert digest(SOURCE / "weights/cassette_lower_epoch173.pt") == protocol["initial_checkpoint_sha256"]
    assert digest(SOURCE / protocol["evaluation"]["primary_reference"]) == protocol["evaluation"]["primary_reference_sha256"]

    proposals, inventories, receipts, results = {}, {}, {}, {}
    for role in ROLES:
        spec = protocol["roles"][role]
        path = SOURCE / spec["candidate_manifest"]
        assert digest(path) == spec["candidate_manifest_sha256"]
        proposal = read(path)
        proposals[role] = {row["image_id"]: row for row in proposal["changes"]}
        for row in proposal["changes"]:
            assert digest(path.parent / row["candidate_label"]) == row["candidate_label_sha256"]
        if role == "extended_reviewed":
            assert digest(path.parent / proposal["review"]["path"]) == proposal["review"]["sha256"]
            assert proposal["review"]["sha256"] == "e8302f06cf57b82e82039f7f96415b9a62e39f54cc4b2805afe87e0a19b4258e"
        staging = read(UNPACKED / role / "staging-manifest.json")
        assert all(staging["source"][key] == value for key, value in spec.items())
        inventories[role] = {row["path"]: row["output_sha256"] for row in staging["variants"]["candidate"]["files"]}
        expected = {}
        for image_id, row in records.items():
            expected[row["image"]] = row["image_sha256"]
            expected[row["label"]] = proposals[role].get(image_id, {}).get("candidate_label_sha256", row["label_sha256"])
        assert inventories[role] == expected
        receipt = receipts[role] = read(UNPACKED / role / "training-receipt.json")
        assert receipt["source"] == source and receipt["runtime"] == index["runtime"]
        assert receipt["arm"] == "candidate" and receipt["purpose"] == "paired-finetune"
        assert receipt["status"] == "complete" and receipt["completed_epochs"] == list(range(1, 31))
        assert receipt["optimizer_steps"] == 78 and receipt["batches_completed"] == 1050 and receipt["images_processed"] == 4110
        assert all(receipt[key] is True for key in ("training_returned", "finalization_completed", "optimizer_parameter_change_observed", "validation_executed", "inputs_reverified_after_worker"))
        assert receipt["checkpoint_selection"] == "final_epoch" and receipt["checkpoint"]["path"] == "fit/weights/last.pt"
        assert receipt["execution"]["exit_code"] == 0 and receipt["execution"]["stop_reason"] is None
        assert receipt["initial_checkpoint_sha256"] == protocol["initial_checkpoint_sha256"]
        settings = receipt["training_settings"]
        assert settings["resume"] is False and settings["model"].endswith("/weights/cassette_lower_epoch173.pt")
        assert settings["epochs"] == 30 and settings["batch"] == 4 and settings["nbs"] == 64
        assert settings["seed"] == 46 and settings["imgsz"] == 1280 and settings["amp"] is False
        samples = receipt["optimizer_step_samples"]
        assert len(samples) == 8 and all(item["witness_parameter_changed"] for item in samples)
        rows = csv_rows(UNPACKED / role / "fit/results.csv")
        assert [int(row["epoch"]) for row in rows] == list(range(1, 31))
        assert all(math.isfinite(float(value)) for row in rows for value in row.values())
        log = (UNPACKED / role / "train.log").read_text()
        log = re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", log).replace("\r", "\n")
        completed = sorted(set(int(x) for x in re.findall(r"(?m)^\s*(\d+)/30\s+[^\n]*\b35/35\b", log)))
        assert completed == list(range(1, 31)) and "30 epochs completed" in log
        validation_rows = len(re.findall(r"(?m)^\s*all\s+20\s+664\s+", log))
        assert validation_rows >= 30 and "resume=False" in log
        results[role] = {
            "created_at_utc": receipt["created_at_utc"], "status": receipt["status"],
            "arm": receipt["arm"], "completed_epochs": len(receipt["completed_epochs"]),
            "optimizer_steps": receipt["optimizer_steps"], "batches_completed": receipt["batches_completed"],
            "images_processed": receipt["images_processed"], "worker_wall_seconds": receipt["worker_wall_seconds"],
            "training_counts": staging["variants"]["candidate"]["counts"],
            "checkpoint_identity": index["roles"][role]["checkpoint_identity"],
            "optimizer_parameter_change_witnesses": len(samples), "csv_epoch_sequence": [int(row["epoch"]) for row in rows],
            "log_training_epochs_completed_35_of_35": completed, "log_validation_rows_20_images_664_objects": validation_rows,
            "final_epoch_csv_metrics": {k: float(v) for k, v in rows[-1].items() if k.startswith("metrics/")},
        }
    old, new = (proposals[role] for role in ROLES)
    assert len(old) == 8 and set(new) == set(old) | set(DELTA)
    for image_id, row in old.items():
        first = SOURCE / Path(protocol["roles"]["old_reviewed"]["candidate_manifest"]).parent / row["candidate_label"]
        second = SOURCE / Path(protocol["roles"]["extended_reviewed"]["candidate_manifest"]).parent / new[image_id]["candidate_label"]
        assert first.read_bytes() == second.read_bytes()
    actual_delta = sorted(path for path in inventories[ROLES[0]] if inventories[ROLES[0]][path] != inventories[ROLES[1]][path])
    assert actual_delta == sorted(records[image_id]["label"] for image_id in DELTA)
    delta_summary = []
    for image_id in DELTA:
        change = new[image_id]
        before = (SOURCE / "data" / records[image_id]["label"]).read_text().splitlines()
        after = (SOURCE / Path(protocol["roles"]["extended_reviewed"]["candidate_manifest"]).parent / change["candidate_label"]).read_text().splitlines()
        assert len(after) >= len(before) and not change["deletions"]
        changed_rows = [i + 1 for i, (left, right) in enumerate(zip(before, after)) if left != right]
        assert sorted(changed_rows) == sorted(item["original_row"] for item in change["replacements"])
        for left, right in zip(before, after):
            a, b = left.split(), right.split()
            assert a[0] == b[0] and a[5:] == b[5:]
        assert all(all(float(value) == 0 for value in row.split()[5:]) for row in after[len(before):])
        delta_summary.append({"image_id": image_id, "bbox_replaced_rows": changed_rows, "added_rows": len(after) - len(before), "all_previous_corner_tokens_unchanged": True})
    assert sum(len(item["bbox_replaced_rows"]) for item in delta_summary) == 11
    assert sum(item["added_rows"] for item in delta_summary) == 1

    old_storages = tensor_storage_inventory(UNPACKED / "old_reviewed/fit/weights/last.pt")
    new_storages = tensor_storage_inventory(UNPACKED / "extended_reviewed/fit/weights/last.pt")
    current_storages = tensor_storage_inventory(CURRENT / "fit/weights/last.pt")
    assert old_storages == current_storages and len(old_storages) == len(new_storages) == 883
    non_time = lambda rows: [{k: v for k, v in row.items() if k != "time"} for row in rows]
    assert non_time(csv_rows(CURRENT / "fit/results.csv")) == non_time(csv_rows(UNPACKED / "old_reviewed/fit/results.csv"))
    notebook = subprocess.check_output(["git", "show", NOTEBOOK_SHA + ":notebooks/baomai_visible_extent.ipynb"], cwd=SOURCE)
    notebook_text = "\n".join("".join(cell["source"]) for cell in json.loads(notebook)["cells"])
    assert 'SOURCE_REVISION = "' + SOURCE_SHA + '"' in notebook_text
    assert 'PROTOCOL_SHA256 = "' + index["protocol"]["sha256"] + '"' in notebook_text
    assert "Both arms are complete; no resource trial or training will repeat." in notebook_text
    times = [datetime.fromisoformat(receipts[role]["created_at_utc"]) for role in ROLES]
    assert datetime.fromisoformat(protocol["declared_at_utc"]) < times[0] - timedelta(seconds=receipts[ROLES[0]]["execution"]["wall_seconds"])
    assert times[0] < times[1] < datetime.fromisoformat(index["created_at_utc"])
    strict_result = read(BASE / "package-verification.stdout")
    assert strict_result["status"] == "verified_existing" and strict_result["sha256"] == ARCHIVE_SHA
    assert not (BASE / "package-verification.stderr").read_text().strip()
    assert digest(archive_path) == ARCHIVE_SHA and git("status", "--porcelain") == ""
    output = {
        "schema_version": 1, "kind": "independent-returned-visible-extent-provenance-audit",
        "created_at_utc": datetime.now(timezone.utc).isoformat(), "status": "passed",
        "pull_request": {"url": "https://github.com/Siuuuers/dl/pull/43", "head_revision": RESULT_SHA,
                         "archive_path": ARCHIVE_PATH, "archive_git_blob": git("rev-parse", RESULT_SHA + ":" + ARCHIVE_PATH)},
        "archive": {"filename": ARCHIVE_NAME, "size_bytes": 39776639, "sha256": ARCHIVE_SHA,
                    "members": names, "crc_all_passed": True, "all_twelve_payload_hashes_and_sizes_verified": True,
                    "every_member_matches_extracted_bytes": True, "strict_published_packager": "verified_existing"},
        "source": {**source, "checkout_clean": True, "checkout_tree": git("rev-parse", "HEAD^{tree}"),
                   "eight_recorded_source_file_hashes_verified": True, "packager_sha256": index["packager_sha256"]},
        "protocol": index["protocol"], "packaged_at_utc": index["created_at_utc"],
        "notebook": {"revision": NOTEBOOK_SHA, "sha256": hashlib.sha256(notebook).hexdigest(),
                     "source_and_protocol_pins_match": True, "completed_pair_recovery_skips_training": True},
        "runtime": index["runtime"], "shared_training_settings": index["shared_training_settings"],
        "inputs": {"original_images_verified": 157, "original_labels_verified": 157,
                   "initial_checkpoint_bytes_verified": True, "initial_checkpoint_sha256": protocol["initial_checkpoint_sha256"],
                   "inherited_reviewed_label_files_byte_identical": 8, "effective_changed_label_paths": actual_delta,
                   "delta": delta_summary, "reviewed_unchanged_images": ["new_000062", "new_000063"],
                   "all_images_and_in_training_validation_labels_unchanged": True,
                   "candidate_manifest_sha256": protocol["roles"]["extended_reviewed"]["candidate_manifest_sha256"],
                   "candidate_review_sha256": "e8302f06cf57b82e82039f7f96415b9a62e39f54cc4b2805afe87e0a19b4258e",
                   "primary_post_training_reference_sha256": protocol["evaluation"]["primary_reference_sha256"]},
        "roles": results,
        "storage_and_trajectory_comparison": {
            "current_pr35_checkpoint_sha256": digest(CURRENT / "fit/weights/last.pt"),
            "old_control_vs_current_pr35_all_883_tensor_storage_payloads_byte_identical": True,
            "old_control_vs_current_pr35_all_30_epoch_csv_fields_except_time_equal": True,
            "old_vs_extended_tensor_storage_payloads_total": len(old_storages),
            "old_vs_extended_tensor_storage_payloads_different": sum(old_storages[k] != new_storages[k] for k in old_storages),
            "scope": "ZIP storage bytes only; no checkpoint deserialization or inference by this audit."},
        "limits": [
            "Receipt/log/code consistency validates returned evidence, not an independent observation of the remote execution.",
            "Drive completion markers and a restoration transcript are not packaged. The notebook recovery branch supports the reported no-retraining recovery, but the archive alone cannot prove when a runtime was lost or restored.",
            "Staging checkpoint_bytes_verified and source_revision_git_object_checked are false by design for reusable staging. The training entrypoint independently requires actual initial checkpoint bytes, records their digest and rechecks them after the worker; this audit verifies the available original bytes separately.",
            "Final CSV metrics use the original 664-object in-training validation. Corrected 663-object evaluation at 0.13/0.15 and model promotion require separate inference/review.",
            "One seed, one matched pair, a reused correlated 20-image development set and retained annotation uncertainty limit generalization claims.",
        ],
    }
    (BASE / "audit-provenance.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"status": output["status"], "audit": str(BASE / "audit-provenance.json"),
                      "archive_sha256": ARCHIVE_SHA, "source_revision": SOURCE_SHA,
                      "accepted_delta_images": list(DELTA), "optimizer_steps_each": 78}, indent=2))


if __name__ == "__main__":
    main()
