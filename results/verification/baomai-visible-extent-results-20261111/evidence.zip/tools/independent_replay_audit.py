#!/usr/bin/env python3
"""Independent saved-prediction audit; never load a model or call inference."""

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import sys
import zipfile

sys.dont_write_bytecode = True
ROLES = ("old_reviewed", "extended_reviewed", "current")
THRESHOLDS = (0.13, 0.15)
RADII = (2, 5, 10)
SOURCE = "d43a58b9456a782ace14e20f0bf7ed2da3572ca1"
DRIVER_SHA256 = "01da5a0f067d3734cdaa990674d9092c768febc4a089dbb35f8ad3e19ef74b8f"
PROTOCOL_SHA256 = "42aa275a5d2ed1ccabb786c07b537a8f0d515b27b7804fec2b71e942d6c9022b"
PRIMARY_REFERENCE_SHA256 = "2e60b3e81195448cc565a1000b4305e3215baba2bf0ee0c976e6551c2e64937c"
ORIGINAL_REFERENCE_SHA256 = "72ae8365d5abf0b45b75d400a2e6d22119c0e31b54ee33035feb8edc1f967926"
CANDIDATE_SHA256 = "ab89253e4c2e886a6f1274fa50e400cf568c132e9cecc83d8f558d567b88c6d4"
PRIOR_CURRENT_ZIP_SHA256 = "baf48d2e52ef3571ef500de74c0f2a1b5a25e990ba290e4692f440d457d0bcb3"
MANIFESTS = {
 "old_reviewed": "5db89fa828b51446f651e4e7c064ba9f4738658cff3bdad3971d1a1215705c87",
 "extended_reviewed": "f0b229fb6649a3c0c116163d425c1f5992ef2d360a1d8d3d1346d581bfebbf45",
 "current": "c5f07c4445a7b33a679fd4fc896aaf9643d81b4f72d8ca8e4e7179cb0bc691e8",
}
MODELS = {
    "old_reviewed": "db0e8c625aa0261d32f8af0f48b5362ab66e5c51a06d2b6f45b046798bd4184f",
    "extended_reviewed": "d7cc62189743e7c2750035fc2b98e8b499e9ca160489407dc11e0002c8f01fd0",
    "current": "420c00f73eeba24e587342400878b7d96371d3e745772113809aa705ec8163b1",
}


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    def unique(items):
        result = {}
        for key, value in items:
            assert key not in result, (path, "duplicate key", key)
            result[key] = value
        return result
    def reject(value):
        raise ValueError(value)
    return json.loads(Path(path).read_text(), object_pairs_hook=unique, parse_constant=reject)


def same(a, b, context):
    assert a == b, context


def parse_labels(path):
    objects = []
    for line in path.read_text().splitlines():
        assert line.strip()
        fields = list(map(float, line.split()))
        assert len(fields) == 11 and fields[0] == 0
        cx, cy, w, h = fields[1:5]
        points = [[fields[k] * 1280, fields[k + 1] * 720, int(fields[k + 2])] for k in (5, 8)]
        objects.append({"class_id": 0, "bbox_xyxy": [(cx - w/2)*1280, (cy - h/2)*720,
                        (cx + w/2)*1280, (cy + h/2)*720], "keypoints": points})
    return objects


def overlap(a, b):
    area = max(0, min(a[2], b[2]) - max(a[0], b[0])) * max(0, min(a[3], b[3]) - max(a[1], b[1]))
    return area / ((a[2]-a[0])*(a[3]-a[1]) + (b[2]-b[0])*(b[3]-b[1]) - area)


def returned(point):
    x, y, confidence = point
    return (confidence >= .5 and x is not None and y is not None and math.isfinite(x)
            and math.isfinite(y) and 0 <= x < 1280 and 0 <= y < 720)


def percentile(values, q):
    values = sorted(values)
    if not values:
        return None
    index = (len(values) - 1) * q
    lo, hi = math.floor(index), math.ceil(index)
    return values[lo] + (values[hi] - values[lo]) * (index - lo)


def independent_objects(gold, predictions, score):
    available = set(range(len(gold)))
    assignment = {}
    for pi in sorted(range(len(predictions)), key=lambda i: (-predictions[i]["confidence"], i)):
        choices = [(overlap(predictions[pi]["bbox_xyxy"], gold[gi]["bbox_xyxy"]), gi)
                   for gi in available if predictions[pi]["class_id"] == gold[gi]["class_id"]]
        choices = [(iou, gi) for iou, gi in choices if iou >= .5]
        if choices:
            _, gi = min(choices, key=lambda pair: (-pair[0], pair[1]))
            available.remove(gi)
            assignment[gi] = pi
    same(assignment, {r["gold_index"]: r["prediction_index"] for r in score["matches"]}, "independent matching")
    matched_pi = set(assignment.values())
    extra = [i for i in range(len(predictions)) if i not in matched_pi]
    duplicates = [pi for pi in extra if any(overlap(predictions[pi]["bbox_xyxy"], gold[gi]["bbox_xyxy"]) >= .5
                  and predictions[pi]["class_id"] == gold[gi]["class_id"] for gi in assignment)]
    same(extra, score["unmatched_prediction_indices"], "independent extra IDs")
    same(duplicates, score["duplicate_prediction_indices"], "independent duplicate IDs")
    pairs = {r["gold_index"]: r for r in score["matches"]}
    rows = []
    for gi, target in enumerate(gold):
        visible = [p[2] == 2 for p in target["keypoints"]]
        flags, errors = [False, False], [None, None]
        if gi in assignment:
            points = predictions[assignment[gi]]["keypoints"]
            for side in (0, 1):
                flags[side] = returned(points[side])
                if visible[side] and flags[side]:
                    errors[side] = math.hypot(points[side][0] - target["keypoints"][side][0],
                                              points[side][1] - target["keypoints"][side][1])
        rows.append({"reference_row_one_based": gi+1, "locatable_corners": sum(visible),
                     "reference_endpoint_visible": visible, "matched": gi in assignment,
                     "prediction_index_zero_based": assignment.get(gi),
                     "matching_iou": pairs[gi]["iou"] if gi in pairs else None,
                     "endpoint_returned": flags, "visible_endpoint_errors_px": errors,
                     "both_visible_within_radius": {str(r): all(visible) and all(e is not None and e <= r for e in errors) for r in RADII}})
    return rows


def groups(rows):
    result = {}
    for n in (0, 1, 2):
        group = [row for row in rows if row["locatable_corners"] == n]
        errors = [e for row in group for e in row["visible_endpoint_errors_px"] if e is not None]
        matched = sum(row["matched"] for row in group)
        result[str(n)] = {"reference_objects": len(group), "matched_objects": matched,
            "missed_objects": len(group)-matched, "visible_endpoints": n*len(group),
            "returned_visible_endpoints": len(errors), "missing_visible_endpoints": n*len(group)-len(errors),
            "unlocatable_on_matched_objects": (2-n)*matched,
            "returned_on_unlocatable_reference": sum(not v and ret for row in group for v, ret in
                zip(row["reference_endpoint_visible"], row["endpoint_returned"])),
            "conditional_median_error_px": percentile(errors, .5), "conditional_p95_error_px": percentile(errors, .95),
            "radii": [{"radius_px": r, "visible_endpoints_within_radius": sum(e <= r for e in errors),
                       "both_visible_objects_within_radius": sum(row["both_visible_within_radius"][str(r)] for row in group)} for r in RADII]}
    return result


def check_review_map(primary, saved, comparison):
    """Reconstruct reference-row provenance without the evaluation driver."""
    files = {row["image_id"]: row for row in primary["files"]}
    expected, unresolved = {}, []
    for row in primary["queue_dispositions"]:
        entry = files[row["image_id"]]
        mapped = entry["retained_source_to_revised_row_one_based"][row["source_row_one_based"] - 1]
        if mapped is not None:
            object_id = f"{row['image_id']}:{mapped}"
            assert 1 <= mapped <= entry["row_count"]
            expected.setdefault(object_id, {})["queue_disposition"] = row
            if row["disposition"] == "retained_unresolved":
                unresolved.append(object_id)
    assert len(unresolved) == len(set(unresolved)) == 19
    for row in primary["edits"]:
        revised = row.get("revised_row_one_based")
        if revised is not None:
            assert 1 <= revised <= files[row["image_id"]]["row_count"]
            expected.setdefault(f"{row['image_id']}:{revised}", {}).setdefault("accepted_edits", []).append(row)
    expected.setdefault("new_000011:61", {})["additional_caveat"] = (
        "Earlier original-pixel review retains boundary/identity uncertainty; "
        "see the pinned docs/low-confidence-review-2026-11-11.md. No new adjudication is made here.")
    same(saved, expected, "frozen reference review map")
    changes = {}
    for pair, thresholds in comparison["comparisons"]["primary"].items():
        for threshold, report in thresholds.items():
            examined = []
            for change in report["object_changes"]:
                object_id = change["object_id"]
                prior = expected.get(object_id, {"status": "No specific assessment in the frozen review map; not a certification."})
                same(change["prior_review"], prior, "gain/loss prior uncertainty")
                examined.append({"object_id":object_id, "change":change["change"],
                                 "retained_uncertain":object_id in unresolved,
                                 "separate_caveat":object_id == "new_000011:61",
                                 "has_specific_review_record":object_id in expected})
            changes[f"{pair}/{threshold}"] = examined
    return {"retained_uncertain_count":len(unresolved), "retained_uncertain_primary_ids":unresolved,
            "separate_caveat_ids":["new_000011:61"], "all_cases_remain_in_reference":True,
            "changed_object_provenance":changes,
            "limit":"Absence from this map does not certify physical identity, geometry, or visibility."}


def compare_prior_current(path, current, header, records):
    """Compare fresh arrays with the hash-pinned earlier 0.13/0.15 evidence."""
    assert sha(path) == PRIOR_CURRENT_ZIP_SHA256
    member = "confidence/run-001/predictions.jsonl"
    with zipfile.ZipFile(path) as archive:
        data = archive.read(member)
        inventory = json.loads(archive.read("confidence/inventory.json"))
        descriptor = inventory["run-001/predictions.jsonl"]
        assert hashlib.sha256(data).hexdigest() == descriptor["sha256"]
        assert len(data) == descriptor["size_bytes"]
    rows = [json.loads(line) for line in data.decode().splitlines()]
    prior_header, items = rows[0], rows[1:]
    assert prior_header["record_type"] == "run" and len(items) == 40
    assert prior_header["model_sha256"] == MODELS["current"]
    assert prior_header["manifest_sha256"] == ORIGINAL_REFERENCE_SHA256
    same(prior_header["checkpoint_identity"],header["checkpoint_identity"],"prior current checkpoint")
    same(prior_header["inference"],header["inference"],"prior current inference settings")
    assert prior_header["box_confidences"] == [.15,.13]
    by_id = {row["id"]:row for row in records}
    prior = {}
    for row in items:
        key = (row["threshold"],row["image_id"])
        assert key not in prior and row["record_type"] == "prediction"
        source = by_id[row["image_id"]]
        assert row["image_sha256"] == source["image_sha256"] and row["label_sha256"] == source["label_sha256"]
        assert [row["width"],row["height"]] == [1280,720]
        prior[key] = row["predictions"]
    same(set(prior),set(current),"prior and fresh current threshold/image set")
    different = [{"threshold":key[0],"image_id":key[1],"prior_predictions":len(prior[key]),
                  "fresh_predictions":len(current[key])} for key in current if current[key] != prior[key]]
    common_runtime_keys = sorted(set(prior_header["runtime"]) & set(header["runtime"]))
    runtime_differences = {key:{"before":prior_header["runtime"][key],"after":header["runtime"][key]}
                          for key in common_runtime_keys if prior_header["runtime"][key] != header["runtime"][key]}
    return {"archive_sha256":PRIOR_CURRENT_ZIP_SHA256,"member":member,
            "member_sha256":descriptor["sha256"],"total_image_threshold_pairs":len(current),
            "exact_ordered_prediction_arrays":len(current)-len(different),"different_arrays":different,
            "runtime_fields_compared":common_runtime_keys,"runtime_differences":runtime_differences,
            "scope":"Predictions are compared by fixed image/threshold key, preserving each array's order. The earlier run visited0.15 before0.13; the fresh run visited0.13 before0.15. Equality is observed, not required for the numerical audit to pass."}


def availability_partition(before, after, before_predictions, after_predictions, threshold):
    """Separate output changes on common matches from a changed match denominator."""
    partitions = {
        "common_matches": [key for key in before if before[key]["matched"] and after[key]["matched"]],
        "lost_matches": [key for key in before if before[key]["matched"] and not after[key]["matched"]],
        "gained_matches": [key for key in before if not before[key]["matched"] and after[key]["matched"]],
    }
    counts = {}
    for name, ids in partitions.items():
        counts[name] = {}
        for role, states in (("old_reviewed", before), ("extended_reviewed", after)):
            matched = [states[key] for key in ids if states[key]["matched"]]
            counts[name][role] = {
                "matched_objects": len(matched),
                "unlocatable_opportunities": sum(not flag for row in matched for flag in row["reference_endpoint_visible"]),
                "returned_on_unlocatable": sum(not flag and returned for row in matched
                    for flag, returned in zip(row["reference_endpoint_visible"], row["endpoint_returned"])),
            }
    sides = []
    for key in partitions["common_matches"]:
        first, second = before[key], after[key]
        same(first["reference_endpoint_visible"], second["reference_endpoint_visible"], "fixed endpoint visibility")
        for side, visible in enumerate(first["reference_endpoint_visible"]):
            if not visible and first["endpoint_returned"][side] != second["endpoint_returned"][side]:
                image_id = key.rsplit(":", 1)[0]
                sides.append({
                    "object_id": key, "side_zero_based": side,
                    "old_returned": first["endpoint_returned"][side],
                    "new_returned": second["endpoint_returned"][side],
                    "old_raw_keypoint": before_predictions[threshold, image_id][first["prediction_index_zero_based"]]["keypoints"][side],
                    "new_raw_keypoint": after_predictions[threshold, image_id][second["prediction_index_zero_based"]]["keypoints"][side],
                })
    return {"partition_counts": counts,
            "lost_object_ids": partitions["lost_matches"], "gained_object_ids": partitions["gained_matches"],
            "common_match_v0_return_changes": sides,
            "limit":"Reference-v0 output availability is a disagreement diagnostic. Neither a reduced denominator nor a lower returned count establishes hidden-coordinate accuracy."}


def audit(args):
    root, run = args.root.resolve(), args.run.resolve()
    status = read(run / "status.json")
    assert status["status"] == "complete" and status["mode"] == "fresh_inference"
    assert status["fresh_image_prediction_calls"] == 120 and status["scored_image_reference_threshold_pairs"] == 240
    inventory = read(run / "inventory.json")
    for name, spec in inventory.items():
        assert sha(run/name) == spec["sha256"] and (run/name).stat().st_size == spec["size_bytes"]
    identity = read(run / "identity.json")
    assert identity["source"]["revision"] == SOURCE and identity["source"]["working_tree_status"] == ""
    assert sha(args.driver) == identity["driver_sha256"] == DRIVER_SHA256
    assert identity["returned_training_source"]["revision"] == SOURCE
    assert identity["returned_training_source"]["working_tree_status"] == ""
    assert identity["protocol_sha256"] == PROTOCOL_SHA256
    assert identity["primary_reference_sha256"] == PRIMARY_REFERENCE_SHA256
    assert identity["original_reference_sha256"] == ORIGINAL_REFERENCE_SHA256
    protocol = read(run / "protocol.json")
    assert sha(root / "experiments/visible-extent-2026-11-11.json") == PROTOCOL_SHA256
    assert protocol["evaluation"]["primary_box_confidence"] == .13
    assert protocol["evaluation"]["diagnostic_box_confidences"] == [.15]
    assert protocol["roles"]["extended_reviewed"]["candidate_manifest_sha256"] == CANDIDATE_SHA256
    assert sha(root / protocol["roles"]["extended_reviewed"]["candidate_manifest"]) == CANDIDATE_SHA256
    for path, digest in identity["source_helpers_sha256"].items():
        assert sha(root/path) == digest
    sys.path.insert(0, str(root / "scripts"))
    from pose_scoring import score_image, aggregate_scores
    from diagnose_pose_quality import quality_for_image, aggregate_quality
    original = read(root / "data/manifest.json")
    primary_path = root / "data/references/visible-front-2026-11-11/manifest.json"
    primary = read(primary_path)
    assert sha(primary_path) == identity["primary_reference_sha256"]
    assert sha(root / "data/manifest.json") == identity["original_reference_sha256"]
    assert sha(run / "protocol.json") == identity["protocol_sha256"]
    records = sorted((r for r in original["records"] if r["split"] == "val"), key=lambda r:r["id"])
    ids = [r["id"] for r in records]
    primary_files = {r["image_id"]:r for r in primary["files"]}
    references = {"original": {}, "primary": {}}
    for record in records:
        assert sha(root / "data" / record["image"]) == record["image_sha256"]
        for reference, path, digest in (
            ("original", root / "data" / record["label"], record["label_sha256"]),
            ("primary", primary_path.parent / primary_files[record["id"]]["label_path"], primary_files[record["id"]]["label_sha256"])):
            assert sha(path) == digest
            references[reference][record["id"]] = parse_labels(path)
    denominators = {name:dict(sorted(Counter(sum(p[2] == 2 for p in obj["keypoints"]) for rows in ref.values() for obj in rows).items())) for name, ref in references.items()}
    same(denominators["primary"], {0:19, 1:60, 2:584}, "primary denominator")
    same(denominators["original"], {0:21, 1:59, 2:584}, "original denominator")
    for name, count, points in (("primary",663,1228),("original",664,1227)):
        assert sum(denominators[name].values()) == count
        assert sum(k*v for k,v in denominators[name].items()) == points
        assert sum(not rows for rows in references[name].values()) == 3
    headers, raw, recomputed, reports, compact = {}, {}, {}, {}, {}
    for role in ROLES:
        lines = (run/f"predictions-{role}.jsonl").read_text().splitlines()
        data = [json.loads(line) for line in lines]
        header, items = data[0], data[1:]
        headers[role] = header
        assert header["role"] == role and header["record_type"] == "run" and len(items) == 40
        same(header["identities"], identity, "raw identity")
        assert header["model_sha256"] == MODELS[role]
        assert header["checkpoint_identity"] == identity["checkpoints"][role]
        manifest_path = args.current_manifest if role == "current" else args.returned_root / role / "checkpoint-manifest.json"
        manifest = read(manifest_path)
        assert sha(manifest_path) == header["checkpoint_identity"]["manifest_sha256"] == MANIFESTS[role]
        assert sha(manifest_path.parent / manifest["checkpoint"]["path"]) == MODELS[role]
        assert header["thresholds"] == list(THRESHOLDS)
        same(header["inference"], headers[ROLES[0]]["inference"], "inference settings")
        same(header["runtime"], headers[ROLES[0]]["runtime"], "inference runtime")
        runtime = header["runtime"]
        assert runtime["device_actual"] == "cpu" and runtime["backend_end2end"] is False and runtime["backend_fp16"] is False
        assert runtime["torch_threads"] == 4 and runtime["torch_interop_threads"] == 1
        assert header["inference"]["imgsz"] == 1280 and header["inference"]["iou"] == .7 and header["inference"]["nms"] is True
        state = header["model_state_before_prediction"]
        state_bytes = json.dumps(state["tensors"], sort_keys=True, separators=(",", ":")).encode()
        assert hashlib.sha256(state_bytes).hexdigest() == state["sha256"]
        assert len(state["tensors"]) == state["tensor_count"] and sum(t["bytes"] for t in state["tensors"]) == state["tensor_bytes"]
        same([(i["threshold"], i["image_id"]) for i in items], [(t,i) for t in THRESHOLDS for i in ids], "raw call sequence")
        raw[role] = {(i["threshold"],i["image_id"]):i["predictions"] for i in items}
        record_map = {r["id"]:r for r in records}
        for item in items:
            source = record_map[item["image_id"]]
            assert item["role"] == role and item["record_type"] == "prediction"
            assert item["image_sha256"] == source["image_sha256"] and item["original_label_sha256"] == source["label_sha256"]
            assert (item["width"],item["height"]) == (1280,720) and item["predict_call_wall_ms"] > 0
            assert all(p["confidence"] >= item["threshold"] for p in item["predictions"])
        for reference, ref in references.items():
            saved = read(run/f"scoring-{role}-{reference}.json")
            for threshold in THRESHOLDS:
                report = saved[str(threshold)]
                reports[role,reference,threshold] = report
                scores, qualities, states = [], [], {}
                same([r["image_id"] for r in report["per_image"]], ids, "score image ordering")
                for image, entry in zip(ids, report["per_image"]):
                    predictions, gold = raw[role][threshold,image], ref[image]
                    score = score_image(gold,predictions,1280,720,.5,.5)
                    quality = quality_for_image(gold,predictions,1280,720,RADII)
                    same(score,entry["score"],(role,reference,threshold,image,"score"))
                    same(quality,entry["quality"],(role,reference,threshold,image,"quality"))
                    states[image] = independent_objects(gold,predictions,score)
                    same(states[image],entry["objects"],(role,reference,threshold,image,"object states"))
                    scores.append(score); qualities.append(quality)
                same(aggregate_scores(scores),report["score"],"aggregate score")
                same(aggregate_quality(qualities),report["quality"],"aggregate quality")
                pooled = groups([r for rows in states.values() for r in rows])
                same(pooled,report["groups_by_locatable_corners"],"independent corner groups")
                same({int(k):v["reference_objects"] for k,v in pooled.items()},denominators[reference],"all-reference group denominators")
                for r in RADII:
                    q = next(q for q in report["quality"]["radii"] if q["radius_px"] == r)
                    same(pooled["2"]["radii"][RADII.index(r)]["both_visible_objects_within_radius"],q["both_visible_objects_within_radius"],"independent all-eligible both-corner count")
                subsets = {"empty":[i for i in ids if not ref[i]], "nonempty":[i for i in ids if ref[i]]}
                subsets.update({f"{a:03d}_{b:03d}":[i for i in ids if a <= int(i.split('_')[-1]) <= b] for a,b in [(7,11),(53,59),(86,90),(146,148)]})
                for name, image_ids in subsets.items():
                    target = report["by_scene" if name in ("empty","nonempty") else "by_filename_range"][name]
                    positions = [ids.index(i) for i in image_ids]
                    same(aggregate_scores([scores[i] for i in positions]),target["score"],"subset score")
                    same(aggregate_quality([qualities[i] for i in positions]),target["quality"],"subset quality")
                miss_free = [i for i,s in zip(ids,scores) if ref[i] and s["fn"] == 0]
                same(miss_free,report["miss_free_nonempty_image_ids"],"miss-free scenes")
                same({i:len(raw[role][threshold,i]) for i in ids if not ref[i]},report["empty_image_predictions"],"empty scenes")
                recomputed[role,reference,threshold] = {f"{image}:{r['reference_row_one_based']}":r for image,rows in states.items() for r in rows}
                if reference == "primary":
                    same(set(report["focus"]), {"new_000008:33","new_000009:57"}, "fixed focus identities")
                    for object_id, saved_focus in report["focus"].items():
                        image_id, row = object_id.rsplit(":",1)
                        target = ref[image_id][int(row)-1]
                        proposals = raw[role][threshold,image_id]
                        iou, pi = max(((overlap(target["bbox_xyxy"],prediction["bbox_xyxy"]),index)
                                       for index,prediction in enumerate(proposals)), default=(0,None))
                        expected_focus = {**states[image_id][int(row)-1], "reference_geometry":target,
                                          "max_proposal_iou":iou,
                                          "max_overlap_prediction_index_zero_based":pi if iou > 0 else None,
                                          "max_overlap_raw_prediction":proposals[pi] if iou > 0 else None}
                        # Algebraically equivalent area expressions can differ at
                        # the final floating-point bit; every identity stays exact.
                        assert math.isclose(saved_focus["max_proposal_iou"],iou,rel_tol=1e-14,abs_tol=1e-15)
                        same({key:value for key,value in saved_focus.items() if key != "max_proposal_iou"},
                             {key:value for key,value in expected_focus.items() if key != "max_proposal_iou"},
                             "independent focus outcome")
                compact[f"{role}/{reference}/{threshold}"] = {k:report["score"][k] for k in ("gold_count","prediction_count","tp","fn","fp","duplicate_fp","other_fp","visible_endpoints","returned_endpoints","missing_endpoints")}
                compact[f"{role}/{reference}/{threshold}"].update(both_corners={str(r):pooled['2']['radii'][RADII.index(r)]['both_visible_objects_within_radius'] for r in RADII},miss_free_nonempty_images=miss_free)
    comparison = read(run/"comparison.json")
    assert comparison["experiment_id"] == "visible-extent-seed46-v1"
    assert comparison["mode"] == "fresh_inference" and comparison["primary_confidence"] == .13
    assert comparison["thresholds"] == list(THRESHOLDS)
    assert comparison["fresh_image_prediction_calls"] == 120 and comparison["warmup_calls_excluded"] == 3
    for (role,reference,threshold), report in reports.items():
        same(comparison["metrics"][role][reference][str(threshold)],
             {key:report[key] for key in ("score","quality","groups_by_locatable_corners", "miss_free_nonempty_image_ids", "empty_image_predictions", "focus")},
             "comparison summary is the audited reference/threshold report")
    changes = {}
    for reference in references:
        for before,after in (("old_reviewed","extended_reviewed"),("current","old_reviewed"),("current","extended_reviewed")):
            for threshold in THRESHOLDS:
                a,b = recomputed[before,reference,threshold],recomputed[after,reference,threshold]
                expected = comparison["comparisons"][reference][f"{after}-vs-{before}"][str(threshold)]
                gained = [i for i in a if not a[i]["matched"] and b[i]["matched"]]
                lost = [i for i in a if a[i]["matched"] and not b[i]["matched"]]
                corners = {str(r):{change:[i for i in a if a[i]["both_visible_within_radius"][str(r)] == (change == "lost") and b[i]["both_visible_within_radius"][str(r)] == (change == "gained")] for change in ("gained","lost")} for r in RADII}
                same(gained,expected["gained_object_ids"],"gained object identities")
                same(lost,expected["lost_object_ids"],"lost object identities")
                same(corners,expected["both_corner_changes"],"corner gain/loss identities")
                changes[f"{after}-vs-{before}/{reference}/{threshold}"] = {"gained":gained,"lost":lost,"both_corner_changes":corners,
                    "availability_changes":[{"object_id":i,"before":a[i]["endpoint_returned"],"after":b[i]["endpoint_returned"]} for i in a if a[i]["endpoint_returned"] != b[i]["endpoint_returned"]]}
    identical_calls = sum(raw["old_reviewed"][key] == raw["current"][key] for key in raw["current"])
    old_current_tensors_identical = headers["old_reviewed"]["model_state_before_prediction"] == headers["current"]["model_state_before_prediction"]
    old_tensors = headers["old_reviewed"]["model_state_before_prediction"]["tensors"]
    new_tensors = headers["extended_reviewed"]["model_state_before_prediction"]["tensors"]
    same([(t['name'],t['shape'],t['dtype']) for t in old_tensors],[(t['name'],t['shape'],t['dtype']) for t in new_tensors],"tensor layout")
    changed_tensors = [a['name'] for a,b in zip(old_tensors,new_tensors) if a['sha256'] != b['sha256']]
    tensor_comparisons = {}
    for before,after in (("old_reviewed","extended_reviewed"),("current","old_reviewed"),("current","extended_reviewed")):
        aa = headers[before]["model_state_before_prediction"]["tensors"]
        bb = headers[after]["model_state_before_prediction"]["tensors"]
        same([(t["name"],t["shape"],t["dtype"]) for t in aa],[(t["name"],t["shape"],t["dtype"]) for t in bb],"tensor layouts")
        tensor_comparisons[f"{after}-vs-{before}"] = {"tensor_lists_identical": aa == bb, "changed_tensor_names": [a["name"] for a,b in zip(aa,bb) if a["sha256"] != b["sha256"]], "ordered_prediction_arrays_identical": sum(raw[before][key] == raw[after][key] for key in raw[before]), "total_prediction_arrays":len(raw[before])}
    review_map = check_review_map(primary,read(run/"reference-review-notes.json"),comparison)
    prior_current = compare_prior_current(args.prior_current_zip,raw["current"],headers["current"],records) if args.prior_current_zip else None
    availability = {}
    for reference in references:
        for threshold in THRESHOLDS:
            partition = availability_partition(recomputed["old_reviewed",reference,threshold],
                recomputed["extended_reviewed",reference,threshold],raw["old_reviewed"],raw["extended_reviewed"],threshold)
            for role in ("old_reviewed","extended_reviewed"):
                q = reports[role,reference,threshold]["quality"]
                summed = {field:sum(row[role][field] for row in partition["partition_counts"].values())
                          for field in ("matched_objects","unlocatable_opportunities","returned_on_unlocatable")}
                same(summed,{"matched_objects":q["tp"],"unlocatable_opportunities":q["unlocatable_on_matched_objects"],
                             "returned_on_unlocatable":q["returned_on_unlocatable_reference"]},"availability decomposition reconciles")
            availability[f"{reference}/{threshold}"] = partition
    result = {"schema_version":1,"kind":"independent-visible-extent-result-replay-audit","status":"passed",
        "created_at_utc":datetime.now(timezone.utc).isoformat(),"run_identity_sha256":sha(run/'identity.json'),
        "script_sha256":sha(__file__),"source_revision":SOURCE,"source_driver_sha256":identity['driver_sha256'],
        "command":[sys.executable,*sys.argv],"verified_counts":{"fresh_image_calls":120,"per_image_scores":240,"per_image_quality_records":240,"full_aggregates":12,"subset_aggregates":72,"independent_object_group_summaries":12},
        "reference_corner_group_denominators":denominators,"runtime":headers['old_reviewed']['runtime'],
        "model_hashes":MODELS,"model_state_digests":{r:headers[r]['model_state_before_prediction']['sha256'] for r in ROLES},
        "old_current_exact_ordered_prediction_calls":identical_calls,"old_current_tensor_lists_identical":old_current_tensors_identical,
        "tensor_comparisons":tensor_comparisons,"reference_uncertainty":review_map,"prior_current_prediction_comparison":prior_current,
        "v0_availability_decomposition":availability,
        "extended_changed_tensors":len(changed_tensors),"tensor_count":len(old_tensors),"changed_tensor_names":changed_tensors,
        "metrics":compact,"changes":changes,"method":"The new evaluation driver is not imported or replayed. Original score/quality helpers are rerun directly, and a separate greedy matcher, per-object endpoint computation, group denominator/radius aggregation and object-change construction check the driver outputs independently.",
        "limits":["No model loading or new inference. Model bytes are hashed; state tensor hashes are verified for internal consistency and compared from recorded evidence.","All eligible reference objects, including misses, remain in group and both-corner denominators.","Reference-v0 availability disagreements do not establish hidden-coordinate error."]}
    args.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({"status":"passed","output":str(args.output),"sha256":sha(args.output),"verified_counts":result['verified_counts'],"old_current_exact_ordered_prediction_calls":identical_calls,"extended_changed_tensors":len(changed_tensors),"tensor_count":len(old_tensors)}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('root','run','returned-root','current-manifest','output','driver'):
        parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument("--prior-current-zip",type=Path)
    audit(parser.parse_args())
