"""Bind the established evaluation driver to the verified PR43 return."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re

p=argparse.ArgumentParser()
p.add_argument('--root',type=Path,required=True)
p.add_argument('--returned',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args()
root=a.root.resolve(); returned=a.returned.resolve()

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

template=root/'results/verification/baomai-partial-fronts-results-20261111/evaluate_comparison.py'
text=template.read_text()
models={'current':'420c00f73eeba24e587342400878b7d96371d3e745772113809aa705ec8163b1'}
manifests={'current':'c5f07c4445a7b33a679fd4fc896aaf9643d81b4f72d8ca8e4e7179cb0bc691e8'}
for role in ('old_reviewed','extended_reviewed'):
    manifest_path=returned/role/'checkpoint-manifest.json'
    manifest=json.loads(manifest_path.read_text())
    checkpoint=(manifest_path.parent/manifest['checkpoint']['path']).resolve()
    assert checkpoint.is_relative_to(manifest_path.parent.resolve())
    models[role]=sha(checkpoint)
    assert models[role]==manifest['checkpoint']['sha256']
    manifests[role]=sha(manifest_path)

def replace(old,new):
    global text
    assert old in text,old
    text=text.replace(old,new)

replace('Evaluate the fixed PR40 pair','Evaluate the fixed PR43 visible-extent pair')
replace('experiments/partial-fronts-2026-11-11.json','experiments/visible-extent-2026-11-11.json')
replace('428cd853e0991ba138def8ba9ba9b74909bc654ab2d0c9c49e32a5b598479726','42aa275a5d2ed1ccabb786c07b537a8f0d515b27b7804fec2b71e942d6c9022b')
replace('2d8b6f61865100e50742e384fb06dd87c37fb603','d43a58b9456a782ace14e20f0bf7ed2da3572ca1')
replace('THRESHOLDS = (0.15, 0.25, 0.40)','THRESHOLDS = (0.13, 0.15)')
for name,value in [('MODEL_SHA256',models),('MANIFEST_SHA256',manifests)]:
    text,count=re.subn(r'^'+name+r' = \{.*?^\}',name+' = '+json.dumps(value,indent=4),text,count=1,flags=re.M|re.S)
    assert count==1
replace('"scripts/package_partial_front_results.py": "17abedbc58487de7a14344d4fa2657261c79fe0c7be75921c540a142afcb75e9"',
        '"scripts/package_visible_extent_results.py": "'+sha(root/'scripts/package_visible_extent_results.py')+'"')
replace('from package_partial_front_results import','from package_visible_extent_results import')
replace('device="cpu", conf=.15, **api["inference"]','device="cpu", conf=THRESHOLDS[0], **api["inference"]')
replace('require(len(items) == 60, "replay must contain 60 real image predictions")',
        'require(len(items) == len(THRESHOLDS) * len(preflight["records"]), "replay real-image prediction count differs")')
replace('"experiment_id": "partial-fronts-seed46-v1"','"experiment_id": "visible-extent-seed46-v1"')
replace('"primary_confidence": .15','"primary_confidence": THRESHOLDS[0]')
replace('"fresh_image_prediction_calls": 0 if args.replay_directory else 180',
        '"fresh_image_prediction_calls": 0 if args.replay_directory else len(ROLES) * len(THRESHOLDS) * len(references["primary"])')
replace('"scored_image_reference_threshold_pairs": 360',
        '"scored_image_reference_threshold_pairs": len(ROLES) * len(THRESHOLDS) * sum(len(rows) for rows in references.values())')
replace('reports[role]["primary"]["0.15"]["score"]','reports[role]["primary"][str(THRESHOLDS[0])]["score"]')
replace('verified extracted PR40 bundle','verified extracted PR43 bundle')
assert 'package_partial_front_results' not in text
assert 'partial-fronts-seed46-v1' not in text
assert 'PENDING' not in text
ast.parse(text)
compile(text,str(a.output),'exec')
a.output.write_text(text)
binding={'driver_sha256':sha(a.output),'template_sha256':sha(template),
         'training_revision':'d43a58b9456a782ace14e20f0bf7ed2da3572ca1',
         'model_sha256':models,'checkpoint_manifest_sha256':manifests,
         'thresholds':[0.13,0.15],'planned_real_prediction_calls':120,
         'planned_image_reference_threshold_scores':240}
a.output.with_name('driver-binding.json').write_text(json.dumps(binding,indent=2)+'\n')
print(json.dumps(binding,indent=2))
