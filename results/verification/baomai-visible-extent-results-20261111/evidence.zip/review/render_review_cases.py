"""Render original crops and saved-prediction overlays; no inference or label edits."""
import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

RUN = Path('/workspace/scratch/11398f9f3638/pr43-evaluation/run-001')
SRC = Path('/workspace/scratch/11398f9f3638/pr43-return/source')
OUT = Path(__file__).parent
FONT = ImageFont.truetype('DejaVuSans.ttf', 13)
SMALL = ImageFont.truetype('DejaVuSans.ttf', 11)
ROLES = ['old_reviewed', 'extended_reviewed']
COLORS = {'old_reviewed': '#ff4daa', 'extended_reviewed': '#00cfff'}
PRED = {}
SCORE = {}
for role in ROLES:
    records = [json.loads(line) for line in (RUN/f'predictions-{role}.jsonl').read_text().splitlines()]
    PRED[role] = {r['image_id']: r['predictions'] for r in records if r['record_type']=='prediction' and r['threshold']==0.13}
    SCORE[role] = {r['image_id']: r['score'] for r in json.loads((RUN/f'scoring-{role}-primary.json').read_text())['0.13']['per_image']}

def iou(a,b):
    inter = max(0,min(a[2],b[2])-max(a[0],b[0]))*max(0,min(a[3],b[3])-max(a[1],b[1]))
    union=(a[2]-a[0])*(a[3]-a[1])+(b[2]-b[0])*(b[3]-b[1])-inter
    return inter/union if union else 0

def refs(image_id):
    result=[]
    for row,line in enumerate((SRC/f'data/references/visible-front-2026-11-11/labels/val/{image_id}.txt').read_text().splitlines(),1):
        f=list(map(float,line.split()));x,y,w,h=f[1:5]
        result.append({'row':row, 'bbox_xyxy':[(x-w/2)*1280,(y-h/2)*720,(x+w/2)*1280,(y+h/2)*720], 'keypoints':[[f[5]*1280,f[6]*720,f[7]],[f[8]*1280,f[9]*720,f[10]]]})
    return result

# Indices are zero-based prediction positions; reference rows are one-based.
CASES=[
 ('090_loss43',90,(375,640,505,720),4,[('old_reviewed',45),('extended_reviewed',45)]),
 ('090_gap48',90,(650,435,765,520),4,[('old_reviewed',53),('extended_reviewed',53),('extended_reviewed',56)]),
 ('090_device',90,(1180,640,1280,720),4,[('old_reviewed',57),('extended_reviewed',48)]),
 ('007_match15',7,(855,0,970,50),4,[('old_reviewed',52),('old_reviewed',53),('extended_reviewed',52),('extended_reviewed',53)]),
 ('007_removed_top',7,(625,0,745,45),4,[('old_reviewed',57)]),
 ('009_added_top',9,(495,0,640,45),4,[('extended_reviewed',74)]),
 ('009_removed_left',9,(580,425,685,500),4,[('old_reviewed',59)]),
 ('010_added_hand',10,(425,575,605,685),3,[('extended_reviewed',31)]),
 ('011_removed_right',11,(720,415,830,490),4,[('old_reviewed',65)]),
 ('011_added_left',11,(585,435,685,510),4,[('extended_reviewed',66)]),
 ('054_bottom',54,(480,375,635,480),3,[('old_reviewed',22),('extended_reviewed',24),('extended_reviewed',25)]),
 ('055_added_top',55,(390,0,550,45),4,[('extended_reviewed',28)]),
 ('059_reclassified',59,(615,385,815,480),3,[('old_reviewed',18),('extended_reviewed',18)]),
 ('089_left_assignment',89,(555,445,685,515),4,[('old_reviewed',53),('old_reviewed',56),('extended_reviewed',53),('extended_reviewed',59)]),
 ('089_removed_gap',89,(650,420,780,490),4,[('old_reviewed',58)]),
]

manifest=[]
for name, num, roi, scale, selected in CASES:
    image_id=f'new_{num:06d}'
    original=Image.open(SRC/f'data/images/val/{image_id}.png').convert('RGB')
    seedboxes=[PRED[role][image_id][idx]['bbox_xyxy'] for role,idx in selected]
    nearby={role:[i for i,p in enumerate(PRED[role][image_id]) if any(iou(p['bbox_xyxy'],b)>=.10 for b in seedboxes)] for role in ROLES}
    nearbyrefs=[r for r in refs(image_id) if any(iou(r['bbox_xyxy'],b)>=.05 for b in seedboxes)]
    crop=original.crop(roi).resize(((roi[2]-roi[0])*scale,(roi[3]-roi[1])*scale),Image.Resampling.NEAREST)
    h=crop.height+32; canvas=Image.new('RGB',(crop.width,3*h),'#ffffff')
    for panel,role in enumerate([None]+ROLES):
        ybase=panel*h+32; canvas.paste(crop,(0,ybase));draw=ImageDraw.Draw(canvas)
        title=f'{image_id} original {roi}' if role is None else f'{role}; p=index0, r=row1; green=reference'
        draw.text((5,panel*h+6),title,font=FONT,fill='black')
        if role is None: continue
        def xy(x,y): return ((x-roi[0])*scale,(y-roi[1])*scale+ybase)
        def box(b,color,label):
            left,top=xy(b[0],b[1]);right,bottom=xy(b[2],b[3])
            # Clip display to this crop rather than draw across panels.
            left=max(0,left);right=min(crop.width-1,right);top=max(ybase,top);bottom=min(ybase+crop.height-1,bottom)
            if right>left and bottom>top:
                draw.rectangle((left,top,right,bottom),outline=color,width=2)
                draw.text((left+2,top+2),label,font=SMALL,fill=color,stroke_width=1,stroke_fill='black')
        for ref in nearbyrefs:
            box(ref['bbox_xyxy'],'#42ef65',f"r{ref['row']}")
            for x,y,v in ref['keypoints']:
                if v:
                    X,Y=xy(x,y)
                    if 0<=X<crop.width and ybase<=Y<ybase+crop.height:draw.ellipse((X-3,Y-3,X+3,Y+3),fill='#42ef65')
        for idx in nearby[role]:
            pred=PRED[role][image_id][idx];col=COLORS[role]
            box(pred['bbox_xyxy'],col,f'p{idx} {pred["confidence"]:.3f}')
            for x,y,c in pred['keypoints']:
                X,Y=xy(x,y)
                if 0<=X<crop.width and ybase<=Y<ybase+crop.height:
                    draw.ellipse((X-3,Y-3,X+3,Y+3),outline=col,fill=col if c>=.5 and 0<=x<1280 and 0<=y<720 else None,width=1)
    canvas.save(OUT/f'{name}.png')
    crop.save(OUT/f'{name}_raw.png')
    manifest.append({'case':name,'image_id':image_id,'roi_xyxy':roi,'selected_predictions':selected,'context_predictions_by_role':nearby,'reference_rows':[r['row'] for r in nearbyrefs],'figure':f'{name}.png'})
(OUT/'figure-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
