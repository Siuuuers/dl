"""Persist the completed bounded original-pixel review; source remains read-only."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

OUT=Path(__file__).parent
SRC=Path('/workspace/scratch/11398f9f3638/pr43-return/source')
RUN=Path('/workspace/scratch/11398f9f3638/pr43-evaluation/run-001')
Q=json.loads((OUT/'queue.json').read_text())

OBS={
 ('old_reviewed','new_000007',57):('007_removed_top','removed_top_band_alternative','The thin top-edge box covers an upper portion of the already represented top-clipped front associated with reference row4. No separating contour establishes an additional physical front in this strip. The broader row4 proposal remains. Do not treat the removed strip as a certified lost physical instance.'),
 ('old_reviewed','new_000009',59):('009_removed_left','removed_overlapping_occlusion_alternative','The box crosses the exposed left strips and gripper around neighboring rows50/51. Those visible fronts remain represented and matched. Several overlapping alternatives remain; the diagnostic one-to-one association cannot identify a persistent neural proposal lineage.'),
 ('extended_reviewed','new_000009',74):('009_added_top','added_top_band_alternative_no_new_front','The added 5.64px-high top-edge box lies within the already represented clipped front associated with row4. The original shows no independent separating face for this extra strip. No new instance or corner is accepted.'),
 ('extended_reviewed','new_000010',31):('010_added_hand','added_occlusion_alternative_no_new_front','The added spatially unpaired box repeats the hand-occluded region of existing rows31/32, with much of its width on the hand. The visible left material and existing matches remain; no additional distinct front is demonstrated. A right coordinate on the hand is not a newly observed hidden corner.'),
 ('old_reviewed','new_000011',65):('011_removed_right','removed_duplicate_of_retained_partial_front','This alternative spans the right jaw and the same exposed right-side cassette fragment associated with row60. The primary row60 proposal remains in the extended outputs. Removal does not demonstrate loss of a separately observed front.'),
 ('extended_reviewed','new_000011',66):('011_added_left','added_duplicate_of_retained_partial_front','This additional broad box repeats the lowest exposed strip left of the jaw associated with row58 and extends across the gripper. Row58 was already represented and remains matched. No distinct extra front is supported.'),
 ('old_reviewed','new_000054',22):('054_bottom','removed_alternative_across_existing_fronts','This alternative overlaps the already represented lower stack, particularly rows21/22. Both physical fronts remain visible and matched; the removed box does not establish an independently lost instance.'),
 ('extended_reviewed','new_000054',24):('054_bottom','added_lower_front_and_rack_spill','The added box encloses part of the already represented bottom front and extends into the rack/base below it. The original does not show a separate cassette front at that lower extent. No new instance is accepted.'),
 ('extended_reviewed','new_000054',25):('054_bottom','added_lower_band_and_rack_spill','This lower shifted alternative crosses the existing bottom-front lower region and rack/base. It does not establish a further cassette below the stack. No new instance is accepted.'),
 ('extended_reviewed','new_000055',28):('055_added_top','added_top_band_alternative_no_new_front','The thin upper-frame proposal covers the top band of the already represented truncated front associated with row22. No distinct physical front boundary is established for an additional instance at the image edge.'),
 ('old_reviewed','new_000089',58):('089_removed_gap','removed_duplicate_of_retained_gap_front','This box repeats the existing upper jaw-gap front associated with row46. The extended model retains a matched proposal for that front and neighboring surfaces. No separate physical front is lost by this extra removal.'),
 ('old_reviewed','new_000090',57):('090_device','removed_background_proposal_other_background_outputs_remain','The cropped region is blue device/background material, not an observed cassette front. This removed proposal is a supported background error; two other proposals remain on the same device region, so it is not a cleaned-up scene.'),
 ('extended_reviewed','new_000090',56):('090_gap48','added_duplicate_of_retained_gap_front','The new box repeats the already represented lower jaw-gap fragment associated with row48. The actual outer lower corners remain unavailable behind the jaws; this is neither a new physical front nor a newly recovered corner pair.'),
}

unpaired=[]
for r in Q['unpaired_proposals']:
    key=(r['role'],r['image_id'],r['prediction_index_zero_based'])
    figure,disposition,observation=OBS[key]
    unpaired.append({**r,'visual_disposition':disposition,'observation':observation,'figure':figure+'.png','original_crop':figure+'_raw.png','new_physical_instance_accepted':False,'reference_change_accepted':False,'review_status':'independent_original_pixel_review_and_root_concurrence'})
assert len(unpaired)==len(OBS)==13

paired=[]
for r in Q['paired_official_status_changes']:
    img=r['image_id']
    if img=='new_000007':
        figure='007_competition_clean.png'; finding='A thin and a tall proposal exist in both runs. The old thin proposal already has both reference-corner errors within5px but ranks below the old tall proposal. The extended thin proposal ranks above its tall competitor and receives the official match. The 10px pair gain is an assignment-selection outcome among already available alternatives, not a newly discovered front or the first useful thin localization. The new thin left-corner error is worse than the old thin alternative.'
    elif img=='new_000059':
        figure='059_reclassified.png'; finding='The paired box still spans the same lower central front/occluder region. Small geometry changes alter duplicate-versus-other scoring; the separately matched row19 proposal remains. This is not a new physical object or physical disappearance.'
    elif img=='new_000089':
        figure='089_left_assignment.png'; finding='Competing boxes for the same partially visible lower-left-of-jaw front remain. Which associated box receives row43 changes while the row stays matched. Diagnostic greedy pairing is not a claim of persistent proposal lineage, and no additional physical front is established.'
    else:
        assert img=='new_000090'
        figure='090_loss_clean.png'; finding='The supported partially hand-occluded front remains proposed by a nearly identical box. Fixed-reference IoU changes0.5024810504206354 to0.4971769530366893, crossing the unchanged0.50 rule. This is a lost scored match, not disappearance of the proposal. Both boxes include excess roof/hand/background; both return a right coordinate on the hand where the true lower corner is unavailable.'
    paired.append({**r,'figure':figure,'observation':finding,'new_physical_instance_accepted':False,'reference_change_accepted':False,'review_status':'independent_original_pixel_review_and_root_concurrence'})
assert len(paired)==6

ids=['new_000090','new_000007','new_000009','new_000010','new_000011','new_000054','new_000055','new_000089','new_000059']
inventory=[]
for image_id in ids:
    p=SRC/f'data/images/val/{image_id}.png';label=SRC/f'data/references/visible-front-2026-11-11/labels/val/{image_id}.txt'
    inventory.append({'image_id':image_id,'image_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'primary_label_sha256':hashlib.sha256(label.read_bytes()).hexdigest(),'full_original_viewed_before_overlay':True})

record={
 'schema_version':1,'kind':'bounded_pr43_original_pixel_prediction_review','status':'complete_with_root_concurrence','created_at_utc':datetime.now(timezone.utc).isoformat(),
 'primary_confidence':0.13,'reference':'baomai-visible-front-2026-11-11','reference_manifest_sha256':'2e60b3e81195448cc565a1000b4305e3215baba2bf0ee0c976e6551c2e64937c',
 'scope':'Nine full original validation images viewed before overlays. Fifteen original-crop/comparison groups cover every primary gained/lost object, all13 spatially unpaired proposals, all6 paired official assignment/status changes,007:15 competition, and090:48 missing-corner output changes. This is not a complete twenty-image relabel or certification.',
 'association_criterion':Q['association_criterion'],'association_limits':'Some unpaired proposals have IoU>=0.50 with an already-used counterpart. Unpaired means unmatched under the declared one-to-one diagnostic pairing, not spatially novel or physically distinct. All status changes are separately reviewed so an assignment switch cannot silently hide a new duplicate/extra.',
 'source_hashes':Q['source_hashes'],'original_image_review_inventory':inventory,
 'primary_gained_object_ids':Q['gained_object_ids'],'primary_lost_object_ids':Q['lost_object_ids'],
 'unpaired_proposal_count':13,'extended_unpaired_count':7,'old_unpaired_count':6,'paired_official_status_change_count':6,
 'unpaired_proposals':unpaired,'paired_official_status_changes':paired,
 'corner_competition_007':json.loads((OUT/'007_competition.json').read_text()),
 'missing_corner_output_review':{
   'new_returns_on_reference_unlocatable_sides_among_still_matched_objects':Q['new_returns_on_reference_unlocatable_sides'],
   'removed_returns_on_reference_unlocatable_sides_among_still_matched_objects':Q['removed_returns_on_reference_unlocatable_sides'],
   'case':'new_000090:48','observation':'Both true outer lower corners of the partial jaw-gap front remain unavailable. Old matched53 returned both coordinates; extended matched53 has endpoint confidences0.4859151542186737 and0.4558163583278656, so neither passes0.50. This reduced unsupported output is consistent with missing-corner handling; it establishes no hidden-coordinate accuracy. The new extra56 also has both endpoint confidences below0.50.',
   'figure':'090_gap48.png','review_status':'independent_original_pixel_review_and_root_concurrence'},
 'root_concurrence':{
   'status':'concurred_after_independent_review','reviewer':'root assistant',
   'evidence_scope':'Root reports inspecting the nine full originals, all15 raw crops, and all15 comparison panels; requested the separate clean007 competition figure and exact old-thin corner errors.',
   'conclusions':'No separately supported newly recovered front. Added outputs repeat represented regions or spill into rack base/occluder. Removed device proposal is background while other device errors persist.090:43 survives with nearly identical erroneous extent;090:48 suppression aligns unavailable outer corners.007:15 score gain requires the competing-proposal interpretation.',
   'limits':'Bounded review only; no full validation relabel or certification.'},
 'reference_uncertainty':'All19 inherited unresolved reference dispositions and the separate011:61 caveat remain unchanged. No reference row, point, denominator, or matching rule is changed after prediction inspection.',
 'outcome':'No additional independently supported front recovery is established by this primary comparison. Record the exact scoring tradeoffs without presenting the090:43 loss as proposal absence or the007:15 gain as newly available localization.',
 'actions_not_performed':['No model inference or training by this review agent','No source, label, split or reference modification','No automatic model promotion'],
 'figure_manifest':'figure-manifest.json','clean_competition_figure':'007_competition_clean.png','clean_lost_match_figure':'090_loss_clean.png',
}
(OUT/'visual-review.json').write_text(json.dumps(record,indent=2)+'\n')
inventory={}
for p in sorted(OUT.iterdir()):
    if p.is_file() and p.name!='visual-review-inventory.json':
        inventory[p.name]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size_bytes':p.stat().st_size}
(OUT/'visual-review-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
for name in ['visual-review.json','queue.json','007_competition.json','007_competition_clean.png','090_loss_clean.png','090_loss43.png','090_gap48.png','figure-manifest.json','visual-review-inventory.json']:
    p=OUT/name;print(name,hashlib.sha256(p.read_bytes()).hexdigest(),p.stat().st_size)
