import json
import sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

OUT=Path(__file__).parent
Q=json.loads((OUT/'queue.json').read_text())
case=next(x for x in Q['paired_official_status_changes'] if x['image_id']=='new_000090')
SRC=Path('/workspace/scratch/11398f9f3638/pr43-return/source')
sys.path.insert(0,str(SRC/'scripts'))
from evaluate_pose import parse_pose_labels
label=SRC/'data/references/visible-front-2026-11-11/labels/val/new_000090.txt'
ref=parse_pose_labels(label.read_text(),1280,720,str(label))[42]
im=Image.open('/workspace/scratch/11398f9f3638/pr43-return/source/data/images/val/new_000090.png').convert('RGB')
roi=(385,650,495,718);scale=4
crop=im.crop(roi).resize((440,272),Image.Resampling.NEAREST)
canvas=Image.new('RGB',(1360,445),'white');draw=ImageDraw.Draw(canvas)
title=ImageFont.truetype('DejaVuSans.ttf',23);font=ImageFont.truetype('DejaVuSans.ttf',16)
draw.text((15,10),'090:43 remains proposed while fixed-reference IoU crosses 0.50',font=title,fill='black')
headings=[('Original pixels','Unchanged 1280 × 720 source'),('Old reviewed control','IoU 0.502481: official match'),('Extended reviewed candidate','IoU 0.497177: scored extra')]
yb=105
for col,(heading,sub) in enumerate(headings):
    x0=col*460;draw.text((x0+6,52),heading,font=font,fill='black');draw.text((x0+6,76),sub,font=font,fill='black');canvas.paste(crop,(x0,yb))
    if col==0:continue
    pred=case['before' if col==1 else 'after']['prediction'];color='#ee168c' if col==1 else '#007eb8'
    def xy(x,y):return x0+(x-roi[0])*scale,yb+(y-roi[1])*scale
    for obj,c in [(ref,'#12b438'),(pred,color)]:
        a,b,d,e=obj['bbox_xyxy'];left,top=xy(a,b);right,bottom=xy(d,e)
        draw.rectangle((left,top,right,bottom),outline=c,width=2)
        for px,py,v in obj['keypoints']:
            if obj is ref and not v:continue
            X,Y=xy(px,py);draw.ellipse((X-4,Y-4,X+4,Y+4),fill=c)
draw.text((15,389),'Green: frozen reference and its visible left corner. Magenta/blue: prediction 45 in each run (zero-based).',font=font,fill='black')
draw.text((15,416),'Both boxes include excess material. The true right corner is hidden; each returned right point lies on the hand.',font=font,fill='black')
canvas.save(OUT/'090_loss_clean.png')
