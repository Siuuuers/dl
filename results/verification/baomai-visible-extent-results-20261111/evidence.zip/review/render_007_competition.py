import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

OUT=Path(__file__).parent
D=json.loads((OUT/'007_competition.json').read_text())
im=Image.open('/workspace/scratch/11398f9f3638/pr43-return/source/data/images/val/new_000007.png').convert('RGB')
roi=(855,0,970,45);scale=4
crop=im.crop(roi).resize((460,180),Image.Resampling.NEAREST)
font=ImageFont.truetype('DejaVuSans.ttf',15)
small=ImageFont.truetype('DejaVuSans.ttf',13)
title=ImageFont.truetype('DejaVuSans.ttf',19)
canvas=Image.new('RGB',(940,820),'white');draw=ImageDraw.Draw(canvas)
draw.text((16,10),'007:15 — two competing proposals remain in each model',font=title,fill='black')
draw.text((16,40),'Original pixels first; green = fixed reference; magenta = old; blue = extended.',font=font,fill='black')
canvas.paste(crop,(240,72));draw.text((240,255),'Original crop x855–970, y0–45; nearest-neighbor ×4',font=small,fill='black')

def panel(item,x0,y0):
    role=item['role'];pred=item['prediction'];col='#ee168c' if role=='old_reviewed' else '#007eb8'
    state='official match' if item['official_match'] else 'scored duplicate'
    kind='tall' if (role=='old_reviewed' and item['prediction_index_zero_based']==52) or (role=='extended_reviewed' and item['prediction_index_zero_based']==53) else 'thin'
    draw.text((x0,y0),f'{role}: {kind}, p{item["prediction_index_zero_based"]}, {state}',font=small,fill='black')
    e=item['endpoint_errors_px'];draw.text((x0,y0+21),f'Confidence {pred["confidence"]:.6f}; errors L/R {e[0]:.2f}/{e[1]:.2f} px',font=small,fill='black')
    yb=y0+45;canvas.paste(crop,(x0,yb))
    def xy(x,y):return x0+(x-roi[0])*scale,yb+(y-roi[1])*scale
    for obj,color in [(D['reference'],'#12b438'),(pred,col)]:
        a,b,c,d=obj['bbox_xyxy'];left,top=xy(a,b);right,bottom=xy(c,d)
        draw.rectangle((left,top,right,bottom),outline=color,width=2)
        for px,py,v in obj['keypoints']:
            X,Y=xy(px,py);draw.ellipse((X-4,Y-4,X+4,Y+4),fill=color)

lookup={(p['role'],p['prediction_index_zero_based']):p for p in D['proposals']}
panel(lookup['old_reviewed',52],0,290)
panel(lookup['extended_reviewed',53],480,290)
panel(lookup['old_reviewed',53],0,540)
panel(lookup['extended_reviewed',52],480,540)
draw.text((16,786),'Prediction indices are zero-based. Errors use the frozen original-size row 15 corners.',font=small,fill='black')
canvas.save(OUT/'007_competition_clean.png')
