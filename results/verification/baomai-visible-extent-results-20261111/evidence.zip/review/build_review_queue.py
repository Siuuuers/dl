"""Read-only saved-prediction association for bounded visual review; no scoring edits."""
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/scratch/11398f9f3638/pr43-evaluation/run-001')
OUT = Path(__file__).parent
CONF = '0.13'

def read(name):
    return json.loads((ROOT / name).read_text())

def predictions(role):
    records = [json.loads(line) for line in (ROOT / f'predictions-{role}.jsonl').read_text().splitlines()]
    return {r['image_id']: r['predictions'] for r in records if r['record_type'] == 'prediction' and str(r['threshold']) == CONF}

def iou(a, b):
    ix = max(0.0, min(a[2], b[2]) - max(a[0], b[0]))
    iy = max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    inter = ix * iy
    union = (a[2]-a[0])*(a[3]-a[1]) + (b[2]-b[0])*(b[3]-b[1]) - inter
    return inter / union if union > 0 else 0.0

old = predictions('old_reviewed')
new = predictions('extended_reviewed')
current = predictions('current')
scores = {role: {x['image_id']: x for x in read(f'scoring-{role}-primary.json')[CONF]['per_image']} for role in ['old_reviewed', 'extended_reviewed']}

def status(role, image_id, idx):
    s = scores[role][image_id]['score']
    for match in s['matches']:
        if match['prediction_index'] == idx:
            return {'kind': 'matched', 'reference_row_one_based': match['gold_index']+1, 'reference_iou': match['iou']}
    return {'kind': 'duplicate_extra' if idx in s['duplicate_prediction_indices'] else 'other_extra'}

def record(role, image_id, idx):
    preds = old[image_id] if role == 'old_reviewed' else new[image_id]
    return {'role': role, 'image_id': image_id, 'prediction_index_zero_based': idx,
            'prediction_id_one_based': idx+1, 'score_status': status(role, image_id, idx), 'prediction': preds[idx]}

associations = []
unpaired = []
status_changes = []
new_unlocatable_returns = []
removed_unlocatable_returns = []
for image_id in old:
    a, b = old[image_id], new[image_id]
    candidates = [(iou(x['bbox_xyxy'], y['bbox_xyxy']), i, j) for i, x in enumerate(a) for j, y in enumerate(b) if x['class_id'] == y['class_id']]
    candidates.sort(key=lambda t: (-t[0], t[1], t[2]))
    used_a, used_b = set(), set()
    for overlap, i, j in candidates:
        if overlap < 0.5:
            break
        if i in used_a or j in used_b:
            continue
        used_a.add(i); used_b.add(j)
        pa, pb = record('old_reviewed', image_id, i), record('extended_reviewed', image_id, j)
        associations.append({'image_id': image_id, 'old_index_zero_based': i, 'new_index_zero_based': j, 'iou': overlap})
        # Numeric IoU drift by itself is not a change of official assignment/status.
        sa, sb = pa['score_status'], pb['score_status']
        if (sa['kind'], sa.get('reference_row_one_based')) != (sb['kind'], sb.get('reference_row_one_based')):
            status_changes.append({'image_id': image_id, 'association_iou': overlap, 'before': pa, 'after': pb})
    for role, vals, used, others in [('old_reviewed', a, used_a, b), ('extended_reviewed', b, used_b, a)]:
        for idx, pred in enumerate(vals):
            if idx in used:
                continue
            best = max([(iou(pred['bbox_xyxy'], x['bbox_xyxy']), j) for j, x in enumerate(others)], default=(0, None))
            unpaired.append({**record(role, image_id, idx), 'best_other_iou': best[0], 'best_other_index_zero_based': best[1]})
    oa = {x['reference_row_one_based']: x for x in scores['old_reviewed'][image_id]['objects']}
    ob = {x['reference_row_one_based']: x for x in scores['extended_reviewed'][image_id]['objects']}
    for row, x in oa.items():
        y = ob[row]
        if not (x['matched'] and y['matched']):
            continue
        for side in range(2):
            if x['reference_endpoint_visible'][side]:
                continue
            if x['endpoint_returned'][side] != y['endpoint_returned'][side]:
                change = {'image_id': image_id, 'reference_row_one_based': row, 'side': ['left', 'right'][side],
                          'before': record('old_reviewed', image_id, x['prediction_index_zero_based']),
                          'after': record('extended_reviewed', image_id, y['prediction_index_zero_based'])}
                (new_unlocatable_returns if y['endpoint_returned'][side] else removed_unlocatable_returns).append(change)

comparison = read('comparison.json')['comparisons']['primary']['extended_reviewed-vs-old_reviewed'][CONF]
result = {
    'status': 'queue_prepared_not_yet_visually_reviewed', 'confidence': float(CONF),
    'association_criterion': 'Within each image and class, greedily pair boxes by descending pair IoU >= 0.50, breaking ties by old then new zero-based index; one-to-one. Uses saved post-NMS predictions. Diagnostic correspondence only, not physical identity or ground truth.',
    'coverage': 'Review all gained/lost frozen-reference rows, every spatially unpaired proposal in either direction (including extras and duplicates), and every paired official assignment/status change. Also flag newly returned points on reference-unlocatable sides among still-matched objects. This does not visually certify all paired proposals.',
    'source_hashes': {n: hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['comparison.json', 'predictions-old_reviewed.jsonl', 'predictions-extended_reviewed.jsonl', 'scoring-old_reviewed-primary.json', 'scoring-extended_reviewed-primary.json']},
    'old_and_current_prediction_arrays_exactly_equal': old == current,
    'gained_object_ids': comparison['gained_object_ids'], 'lost_object_ids': comparison['lost_object_ids'],
    'associations': associations, 'unpaired_proposals': unpaired, 'paired_official_status_changes': status_changes,
    'new_returns_on_reference_unlocatable_sides': new_unlocatable_returns,
    'removed_returns_on_reference_unlocatable_sides': removed_unlocatable_returns,
}
(OUT/'queue.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({'paired_count': len(associations), 'unpaired': [{k:x[k] for k in ['role', 'image_id', 'prediction_index_zero_based', 'score_status', 'best_other_iou', 'best_other_index_zero_based']} for x in unpaired], 'status_changes': [{'image_id': x['image_id'], 'association_iou': x['association_iou'], 'old': x['before']['score_status'], 'new': x['after']['score_status'], 'old_index': x['before']['prediction_index_zero_based'], 'new_index': x['after']['prediction_index_zero_based']} for x in status_changes], 'new_unlocatable_count': len(new_unlocatable_returns), 'removed_unlocatable_count': len(removed_unlocatable_returns), 'old_current_exact': old == current}, indent=2))
