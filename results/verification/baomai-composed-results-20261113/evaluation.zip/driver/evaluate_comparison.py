#!/usr/bin/env python3
"""Run the prospectively fixed PR58 comparison using unchanged scoring helpers."""

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import signal
import sys
import time

sys.dont_write_bytecode = True
ROLES = ("reference", "candidate", "current")
PROTOCOL_PATH = "experiments/composed-fronts-2026-11-12.json"
PROTOCOL_SHA256 = "2e73d4d81585e8ed1759bdb02aea98d8c9db3a856f8887ef9f41069eb799fa3f"
ORIGINAL_SHA256 = "72ae8365d5abf0b45b75d400a2e6d22119c0e31b54ee33035feb8edc1f967926"
REFERENCES = {
    "primary": ("data/references/visible-front-adjudication-2026-11-12/manifest.json", "75e8689f65f7f32ca7f4657f27d214aa1ba371347812de780c6e5e6ac21af61e", (663, 1227, 3)),
    "sensitivity": ("data/references/visible-front-corners-2026-11-12/manifest.json", "28ba06fe7183ebbfa6f295639194a67c4b473c17a8d67c28a9733eb359bdba92", (663, 1228, 3)),
}
MODEL_SHA256 = {
    "reference": "a3d9fdc2cf1fa067340ad4f38c9a345e7d480c298852e56b992adaeb9c8d1387",
    "candidate": "7c5f3114dfaeff58a873647d31e1be26e16a1941d3d20890c6a613ab853e41fb",
    "current": "420c00f73eeba24e587342400878b7d96371d3e745772113809aa705ec8163b1",
}
MANIFEST_SHA256 = {
    "reference": "8b02feb1a81faabeb50063734ff0cbbd1cbc6b7d2fe4b7be33d59220ec692c4b",
    "candidate": "d3178bfbfda1335a70e51dd14d7306698b5682dfb22b6a6cb091250dd5df2d39",
    "current": "c5f07c4445a7b33a679fd4fc896aaf9643d81b4f72d8ca8e4e7179cb0bc691e8",
}
HELPER_PATH = "results/verification/baomai-endpoint-results-20261112/evaluate_comparison.py"
SOURCE_SHA256 = {
    HELPER_PATH: "54a66f22775fc8dbc1469a651991977d1f145efee99427bca6835e693abde64c",
    "scripts/evaluate_pose.py": "3f80bd09efbe97327b705ffe6ad3e662111f3e2bc71b69b51a9d38d7baa90ce0",
    "scripts/pose_scoring.py": "04e5cdbef26df978707d0b6e4b82f05471b6012845f7986b9c05c71644ec0018",
    "scripts/diagnose_pose_quality.py": "a3baa1285d1580ee44547f7c3d606f524f2f40616fed568885746d2014159953",
    "scripts/pose_checkpoint.py": "f902c34720283480f948cca78bd2d6d24fd07bf6bc5a325945172d56d55f5bd5",
    "scripts/package_composed_results.py": "1883edcf48c0f2b8ffd1ae77e950e60002934268f1fb91a05b4cae34b7896aa9",
    "scripts/package_gpu_results.py": "120b1a3d22f9cb8896af67a84b7d3da686d89e41b63d5889eb7fb106bdce477c",
    "scripts/verify_pose_composed_candidate.py": "e538dfce5de0b1fb10047bbce0598882ee1083825ed6061469c85a3daf08bd32",
    "scripts/verify_pose_endpoint_candidate.py": "9adcf9805ba9ee6fbe252c05903bab5a997e9e7c5063362d77e1f5fcccdb53d5",
    "scripts/verify_pose_annotation_candidate.py": "0dc3d263b4aad594e1019de8f8318dcd963d9c0c2f4604ad2dee408c83af7979",
    "scripts/verify_pose_candidate.py": "03395b9a82a4c120647a1cac51c89fd214d8cf9b15c04e2196a40f39077d8491",
    "scripts/verify_pose_box_candidate.py": "f8613b9b310f25930a9d47169650473d3fbc0a1032868dd80222d956d26e1ea5",
    "scripts/restore_gpu_inputs.py": "dbe0e2658d9752e5dcd244f377f5f4ed4e18b63d5f52fc73ff3f1ddd85768aa0",
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def pinned(path, expected):
    require(sha256(path) == expected, f"file SHA256 differs: {path}")


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def load_helpers(root):
    for path, expected in SOURCE_SHA256.items():
        pinned(root / path, expected)
    spec = importlib.util.spec_from_file_location("previous_comparison_helpers", root / HELPER_PATH)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    helper.MODEL_SHA256 = MODEL_SHA256
    helper.ROLES = ROLES
    sys.path.insert(0, str(root / "scripts"))
    from evaluate_pose import (INFERENCE, _prediction_records, _runtime_and_model,
                               _source_identity, parse_pose_labels, preflight_dataset)
    from pose_scoring import _box_iou, _percentile, aggregate_scores, score_image
    from diagnose_pose_quality import _returned, aggregate_quality, quality_for_image
    api = dict(inference=INFERENCE, predictions=_prediction_records, model=_runtime_and_model,
               source=_source_identity, iou=_box_iou, percentile=_percentile, score=score_image,
               aggregate=aggregate_scores, returned=_returned, quality=quality_for_image,
               aggregate_quality=aggregate_quality)
    return helper, api, preflight_dataset, parse_pose_labels


def load_inputs(root, returned, current_manifest, helper, preflight_dataset, parse_labels):
    from package_composed_results import validate_protocol, collect_composed_run, check_composed_pair
    from pose_checkpoint import select_checkpoint
    pinned(root / PROTOCOL_PATH, PROTOCOL_SHA256)
    pinned(root / "data/manifest.json", ORIGINAL_SHA256)
    context = validate_protocol(root)
    original = preflight_dataset(root, require_weights=False)
    bundles = {role: collect_composed_run(original, returned / role, role, context) for role in ROLES[:2]}
    check_composed_pair(bundles, context)
    for role, bundle in bundles.items():
        require(bundle["receipt"]["source"]["revision"] == "082ea773426b6422f859c68b8b6ec8496ef07df0", "training revision differs")
        for path, expected in bundle["receipt"]["source"]["files_sha256"].items():
            pinned(root / path, expected)
    selected = {}
    for role in ROLES:
        manifest = current_manifest if role == "current" else returned / role / "checkpoint-manifest.json"
        pinned(manifest, MANIFEST_SHA256[role])
        selected[role] = select_checkpoint(original, manifest, require_weights=True)
        require(selected[role]["model_sha256"] == MODEL_SHA256[role], f"model identity differs: {role}")
    references, inventories, notes = {}, {}, {}
    for name, (path, expected, counts) in REFERENCES.items():
        pinned(root / path, expected)
        manifest = helper.read_json(root / path)
        files = {row["image_id"]: row for row in manifest["files"]}
        require(len(files) == len(manifest["files"]) == 20 and set(files) == {r["id"] for r in original["records"]}, "reference image set differs")
        references[name], inventories[name] = [], []
        for source in original["records"]:
            entry = files[source["id"]]
            require(entry["image_sha256"] == source["image_sha256"] and [entry["width"], entry["height"]] == [1280, 720], "reference image identity differs")
            require(entry["label_path"] == f"labels/val/{source['id']}.txt", "reference mapping differs")
            label = (root / path).parent / entry["label_path"]
            pinned(label, entry["label_sha256"])
            gold = parse_labels(label.read_text(), 1280, 720, str(label))
            require(len(gold) == entry["row_count"], "reference row count differs")
            references[name].append({**source, "label_path": str(label), "label_sha256": entry["label_sha256"], "gold": gold})
            inventories[name].append({"image_id": source["id"], "image_sha256": source["image_sha256"], "original_label_sha256": source["label_sha256"], "primary_label_sha256": entry["label_sha256"], "width": 1280, "height": 720})
        actual = (sum(len(r["gold"]) for r in references[name]), sum(p[2] == 2 for r in references[name] for g in r["gold"] for p in g["keypoints"]), sum(not r["gold"] for r in references[name]))
        require(actual == counts, f"reference counts differ: {name}")
        if name == "primary":
            for row in manifest["queue_dispositions"]:
                mapped = files[row["image_id"]]["retained_source_to_revised_row_one_based"][row["source_row_one_based"] - 1]
                if mapped is not None:
                    notes.setdefault(f"{row['image_id']}:{mapped}", {})["queue_disposition"] = row
            for row in manifest["edits"]:
                if row.get("revised_row_one_based") is not None:
                    notes.setdefault(f"{row['image_id']}:{row['revised_row_one_based']}", {}).setdefault("accepted_edits", []).append(row)
    references["original"] = original["records"]
    identities = {"protocol_sha256": PROTOCOL_SHA256, "primary_reference_sha256": REFERENCES["primary"][1],
                  "sensitivity_reference_sha256": REFERENCES["sensitivity"][1], "original_reference_sha256": ORIGINAL_SHA256,
                  "source_helpers_sha256": SOURCE_SHA256, "image_reference_inventory": inventories["primary"],
                  "sensitivity_image_reference_inventory": inventories["sensitivity"],
                  "checkpoints": {role: data["checkpoint_identity"] for role, data in selected.items()},
                  "returned_training_source": bundles["reference"]["receipt"]["source"],
                  "returned_training_runtime": bundles["reference"]["receipt"]["runtime"]}
    return selected, references, identities, notes


def run(args):
    root, returned, output = args.root.resolve(), args.returned_root.resolve(), args.output.resolve()
    require(not output.is_relative_to(root), "write evidence outside source")
    output.mkdir(parents=True, exist_ok=False)
    started = time.perf_counter()
    helper, api, preflight, parse_labels = load_helpers(root)
    os.environ["YOLO_CONFIG_DIR"] = str(output / "runtime-config")
    blocked = helper.disable_network()
    try:
        selected, references, identities, notes = load_inputs(root, returned, args.current_manifest.resolve(), helper, preflight, parse_labels)
        source = api["source"](root)
        require(source["working_tree_status"] == "", "fresh inference requires clean committed source")
        identities.update(source=source, driver_sha256=sha256(__file__), command=[sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]], created_at_utc=datetime.now(timezone.utc).isoformat())
        write_json(output / "identity.json", identities)
        (output / "protocol.json").write_bytes((root / PROTOCOL_PATH).read_bytes())
        write_json(output / "reference-review-notes.json", notes)
        write_json(output / "runtime-packages.json", {d.metadata["Name"]: d.version for d in importlib.metadata.distributions()})
        import torch
        torch.set_num_interop_threads(1)
        reports, headers = {}, {}
        for role in ROLES:
            header, items = helper.infer_role(role, selected[role], output, api, identities)
            headers[role] = {"runtime": header["runtime"], "model_state_before_prediction": header["model_state_before_prediction"], "warmup_wall_ms_excluded": header["warmup_wall_ms_excluded"]}
            reports[role] = {}
            for reference, records in references.items():
                reports[role][reference] = {"0.13": helper.score_records(records, items, api, reference == "primary")}
                write_json(output / f"scoring-{role}-{reference}.json", reports[role][reference])
        require(all(headers[r]["runtime"] == headers[ROLES[0]]["runtime"] for r in ROLES), "inference runtime differs")
        comparison = {}
        for reference in references:
            comparison[reference] = {}
            for before, after in (("reference", "candidate"), ("current", "reference"), ("current", "candidate")):
                data = helper.compare_reports(reports[before][reference]["0.13"], reports[after][reference]["0.13"], notes if reference == "primary" else {})
                data["common_endpoints"] = helper.common_endpoint_comparison(reports[before][reference]["0.13"], reports[after][reference]["0.13"], api)
                comparison[reference][f"{after}-vs-{before}"] = {"0.13": data}
        require(source == api["source"](root), "source changed during evaluation")
        for path, expected in SOURCE_SHA256.items():
            pinned(root / path, expected)
        keys = ("score", "quality", "groups_by_locatable_corners", "miss_free_nonempty_image_ids", "empty_image_predictions", "focus")
        summary = {"status": "complete", "experiment_id": "composed-fronts-seed46-v1", "mode": "fresh_inference",
                   "primary_reference": "primary", "primary_confidence": .13, "thresholds": [.13],
                   "roles": {role: {"checkpoint_identity": selected[role]["checkpoint_identity"], **headers[role]} for role in ROLES},
                   "metrics": {role: {reference: {"0.13": {k: reports[role][reference]["0.13"][k] for k in keys}} for reference in references} for role in ROLES},
                   "comparisons": comparison, "network_events_blocked": blocked, "fresh_image_prediction_calls": 60,
                   "warmup_calls_excluded": 3, "total_wall_seconds": time.perf_counter() - started,
                   "limits": ["PR35 is an operational comparator, not a third training arm.", "Three fixed references are reported separately; no labels, thresholds or models are selected using these results.", "The stored original PNG bytes and finalized checkpoint bytes were verified before fresh inference.", "Unlocatable slots have no measured hidden-coordinate error.", "The same reused development images do not establish unseen-scene performance.", "Single CPU call timings are descriptive, not deployment-camera benchmarks."]}
        write_json(output / "comparison.json", summary)
        write_json(output / "status.json", {"status": "complete", "mode": "fresh_inference", "fresh_image_prediction_calls": 60, "scored_image_reference_threshold_pairs": 180, "total_wall_seconds": time.perf_counter() - started})
        write_json(output / "inventory.json", {p.name: {"sha256": sha256(p), "size_bytes": p.stat().st_size} for p in sorted(output.glob("*.json*"))})
        print(json.dumps({"status": "complete", "output": str(output), "primary_metrics": {r: {k: reports[r]["primary"]["0.13"]["score"][k] for k in ("tp", "fn", "fp")} for r in ROLES}}))
    except Exception as error:
        write_json(output / "status.json", {"status": "incomplete", "error_type": type(error).__name__, "error": str(error), "network_events_blocked": blocked, "total_wall_seconds": time.perf_counter() - started})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--returned-root", type=Path, required=True)
    parser.add_argument("--current-manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    def deadline(signum, frame):
        raise TimeoutError("900-second bounded evaluation deadline reached")
    signal.signal(signal.SIGALRM, deadline)
    signal.setitimer(signal.ITIMER_REAL, 900)
    try:
        run(args)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)


if __name__ == "__main__":
    main()
