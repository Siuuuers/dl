# PR58 public numerical replay capsule

This is a minimized **public derivative** of the completed PR58 evidence capsule. The comparison retains PR35. The derivative contains saved numerical evidence and annotation-review records; it contains **no image bytes, weights, full host package inventory or private absolute workspace paths**.

Read `public-derivation.md` and `public-derivation.json` for the original capsule identity, precise omissions, normalization and unchanged-data checks. The original immutable capsule remains separate; the two archives do not share a file hash.

## Replay

From a newly extracted directory:

```bash
python3 -S -B verify_payload.py
python3 -S -B audit/independent-audit.py \
  --root source \
  --evaluation evaluation \
  --driver driver/evaluate_comparison.py \
  --skip-image-bytes \
  --output /path/to/new-public-replay-audit.json
```

The auditor is byte-identical to the original. Only Python's standard library is needed; no model, GPU, network or inference is used. Expected: verified, **180 image/model/reference cases, 5,970 reference-object states, nine pairwise comparisons and 221,196 scalar/structure checks**. The supplied `audit/public-replay.json` records the run against this derivative.

Replay does not reverify absent image/checkpoint bytes or independently prove the earlier inference. Original per-image prediction-record bytes, frozen labels/manifests, score files, evaluation driver and numerical auditor are preserved. Only the prediction-file metadata headers have symbolic local paths; their new whole-file hashes are indexed in `evaluation/inventory.json`.

## Contents and provenance

- `source/`: exact frozen protocol and three reference label sets.
- `evaluation/`: unchanged prediction arrays, scores and comparison; path-normalized input identity/header records; current file inventory.
- `driver/`: exact previously executed inference driver and source helpers. It requires the separately pinned source checkout and external inputs; this derivative is not a standalone inference distribution.
- `audit/`: unchanged auditor and the new public-derivative arithmetic replay record.
- `provenance/`: unchanged already-public PR35/PR58 training payloads and other provenance; local image/verification paths are normalized where documented.
- `review/`: retained review text, geometry, source-image hashes and crop descriptions. **All referenced PNGs are omitted.** These records document the earlier original-image review; the derivative does not newly perform or reproduce visual adjudication.
- `runtime/requirements-inference.lock.txt`: the previously observed 40-distribution inference version list. Fresh installation from it was not tested. Full host inventories and configuration are omitted.
- `historical/`: original audit and inventory records. Their original hashes and image-verification claims concern the original run/capsule, not this minimized derivative.

`<WORKSPACE>` is a symbolic replacement for the private absolute workspace prefix. No value for it is distributed. Already-public Colab paths in byte-preserved PR35/PR58 receipts and logs remain unchanged.

`payload-inventory.json` is the active list of every other included file. Historical inventories may name omitted images and superseded header hashes; they are retained only as historical records and must not be used to verify this derivative. The external ZIP checksum covers the complete archive.

The selected checkpoint remains PR35 at input 1280, box confidence 0.13, NMS 0.70 and endpoint cutoff 0.50. No new inference, training, threshold selection, label edit or promotion is performed by this derivation. Reused development images do not establish unseen-scene reliability.
