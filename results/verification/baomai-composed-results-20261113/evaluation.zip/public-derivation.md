# Public derivative of the PR58 evidence capsule

This is a new minimized archive, derived from the immutable original capsule **SHA256 `ceaed6f73e7aea16746e605ce920eafa58950596d7ebd765653163a703ac0c37`** (21,215,096 bytes). The original remains unchanged and is not included.

## What was removed or normalized

- Omit **all 80 PNGs**, including six complete training originals and every crop/overlay. Their source-image identities and prior review records remain.
- Omit six host runtime/configuration/capture files and the duplicate full 146-package snapshot. Retain only the observed 40-distribution inference version list under `runtime/`.
- Normalize the private absolute workspace prefix to literal `<WORKSPACE>` in six generated metadata files. The actual local path is not distributed. The prediction files change only in their first run-header line.
- Regenerate the active evaluation and payload inventories. Move original audit/index records to `historical/`; preserve their original bytes and historical meaning.

The exact omitted members, original/public file hashes and normalization scope are recorded in `public-derivation.json`. That file also lists the 150 unchanged copied members.

## What remains exact

All60 per-image prediction-record lines across the three model roles are byte-identical, including their numerical arrays, confidences, image identities and newlines. All60 frozen reference label files, all 64 source files, all nine score files and the aggregate comparison retain their original bytes. The independent auditor, evaluation driver and payload verifier are unchanged.

Already-public PR35/PR58 provenance payloads retain their bytes, including their recorded Colab paths. Historical hashes inside review records continue to identify original prediction files or omitted images; they are not quietly reassigned to normalized derivative files. Current derivative file identities come from the active inventories.

## Verification and limits

The same unmodified auditor verified this derivative: **180 image/model/reference cases, 5,970 reference-object states, nine pairwise comparisons and 221,196 scalar/structure checks**. See `audit/public-replay.json`. Both original-image and checkpoint-byte verification are false in this portable run, as those bytes are absent.

No inference, training, model selection, threshold selection or label edit occurred during derivation. PR35 remains selected. This archive can reproduce the saved arithmetic; it cannot independently reproduce visual adjudication or establish new-session performance.
