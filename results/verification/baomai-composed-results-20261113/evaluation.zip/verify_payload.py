#!/usr/bin/env python3
"""Verify every recorded payload file using only the Python standard library."""
from pathlib import Path, PurePosixPath
import hashlib
import json

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'payload-inventory.json').read_text())
for item in manifest['files']:
    rel = PurePosixPath(item['path'])
    if rel.is_absolute() or '..' in rel.parts:
        raise SystemExit('Unsafe inventory path')
    path = root.joinpath(*rel.parts)
    if not path.is_file() or path.is_symlink():
        raise SystemExit(f'Missing or invalid payload: {rel}')
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    if path.stat().st_size != item['size_bytes'] or digest != item['sha256']:
        raise SystemExit(f'Payload differs: {rel}')
print(json.dumps({'status': 'verified', 'files': len(manifest['files']), 'bytes': sum(x['size_bytes'] for x in manifest['files'])}))
