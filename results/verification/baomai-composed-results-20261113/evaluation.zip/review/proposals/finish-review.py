#!/usr/bin/env python3
"""Record bounded original-first review judgments and numerical context."""
import hashlib
import json
from collections import Counter
from pathlib import Path

root = Path(__file__).resolve().parent
context = json.loads((root/'overlay-context.json').read_text())
raw = json.loads((root/'raw-observations.json').read_text())
raw_by_id = {x['case_id']: x for x in raw['cases']}
cases_index = json.loads((root/'cases.json').read_text())
association = json.loads((root/'associations.json').read_text())
evaluation = root.parent/'evaluation'
score = {role: {x['image_id']: x['score'] for x in json.loads((evaluation/f'scoring-{role}-primary.json').read_text())['0.13']['per_image']} for role in ('current','reference','candidate')}

# These are recorded visual judgments, not labels inferred by a threshold.
notes = {
'P01': ('unresolved', 'Top-border strip only 7.09 px high. A broad proposal for the same stack band persists in all models, and PR35 already returns an almost identical thin proposal. The original pixels do not settle whether the thin strip is a separate lower front. No new physical recovery is established.'),
'P02': ('unresolved', 'Top-border strip only 5.93 px high. The control already returns an almost identical thin proposal; a broad stack-band proposal also persists. Truncation prevents an independent front-identity decision.'),
'P03': ('existing-front alternative', 'Narrow white front material is visible behind the occluder. The surplus PR35 box extends beyond that material into the occluder; the candidate retains several alternatives over the same fronts. This is reduced proposal multiplicity, not disappearance of the physical front.'),
'P04': ('existing-front alternative', 'The target spans an existing partial white-front band and the occluder. Several candidate proposals remain over it. Removing one surplus alternative does not remove this detected region.'),
'P05': ('existing-front alternative', 'Same exposed-front region as P03, now the control output. The target extends across the occluder; candidate alternatives still cover the existing material.'),
'P06': ('existing-front alternative', 'Same upper partial-front region as P04, now the control output. Candidate proposals retain this region; one surplus alternative is absent from the association.'),
'P07': ('background', 'The target covers an upper triangular hardware/non-front surface, not a separately supported lower white-front band. A candidate box still covers the same patch (IoU 0.762), so this is removal of one surplus non-target alternative, not complete suppression of the patch.'),
'P08': ('existing-front alternative', 'A white sliver beside the finger belongs to an already represented partial-front region. All three models match primary row 31; the candidate adds an alternative and its selected row-31 assignment changes. The visible evidence does not show an additional physical front.'),
'P09': ('unresolved', 'The box straddles a white sliver and a finger, with most proposed extent occluded. Existing alternatives survive, but raw pixels do not establish an additional lower front or its hidden extent. The official other-FP status is not used as a physical verdict.'),
'P10': ('unresolved', 'The crop is dominated by hardware/occluder and the exact white-front identity is unclear. The fixed reference treats this as a duplicate near row 60, and candidate p59 still covers the region. This review cannot independently certify that the whole removed box is background.'),
'P11': ('unresolved', 'A truncated top-border band. Multiple alternative extents persist in the candidate; the pixels do not establish a separate lost front.'),
'P12': ('unresolved', 'Same top-border band as P11, now the control output. Truncation and overlapping extents prevent a confident physical additional-front decision.'),
'P13': ('unresolved', 'Same hardware/occluder region as P10, now the control output. It is scored as a duplicate of row 60, but independent physical identity remains uncertain. Candidate p59 persists.'),
'P14': ('existing-front alternative', 'Clear additional wide box across existing white stack bands. A stronger candidate box already covers the same front; the fixed scorer calls the surplus a duplicate near row 9. No distinct additional band is visible.'),
'P15': ('existing-front alternative', 'Clear additional box across adjacent already detected white stack bands. Existing candidate proposals persist, and the target is a scored duplicate near row 16.'),
'P16': ('existing-front alternative', 'PR35 has a surplus box across the existing bottom white stack front. The candidate keeps that front with another box; this is a supported reduction of redundant alternatives relative to PR35.'),
'P17': ('background', 'The control target extends across the basket lip/support rail below the last white front. No separate lower-front band is visible in the added extent. A broader candidate proposal still covers the rail, so the patch is not completely suppressed.'),
'P18': ('existing-front alternative', 'Clear additional wide box across existing neighboring white stack bands. Other candidate proposals already cover these fronts; the fixed scorer calls it a duplicate near row 8.'),
'P19': ('existing-front alternative', 'The target overlaps the existing partially occluded white front and the tool. Multiple candidate alternatives remain; removing one surplus PR35 box is not a physical-front loss.'),
'P20': ('existing-front alternative', 'Same partially occluded front as P19, now the control output. Candidate alternatives persist, so the removed output is a surplus extent around an existing front.'),
'P21': ('unresolved', 'A broad thin proposal at the top image boundary, over material also represented by a stronger surviving candidate box. The cropped front identity and extent are not independently settled; do not infer loss or true-background suppression.'),
'P22': ('existing-front alternative', 'The partial white front remains visible behind the tool. PR35 had an extra overlapping box; candidate p48 still covers the same front with high confidence. This supports a local reduction of redundant alternatives.'),
'P23': ('existing-front alternative', 'A small white front sliver remains beside the occluder. The candidate adds another broad extent covering the sliver and occluder, with other candidate and comparator proposals already present. The area is not a newly recovered separate front.'),
}
assert set(notes) == {x['case_id'] for x in context['cases']}

def h(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def score_status(c):
    s = score[c['target_role']][c['image_id']]
    idx = c['prediction_index']
    for m in s['matches']:
        if m['prediction_index'] == idx:
            return {'category':'matched','gold_row_one_based':m['gold_index']+1,'iou':m['iou']}
    if idx in s['duplicate_prediction_indices']:
        return {'category':'duplicate_fp'}
    assert idx in s['other_fp_prediction_indices']
    return {'category':'other_fp'}

def nearest_delta(c, role):
    near = c['nearest_boxes'][role][0]
    target = c['target_prediction']
    # A nearest box may already be consumed in greedy association. This is not
    # an assertion that it corresponds to the same physical instance.
    before, after = (near,target) if c['target_role']=='candidate' else (target,near)
    d = [b-a for a,b in zip(before['bbox_xyxy'],after['bbox_xyxy'])]
    return {'nearest_role':role, **near,
            'nearest_is_association_pair':False,
            'candidate_minus_comparator_confidence':after['confidence']-before['confidence'],
            'candidate_minus_comparator_bbox_xyxy_px':d,
            'max_absolute_bbox_coordinate_difference_px':max(abs(x) for x in d)}

rows=[]
for c in context['cases']:
    category, decision = notes[c['case_id']]
    near_roles = c['unmatched_against'] if c['target_role']=='candidate' else ['candidate']
    rows.append({
        'case_id':c['case_id'],'image_id':c['image_id'],
        'target_role':c['target_role'],'prediction_index':c['prediction_index'],
        'spatial_status':c['spatial_status'],'unmatched_against':c['unmatched_against'],
        'target_confidence':c['target_prediction']['confidence'],
        'target_bbox_xyxy_px':c['target_prediction']['bbox_xyxy'],
        'physical_review_category':category,'physical_review_decision':decision,
        'raw_observation':raw_by_id[c['case_id']]['observation'],
        'source_image_sha256':raw_by_id[c['case_id']]['source_image_sha256'],
        'official_primary_score_status':score_status(c),
        'nearest_surviving_context':{r:nearest_delta(c,r) for r in near_roles},
        'nearest_primary_reference':c['nearest_boxes']['primary_reference'][0],
        'crop_xyxy_px':c['crop_xyxy'],'overlay':c['overlay'],
        'confirmed_new_distinct_physical_front':False,
    })
summary = {
    'unique_outputs_reviewed':len(rows),
    'category_counts':dict(Counter(x['physical_review_category'] for x in rows)),
    'category_counts_by_role':{r:dict(Counter(x['physical_review_category'] for x in rows if x['target_role']==r)) for r in ('candidate','current','reference')},
    'association_counts':{r:x['counts'] for r,x in association['comparisons'].items()},
    'candidate_addition_case_ids_by_comparator':{r:[x['case_id'] for x in rows if x['target_role']=='candidate' and r in x['unmatched_against']] for r in ('current','reference')},
    'removed_comparator_case_ids':{r:[x['case_id'] for x in rows if x['target_role']==r] for r in ('current','reference')},
    'confirmed_new_distinct_physical_fronts':0,
}
out = {
    'schema_version':1,
    'scope':'All outputs unpaired by fixed same-class greedy IoU 0.50 box association, in either direction, candidate versus PR35 and candidate versus matched control at confidence 0.13. No additional inference, thresholds, training, or reference edits.',
    'index_basis':'Zero-based position in each saved prediction JSON list; G rows are one-based.',
    'method':'Original RGB crops inspected first, then all 23 overlays. Nearest-neighbor 2x enlargement; no synthetic pixels. Reviewer had prior metric/prediction exposure, so this is original-first, not fully blinded. These are AI-assisted review judgments, not a new independently adjudicated ground truth.',
    'category_definitions':{
        'existing-front alternative':'Visible existing front material with overlapping alternative extents already present; no separate new physical front established.',
        'background':'The selected surplus extent chiefly covers a non-target surface, with no supported separate lower-front band; surviving outputs can still cover the same area.',
        'unresolved':'Border truncation, occlusion, or weak visible evidence prevents a confident independent physical-front decision.',
    },
    'limitations':[
        'An unpaired box may still have IoU >= 0.50 with an already consumed box. It does not mean the region is physically new or absent.',
        'The nearest-context confidence/coordinate deltas are descriptive. They are not a verified same-instance change or a match in the greedy association.',
        'The fixed reference score status is reported separately from visual physical interpretation. Other FP does not prove background.',
        'Union counts include separately reviewed PR35/control outputs from the same physical region and must not be treated as a net physical error count.',
        'This review covers the unpaired proposal scope only; it does not adjudicate all surviving outputs, every reference row, or novel images.',
    ],
    'conclusion':'Local redundant-output reductions are visible, but clear new redundant proposals also appear. Two removed control outputs occupy non-front surfaces, yet candidate alternatives still cover those patches. No inspected addition establishes a newly recovered distinct physical cassette front. The review does not establish global false-output suppression or external generalization.',
    'input_sha256':{name:h(root/name) for name in ('associations.json','cases.json','raw-observations.json','overlay-context.json','render-proposal-review.py')},
    'summary':summary,'cases':rows,
}
(root/'decisions.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')

lines = [
'# PR58 proposal review',
'',
'All 23 outputs left unpaired in either direction by fixed IoU 0.50 association were inspected. There is local reduction of redundant output multiplicity, alongside new redundant proposals. No inspected addition establishes a newly recovered distinct physical cassette front. Border and heavily occluded cases remain unresolved.',
'',
'## Scope and method',
'',
'At confidence 0.13, same-class box pairs were sorted by descending IoU, then zero-based before/candidate indexes, and selected greedily at IoU >= 0.50. This review association is separate from the official prediction-to-reference scorer. A box can remain unpaired even when it overlaps another already-paired box. Therefore “added” and “removed” below mean unpaired output multiplicity, not physical appearance or disappearance.',
'',
'Exact original RGB crops were inspected before model/reference overlays. The six raw contact sheets and frozen raw notes precede the 23 overlay sheets. The reviewer had already seen numerical metrics and predictions: this is original-first, not fully blinded, and it is AI-assisted review rather than independent human ground-truth adjudication. No training, threshold search, extra inference, or reference changes were performed.',
'',
'| Comparison | Paired outputs | Comparator-only | Candidate-only | Total before → after |',
'|---|---:|---:|---:|---:|',
]
for role,label in [('current','Candidate versus PR35'),('reference','Candidate versus matched control')]:
    z=association['comparisons'][role]['counts']
    lines.append(f"| {label} | {z['paired']} | {z['before_only']} | {z['candidate_only']} | {z['before_total']} → {z['candidate_total']} |")
lines += [
'',
'The union is eight candidate outputs, seven PR35 outputs, and eight control outputs. The categories below concern physical interpretation; official duplicate/other-FP status is kept separately. Union counts are not independent physical-object counts.',
'',
'| Target role | Existing-front alternative | Non-front/background | Unresolved |',
'|---|---:|---:|---:|',
]
for role in ('candidate','current','reference'):
    q=summary['category_counts_by_role'][role]
    lines.append(f"| {role} | {q.get('existing-front alternative',0)} | {q.get('background',0)} | {q.get('unresolved',0)} |")
lines += [
'',
'## Findings',
'',
'- The clearest added redundant boxes are P14/P15/P18: candidate `new_000053:p21`, `new_000053:p22`, and `new_000057:p21`. Each spans already detected stack bands. Their official primary statuses are duplicate FP.',
'- P03–P06, P16, P19/P20, and P22 show removals of surplus alternatives around existing fronts. The physical front and other proposals persist. This supports local changes in proposal multiplicity, not a claim that all false outputs disappeared.',
'- P07 and P17 are removed control surplus extents over a non-front surface or support rail. Candidate boxes still cover those patches, with nearest IoU 0.762 and 0.567 respectively. These regions are not completely suppressed.',
'- P01/P02/P11/P12/P21 are truncated border cases. P09 and P10/P13 are heavily occluded or ambiguous. They remain unresolved rather than being called background because of a scoring category.',
'- P08 is an additional extent around a partial front already matched as primary row 31 by all models; it is not a new physical recovery. P23 is an alternative around an already represented white sliver and occluder.',
'',
'## Complete case list',
'',
'Indexes below are zero-based positions in saved prediction lists. G rows in overlays are one-based annotation rows. Confidence is the target output confidence. “Nearest candidate” or “nearest comparator” context, all coordinate/confidence differences, raw observations, original SHA256 values, and scoring statuses are preserved in `decisions.json`; nearest context is not a greedy association pair.',
'',
'| Case | Image | Role:index | Confidence | Physical interpretation | Fixed primary score | Overlay |',
'|---|---|---|---:|---|---|---|',
]
for x in rows:
    s=x['official_primary_score_status']; ss=s['category']
    if 'gold_row_one_based' in s: ss+=f" G{s['gold_row_one_based']}"
    lines.append(f"| {x['case_id']} | {x['image_id']} | {x['target_role']}:{x['prediction_index']} | {x['target_confidence']:.6f} | {x['physical_review_category']} | {ss} | [{x['case_id']}]({x['overlay']['path']}) |")
lines += [
'',
'## Evidence and reproduction',
'',
'- `raw-contact-sheet-1.png` through `raw-contact-sheet-6.png`: original pixels without model or reference overlays.',
'- `raw-observations.json`: observations recorded before viewing overlays.',
'- `associations.json` and `cases.json`: exact selection algorithm, every association, prediction hashes, source image hashes, crop coordinates, and selected outputs.',
'- `overlay-P01.png` through `overlay-P23.png`: PR35, control, candidate, and primary-reference context. A magenta dashed guide in other panels is the selected target location, not another model prediction.',
'- `overlay-context.json` and `decisions.json`: quantitative context and review decisions. Pixel differences describe nearest surviving boxes, not independently identified physical-instance changes.',
'',
'The renderer needs Pillow, DejaVu Sans, the source checkout with the exact original images, and the saved evaluation. It does not load model weights. Regenerate to a separate output directory, inspect raw sheets and record observations there, then run overlays:',
'',
'```bash',
'python render-proposal-review.py raw --repo /path/to/dl --evaluation /path/to/evaluation --output /path/to/review',
'python render-proposal-review.py overlay --repo /path/to/dl --evaluation /path/to/evaluation --output /path/to/review',
'```',
'',
'Offline numerical replay is a separate evaluation/audit capability. These image review judgments require the source pixels and cannot be established from metric replay alone.',
]
(root/'review.md').write_text('\n'.join(lines)+'\n')
files = sorted(p for p in root.iterdir() if p.is_file() and p.name != 'inventory.json')
(root/'inventory.json').write_text(json.dumps({'schema_version':1,'files':[{'path':p.name,'bytes':p.stat().st_size,'sha256':h(p)} for p in files]},indent=2)+'\n')
print(json.dumps(summary,indent=2))
