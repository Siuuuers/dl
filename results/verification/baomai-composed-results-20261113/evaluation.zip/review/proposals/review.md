# PR58 proposal review

All 23 outputs left unpaired in either direction by fixed IoU 0.50 association were inspected. There is local reduction of redundant output multiplicity, alongside new redundant proposals. No inspected addition establishes a newly recovered distinct physical cassette front. Border and heavily occluded cases remain unresolved.

## Scope and method

At confidence 0.13, same-class box pairs were sorted by descending IoU, then zero-based before/candidate indexes, and selected greedily at IoU >= 0.50. This review association is separate from the official prediction-to-reference scorer. A box can remain unpaired even when it overlaps another already-paired box. Therefore “added” and “removed” below mean unpaired output multiplicity, not physical appearance or disappearance.

Exact original RGB crops were inspected before model/reference overlays. The six raw contact sheets and frozen raw notes precede the 23 overlay sheets. The reviewer had already seen numerical metrics and predictions: this is original-first, not fully blinded, and it is AI-assisted review rather than independent human ground-truth adjudication. No training, threshold search, extra inference, or reference changes were performed.

| Comparison | Paired outputs | Comparator-only | Candidate-only | Total before → after |
|---|---:|---:|---:|---:|
| Candidate versus PR35 | 721 | 7 | 7 | 728 → 728 |
| Candidate versus matched control | 721 | 8 | 7 | 729 → 728 |

The union is eight candidate outputs, seven PR35 outputs, and eight control outputs. The categories below concern physical interpretation; official duplicate/other-FP status is kept separately. Union counts are not independent physical-object counts.

| Target role | Existing-front alternative | Non-front/background | Unresolved |
|---|---:|---:|---:|
| candidate | 5 | 0 | 3 |
| current | 5 | 0 | 2 |
| reference | 3 | 2 | 3 |

## Findings

- The clearest added redundant boxes are P14/P15/P18: candidate `new_000053:p21`, `new_000053:p22`, and `new_000057:p21`. Each spans already detected stack bands. Their official primary statuses are duplicate FP.
- P03–P06, P16, P19/P20, and P22 show removals of surplus alternatives around existing fronts. The physical front and other proposals persist. This supports local changes in proposal multiplicity, not a claim that all false outputs disappeared.
- P07 and P17 are removed control surplus extents over a non-front surface or support rail. Candidate boxes still cover those patches, with nearest IoU 0.762 and 0.567 respectively. These regions are not completely suppressed.
- P01/P02/P11/P12/P21 are truncated border cases. P09 and P10/P13 are heavily occluded or ambiguous. They remain unresolved rather than being called background because of a scoring category.
- P08 is an additional extent around a partial front already matched as primary row 31 by all models; it is not a new physical recovery. P23 is an alternative around an already represented white sliver and occluder.

## Complete case list

Indexes below are zero-based positions in saved prediction lists. G rows in overlays are one-based annotation rows. Confidence is the target output confidence. “Nearest candidate” or “nearest comparator” context, all coordinate/confidence differences, raw observations, original SHA256 values, and scoring statuses are preserved in `decisions.json`; nearest context is not a greedy association pair.

| Case | Image | Role:index | Confidence | Physical interpretation | Fixed primary score | Overlay |
|---|---|---|---:|---|---|---|
| P01 | new_000007 | candidate:57 | 0.136141 | unresolved | other_fp | [P01](overlay-P01.png) |
| P02 | new_000009 | candidate:73 | 0.135683 | unresolved | other_fp | [P02](overlay-P02.png) |
| P03 | new_000009 | current:54 | 0.657215 | existing-front alternative | other_fp | [P03](overlay-P03.png) |
| P04 | new_000009 | current:59 | 0.462283 | existing-front alternative | other_fp | [P04](overlay-P04.png) |
| P05 | new_000009 | reference:55 | 0.655431 | existing-front alternative | other_fp | [P05](overlay-P05.png) |
| P06 | new_000009 | reference:59 | 0.458641 | existing-front alternative | other_fp | [P06](overlay-P06.png) |
| P07 | new_000009 | reference:76 | 0.130288 | background | other_fp | [P07](overlay-P07.png) |
| P08 | new_000010 | candidate:30 | 0.509050 | existing-front alternative | matched G31 | [P08](overlay-P08.png) |
| P09 | new_000010 | candidate:37 | 0.153352 | unresolved | other_fp | [P09](overlay-P09.png) |
| P10 | new_000011 | current:65 | 0.144465 | unresolved | duplicate_fp | [P10](overlay-P10.png) |
| P11 | new_000011 | current:67 | 0.131763 | unresolved | other_fp | [P11](overlay-P11.png) |
| P12 | new_000011 | reference:65 | 0.137793 | unresolved | other_fp | [P12](overlay-P12.png) |
| P13 | new_000011 | reference:66 | 0.136625 | unresolved | duplicate_fp | [P13](overlay-P13.png) |
| P14 | new_000053 | candidate:21 | 0.641615 | existing-front alternative | duplicate_fp | [P14](overlay-P14.png) |
| P15 | new_000053 | candidate:22 | 0.389490 | existing-front alternative | duplicate_fp | [P15](overlay-P15.png) |
| P16 | new_000054 | current:22 | 0.609144 | existing-front alternative | duplicate_fp | [P16](overlay-P16.png) |
| P17 | new_000054 | reference:24 | 0.307113 | background | other_fp | [P17](overlay-P17.png) |
| P18 | new_000057 | candidate:21 | 0.340587 | existing-front alternative | duplicate_fp | [P18](overlay-P18.png) |
| P19 | new_000059 | current:18 | 0.472842 | existing-front alternative | duplicate_fp | [P19](overlay-P19.png) |
| P20 | new_000059 | reference:18 | 0.428635 | existing-front alternative | duplicate_fp | [P20](overlay-P20.png) |
| P21 | new_000059 | reference:21 | 0.132397 | unresolved | other_fp | [P21](overlay-P21.png) |
| P22 | new_000089 | current:58 | 0.442315 | existing-front alternative | duplicate_fp | [P22](overlay-P22.png) |
| P23 | new_000090 | candidate:51 | 0.292368 | existing-front alternative | other_fp | [P23](overlay-P23.png) |

## Evidence and reproduction

- `raw-contact-sheet-1.png` through `raw-contact-sheet-6.png`: original pixels without model or reference overlays.
- `raw-observations.json`: observations recorded before viewing overlays.
- `associations.json` and `cases.json`: exact selection algorithm, every association, prediction hashes, source image hashes, crop coordinates, and selected outputs.
- `overlay-P01.png` through `overlay-P23.png`: PR35, control, candidate, and primary-reference context. A magenta dashed guide in other panels is the selected target location, not another model prediction.
- `overlay-context.json` and `decisions.json`: quantitative context and review decisions. Pixel differences describe nearest surviving boxes, not independently identified physical-instance changes.

The renderer needs Pillow, DejaVu Sans, the source checkout with the exact original images, and the saved evaluation. It does not load model weights. Regenerate to a separate output directory, inspect raw sheets and record observations there, then run overlays:

```bash
python render-proposal-review.py raw --repo /path/to/dl --evaluation /path/to/evaluation --output /path/to/review
python render-proposal-review.py overlay --repo /path/to/dl --evaluation /path/to/evaluation --output /path/to/review
```

Offline numerical replay is a separate evaluation/audit capability. These image review judgments require the source pixels and cannot be established from metric replay alone.
