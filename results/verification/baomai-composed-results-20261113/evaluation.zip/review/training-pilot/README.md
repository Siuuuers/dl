# Six-image original-first training review

Date: 2026-11-13 (Hong Kong). No model predictions were opened and no labels were changed.

The deterministic cohort was saved in `selection.json` before viewing image pixels. It contains `new_000001`, `new_000013`, `new_000027`, `old_000004`, `old_000010`, and `new_000133`: 117 existing object rows. All six original PNG and label hashes match the frozen baomai manifest. Full raw images were inspected before their original-label overlays.

## Supported findings

- `new_000027`: the first two white frontal strips at the upper-left frame boundary are identifiable, top-clipped cassette fronts and have no source labels. Their exact new boxes and endpoint coordinates are not yet accepted. The two exact review ROIs are `[0,0,86,25]` and `[82,0,325,25]`; these ROIs are not training boxes. The first left corner is outside the frame. Other soft corner placements remain unresolved rather than being silently marked missing. Parent-agent review independently agrees with the two identity findings.
- `old_000010`, source row1: the front continues visibly to the upper frame boundary, while the current box starts at y=16.3056024px. One supported proposal changes only `y_min` to0. All other box bounds and both endpoint tokens stay fixed. This is a bounded correction, not a full tight-box certification.
- `new_000133`: the original supports the empty label. The gripper and basket are background for this target.

## Unresolved findings

Additional very thin fragments farther right along `new_000027`'s top edge are not automatically accepted as objects. `new_000013` row34 and `new_000001` rows42–43 have boxes extending through gripper-covered space; the visible-front identities remain, but exact tighter bounds are not accepted here. No hidden endpoint is filled. No unequivocal new edit was established in `old_000004`.

## Evidence and limits

`review.json` contains exact source rows, before/proposed coordinates, statuses and evidence paths. `originals/` contains hash-verified originals; `overlays/` shows only frozen source labels; `crops/` contains original/overlay views with coordinates and nearest-neighbor zoom factors in `crop-index.json`. `original-first-notes.json` preserves observations written before label-overlay inspection.

All six originals and117 source rows were viewed, with detailed adjudication confined to the recorded issues. This is assistant review, not certification of all annotations or independent test evidence. There are **zero new ready-to-train label files**, **two supported omitted-object identities**, and **one precise box-bound proposal**. No performance improvement or new training run follows automatically from this review.

Root assistant independently inspected the full original and top crop of `old_000010` before the overlay and supports the single-bound proposal. `root-adjudication.json` records the exact proposed row and unchanged tokens, without applying it to a training dataset. It also records the updated coverage union: 70/137 images; 67 remain (57 nonempty, 10 empty).
