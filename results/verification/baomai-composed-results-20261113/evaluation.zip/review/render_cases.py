#!/usr/bin/env python3
"""Render exact reference and saved-prediction comparisons on original pixels."""
import argparse
import hashlib
import json
import math
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def iou(a,b):
    z=max(0,min(a[2],b[2])-max(a[0],b[0]))*max(0,min(a[3],b[3])-max(a[1],b[1]))
    u=(a[2]-a[0])*(a[3]-a[1])+(b[2]-b[0])*(b[3]-b[1])-z
    return z/u if u else 0

def gold(text):
    out=[]
    for line in text.splitlines():
        a=list(map(float,line.split()))
        out.append({'bbox_xyxy':[(a[1]-a[3]/2)*1280,(a[2]-a[4]/2)*720,(a[1]+a[3]/2)*1280,(a[2]+a[4]/2)*720],
                    'keypoints':[[a[5]*1280,a[6]*720,a[7]],[a[8]*1280,a[9]*720,a[10]]]})
    return out

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('source','evaluation','images','output'):p.add_argument('--'+n,type=Path,required=True)
    args=p.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    refs={'primary':'visible-front-adjudication-2026-11-12','sensitivity':'visible-front-corners-2026-11-12'}
    comp=json.loads((args.evaluation/'comparison.json').read_text())
    roles=('current','reference','candidate')
    predictions={r:{x['image_id']:x for x in map(json.loads,(args.evaluation/f'predictions-{r}.jsonl').read_text().splitlines()[1:])} for r in roles}
    reports={ref:{r:json.loads((args.evaluation/f'scoring-{r}-{ref}.json').read_text())['0.13'] for r in roles} for ref in refs}
    cases=set()
    for ref in refs:
        for by_t in comp['comparisons'][ref].values():
            t=by_t['0.13']
            for obj in t['gained_object_ids']+t['lost_object_ids']:cases.add(obj)
            for x in t['both_corner_changes'].values():cases.update(x['gained']+x['lost'])
    font_path='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    font=ImageFont.truetype(font_path,18);small=ImageFont.truetype(font_path,15);large=ImageFont.truetype(font_path,24)
    records=[]
    for key in sorted(cases):
        image_id,num=key.split(':');idx=int(num)-1
        image_path=args.images/(image_id+'.png');im=Image.open(image_path).convert('RGB')
        assert im.size==(1280,720)
        for ref in (['primary','sensitivity'] if key=='new_000010:28' else ['primary']):
            label=args.source/'data/references'/refs[ref]/'labels/val'/(image_id+'.txt')
            g=gold(label.read_text())[idx]
            selected={};all_boxes=[g['bbox_xyxy']]
            for role in roles:
                row=next(x for x in reports[ref][role]['per_image'] if x['image_id']==image_id)
                s=row['objects'][idx];preds=predictions[role][image_id]['predictions']
                assert predictions[role][image_id]['image_sha256']==sha(image_path)
                ranked=sorted([(iou(g['bbox_xyxy'],x['bbox_xyxy']),i,x) for i,x in enumerate(preds)],reverse=True)
                pi=s['prediction_index_zero_based'] if s['matched'] else ranked[0][1]
                pred=preds[pi];all_boxes.append(pred['bbox_xyxy'])
                selected[role]={'official_state':s,'shown_prediction_index_zero_based':pi,'shown_prediction':pred,
                                'shown_prediction_iou':iou(g['bbox_xyxy'],pred['bbox_xyxy']),
                                'shown_prediction_endpoint_errors_px':[math.hypot(a[0]-b[0],a[1]-b[1]) if b[2]==2 else None for a,b in zip(pred['keypoints'],g['keypoints'])],
                                'overlapping_alternatives':[{'index_zero_based':i,'iou':v,'prediction':x} for v,i,x in ranked if v>=.15 and i!=pi]}
            x0=max(0,math.floor(min(b[0] for b in all_boxes))-28);x1=min(1280,math.ceil(max(b[2] for b in all_boxes))+28)
            y0=max(0,math.floor(min(b[1] for b in all_boxes))-28);y1=min(720,math.ceil(max(b[3] for b in all_boxes))+28)
            if x1-x0<150:
                c=(x0+x1)//2;x0=max(0,c-75);x1=min(1280,x0+150)
            if y1-y0<95:
                c=(y0+y1)//2;y0=max(0,c-48);y1=min(720,y0+96)
            crop=(x0,y0,x1,y1);raw=im.crop(crop)
            scale=min(510/raw.width,220/raw.height)
            size=(round(raw.width*scale),round(raw.height*scale))
            canvas=Image.new('RGB',(1100,745),'#f6f8fa');draw=ImageDraw.Draw(canvas)
            draw.text((20,14),f'{key}  |  {ref} reference',font=large,fill='#182c3a')
            draw.text((20,48),'Original pixels enlarged with nearest-neighbor. All coordinates and errors use original pixels.',font=small,fill='#364453')
            for n,role in enumerate(('raw',*roles)):
                xx=20+(n%2)*550;yy=86+(n//2)*304
                title={'raw':'Original crop','current':'Selected PR35','reference':'Matched endpoint control','candidate':'PR58 composed candidate'}[role]
                draw.text((xx,yy),title,font=font,fill='#182c3a')
                ox=xx+(510-size[0])//2;oy=yy+29
                canvas.paste(raw.resize(size,Image.Resampling.NEAREST),(ox,oy))
                def point(q):return ((q[0]-x0)*scale,(q[1]-y0)*scale)
                def box(b,color,width):draw.rectangle((*point(b[:2]),*point(b[2:])),outline=color,width=width)
                if role=='raw':
                    draw.text((xx,yy+254),f'ROI [{x0}, {y0}, {x1}, {y1}]',font=small,fill='#364453');continue
                canvas_draw=draw
                panel=raw.resize(size,Image.Resampling.NEAREST)
                draw=ImageDraw.Draw(panel)
                s=selected[role];box(g['bbox_xyxy'],'#00b45a',2)
                for q in g['keypoints']:
                    if q[2]==2:
                        a,b=point(q);draw.ellipse((a-5,b-5,a+5,b+5),outline='#00ff66',width=2)
                for alt in s['overlapping_alternatives']:
                    box(alt['prediction']['bbox_xyxy'],'#5a9fdd',1)
                box(s['shown_prediction']['bbox_xyxy'],'#ff661f',2)
                for q in s['shown_prediction']['keypoints']:
                    if q[2]>=.5:
                        a,b=point(q);draw.line((a-5,b-5,a+5,b+5),fill='#ff661f',width=2);draw.line((a-5,b+5,a+5,b-5),fill='#ff661f',width=2)
                canvas.paste(panel,(ox,oy))
                draw=canvas_draw
                state='matched' if s['official_state']['matched'] else 'UNMATCHED; best existing proposal shown'
                draw.text((xx,yy+254),f'{state}; box IoU {s["shown_prediction_iou"]:.6f}',font=small,fill='#364453')
                errs=', '.join('n/a' if v is None else f'{v:.3f}' for v in s['shown_prediction_endpoint_errors_px'])
                draw.text((xx,yy+275),f'Proposal #{s["shown_prediction_index_zero_based"]+1}; L/R errors {errs} px',font=small,fill='#364453')
            draw.text((20,710),'Green: reference  |  Orange: shown prediction  |  Blue: other overlapping proposals (review aid)',font=small,fill='#364453')
            name=key.replace(':','-')+'-'+ref+'.png';canvas.save(args.output/name)
            raw.save(args.output/(key.replace(':','-')+'-raw.png'))
            records.append({'object_id':key,'reference':ref,'image_sha256':sha(image_path),'label_sha256':sha(label),
                            'crop_xyxy':crop,'reference_geometry':g,'models':selected,'figure':name})
    (args.output/'cases.json').write_text(json.dumps({'renderer_sha256':sha(__file__),'cases':records},indent=2)+'\n')
    print(json.dumps({'cases':len(records),'output':str(args.output)}))
if __name__=='__main__':main()
