#!/usr/bin/env python3
"""Independent standard-library recomputation of the fixed PR58 saved predictions.

No project helper imports, model loading, inference, training, or label edits.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys
ROLES = ('reference', 'candidate', 'current')
PAIRS = (('reference', 'candidate'), ('current', 'reference'), ('current', 'candidate'))
RADII = (5, 10)
PROTOCOL_PATH = 'experiments/composed-fronts-2026-11-12.json'
PROTOCOL_SHA = '2e73d4d81585e8ed1759bdb02aea98d8c9db3a856f8887ef9f41069eb799fa3f'
REFERENCES = {
    'primary': ('data/references/visible-front-adjudication-2026-11-12', '75e8689f65f7f32ca7f4657f27d214aa1ba371347812de780c6e5e6ac21af61e'),
    'sensitivity': ('data/references/visible-front-corners-2026-11-12', '28ba06fe7183ebbfa6f295639194a67c4b473c17a8d67c28a9733eb359bdba92')}
ORIGINAL_SHA = '72ae8365d5abf0b45b75d400a2e6d22119c0e31b54ee33035feb8edc1f967926'
MODELS = {'reference': 'a3d9fdc2cf1fa067340ad4f38c9a345e7d480c298852e56b992adaeb9c8d1387',
          'candidate': '7c5f3114dfaeff58a873647d31e1be26e16a1941d3d20890c6a613ab853e41fb',
          'current': '420c00f73eeba24e587342400878b7d96371d3e745772113809aa705ec8163b1'}
checks = 0


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def same(actual, expected, where):
    global checks
    checks += 1
    if isinstance(actual, dict):
        assert isinstance(expected, dict) and actual.keys() == expected.keys(), (where, 'keys')
        for k in actual:
            same(actual[k], expected[k], f'{where}/{k}')
    elif isinstance(actual, list):
        assert isinstance(expected, list) and len(actual) == len(expected), (where, 'length')
        for i, (a, b) in enumerate(zip(actual, expected)):
            same(a, b, f'{where}/{i}')
    elif type(actual) is float:
        assert isinstance(expected, (int, float)) and not isinstance(expected, bool), (where, actual, expected)
        assert math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-10), (where, actual, expected)
    else:
        assert type(actual) is type(expected) and actual == expected, (where, actual, expected)


def quantile(values, q):
    values = sorted(values)
    if not values:
        return None
    pos = (len(values) - 1) * q
    lo, hi = math.floor(pos), math.ceil(pos)
    return values[lo] + (values[hi] - values[lo]) * (pos - lo)


def rate(a, b):
    return a / b if b else None


def labels(path):
    result = []
    for row in Path(path).read_text().splitlines():
        if not row.strip():
            continue
        f = list(map(float, row.split()))
        assert len(f) == 11 and f[0] == 0 and all(math.isfinite(x) for x in f)
        x, y, w, h = f[1:5]
        result.append({'class_id': 0, 'bbox_xyxy': [(x-w/2)*1280, (y-h/2)*720, (x+w/2)*1280, (y+h/2)*720],
                       'keypoints': [[f[k]*1280, f[k+1]*720, int(f[k+2])] for k in (5, 8)]})
    return result


def overlap(a, b):
    inter = max(0, min(a[2], b[2])-max(a[0], b[0])) * max(0, min(a[3], b[3])-max(a[1], b[1]))
    return inter / ((a[2]-a[0])*(a[3]-a[1]) + (b[2]-b[0])*(b[3]-b[1]) - inter)


def available(p):
    return p[2] >= .5 and all(v is not None and math.isfinite(v) for v in p[:2]) and 0 <= p[0] < 1280 and 0 <= p[1] < 720


def score(gold, predicted):
    unmatched = set(range(len(gold)))
    matches = []
    for p in sorted(range(len(predicted)), key=lambda i: (-predicted[i]['confidence'], i)):
        candidates = [(overlap(predicted[p]['bbox_xyxy'], gold[g]['bbox_xyxy']), g) for g in unmatched
                      if predicted[p]['class_id'] == gold[g]['class_id']]
        candidates = [(o, g) for o, g in candidates if o >= .5]
        if candidates:
            o, g = min(candidates, key=lambda pair: (-pair[0], pair[1]))
            unmatched.remove(g)
            matches.append({'gold_index': g, 'prediction_index': p, 'iou': o})
    matched = {m['gold_index']: m for m in matches}
    matched_p = {m['prediction_index'] for m in matches}
    extras = [p for p in range(len(predicted)) if p not in matched_p]
    duplicate = [p for p in extras if any(predicted[p]['class_id'] == gold[g]['class_id'] and
                  overlap(predicted[p]['bbox_xyxy'], gold[g]['bbox_xyxy']) >= .5 for g in matched)]
    objects = []
    for g, obj in enumerate(gold):
        m = matched.get(g)
        visible = [p[2] == 2 for p in obj['keypoints']]
        returned = [available(p) for p in predicted[m['prediction_index']]['keypoints']] if m else [False, False]
        errors = [math.dist(obj['keypoints'][side][:2], predicted[m['prediction_index']]['keypoints'][side][:2])
                  if visible[side] and returned[side] else None for side in (0, 1)]
        objects.append({'reference_row_one_based': g+1, 'locatable_corners': sum(visible),
                        'reference_endpoint_visible': visible, 'matched': m is not None,
                        'prediction_index_zero_based': m['prediction_index'] if m else None,
                        'matching_iou': m['iou'] if m else None, 'endpoint_returned': returned,
                        'visible_endpoint_errors_px': errors,
                        'both_visible_within_radius': {str(r): all(visible) and all(e is not None and e <= r for e in errors) for r in RADII}})
    errors = [e for m in matches for e in objects[m['gold_index']]['visible_endpoint_errors_px'] if e is not None]
    visible = sum(o['locatable_corners'] for o in objects)
    counts = {'gold_count': len(gold), 'prediction_count': len(predicted), 'tp': len(matches),
              'fn': len(unmatched), 'fp': len(extras), 'duplicate_fp': len(duplicate), 'other_fp': len(extras)-len(duplicate),
              'visible_endpoints': visible, 'returned_endpoints': len(errors), 'missing_endpoints': visible-len(errors)}
    counts.update(endpoint_coverage=rate(len(errors), visible), conditional_median_error_px=quantile(errors,.5),
                  conditional_p95_error_px=quantile(errors,.95), endpoint_errors_px=errors,
                  matches=matches, unmatched_gold_indices=sorted(unmatched), unmatched_prediction_indices=extras,
                  duplicate_prediction_indices=duplicate, other_fp_prediction_indices=[p for p in extras if p not in duplicate])
    quality = {'gold_count': len(gold), 'prediction_count': len(predicted), 'tp': len(matches), 'fn': len(unmatched), 'fp': len(extras),
               'visible_endpoints': visible, 'returned_visible_endpoints': len(errors),
               'both_visible_objects': sum(o['locatable_corners']==2 for o in objects),
               'both_visible_objects_with_both_returned': sum(o['locatable_corners']==2 and all(o['endpoint_returned']) for o in objects),
               'unlocatable_reference_endpoints': 2*len(gold)-visible,
               'unlocatable_on_matched_objects': sum(2-o['locatable_corners'] for o in objects if o['matched']),
               'returned_on_unlocatable_reference': sum(not v and r for o in objects for v,r in zip(o['reference_endpoint_visible'],o['endpoint_returned'])),
               'radii': [{'radius_px': r, 'visible_endpoints_within_radius': sum(e<=r for e in errors),
                         'both_visible_objects_within_radius': sum(o['both_visible_within_radius'][str(r)] for o in objects)} for r in RADII]}
    return {'score': counts, 'quality': quality, 'objects': objects}


def pooled(images):
    errors = [e for row in images for e in row['score']['endpoint_errors_px']]
    fields = ('gold_count','prediction_count','tp','fn','fp','duplicate_fp','other_fp','visible_endpoints','returned_endpoints','missing_endpoints')
    s = {k: sum(row['score'][k] for row in images) for k in fields}
    s.update(image_count=len(images), endpoint_coverage=rate(s['returned_endpoints'],s['visible_endpoints']),
             conditional_median_error_px=quantile(errors,.5), conditional_p95_error_px=quantile(errors,.95), endpoint_errors_px=errors)
    qfields = set(images[0]['quality'])-{'radii'}
    q = {k: sum(row['quality'][k] for row in images) for k in qfields}
    q.update(image_count=len(images),object_precision=rate(q['tp'],q['prediction_count']),object_recall=rate(q['tp'],q['gold_count']),
             visible_endpoint_coverage=rate(q['returned_visible_endpoints'],q['visible_endpoints']),
             both_visible_objects_returned_fraction=rate(q['both_visible_objects_with_both_returned'],q['both_visible_objects']),
             returned_on_unlocatable_reference_fraction=rate(q['returned_on_unlocatable_reference'],q['unlocatable_on_matched_objects']))
    q['radii'] = []
    for i,r in enumerate(RADII):
        v=sum(row['quality']['radii'][i]['visible_endpoints_within_radius'] for row in images)
        b=sum(row['quality']['radii'][i]['both_visible_objects_within_radius'] for row in images)
        q['radii'].append({'radius_px':r,'visible_endpoints_within_radius':v,'both_visible_objects_within_radius':b,
                           'visible_endpoint_success_rate':rate(v,q['visible_endpoints']),'both_visible_object_success_rate':rate(b,q['both_visible_objects'])})
    return {'score':s,'quality':q}


def groups(objects):
    out = {}
    for n in range(3):
        rows=[o for o in objects if o['locatable_corners']==n]
        errors=[e for o in rows for e in o['visible_endpoint_errors_px'] if e is not None]
        out[str(n)]={'reference_objects':len(rows),'matched_objects':sum(o['matched'] for o in rows),'missed_objects':sum(not o['matched'] for o in rows),
                    'visible_endpoints':n*len(rows),'returned_visible_endpoints':len(errors),'missing_visible_endpoints':n*len(rows)-len(errors),
                    'unlocatable_on_matched_objects':sum(o['matched'] for o in rows)*(2-n),
                    'returned_on_unlocatable_reference':sum(not v and r for o in rows for v,r in zip(o['reference_endpoint_visible'],o['endpoint_returned'])),
                    'conditional_median_error_px':quantile(errors,.5),'conditional_p95_error_px':quantile(errors,.95),
                    'radii':[{'radius_px':r,'visible_endpoints_within_radius':sum(e<=r for e in errors),
                              'both_visible_objects_within_radius':sum(o['both_visible_within_radius'][str(r)] for o in rows)} for r in RADII]}
    return out


def pairwise(old, new, expected):
    matches=lambda data:{k for k,v in data.items() if v['matched']}
    old_match,new_match=matches(old),matches(new)
    gained,lost=sorted(new_match-old_match),sorted(old_match-new_match)
    same(gained,sorted(expected['gained_object_ids']),'pair/gained')
    same(lost,sorted(expected['lost_object_ids']),'pair/lost')
    same(sorted(gained+lost),sorted(row['object_id'] for row in expected['object_changes']),'pair/object change inventory')
    for row in expected['object_changes']:
        same(old[row['object_id']],row['before'],'pair/object change before')
        same(new[row['object_id']],row['after'],'pair/object change after')
    corners={}
    for r in RADII:
        a={k for k,v in old.items() if v['both_visible_within_radius'][str(r)]}
        b={k for k,v in new.items() if v['both_visible_within_radius'][str(r)]}
        corners[str(r)]={'gained':sorted(b-a),'lost':sorted(a-b)}
        same(corners[str(r)],{k:sorted(v) for k,v in expected['both_corner_changes'][str(r)].items()},'pair/corners')
    out={'gained_object_ids':gained,'lost_object_ids':lost,'both_corner_changes':corners}
    common=old_match & new_match
    published=expected['common_endpoints']
    for key,value in [('matched_before',len(old_match)),('matched_after',len(new_match)),('common_matched_objects',len(common)),('common_matched_object_ids',sorted(common))]:
        same(value,published[key],f'pair/common/{key}')
    out['common_matched_objects']=len(common)
    for flag,name in [(False,'unlocatable'),(True,'locatable')]:
        slots={(k,s) for k,v in old.items() for s,f in enumerate(v['reference_endpoint_visible']) if f==flag}
        shared={slot for slot in slots if slot[0] in common}
        ret=lambda data,pop:{(k,s) for k,s in pop if data[k]['endpoint_returned'][s]}
        a,b=ret(old,slots),ret(new,slots)
        ca,cb=ret(old,shared),ret(new,shared)
        numbers={'full_reference_slots':len(slots),'full_reference_returned_before':len(a),'full_reference_returned_after':len(b),
                 'slots_on_matched_objects_before':sum(k in old_match for k,s in slots),'slots_on_matched_objects_after':sum(k in new_match for k,s in slots),
                 'common_matched_slots':len(shared),'common_matched_returned_before':len(ca),'common_matched_returned_after':len(cb)}
        for key,value in numbers.items():same(value,published[name][key],f'pair/{name}/{key}')
        for key,changes in [('common_matched_availability_changes',ca^cb),('full_reference_availability_changes',a^b)]:
            same(sorted([list(x) for x in changes]),sorted([[s['object_id'],s['side_index_zero_based']] for s in published[name][key]]),f'pair/{name}/{key}')
            for row in published[name][key]:
                k,s=row['object_id'],row['side_index_zero_based']
                for prefix,source in [('before',old),('after',new)]:
                    same(source[k]['matched'],row[prefix+'_matched'],'pair/availability matched')
                    same(source[k]['endpoint_returned'][s],row[prefix+'_returned'],'pair/availability returned')
                    if 'before_error_px' in row:
                        same(source[k]['visible_endpoint_errors_px'][s],row[prefix+'_error_px'],'pair/availability error')
        values={'before':[old[k]['visible_endpoint_errors_px'][s] for k,s in ca], 'after':[new[k]['visible_endpoint_errors_px'][s] for k,s in cb]}
        cond={n:{'count':len(v),'median_px':quantile(v,.5),'p95_px':quantile(v,.95)} for n,v in values.items()} if flag else None
        same(cond,published[name]['common_matched_conditional_errors'],f'pair/{name}/conditional errors')
        identities=lambda x:[{'object_id':k,'side':'left' if s==0 else 'right'} for k,s in sorted(x)]
        out[name]={**numbers,'common_matched_suppressed':identities(ca-cb),'common_matched_newly_returned':identities(cb-ca),
                   'full_reference_lost_returns':identities(a-b),'full_reference_new_returns':identities(b-a),
                   'conditional_errors':cond}
        if flag:
            errors={n:[data[k]['visible_endpoint_errors_px'][s] for k,s in ca&cb] for n,data in [('before',old),('after',new)]}
            delta=[new[k]['visible_endpoint_errors_px'][s]-old[k]['visible_endpoint_errors_px'][s] for k,s in ca&cb]
            out[name]['identical_common_returned_errors']={n:{'count':len(v),'median_px':quantile(v,.5),'p95_px':quantile(v,.95)} for n,v in errors.items()}
            out[name]['paired_error_change']={'count':len(delta),'mean_px':sum(delta)/len(delta) if delta else None,'median_px':quantile(delta,.5),
                                             'better':sum(x<0 for x in delta),'worse':sum(x>0 for x in delta),'equal':sum(x==0 for x in delta)}
    return out



def check_delta(before, after, published, where):
    if isinstance(before, dict) and isinstance(after, dict):
        keys = (before.keys() & after.keys()) - {'endpoint_errors_px'}
        same(sorted(published), sorted(keys), where + '/keys')
        for key in keys:
            if key == 'radius_px':
                same(before[key], after[key], where + '/radius unchanged')
                same(before[key], published[key], where + '/radius')
            else:
                check_delta(before[key], after[key], published[key], where + '/' + key)
    elif isinstance(before, list) and isinstance(after, list) and len(before) == len(after):
        same(len(published), len(before), where + '/length')
        for i, (a, b, value) in enumerate(zip(before, after, published)):
            check_delta(a, b, value, where + '/' + str(i))
    elif isinstance(before, (int, float)) and isinstance(after, (int, float)) and not isinstance(before, bool) and not isinstance(after, bool):
        same(after - before, published, where)
    else:
        same(None if before == after else {'before': before, 'after': after}, published, where)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True, help='Frozen protocol, manifests and label bytes.')
    parser.add_argument('--evaluation', type=Path, required=True, help='Saved prediction and score files.')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--driver', type=Path, help='Optionally verify the exact evaluation driver bytes.')
    parser.add_argument('--image-root', type=Path, help='Optional directory containing the 20 original validation PNGs.')
    parser.add_argument('--skip-image-bytes', action='store_true', help='Replay without reading original PNG bytes; explicitly recorded as unverified.')
    args = parser.parse_args()
    assert __debug__, 'Run without -O; this numerical audit uses assertions.'
    blocked_network = []
    def reject_network(event, arguments):
        if event in {'socket.connect', 'socket.getaddrinfo', 'socket.sendto'}:
            blocked_network.append(event)
            raise PermissionError('Offline numerical audit forbids ' + event)
    sys.addaudithook(reject_network)
    root, e = args.root.resolve(), args.evaluation.resolve()
    load = lambda p: json.loads(Path(p).read_text())
    assert load(e / 'status.json')['status'] == 'complete'
    assert sha(root / PROTOCOL_PATH) == PROTOCOL_SHA
    protocol = load(root / PROTOCOL_PATH)
    assert protocol['evaluation']['primary_box_confidence'] == .13
    assert protocol['evaluation']['diagnostic_box_confidences'] == []
    assert protocol['evaluation']['radii_px'] == list(RADII)
    assert sha(root / 'data/manifest.json') == ORIGINAL_SHA
    original = load(root / 'data/manifest.json')
    records = {r['id']: r for r in original['records'] if r['split'] == 'val'}
    assert len(records) == 20
    if not args.skip_image_bytes:
        for record in records.values():
            image = args.image_root / (record['id'] + '.png') if args.image_root else root / 'data' / record['image']
            assert sha(image) == record['image_sha256'], str(image)
    gold = {name: {} for name in (*REFERENCES, 'original')}
    provenance = {}
    for name, (directory, digest) in REFERENCES.items():
        refbase = root / directory
        assert sha(refbase / 'manifest.json') == digest
        ref = load(refbase / 'manifest.json')
        assert len(ref['files']) == 20 and {r['image_id'] for r in ref['files']} == set(records)
        for item in ref['files']:
            key = item['image_id']
            record = records[key]
            assert item['image_sha256'] == record['image_sha256']
            assert [item['width'], item['height']] == record['original_size'] == [1280, 720]
            path = refbase / item['label_path']
            assert sha(path) == item['label_sha256']
            gold[name][key] = labels(path)
            assert len(gold[name][key]) == item['row_count']
            provenance[str(path.relative_to(root))] = item['label_sha256']
    for key, record in records.items():
        path = root / 'data' / record['label']
        assert sha(path) == record['label_sha256']
        gold['original'][key] = labels(path)
        provenance[str(path.relative_to(root))] = record['label_sha256']
    counts = {}
    for reference, images in gold.items():
        rows = [obj for values in images.values() for obj in values]
        counts[reference] = {'objects': len(rows), 'locatable_endpoints': sum(p[2] == 2 for obj in rows for p in obj['keypoints']),
                             'two_corner_objects': sum(all(p[2] == 2 for p in obj['keypoints']) for obj in rows),
                             'objects_by_locatable_corner_count': {str(n): sum(sum(p[2] == 2 for p in obj['keypoints']) == n for obj in rows) for n in range(3)}}
    assert counts['primary'] == {'objects': 663, 'locatable_endpoints': 1227, 'two_corner_objects': 584, 'objects_by_locatable_corner_count': {'0': 20, '1': 59, '2': 584}}
    assert [counts['sensitivity'][k] for k in ('objects', 'locatable_endpoints', 'two_corner_objects')] == [663, 1228, 584]
    assert [counts['original'][k] for k in ('objects', 'locatable_endpoints', 'two_corner_objects')] == [664, 1227, 584]
    comparison = load(e / 'comparison.json')
    inventory = load(e / 'inventory.json')
    reports, summaries, headers, raw, independent = {}, {}, {}, {}, {}
    for role in ROLES:
        path = e / f'predictions-{role}.jsonl'
        assert sha(path) == inventory[path.name]['sha256'] and path.stat().st_size == inventory[path.name]['size_bytes']
        lines = [json.loads(line) for line in path.read_text().splitlines()]
        header, rows = lines[0], lines[1:]
        headers[role] = header
        assert header['thresholds'] == [.13] and header['role'] == role
        assert header['model_sha256'] == MODELS[role]
        assert header['inference'] == {'imgsz': 1280, 'rect': True, 'batch': 1, 'nms': True, 'iou': .7,
            'max_det': 300, 'quantize': 32, 'save': False, 'save_txt': False, 'save_crop': False, 'show': False, 'verbose': False}
        assert header['identities']['protocol_sha256'] == PROTOCOL_SHA
        assert header['identities']['primary_reference_sha256'] == REFERENCES['primary'][1]
        assert header['identities']['sensitivity_reference_sha256'] == REFERENCES['sensitivity'][1]
        assert header['identities']['original_reference_sha256'] == ORIGINAL_SHA
        assert len(rows) == 20 and {r['image_id'] for r in rows} == set(records)
        raw[role] = {r['image_id']: r for r in rows}
        reports[role], summaries[role], independent[role] = {}, {}, {}
        for row in rows:
            source = records[row['image_id']]
            assert row['threshold'] == .13 and row['image_sha256'] == source['image_sha256'] and row['original_label_sha256'] == source['label_sha256']
            assert [row['width'], row['height']] == source['original_size'] == [1280, 720]
            assert all(p['class_id'] == 0 and .13 < p['confidence'] <= 1 for p in row['predictions'])
        for reference in gold:
            published = load(e / f'scoring-{role}-{reference}.json')['0.13']
            per, states = [], {}
            assert len(published['per_image']) == 20 and {r['image_id'] for r in published['per_image']} == set(records)
            for image in published['per_image']:
                key = image['image_id']
                own = score(gold[reference][key], raw[role][key]['predictions'])
                same(own['score'], image['score'], f'{role}/{reference}/{key}/score')
                same(own['quality'], image['quality'], f'{role}/{reference}/{key}/quality')
                same(own['objects'], image['objects'], f'{role}/{reference}/{key}/objects')
                own['image_id'] = key
                per.append(own)
                states.update({f"{key}:{obj['reference_row_one_based']}": obj for obj in own['objects']})
            p, g = pooled(per), groups(list(states.values()))
            same(p['score'], published['score'], f'{role}/{reference}/aggregate score')
            same(p['quality'], published['quality'], f'{role}/{reference}/aggregate quality')
            same(g, published['groups_by_locatable_corners'], f'{role}/{reference}/groups')
            for scene in ('empty', 'nonempty'):
                rows = [row for row in per if bool(row['score']['gold_count']) == (scene == 'nonempty')]
                same(pooled(rows), published['by_scene'][scene], f'{role}/{reference}/scene/{scene}')
            for lo, hi in ((7, 11), (53, 59), (86, 90), (146, 148)):
                rows = [row for row in per if lo <= int(row['image_id'].split('_')[-1]) <= hi]
                same(pooled(rows), published['by_filename_range'][f'{lo:03d}_{hi:03d}'], f'{role}/{reference}/filename range')
            missfree = [row['image_id'] for row in per if row['score']['gold_count'] and row['score']['fn'] == 0]
            empty = {row['image_id']: row['score']['prediction_count'] for row in per if not row['score']['gold_count']}
            same(missfree, published['miss_free_nonempty_image_ids'], 'miss-free scenes')
            same(empty, published['empty_image_predictions'], 'empty outputs')
            reports[role][reference] = states
            independent[role][reference] = {**p, 'groups': g, 'per_image': {r['image_id']: r for r in per}}
            summaries[role][reference] = {'score': {k: v for k, v in p['score'].items() if k != 'endpoint_errors_px'},
                'quality': p['quality'], 'groups_by_locatable_corners': g, 'miss_free_nonempty_image_ids': missfree, 'empty_image_predictions': empty,
                'nonempty_images_without_misses_or_extras': [row['image_id'] for row in per if row['score']['gold_count'] and row['score']['fn'] == row['score']['fp'] == 0]}
            reported = comparison['metrics'][role][reference]['0.13']
            for key in ('score', 'quality', 'groups_by_locatable_corners', 'miss_free_nonempty_image_ids', 'empty_image_predictions'):
                same(published[key], reported[key], f'{role}/{reference}/comparison summary/{key}')
    pairs = {name: {} for name in gold}
    scalar = lambda data: {k: v for k, v in data.items() if v is None or isinstance(v, (int, float))}
    for reference in gold:
        for before, after in PAIRS:
            name = f'{after}-vs-{before}'
            published = comparison['comparisons'][reference][name]['0.13']
            pairs[reference][name] = pairwise(reports[before][reference], reports[after][reference], published)
            a, b = independent[before][reference], independent[after][reference]
            for key, prior, current in [('score_delta', scalar(a['score']), scalar(b['score'])),
                                        ('quality_delta', a['quality'], b['quality']), ('groups_delta', a['groups'], b['groups'])]:
                check_delta(prior, current, published[key], reference + '/' + name + '/' + key)
            assert len(published['per_image']) == 20 and {r['image_id'] for r in published['per_image']} == set(records)
            for row in published['per_image']:
                key = row['image_id']
                old, new = a['per_image'][key], b['per_image'][key]
                check_delta(scalar(old['score']), scalar(new['score']), row['score_delta'], reference + '/' + name + '/' + key + '/score_delta')
                check_delta(old['quality'], new['quality'], row['quality_delta'], reference + '/' + name + '/' + key + '/quality_delta')
                for change, flag in [('gained', True), ('lost', False)]:
                    changed = [f'{key}:{i + 1}' for i, (x, y) in enumerate(zip(old['objects'], new['objects'])) if x['matched'] != y['matched'] and y['matched'] == flag]
                    same(changed, row[change + '_object_ids'], reference + '/' + name + '/' + key + '/' + change)
    for role in ROLES[1:]:
        same(headers[role]['runtime'], headers[ROLES[0]]['runtime'], 'shared inference runtime')
        same(headers[role]['identities'], headers[ROLES[0]]['identities'], 'shared source and inference identity')
    driver_sha = headers[ROLES[0]]['identities']['driver_sha256']
    if args.driver:
        assert sha(args.driver) == driver_sha
    result = {'status': 'verified',
        'method': 'Independent standard-library label parsing, IoU/greedy matching, returns, Euclidean errors, linear quantiles, numeric deltas and set comparisons; no project scorer or driver imports.',
        'numerical_comparison_tolerance': {'relative': 1e-12, 'absolute': 1e-10}, 'scalar_and_structure_checks': checks,
        'scored_image_reference_cases': len(ROLES) * len(gold) * len(records),
        'checked_reference_object_states': sum(len(states) for refs in reports.values() for states in refs.values()),
        'checked_pairwise_comparisons': len(PAIRS) * len(gold),
        'original_image_bytes_verified': not args.skip_image_bytes,
        'original_image_bytes_verified_count': 0 if args.skip_image_bytes else len(records),
        'audit_script_sha256': sha(__file__), 'evaluated_driver_sha256': driver_sha, 'evaluated_driver_bytes_verified': args.driver is not None,
        'checkpoint_bytes_verified': False, 'checkpoint_note': 'Recorded checkpoint identifiers are checked; this numerical audit neither reads model bytes nor reruns inference.',
        'prediction_sha256': {role: sha(e / f'predictions-{role}.jsonl') for role in ROLES},
        'protocol_sha256': PROTOCOL_SHA, 'reference_manifest_sha256': {k: v[1] for k, v in REFERENCES.items()},
        'original_reference_sha256': ORIGINAL_SHA, 'reference_counts': counts, 'label_sha256': provenance,
        'source_image_sha256': {r['id']: r['image_sha256'] for r in records.values()},
        'network_events_blocked': blocked_network,
        'metrics': summaries, 'comparisons': pairs,
        'scope': 'Numerical and identity audit only; no new original-image adjudication, inference, training or promotion. Replaying stored predictions does not independently verify the inference that produced them.'}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'status': result['status'], 'checks': checks, 'scored_image_reference_cases': result['scored_image_reference_cases'],
                      'original_image_bytes_verified_count': result['original_image_bytes_verified_count'], 'output': str(args.output)}, indent=2))


if __name__ == '__main__':
    main()
