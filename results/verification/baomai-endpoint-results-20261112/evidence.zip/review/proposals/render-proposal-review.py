#!/usr/bin/env python3
"""Fixed-threshold box association and exact-pixel review aids, never inference.

Prediction indexes are zero-based JSON-list positions. This greedy box-to-box
association is separate from the official prediction-to-reference scorer.
Run raw first; overlay requires the recorded original-pixel observations.
Supply the source checkout, saved evaluation, and review-output directories
explicitly with --repo, --evaluation, and --output. No inference is performed.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys

from PIL import Image, ImageDraw, ImageFont

ROLES = ('current', 'old_reviewed', 'endpoint_reviewed')
FONT = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, obj):
    path.write_text(json.dumps(obj, indent=2, allow_nan=False) + '\n')


def iou(a, b):
    a, b = a['bbox_xyxy'], b['bbox_xyxy']
    intersection = max(0, min(a[2], b[2])-max(a[0], b[0])) * max(0, min(a[3], b[3])-max(a[1], b[1]))
    union = (a[2]-a[0])*(a[3]-a[1]) + (b[2]-b[0])*(b[3]-b[1]) - intersection
    return intersection / union if union > 0 else 0


def inputs(root, evaluation):
    data, hashes = {}, {}
    for role in ROLES:
        path = evaluation / f'predictions-{role}.jsonl'
        rows = [json.loads(line) for line in path.read_text().splitlines()]
        assert rows[0]['record_type'] == 'run' and rows[0]['thresholds'] == [0.13]
        data[role] = {r['image_id']: r for r in rows[1:]}
        assert len(data[role]) == 20 and all(r['threshold'] == 0.13 for r in rows[1:])
        assert all(p['confidence'] >= .13 for r in rows[1:] for p in r['predictions'])
        hashes[role] = sha(path)
    records = {r['id']: r for r in json.loads((root/'data/manifest.json').read_text())['records']}
    assert all(set(data[r]) == set(data['current']) for r in ROLES)
    for image_id in data['current']:
        assert records[image_id]['split'] == 'val'
        assert all(data[r][image_id]['image_sha256'] == records[image_id]['image_sha256'] for r in ROLES)
    return data, records, hashes


def associate(data):
    comparisons, endpoint_only = {}, {}
    for role in ROLES[:2]:
        images, totals = {}, dict(paired=0, before_only=0, endpoint_only=0)
        for image_id in sorted(data[role]):
            before = data[role][image_id]['predictions']
            after = data['endpoint_reviewed'][image_id]['predictions']
            edges = sorted((-iou(a,b), i,j) for i,a in enumerate(before) for j,b in enumerate(after)
                           if a['class_id'] == b['class_id'] and iou(a,b) >= .50)
            used_before, used_after, pairs = set(), set(), []
            for neg_overlap,i,j in edges:
                if i not in used_before and j not in used_after:
                    used_before.add(i)
                    used_after.add(j)
                    pairs.append(dict(before_index=i, endpoint_index=j, iou=-neg_overlap))
            only_before = [i for i in range(len(before)) if i not in used_before]
            only_after = [j for j in range(len(after)) if j not in used_after]
            images[image_id] = dict(pairs=pairs, before_only=only_before, endpoint_only=only_after)
            for key, amount in [('paired',len(pairs)), ('before_only',len(only_before)), ('endpoint_only',len(only_after))]:
                totals[key] += amount
            for index in only_after:
                endpoint_only.setdefault((image_id,index), []).append(role)
        totals['before_total'] = totals['paired'] + totals['before_only']
        totals['endpoint_total'] = totals['paired'] + totals['endpoint_only']
        comparisons[role] = dict(counts=totals,images=images)
    cases=[]
    for number, ((image_id,index), roles) in enumerate(sorted(endpoint_only.items()),1):
        pred=data['endpoint_reviewed'][image_id]['predictions'][index]
        x1,y1,x2,y2=pred['bbox_xyxy']
        cx,cy=(x1+x2)/2,(y1+y2)/2
        halfw=max(120,(x2-x1)/2+60)
        halfh=max(80,(y2-y1)/2+60)
        crop=[max(0,math.floor(cx-halfw)),max(0,math.floor(cy-halfh)),
              min(1280,math.ceil(cx+halfw)),min(720,math.ceil(cy+halfh))]
        cases.append(dict(case_id=f'P{number:02d}',image_id=image_id,prediction_index=index,
                          unmatched_against=roles,endpoint_prediction=pred,crop_xyxy=crop,scale=2))
    return comparisons,cases


def open_image(record, root):
    path=root/'data'/record['image']
    assert sha(path)==record['image_sha256']
    im=Image.open(path).convert('RGB')
    assert list(im.size)==record['original_size']
    return im


def text(draw,xy,string,size=18,color='#17212b'):
    draw.text(xy,string,fill=color,font=ImageFont.truetype(FONT,size))


def raw_sheets(cases, records, root, output):
    result=[]
    for offset in range(0,len(cases),4):
        subset=cases[offset:offset+4]
        sheet=Image.new('RGB',(1440,960),'#f5f6f8')
        d=ImageDraw.Draw(sheet)
        text(d,(18,12),'Original pixels only — no model or reference marks',25)
        for k,case in enumerate(subset):
            col,row=k%2,k//2
            left,top=col*720+18,row*450+62
            rect=case['crop_xyxy']
            im=open_image(records[case['image_id']], root).crop(rect)
            enlarged=im.resize((im.width*2,im.height*2),Image.Resampling.NEAREST)
            title=f"{case['case_id']}  {case['image_id']} : prediction {case['prediction_index']}"
            text(d,(left,top),title,20)
            text(d,(left,top+30),f'Crop {rect}; nearest-neighbor 2x',15)
            box=[round(x,1) for x in case['endpoint_prediction']['bbox_xyxy']]
            text(d,(left,top+51),f'Region to inspect in original coordinates: {box}',15)
            sheet.paste(enlarged,(left,top+78))
            assert sheet.crop((left,top+78,left+enlarged.width,top+78+enlarged.height)).tobytes()==enlarged.tobytes()
        path=output/f'raw-contact-sheet-{offset//4+1}.png'
        sheet.save(path)
        result.append(dict(path=path.name,sha256=sha(path),case_ids=[c['case_id'] for c in subset],raw_pixels_exact=True))
    return result


def overlay_sheets(cases, records, data, root, evaluation, output):
    raw_notes=json.loads((output/'raw-observations.json').read_text())
    assert raw_notes['model_or_reference_overlays_seen'] is False
    assert {r['case_id'] for r in raw_notes['cases']} == {c['case_id'] for c in cases}
    sys.path.insert(0,str(root/'scripts'))
    from evaluate_pose import parse_pose_labels
    reference_root=root/'data/references/visible-front-2026-11-11'
    ref_manifest=reference_root/'manifest.json'
    assert sha(ref_manifest)=='2e60b3e81195448cc565a1000b4305e3215baba2bf0ee0c976e6551c2e64937c'
    reference={r['image_id']:r for r in json.loads(ref_manifest.read_text())['files']}
    scores={}
    for role in ROLES:
        score_path=evaluation/f'scoring-{role}-primary.json'
        scores[role]={r['image_id']:r for r in json.loads(score_path.read_text())['0.13']['per_image']}
    rows=[]
    for case in cases:
        image_id=case['image_id']; target=case['endpoint_prediction']; box=case['crop_xyxy']
        ref=reference[image_id]; refpath=reference_root/ref['label_path']
        assert sha(refpath)==ref['label_sha256']
        gold=parse_pose_labels(refpath.read_text(),1280,720,str(refpath))
        original_rows={v:i+1 for i,v in enumerate(ref['retained_source_to_revised_row_one_based']) if v is not None}
        info={**case,'primary_label_sha256':ref['label_sha256'],'nearest_boxes':{},'official_match_by_role':{}}
        for role,proposals in [(r,data[r][image_id]['predictions']) for r in ROLES]+[('primary_reference',gold)]:
            candidates=[dict(index=i,iou=iou(target,p),bbox_xyxy=p['bbox_xyxy'],
                             **({'confidence':p['confidence']} if 'confidence' in p else
                                {'row_one_based':i+1,'original_row_one_based':original_rows.get(i+1)}))
                        for i,p in enumerate(proposals) if role!='endpoint_reviewed' or i!=case['prediction_index']]
            info['nearest_boxes'][role]=sorted(candidates,key=lambda p:(-p['iou'],p['index']))[:5]
            if role in ROLES:
                info['official_match_by_role'][role]=scores[role][image_id]['score']['matches']
        image=open_image(records[image_id], root).crop(box)
        crop=image.resize((image.width*2,image.height*2),Image.Resampling.NEAREST)
        sheet=Image.new('RGB',(1440,1000),'#f5f6f8');d=ImageDraw.Draw(sheet)
        text(d,(18,12),f"{case['case_id']}  {image_id} : endpoint prediction {case['prediction_index']}",24)
        text(d,(18,45),'Box review only. Magenta dashed guide in other panels = target, not their prediction.',17)
        panels=[('current','PR35 proposals','#1f78e6'),('old_reviewed','Matched control proposals','#008596'),
                ('endpoint_reviewed','Endpoint proposals (target magenta; others gray)','#727b83'),
                ('primary_reference','Primary reference annotation boxes','#c09100')]
        for k,(role,title,color) in enumerate(panels):
            left=18+(k%2)*720; top=90+(k//2)*450
            text(d,(left,top),title,20)
            pane=crop.copy();pd=ImageDraw.Draw(pane)
            proposals=gold if role=='primary_reference' else data[role][image_id]['predictions']
            def mapped(b):return [(b[0]-box[0])*2,(b[1]-box[1])*2,(b[2]-box[0])*2,(b[3]-box[1])*2]
            for index,p in enumerate(proposals):
                b=p['bbox_xyxy']
                if min(box[2],b[2])<=max(box[0],b[0]) or min(box[3],b[3])<=max(box[1],b[1]):continue
                is_target=role=='endpoint_reviewed' and index==case['prediction_index']
                stroke='#ed2b91' if is_target else color
                coords=mapped(b)
                pd.rectangle(coords,outline=stroke,width=4 if is_target else 2)
                label=('G'+str(index+1)) if role=='primary_reference' else ('p'+str(index))
                tx=max(1,min(pane.width-65,coords[0]+2));ty=max(1,min(pane.height-23,coords[1]+2))
                pd.rectangle((tx,ty,tx+len(label)*12,ty+22),fill='#f5f6f8')
                text(pd,(tx+1,ty),label,17,stroke)
            if role!='endpoint_reviewed':
                x1,y1,x2,y2=mapped(target['bbox_xyxy'])
                for x in range(math.floor(x1),math.ceil(x2),14):
                    pd.line((x,y1,min(x+7,x2),y1),fill='#ed2b91',width=3)
                    pd.line((x,y2,min(x+7,x2),y2),fill='#ed2b91',width=3)
                for y in range(math.floor(y1),math.ceil(y2),14):
                    pd.line((x1,y,x1,min(y+7,y2)),fill='#ed2b91',width=3)
                    pd.line((x2,y,x2,min(y+7,y2)),fill='#ed2b91',width=3)
            sheet.paste(pane,(left,top+34))
            text(d,(left,top+392),f"Crop {box}; exact source with nearest-neighbor 2x",15)
        path=output/f"overlay-{case['case_id']}.png";sheet.save(path)
        info['overlay']={'path':path.name,'sha256':sha(path)}
        rows.append(info)
    write(output/'overlay-context.json',dict(schema_version=1,reference_manifest_sha256=sha(ref_manifest),
        raw_observations_sha256=sha(output/'raw-observations.json'),cases=rows,renderer_sha256=sha(__file__)))
    return [r['overlay'] for r in rows]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase',choices=['raw','overlay'])
    parser.add_argument('--repo',type=Path,required=True,
                        help='Source checkout containing original images, reference labels, and scripts')
    parser.add_argument('--evaluation',type=Path,required=True,
                        help='Saved evaluation directory containing prediction JSONL and scoring JSON files')
    parser.add_argument('--output',type=Path,required=True,
                        help='Review directory; overlay requires its existing raw-observations.json')
    args=parser.parse_args()
    root,evaluation,output=(p.resolve() for p in (args.repo,args.evaluation,args.output))
    output.mkdir(parents=True,exist_ok=True)
    data,records,hashes=inputs(root,evaluation)
    comparisons,cases=associate(data)
    if args.phase=='raw':
        sheets=raw_sheets(cases,records,root,output)
        write(output/'associations.json',dict(schema_version=1,confidence=0.13,review_iou=.50,
            algorithm='Within each image and same class, sort all qualifying box pairs by (-IoU,before_index,endpoint_index), then greedily take unused endpoints.',
            index_basis='Zero-based position in each prediction JSON list',
            official_gold_matcher=False,prediction_file_sha256=hashes,comparisons=comparisons))
        for c in cases:
            c['source_image_sha256']=records[c['image_id']]['image_sha256']
        write(output/'cases.json',dict(schema_version=1,unique_endpoint_only_proposals=len(cases),cases=cases,
            raw_sheets=sheets,renderer_sha256=sha(__file__),font_sha256=sha(FONT),
            original_pixel_observations_pending=not (output/'raw-observations.json').exists()))
        print(json.dumps(dict(counts={r:c['counts'] for r,c in comparisons.items()},unique_endpoint_only=len(cases),raw_sheets=sheets)))
    else:
        print(json.dumps(dict(overlays=overlay_sheets(cases,records,data,root,evaluation,output))))


if __name__=='__main__':
    main()
