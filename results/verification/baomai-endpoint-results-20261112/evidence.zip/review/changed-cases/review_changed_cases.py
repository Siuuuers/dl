#!/usr/bin/env python3
"""Reproduce the fixed 14-case PR52 review from saved pixels and raw predictions.

No inference, matching changes, reference editing, or threshold search. Existing
score assignments are copied. Alternative-proposal geometry is diagnostic only.
Requires Pillow. The written evidence remains separate from the frozen scorer.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

CASES = {
    "new_000007": [15], "new_000008": [10, 11, 21, 22],
    "new_000011": [4], "new_000056": [3, 14], "new_000058": [1, 7],
    "new_000059": [2], "new_000087": [53], "new_000090": [43, 48],
}
ROLES = ("current", "old_reviewed", "endpoint_reviewed")
ROLE_NAMES = {"current": "PR35 current", "old_reviewed": "Old-label control", "endpoint_reviewed": "Endpoint treatment"}
COLORS = {"current": "#2879bd", "old_reviewed": "#a56a16", "endpoint_reviewed": "#007c73"}
REFERENCE_COLOR = "#bc31aa"
INK = "#172e42"
MUTED = "#4d5e6b"
BACKGROUND = "#f6f8fa"


def read_json(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False) + "\n")


def font(size=20, bold=False):
    name = "DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"
    return ImageFont.truetype("/usr/share/fonts/truetype/dejavu/" + name, size)


def wrap(draw, text, x, y, width, size=20, color=INK, bold=False, spacing=6):
    f = font(size, bold)
    for paragraph in text.split("\n"):
        line = ""
        for word in paragraph.split():
            trial = (line + " " + word).strip()
            if line and draw.textlength(trial, font=f) > width:
                draw.text((x, y), line, font=f, fill=color)
                y += size + spacing
                line = word
            else:
                line = trial
        draw.text((x, y), line, font=f, fill=color)
        y += size + spacing
    return y


def iou(a, b):
    intersection = max(0., min(a[2], b[2]) - max(a[0], b[0])) * max(0., min(a[3], b[3]) - max(a[1], b[1]))
    union = (a[2]-a[0])*(a[3]-a[1]) + (b[2]-b[0])*(b[3]-b[1]) - intersection
    return intersection / union if union else 0.


def parse_row(text, width, height):
    t = list(map(float, text.split()))
    assert len(t) == 11
    cx, cy, bw, bh = t[1:5]
    return {"class_id": int(t[0]), "bbox_xyxy": [(cx-bw/2)*width, (cy-bh/2)*height, (cx+bw/2)*width, (cy+bh/2)*height],
            "keypoints": [[t[5]*width, t[6]*height, int(t[7])], [t[8]*width, t[9]*height, int(t[10])]]}


def returned(p, width=1280, height=720):
    return p[2] >= .5 and all(math.isfinite(x) for x in p[:2]) and 0 <= p[0] < width and 0 <= p[1] < height


def crop_box(b, width, height):
    cw, ch = max(b[2]-b[0]+96, 180), max(b[3]-b[1]+100, 160)
    x, y = (b[0]+b[2])/2, (b[1]+b[3])/2
    return [max(0, math.floor(x-cw/2)), max(0, math.floor(y-ch/2)), min(width, math.ceil(x+cw/2)), min(height, math.ceil(y+ch/2))]


def prediction_evidence(pred, index, ref, assigned_row):
    errors = [math.dist(g[:2], p[:2]) if g[2] == 2 and returned(p) else None for g, p in zip(ref["keypoints"], pred["keypoints"])]
    return {"prediction_index_zero_based": index, "iou_to_this_reference": iou(ref["bbox_xyxy"], pred["bbox_xyxy"]),
            "assigned_corrected_reference_row_one_based": assigned_row, "raw_prediction": pred,
            "raw_endpoint_returnable": [returned(p) for p in pred["keypoints"]],
            "hypothetical_visible_errors_if_assigned_to_this_reference_px": errors,
            "not_a_rescored_assignment": True}


def role_pair_delta(a, b):
    pa, pb = a["comparison_proposal"]["raw_prediction"], b["comparison_proposal"]["raw_prediction"]
    return {"selection": "scored match when present, otherwise highest-IoU existing proposal",
            "first_index_zero_based": a["comparison_proposal"]["prediction_index_zero_based"],
            "second_index_zero_based": b["comparison_proposal"]["prediction_index_zero_based"],
            "max_box_edge_shift_px": max(abs(x-y) for x, y in zip(pa["bbox_xyxy"], pb["bbox_xyxy"])),
            "pairwise_box_iou": iou(pa["bbox_xyxy"], pb["bbox_xyxy"]),
            "raw_endpoint_movement_px": [math.dist(x[:2], y[:2]) for x, y in zip(pa["keypoints"], pb["keypoints"])],
            "raw_endpoint_confidence_delta": [y[2]-x[2] for x, y in zip(pa["keypoints"], pb["keypoints"])]}


def cross(draw, x, y, color, radius=6, width=2):
    draw.line((x-radius, y, x+radius, y), fill=color, width=width)
    draw.line((x, y-radius, x, y+radius), fill=color, width=width)


def draw_geometry(im, crop, ref, proposal=None, color=None, scale=3, alternative=None):
    result = im.crop(crop).resize(((crop[2]-crop[0])*scale, (crop[3]-crop[1])*scale), Image.Resampling.NEAREST)
    draw = ImageDraw.Draw(result)
    def point(p):
        return ((p[0]-crop[0])*scale, (p[1]-crop[1])*scale)
    def box(b):
        return (*point(b[:2]), *point(b[2:]))
    draw.rectangle(box(ref["bbox_xyxy"]), outline=REFERENCE_COLOR, width=2)
    for p in ref["keypoints"]:
        if p[2] == 2:
            x, y = point(p)
            cross(draw, x, y, "white", radius=7, width=4)
            cross(draw, x, y, REFERENCE_COLOR, radius=7, width=2)
    if alternative:
        pred = alternative["raw_prediction"]
        draw.rectangle(box(pred["bbox_xyxy"]), outline="#6a7280", width=2)
        for p in pred["keypoints"]:
            x, y = point(p)
            draw.rectangle((x-4, y-4, x+4, y+4), outline="#535865", width=2)
    if proposal:
        pred = proposal["raw_prediction"]
        draw.rectangle(box(pred["bbox_xyxy"]), outline=color, width=2)
        for p in pred["keypoints"]:
            x, y = point(p)
            draw.ellipse((x-5, y-5, x+5, y+5), fill=color if returned(p) else None, outline="white" if returned(p) else color, width=2)
            if not returned(p):
                cross(draw, x, y, color, radius=6, width=2)
    return result


def max_error(score):
    e = score["visible_endpoint_errors_px"]
    return max(e) if all(x is not None for x in e) else None


def fnum(x, digits=3):
    return "—" if x is None else f"{x:.{digits}f}"


def write_case_figure(output, case, im):
    crop, ref = case["crop"]["xyxy_half_open"], case["reference"]["geometry"]
    cw, ch = (crop[2]-crop[0])*3, (crop[3]-crop[1])*3
    panel_w, panel_h = max(cw, 510), ch+114
    fig = Image.new("RGB", (panel_w*2+72, panel_h*2+180), BACKGROUND)
    draw = ImageDraw.Draw(fig)
    draw.text((24, 18), case["case_id"] + "  |  frozen corrected reference", font=font(27, True), fill=INK)
    draw.text((24, 56), "Original pixels at 3× nearest-neighbor; purple box/crosses = fixed reference", font=font(18), fill=MUTED)
    for index, role in enumerate((None, "current", "old_reviewed", "endpoint_reviewed")):
        x, y = 24+(index%2)*(panel_w+24), 96+(index//2)*panel_h
        title = "Raw crop — no overlays" if role is None else ROLE_NAMES[role]
        draw.text((x, y), title, font=font(22, True), fill=INK if role is None else COLORS[role])
        if role is None:
            pic = im.crop(crop).resize((cw, ch), Image.Resampling.NEAREST)
            sub = f"Crop x[{crop[0]}, {crop[2]}) y[{crop[1]}, {crop[3]})"
        else:
            evidence = case["roles"][role]
            pic = draw_geometry(im, crop, ref, evidence["comparison_proposal"], COLORS[role])
            score, prop = evidence["score"], evidence["comparison_proposal"]
            sub = f"{'Match' if score['matched'] else 'Unmatched; best existing'} p{prop['prediction_index_zero_based']}  IoU {prop['iou_to_this_reference']:.6f}"
        fig.paste(pic, (x, y+34))
        draw.text((x, y+ch+42), sub, font=font(17), fill=INK)
        if role:
            score = case["roles"][role]["score"]
            err = " / ".join(fnum(v) for v in score["visible_endpoint_errors_px"])
            draw.text((x, y+ch+65), f"L/R error: {err} px  |  returned: {score['endpoint_returned']}", font=font(16), fill=MUTED)
    draw.text((24, fig.height-48), "Filled circles = returned prediction; hollow × = below cutoff. No reference point is drawn for v0.", font=font(17), fill=MUTED)
    fig.save(output)


def write_match_summary(output, cases, images):
    ids = ("new_000007:15", "new_000056:14", "new_000090:43", "new_000090:48")
    selected = {c["case_id"]: c for c in cases}
    fig = Image.new("RGB", (1832, 1880), BACKGROUND)
    d = ImageDraw.Draw(fig)
    d.text((32, 24), "Changes in score are not automatically new physical recoveries", font=font(33, True), fill=INK)
    wrap(d, "Four cases that explain assignment, IoU and endpoint-availability changes. Fixed conf 0.13 / match IoU 0.50 / endpoint cutoff 0.50.", 32, 72, 1760, 22, MUTED)
    cols = ((None, "Raw original crop"), ("current", "PR35 current"), ("old_reviewed", "Old-label control"), ("endpoint_reviewed", "Endpoint treatment"))
    for col, (role, label) in enumerate(cols):
        d.text((32+col*450, 134), label, font=font(23, True), fill=COLORS.get(role, INK))
    texts = {
        ids[0]: "007:15 — PR35 already has the more accurate alternative; a tiny confidence ordering change determines which proposal is scored.",
        ids[1]: "056:14 — Same visible front and same existing proposal. Control → treatment largest box-edge shift: 0.261 px.",
        ids[2]: "090:43 — Same visible front and same existing proposal. Control → treatment largest box-edge shift: 0.689 px.",
        ids[3]: "090:48 — Both physical corners are hidden. Treatment crosses the endpoint cutoff on both v0 slots; there is no corner-error ground truth here.",
    }
    for row, cid in enumerate(ids):
        c = selected[cid]
        base = 184+row*400
        wrap(d, texts[cid], 32, base, 1760, 21, INK, True)
        crop, ref = c["crop"]["xyxy_half_open"], c["reference"]["geometry"]
        for col, (role, _) in enumerate(cols):
            x, y = 32+col*450, base+64
            scale = 2
            if role is None:
                pic = images[c["image_id"]].crop(crop).resize(((crop[2]-crop[0])*scale, (crop[3]-crop[1])*scale), Image.Resampling.NEAREST)
                sub = f"Reference row {c['reference']['row_one_based']} | locatable corners: {c['reference']['locatable_corners']}"
            else:
                e = c["roles"][role]
                alt = e["top_overlap_proposals"][0] if cid == ids[0] and role == "current" else None
                pic = draw_geometry(images[c["image_id"]], crop, ref, e["comparison_proposal"], COLORS[role], scale=scale, alternative=alt)
                p, s = e["comparison_proposal"], e["score"]
                sub = f"{'Matched' if s['matched'] else 'Unmatched'} p{p['prediction_index_zero_based']} | IoU {p['iou_to_this_reference']:.6f}"
            max_h = 260
            if pic.height > max_h:
                # Keep exact 2× pixels: crop only empty context, centered on the target.
                trim = (pic.height-max_h)//2
                pic = pic.crop((0, trim, pic.width, trim+max_h))
            fig.paste(pic, (x, y))
            wrap(d, sub, x, base+333, 430, 17, INK)
            if role:
                e = c["roles"][role]
                pp = e["comparison_proposal"]["raw_prediction"]["keypoints"]
                if cid == ids[3]:
                    more = f"Point conf: {pp[0][2]:.4f} / {pp[1][2]:.4f}"
                else:
                    more = "L/R scored error: " + " / ".join(fnum(v) for v in e["score"]["visible_endpoint_errors_px"]) + " px"
                d.text((x, base+360), more, font=font(16), fill=MUTED)
    wrap(d, "Purple box/crosses = frozen reference; colored box/circles = scored match, or best existing proposal if unmatched. Grey in007 shows the already present PR35 alternative. Hollow × = below endpoint cutoff. Original pixels use nearest-neighbor magnification; no image enhancement.", 32, 1800, 1760, 18, MUTED)
    fig.save(output)


def write_threshold_summary(output, cases, images):
    selected = [c for c in cases if c["reference"]["locatable_corners"] == 2 and c["case_id"] != "new_000007:15"]
    assert len(selected) == 10
    width, top, row_h = 1660, 228, 184
    fig = Image.new("RGB", (width, top+row_h*len(selected)+130), BACKGROUND)
    d = ImageDraw.Draw(fig)
    d.text((32, 24), "The 5 px boundary: small movements, mixed directions", font=font(34, True), fill=INK)
    wrap(d, "Ten changed two-corner cases. Raw thumbnails keep the physical context; the plot uses the larger of the two fixed-reference endpoint errors. All three models stay below 10 px on these cases.", 32, 76, 1580, 22, MUTED)
    d.text((32, 162), "Corrected row", font=font(20, True), fill=INK)
    d.text((240, 162), "Raw pixels at 2× (nearest-neighbor)", font=font(20, True), fill=INK)
    d.text((850, 162), "Larger endpoint error (px)", font=font(20, True), fill=INK)
    x0, x1 = 850, 1360
    def px(v): return x0+v/7*(x1-x0)
    for v in range(8):
        d.text((px(v)-6, 197), str(v), font=font(17), fill=MUTED)
        d.line((px(v), top-4, px(v), top+row_h*len(selected)), fill="#bfc7cf" if v == 5 else "#e2e7ec", width=2 if v == 5 else 1)
    d.text((1410, 162), "Exact max error (px)", font=font(16, True), fill=INK)
    for n, c in enumerate(selected):
        y = top+n*row_h
        d.line((24, y+row_h-10, width-24, y+row_h-10), fill="#dce2e7", width=1)
        d.text((32, y+32), c["case_id"].replace("new_000", ""), font=font(23, True), fill=INK)
        old_score = c["roles"]["old_reviewed"]["score"]
        end_score = c["roles"]["endpoint_reviewed"]["score"]
        change = int(end_score["both_visible_within_radius"]["5"])-int(old_score["both_visible_within_radius"]["5"])
        label = "Control → endpoint: " + ("gain" if change>0 else "loss" if change<0 else "same")
        wrap(d, label, 32, y+69, 185, 16, MUTED)
        b = c["reference"]["geometry"]["bbox_xyxy"]
        cr = [max(0, math.floor(b[0]-12)), max(0, math.floor(b[1]-8)), min(1280, math.ceil(b[2]+12)), min(720, math.ceil(b[3]+8))]
        pic = images[c["image_id"]].crop(cr)
        pic = pic.resize((pic.width*2, pic.height*2), Image.Resampling.NEAREST)
        fig.paste(pic, (240, y+12))
        values = {r: max_error(c["roles"][r]["score"]) for r in ROLES}
        yy = y+64
        d.line((px(values['old_reviewed']), yy, px(values['endpoint_reviewed']), yy), fill="#6f808b", width=3)
        for j, r in enumerate(ROLES):
            v = values[r]
            point_y = yy+(-18 if r == "current" else -2 if r == "old_reviewed" else 14)
            d.ellipse((px(v)-5, point_y-5, px(v)+5, point_y+5), fill=COLORS[r], outline="white", width=1)
            d.text((1410, y+24+j*31), f"{v:.3f}", font=font(21, True), fill=COLORS[r])
    legend_y = top+row_h*len(selected)+14
    for j, r in enumerate(ROLES):
        d.ellipse((32+j*350, legend_y+5, 46+j*350, legend_y+19), fill=COLORS[r])
        d.text((57+j*350, legend_y), ROLE_NAMES[r], font=font(19), fill=INK)
    wrap(d, "The 5 px line is a scoring rule, not a physical boundary or an annotation-confidence interval. Several changes are smaller than one original pixel; a few move one corner by 1–5 px and redistribute error. Reference/scoring are unchanged.", 32, legend_y+40, 1580, 19, MUTED)
    fig.save(output)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--repo", type=Path, default=Path("/workspace/scratch/58fa048dfc17/dl-eval52"))
    ap.add_argument("--evaluation", type=Path, default=Path("/workspace/scratch/58fa048dfc17/pr52-work/evaluation"))
    ap.add_argument("--output", type=Path, default=Path(__file__).resolve().parent)
    args = ap.parse_args()
    repo, evaluation, out = args.repo.resolve(), args.evaluation.resolve(), args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    ref_path = repo / "data/references/visible-front-2026-11-11/manifest.json"
    reference = read_json(ref_path)
    assert reference["counts"]["objects"] == 663 and sha(ref_path) == "2e60b3e81195448cc565a1000b4305e3215baba2bf0ee0c976e6551c2e64937c"
    files = {f["image_id"]: f for f in reference["files"]}
    for f in files.values():
        assert sha(ref_path.parent / f["label_path"]) == f["label_sha256"]
    assert sum(len((ref_path.parent / f["label_path"]).read_text().splitlines()) for f in files.values()) == 663
    predictions, scores, source_hashes = {}, {}, {}
    for role in ROLES:
        pp, sp = evaluation / f"predictions-{role}.jsonl", evaluation / f"scoring-{role}-primary.json"
        predictions[role] = {d["image_id"]: d for d in map(json.loads, pp.read_text().splitlines()) if d["record_type"] == "prediction" and d["threshold"] == .13}
        scores[role] = {d["image_id"]: d for d in read_json(sp)["0.13"]["per_image"]}
        source_hashes[pp.name], source_hashes[sp.name] = sha(pp), sha(sp)
    decisions = read_json(out / "adjudications.json")
    cases, images = [], {}
    for iid, rows in CASES.items():
        image_path = repo / "data/images/val" / (iid+".png")
        image_hash = sha(image_path)
        assert image_hash == files[iid]["image_sha256"]
        im = Image.open(image_path).convert("RGB")
        assert im.size == (files[iid]["width"], files[iid]["height"])
        images[iid] = im
        label_path = ref_path.parent / files[iid]["label_path"]
        row_texts = label_path.read_text().splitlines()
        for row in rows:
            cid = f"{iid}:{row}"
            ref = parse_row(row_texts[row-1], *im.size)
            crop = crop_box(ref["bbox_xyxy"], *im.size)
            case_dir = out / "cases" / f"{iid}-r{row:02d}"
            case_dir.mkdir(parents=True, exist_ok=True)
            raw_path = case_dir / "raw.png"
            im.crop(crop).save(raw_path)
            origin = [i+1 for i, revised in enumerate(files[iid]["retained_source_to_revised_row_one_based"]) if revised == row]
            c = {"case_id": cid, "image_id": iid, "image": {"path": str(image_path), "sha256": image_hash, "size": list(im.size)},
                 "crop": {"path": str(raw_path.relative_to(out)), "sha256": sha(raw_path), "xyxy_half_open": crop, "resampling": "raw.png unchanged crop; figures nearest-neighbor magnification"},
                 "reference": {"manifest": str(ref_path), "manifest_sha256": sha(ref_path), "label_path": str(label_path), "label_sha256": sha(label_path),
                               "row_one_based": row, "row_text": row_texts[row-1], "geometry": ref, "locatable_corners": sum(p[2]==2 for p in ref["keypoints"]),
                               "source_original_rows_one_based": origin, "added_corrected_reference_row": row in files[iid]["added_revised_rows_one_based"]},
                 "roles": {}, "assessment": decisions[cid]}
            for role in ROLES:
                prediction_record = predictions[role][iid]
                assert prediction_record["image_sha256"] == image_hash
                pred = prediction_record["predictions"]
                scored_image = scores[role][iid]
                obj = next(o for o in scored_image["objects"] if o["reference_row_one_based"] == row)
                assignments = {o["prediction_index_zero_based"]: o["reference_row_one_based"] for o in scored_image["objects"] if o["matched"]}
                rank = sorted(range(len(pred)), key=lambda i: (-iou(ref["bbox_xyxy"], pred[i]["bbox_xyxy"]), i))
                proposals = [prediction_evidence(pred[i], i, ref, assignments.get(i)) for i in rank[:4] if iou(ref["bbox_xyxy"], pred[i]["bbox_xyxy"]) > .05]
                assert proposals
                mi = obj["prediction_index_zero_based"]
                matched = prediction_evidence(pred[mi], mi, ref, assignments.get(mi)) if mi is not None else None
                if matched:
                    assert abs(matched["iou_to_this_reference"]-obj["matching_iou"]) < 1e-10
                    assert matched["raw_endpoint_returnable"] == obj["endpoint_returned"]
                    for a, b in zip(matched["hypothetical_visible_errors_if_assigned_to_this_reference_px"], obj["visible_endpoint_errors_px"]):
                        assert (a is None and b is None) or (a is not None and b is not None and abs(a-b)<1e-9)
                c["roles"][role] = {"score": obj, "matched_proposal": matched, "top_overlap_proposals": proposals,
                                    "comparison_proposal": matched or proposals[0], "scoring_file": f"scoring-{role}-primary.json", "predictions_file": f"predictions-{role}.jsonl"}
            c["deltas"] = {"control_to_endpoint": role_pair_delta(c["roles"]["old_reviewed"], c["roles"]["endpoint_reviewed"]),
                           "current_to_endpoint": role_pair_delta(c["roles"]["current"], c["roles"]["endpoint_reviewed"])}
            figure = case_dir / "comparison.png"
            write_case_figure(figure, c, im)
            c["comparison_figure"] = {"path": str(figure.relative_to(out)), "sha256": sha(figure)}
            write_json(case_dir / "evidence.json", c)
            cases.append(c)
    assert len(cases) == 14
    summary_paths = (out / "match-and-visibility-changes.png", out / "endpoint-threshold-cases.png")
    write_match_summary(summary_paths[0], cases, images)
    write_threshold_summary(summary_paths[1], cases, images)
    evidence = {"schema_version": 1, "kind": "pr52-changed-reference-case-review", "case_count": 14, "corrected_reference_objects": 663,
                "fixed_settings": {"box_confidence": .13, "matching_iou": .5, "endpoint_confidence": .5, "radii_px": [5, 10]},
                "method": "Whole original images, then raw reference-centered crops, viewed before overlays. Reviewer knew task IDs/questions and prior related results: not fully blind. Existing score assignments copied and verified; alternative overlap/error diagnostics do not change scoring.",
                "limits": ["Assistant image review, not independent human ground truth.", "No labels, predictions, scorer, thresholds or assignments changed.", "v0 means endpoint not locatable in this image; do not score a hidden coordinate against 0,0.", "Source-to-corrected row map comes from frozen manifest, including deletion shifts in058/059.", "Blur and rounded edges prevent subpixel physical interpretation; all numeric deltas are measurements against frozen labels."],
                "source_files_sha256": source_hashes, "reference_manifest_sha256": sha(ref_path),
                "helper_sha256": sha(Path(__file__)), "adjudications_sha256": sha(out / "adjudications.json"), "raw_first_notes_sha256": sha(out / "raw-first-observations.json"),
                "summary_figures": [{"path": p.name, "sha256": sha(p)} for p in summary_paths], "cases": cases}
    write_json(out / "evidence.json", evidence)
    print(json.dumps({"status": "ok", "case_count": len(cases), "evidence": str(out / "evidence.json"), "evidence_sha256": sha(out / "evidence.json"), "summary_figures": evidence["summary_figures"]}, indent=2))


if __name__ == "__main__":
    main()
