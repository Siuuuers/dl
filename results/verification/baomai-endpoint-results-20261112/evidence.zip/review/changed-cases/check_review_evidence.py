#!/usr/bin/env python3
"""Check the bounded review against saved sources; no inference or source writes."""
import argparse
import hashlib
import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path

from PIL import Image, __version__ as pillow_version


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def signature(obj):
    return (obj["matched"], tuple(obj["endpoint_returned"]),
            obj["both_visible_within_radius"]["5"], obj["both_visible_within_radius"]["10"])


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--repo", required=True, type=Path)
    p.add_argument("--evaluation", required=True, type=Path)
    p.add_argument("--folder", type=Path, default=Path(__file__).resolve().parent)
    a = p.parse_args()
    folder = a.folder.resolve()
    e = read(folder / "evidence.json")
    assert e["case_count"] == len(e["cases"]) == 14
    for name, expected in e["source_files_sha256"].items():
        assert digest(a.evaluation / name) == expected, name
    for name, key in [("review_changed_cases.py", "helper_sha256"), ("adjudications.json", "adjudications_sha256"), ("raw-first-observations.json", "raw_first_notes_sha256")]:
        assert digest(folder / name) == e[key], name
    ref = a.repo / "data/references/visible-front-2026-11-11/manifest.json"
    assert digest(ref) == e["reference_manifest_sha256"]
    reference = read(ref)
    assert reference["counts"]["objects"] == 663
    for f in reference["files"]:
        assert digest(ref.parent / f["label_path"]) == f["label_sha256"]
    observed = set()
    for c in e["cases"]:
        observed.add(c["case_id"])
        image_path = a.repo / "data/images/val" / (c["image_id"]+".png")
        assert digest(image_path) == c["image"]["sha256"]
        original = Image.open(image_path).convert("RGB")
        raw = Image.open(folder / c["crop"]["path"]).convert("RGB")
        expected_crop = original.crop(c["crop"]["xyxy_half_open"])
        assert raw.size == expected_crop.size and raw.tobytes() == expected_crop.tobytes()
        assert digest(folder / c["crop"]["path"]) == c["crop"]["sha256"]
        assert digest(folder / c["comparison_figure"]["path"]) == c["comparison_figure"]["sha256"]
        assert read(folder / "cases" / f"{c['image_id']}-r{c['reference']['row_one_based']:02d}" / "evidence.json") == c
    roles = ("current", "old_reviewed", "endpoint_reviewed")
    scores = {r: read(a.evaluation / f"scoring-{r}-primary.json")["0.13"] for r in roles}
    rows = {r: {(im["image_id"], obj["reference_row_one_based"]): obj for im in scores[r]["per_image"] for obj in im["objects"]} for r in roles}
    assert all(len(x) == 663 for x in rows.values())
    assert set(rows["current"]) == set(rows["old_reviewed"]) == set(rows["endpoint_reviewed"])
    changed = {f"{iid}:{row}" for iid, row in rows["current"] if len({signature(rows[r][(iid, row)]) for r in roles}) > 1}
    assert changed == observed, {"missing": sorted(changed-observed), "unexpected": sorted(observed-changed)}
    for figure in e["summary_figures"]:
        assert digest(folder / figure["path"]) == figure["sha256"]
    receipt = {
        "status": "passed", "checked_at_utc": datetime.now(timezone.utc).isoformat(),
        "command_argv": [sys.executable, *sys.argv], "python": platform.python_version(), "pillow": pillow_version,
        "scopes": {
            "review_cases": 14, "unique_original_review_images": 8, "frozen_reference_rows_checked": 663,
            "source_prediction_and_scoring_file_hashes": 6, "reference_label_file_hashes": 20,
            "raw_crop_pixel_equalities": 14, "per_case_evidence_equalities": 14,
            "per_case_figure_hashes": 14, "summary_figure_hashes": 2,
            "complete_changed_case_union": "Exact union over all663 rows and all3 roles of matched, endpoint_returned, both<=5px, both<=10px changes."
        },
        "changed_case_ids": sorted(changed),
        "evidence_sha256": digest(folder / "evidence.json"),
        "source_reference_manifest_sha256": digest(ref),
        "summary_figures": e["summary_figures"],
        "limits": ["These checks validate source identity, crop fidelity, case coverage and internal consistency; they do not certify assistant visual judgments.", "No inference, deserialization, source edits, reference edits or scoring changes."]
    }
    path = folder / "check-report.json"
    path.write_text(json.dumps(receipt, indent=2, ensure_ascii=False)+"\n")
    print(json.dumps({"status": "passed", "changed_case_count": len(changed), "receipt": str(path), "receipt_sha256": digest(path)}, indent=2))


if __name__ == "__main__":
    main()
