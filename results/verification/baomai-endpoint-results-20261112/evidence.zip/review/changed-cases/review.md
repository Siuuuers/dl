# PR52: original-pixel review of all 14 changed reference cases

The two match gains over the paired old-label control are **existing proposals crossing the fixed IoU boundary**. The apparent 10 px improvement over PR35 on `007:15` is an **assignment change among proposals that PR35 already produced**. The ordinary 5 px changes are mixed: mostly subpixel crossings, with two modest point relocations that return close to PR35's existing behavior. On `090:48`, the treatment returns two coordinates on corners that remain physically hidden.

These case-level findings do not establish a new physical recovery or a robust reason to replace PR35. They explain the changed cases only; whole-image extras, omissions and overall adoption are handled by the separate evaluation.

## Review scope and source controls

The reviewer first viewed the eight original whole PNGs. Next came frozen-reference/schema lookup and all 14 raw, reference-centered crops, before any model overlay was created or viewed. Detailed prediction comparison followed. The reviewer knew the requested cases, questions and related earlier findings; this was an original-pixel-first pass, **not a fully blind evaluation**.

All row IDs refer to the frozen **663-object** `visible-front-2026-11-11` reference. Its SHA256 is `2e 60b 3e 81195448cc 565a 1000b 4305e 3215baba 2bf 0ee 0c 976e 6551c 2e 64937c`. The source-to-corrected row map was used directly. The reviewed `058:1/7` and `059:2` happen to occur before the deletion shifts, so their original row numbers remain unchanged. `090:43` retains original row 43 with a bounded box amendment; `090:48` is an appended reference front.

The fixed settings are box confidence **0.13**, matching IoU **0.50**, endpoint confidence **0.50**, and endpoint radii **5 / 10 original pixels**. Every score assignment is copied unchanged from `scoring-ROLE-primary.json`. Raw proposals come from the matching `predictions-ROLE.jsonl`; an alternative's hypothetical error is diagnostic and never substituted into the score.

## Four mechanisms that matter

### 1. `056:14`: a 0.261 px box change creates a counted match

The original image shows a real front left of the thumb. Its left corner is exposed, while its right corner is hidden by the hand. The control already has the same physical proposal at IoU **0.499891458**; treatment reaches **0.503507469**. The largest corresponding box-edge movement is **0.261108 px**, and the visible left point moves **0.218110 px**. PR35 already matches the case at IoU **0.527511665**.

This is a change in the matching decision at a sharp numerical boundary. The right coordinate remains returned despite a missing reference endpoint. The case cannot support a both-corner accuracy claim.

### 2. `090:43`: another existing proposal crosses IoU 0.50

The raw pixels show a tilted front beside the thumb, with only its left physical lower corner exposed. Control has the same proposal at IoU **0.492400767**; treatment reaches **0.500662504**. Maximum box-edge movement is **0.688782 px**, and the visible point moves **0.094369 px**. PR35 already matches at **0.502481050**.

The frozen reference's earlier review shortened one defective lower box edge; it explicitly did not certify every retained edge. This review preserves that reference and reports the boundary sensitivity without quietly revising it.

### 3. `007:15`: PR35 already contains the more accurate alternative

This is the clipped top front at the far-right rack column. PR35's slightly higher-confidence proposal claims it first:

| PR35 proposal, zero-based index | Box confidence | IoU to row 15 | Left / right errors if assigned |
|---|---:|---:|---:|
| p 52, actually matched | 0.304644 | 0.589225 | 14.596 / 14.356 px |
| p 53, already present but unmatched | 0.300398 | 0.850809 | 4.757 / 3.928 px |

The two new models rank the upper-front alternative ahead of the taller competing proposal. Their selected maximum errors are **5.823 px** for control and **5.023 px** for treatment. They pass 10 px but still fail the both-corner 5 px rule. The operational PR35 model already produced a useful alternative; the apparent gain is principally which proposal the confidence-ordered scorer assigns.

### 4. `090:48`: confidence crosses the cutoff while the corners stay hidden

The visible white front facet sits between the jaws and immediately above the finger. The exposed boundary intersections are caused by occlusion; neither is a locatable outer physical lower corner. The frozen `v0 / v0` decision remains supported.

| Model | Left `(x, y, confidence)` | Right `(x, y, confidence)` | Returned slots |
|---|---|---|---|
| PR35 | `(678.984, 484.279, 0.565171)` | `(735.108, 489.052, 0.612504)` | Both |
| Old-label control | `(680.007, 483.635, 0.490709)` | `(736.237, 487.821, 0.457157)` | Neither |
| Endpoint treatment | `(678.921, 484.391, 0.581436)` | `(735.230, 489.192, 0.627939)` | Both |

Treatment moves the points only **1.323 / 1.701 px** relative to control and raises confidence above 0.50. It creates two additional returned-on-v0 slots versus control. PR35 already returns both. **No endpoint error is defined on these hidden slots**; confidence is not evidence that a corner is physically visible.

## All ten ordinary 5 px cases

The numbers below are the **larger of the two matched endpoint errors**. All three models stay within 10 px on every row in this table. Raw-crop observations and both individual endpoint errors are preserved per case in `evidence.json`.

| Corrected reference case | PR35 max error | Control max error | Treatment max error | Interpretation |
|---|---:|---:|---:|---|
| `008:10` | 4.880 | 5.026 | 4.799 | Left point moves 0.232 px versus control; PR35 already passes 5 px. Both outside corners remain visible around the central jaw. |
| `008:11` | 4.148 | 5.265 | 4.488 | A modest asymmetric relocation: left error worsens 1.892 → 4.488 while right improves 5.265 → 2.603 px. Actual point movement 4.556 / 2.750 px. PR35 already passes. |
| `008:21` | 4.831 | 5.182 | 5.064 | Treatment improves slightly over control but crosses to the failing side versus PR35. Left point moves 0.266 px from PR35 on a soft lower-left transition. |
| `008:22` | 6.034 | 4.509 | 4.512 | The gain versus PR35 is already reproduced by control; treatment/control left positions differ 0.130 px. |
| `011:4` | 5.381 | 4.913 | 5.209 | A 0.494 px right-point movement crosses 5 px on a small, soft top-clipped front. |
| `056:3` | 4.647 | 5.038 | 4.787 | A 0.266 px left-point movement crosses 5 px. Same visible front; all three boxes remain only slightly above matching IoU 0.50. |
| `058:1` | 4.978 | 4.778 | 5.007 | Treatment is 0.006609 px beyond 5 px; its max-error difference from PR35 is 0.028813 px. |
| `058:7` | 3.694 | 5.453 | 3.765 | A 1.855 px left-point relocation improves over control; treatment is only 0.075 px from PR35's point. |
| `059:2` | 4.876 | 4.979 | 5.009 | Left point moves only 0.036291 px; error changes 0.029687 px. This pass/fail change has no perceptible physical localization difference. |
| `087:53` | 5.009 | 4.967 | 4.925 | The treatment's right point is 0.111127 px from PR35 and 0.056631 px from control. Soft upper-front corners make the strict boundary fragile. |

There are four 5 px gains and three losses versus control among these cases. Most are smaller than one original pixel. The exceptions should still be described accurately: `008:11` trades error between corners, and `058:7` moves closer to the frozen left point by a modest amount. Neither is a newly detected front or a clear improvement over PR35's existing result.

## Artifacts and checks

- `evidence.json` contains all 14 records, original/reference/prediction/scoring hashes, fixed row text and geometry, scored matches, overlapping alternatives, point movements, raw coordinates/confidences, and review decisions.
- `cases/IMAGE-rNN/evidence.json`, `raw.png` and `comparison.png` are the portable per-case records.
- `match-and-visibility-changes.png` summarizes the four mechanisms above.
- `endpoint-threshold-cases.png` combines raw thumbnails with the fixed-reference error plot.
- `raw-first-observations.json` records the raw-image review order and initial observations.
- `check-report.json` records the actual scoped verification and runtime versions.
- `artifact-inventory.json` lists final file hashes, excluding itself.

The scoped check passed: six prediction/scoring file hashes; all 20 reference-label hashes and 663 rows; eight original image identities;14 pixel-exact raw crops;14 matching per-case evidence records;14 per-case figure hashes; and both summary figure hashes. It independently derives the union of all three models' changes in matching, endpoint return, both-corner 5 px and both-corner 10 px over all 663 objects and confirms **exactly these 14 cases**, with none omitted.

This validates the source identities, crop fidelity, coverage and internal consistency. It does not turn assistant visual judgment into independent human ground truth. Reference labels, scoring, thresholds and model outputs are unchanged.

## Reproduction

Use Python with Pillow and the DejaVu Sans fonts available at the standard Linux font path. The exact versions used are recorded in `check-report.json`. From this review folder, provide any equivalent checkout and evaluation directories whose input hashes match:

```bash
python review_changed_cases.py --repo /path/to/dl --evaluation /path/to/evaluation --output .
python check_review_evidence.py --repo /path/to/dl --evaluation /path/to/evaluation --folder .
```

The helper reads only the original PNGs, frozen reference labels, saved raw predictions, saved primary scores and the included adjudication record. It writes review artifacts to the specified output folder. It performs no model loading, inference, network request, threshold sweep or source edit. The checker compares crop pixels with originals directly and re-derives the complete changed-case inventory.
