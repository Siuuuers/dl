#!/usr/bin/env python3
"""Independently recompute the frozen PR62 scores using only the standard library."""

import argparse
import datetime
import hashlib
import json
import math
import pathlib


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--root", type=pathlib.Path, required=True)
parser.add_argument("--evaluation", type=pathlib.Path, required=True)
parser.add_argument("--returned-zip", type=pathlib.Path, required=True)
parser.add_argument("--output", type=pathlib.Path, required=True)
args = parser.parse_args()
root = args.root.resolve()
p = args.evaluation.resolve()
load = lambda path: json.loads(path.read_text())
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
inputs, published, summary, verification, status = [load(p / (n + ".json")) for n in (
    "inputs", "scores", "summary", "verification", "status")]
raw = {r: load(p / (r + ".json")) for r in ("current", "control", "candidate")}
checks = 0
failures = []


def check(condition, label):
    global checks
    checks += 1
    if not condition:
        failures.append(label)


def equal(actual, expected, label):
    if (isinstance(actual, (int, float)) and not isinstance(actual, bool)
            and isinstance(expected, (int, float)) and not isinstance(expected, bool)):
        check(math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-9), label)
    elif isinstance(actual, dict) and isinstance(expected, dict):
        check(set(actual) == set(expected), label + ": keys")
        for k in actual.keys() & expected.keys():
            equal(actual[k], expected[k], label + "/" + k)
    elif isinstance(actual, (list, tuple)) and isinstance(expected, (list, tuple)):
        check(len(actual) == len(expected), label + ": length")
        for i, (a, b) in enumerate(zip(actual, expected)):
            equal(a, b, label + "/" + str(i))
    else:
        check(actual == expected, label)


check(status["status"] == "complete", "complete status")
check(set(status["files"]) == {"inputs.json", "scores.json", "summary.json", "verification.json",
                              "current.json", "control.json", "candidate.json"}, "exact output inventory")
for name, h in status["files"].items():
    check(digest(p / name) == h, "file digest " + name)
protocol = load(root / "experiments/occlusion-training-2026-11-13.json")
check(digest(root / "experiments/occlusion-training-2026-11-13.json") == verification["protocol_sha256"],
      "protocol digest")
check(digest(args.returned_zip) == "4c94b9ae2496b0ab8846941e7da61eba4931630b805ca7f35a0a9272fc486cad",
      "PR62 archive digest")
refpath = root / protocol["evaluation"]["primary_reference"]["path"]
check(digest(refpath) == protocol["evaluation"]["primary_reference"]["sha256"], "reference manifest digest")
for item in load(refpath)["files"]:
    textpath = refpath.parent / item["label_path"]
    check(digest(textpath) == item["label_sha256"], "reference label digest " + item["image_id"])
    objects = []
    for line in textpath.read_text().splitlines():
        v = [float(x) for x in line.split()]
        if not v:
            continue
        cls, xc, yc, w, h = v[:5]
        W, H = item["width"], item["height"]
        objects.append({"class_id": int(cls),
                        "bbox_xyxy": [(xc - w / 2) * W, (yc - h / 2) * H,
                                      (xc + w / 2) * W, (yc + h / 2) * H],
                        "keypoints": [[v[i] * W, v[i + 1] * H, v[i + 2]] for i in (5, 8)]})
    equal(objects, inputs["clean_references"][item["image_id"]]["objects"],
          "independent label parsing " + item["image_id"])
for r in raw:
    check(raw[r]["model_sha256"] == verification["models"][r]["model_sha256"], "raw model binding " + r)
check(raw["current"]["model_sha256"] == protocol["evaluation"]["PR35"]["checkpoint_sha256"], "PR35 model binding")


def iou(a, b):
    x = max(0, min(a[2], b[2]) - max(a[0], b[0]))
    y = max(0, min(a[3], b[3]) - max(a[1], b[1]))
    inter = x * y
    return inter / ((a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter)


def pt(p, t, W, H):
    finite = p is not None and all(v is not None and math.isfinite(v) for v in p[:2])
    available = bool(finite and 0 <= p[0] < W and 0 <= p[1] < H and p[2] >= .5)
    err = math.hypot(p[0] - t[0], p[1] - t[1]) if finite else None
    return {"reference_xy": t[:2], "raw_prediction": p, "available": available, "error_px": err,
            "within_5px": available and err <= 5, "within_10px": available and err <= 10}


def match_score(ref, preds):
    gold = ref["objects"]
    W, H = ref["width"], ref["height"]
    remaining = set(range(len(gold)))
    matched = {}
    claimed = set()
    pairs = []
    for j in sorted(range(len(preds)), key=lambda j: (-preds[j]["confidence"], j)):
        eligible = [(iou(preds[j]["bbox_xyxy"], gold[i]["bbox_xyxy"]), i) for i in remaining
                    if preds[j]["class_id"] == gold[i]["class_id"]]
        eligible = [(v, i) for v, i in eligible if v >= .5]
        if eligible:
            v, i = sorted(eligible, key=lambda a: (-a[0], a[1]))[0]
            remaining.remove(i)
            claimed.add(j)
            matched[i] = j
            pairs.append({"gold_index": i, "prediction_index": j, "iou": v})
    extra = [j for j in range(len(preds)) if j not in claimed]
    duplicate = [j for j in extra if any(preds[j]["class_id"] == gold[i]["class_id"]
                 and iou(preds[j]["bbox_xyxy"], gold[i]["bbox_xyxy"]) >= .5 for i in matched)]
    states = {}
    errors = []
    for i, t in enumerate(gold):
        pred = preds[matched[i]] if i in matched else None
        points = [pt(pred["keypoints"][s] if pred else None, q, W, H) if q[2] == 2 else None
                  for s, q in enumerate(t["keypoints"])]
        errors.extend(x["error_px"] for x in points if x is not None and x["available"])
        eligible = all(x is not None for x in points)
        states[i] = {"matched": i in matched, "endpoints": points, "pair_eligible": eligible,
                     "pair_available": eligible and all(x["available"] for x in points),
                     **{f"pair_within_{r}px": eligible and all(x[f"within_{r}px"] for x in points)
                        for r in (5, 10)}}
    visible = sum(q[2] == 2 for t in gold for q in t["keypoints"])
    result = {"gold_count": len(gold), "prediction_count": len(preds), "tp": len(matched),
              "fn": len(remaining), "fp": len(extra), "duplicate_fp": len(duplicate),
              "other_fp": len(extra) - len(duplicate), "visible_endpoints": visible,
              "returned_endpoints": len(errors), "missing_endpoints": visible - len(errors)}
    result.update(matches=pairs, unmatched_gold_indices=sorted(remaining), unmatched_prediction_indices=extra,
                  duplicate_prediction_indices=duplicate,
                  other_fp_prediction_indices=[j for j in extra if j not in duplicate])
    return result, states, errors


counts = ("gold_count", "prediction_count", "tp", "fn", "fp", "duplicate_fp", "other_fp",
          "visible_endpoints", "returned_endpoints", "missing_endpoints")


def quantile(values, q):
    v = sorted(values)
    if not v:
        return None
    pos = (len(v) - 1) * q
    lo, hi = math.floor(pos), math.ceil(pos)
    return v[lo] + (v[hi] - v[lo]) * (pos - lo)


derived = {}
for role, data in raw.items():
    refs = inputs["clean_references"]
    check(set(data["clean"]) == set(refs), "clean image set " + role)
    clean_objs = {}
    clean_tot = {k: 0 for k in counts}
    all_errors = []
    empty = []
    missfree = perfect = 0
    for image_id, ref in refs.items():
        preds = data["clean"][image_id]
        check(all(q["confidence"] >= .13 for q in preds), "clean box threshold " + role + "/" + image_id)
        result, states, errors = match_score(ref, preds)
        stored = published[role]["clean"]["images"][image_id]
        equal(result, {k: stored[k] for k in result}, "clean scoring " + role + "/" + image_id)
        for k in counts:
            clean_tot[k] += result[k]
        all_errors += errors
        if not ref["objects"]:
            empty.extend({"image_id": image_id, "prediction_index": j, "prediction": q}
                         for j, q in enumerate(preds))
        missfree += bool(ref["objects"]) and result["fn"] == 0
        perfect += bool(ref["objects"]) and result["fn"] == result["fp"] == 0
        for i, state in states.items():
            key = f"{image_id}:{i + 1}"
            clean_objs[key] = state
            saved = published[role]["clean"]["objects"][key]
            equal(state, {k: saved[k] for k in state}, "clean object " + role + "/" + key)
    clean_tot.update(image_count=len(refs), endpoint_coverage=len(all_errors) / clean_tot["visible_endpoints"],
                     conditional_median_error_px=quantile(all_errors, .5),
                     conditional_p95_error_px=quantile(all_errors, .95),
                     pair_denominator=sum(s["pair_eligible"] for s in clean_objs.values()),
                     pairs_available=sum(s["pair_available"] for s in clean_objs.values()),
                     pairs_within_5px=sum(s["pair_within_5px"] for s in clean_objs.values()),
                     pairs_within_10px=sum(s["pair_within_10px"] for s in clean_objs.values()),
                     empty_outputs=len(empty), nonempty_miss_free_images=missfree,
                     nonempty_images_without_misses_or_extras=perfect)
    equal(clean_tot, summary["clean"][role], "clean aggregate " + role)
    check((clean_tot["gold_count"], clean_tot["visible_endpoints"], clean_tot["pair_denominator"]) == (663, 1227, 584),
          "fixed denominators " + role)
    records, cases = data["probe"], inputs["probe_cases"]
    check(len(records) == len(cases) == 94, "probe case count " + role)
    check(len({c["case_id"] for c in cases}) == 94, "unique probe cases " + role)
    saved_full = {f["case_id"]: f for f in published[role]["probe_scores"]["full_image_scores"]}
    saved_targets = {(t["case_id"], t["row"]): t for t in published[role]["probe_scores"]["target_scores"]}
    targets = {}
    full = {}
    for case, record in zip(cases, records):
        check(all(record[k] == case[k] for k in ("case_id", "image_id", "condition", "input_rgb_sha256")),
              "probe case binding " + role + "/" + case["case_id"])
        ref = inputs["probe_references"][case["image_id"]]
        preds = record["predictions"]
        check(all(q["confidence"] >= .13 for q in preds), "probe box threshold " + role + "/" + case["case_id"])
        result, states, errors = match_score(ref, preds)
        full[case["case_id"]] = result
        equal(result, {k: saved_full[case["case_id"]]["score"][k] for k in result},
              "probe full scoring " + role + "/" + case["case_id"])
        rows = ([t["row"] for t in inputs["probe_protocol"]["targets"] if t["image_id"] == case["image_id"]]
                if case["condition"] == "intact" else [case["target_row"]])
        for row in rows:
            state = states[row - 1]
            entry = {"case_id": case["case_id"], "image_id": case["image_id"], "row": row,
                     "condition": case["condition"],
                     **{k: state[k] for k in ("matched", "pair_available", "pair_within_5px", "pair_within_10px")},
                     "left": state["endpoints"][0], "right": state["endpoints"][1]}
            targetkey = (case["case_id"], row)
            targets[targetkey] = entry
            equal(entry, {k: saved_targets[targetkey][k] for k in entry},
                  "probe target " + role + "/" + str(targetkey))
    group_counts = {}
    for cond in ("intact", "left", "right", "center"):
        group = [t for t in targets.values() if t["condition"] == cond]
        check(len(group) == 30, "fixed target denominator " + role + "/" + cond)
        d = {k: sum(t[k] for t in group) for k in ("matched", "pair_available", "pair_within_5px", "pair_within_10px")}
        for side in ("left", "right"):
            d.update({f"{side}_{k}": sum(t[side][k] for t in group)
                      for k in ("available", "within_5px", "within_10px")})
            d[side + "_available_error_over_10px"] = sum(t[side]["available"] and t[side]["error_px"] > 10 for t in group)
        equal(d, summary["probe"][role]["target_conditions"][cond]["counts"], "probe aggregates " + role + "/" + cond)
        group_counts[cond] = d
    derived[role] = {"clean": clean_tot, "objects": clean_objs, "probe": group_counts,
                     "targets": targets, "empty_predictions": empty}

comparisons = {}
for b in ("current", "control"):
    a, c = derived["candidate"], derived[b]
    clean_gates = {k: a["clean"][k] <= c["clean"][k] for k in ("fn", "fp", "duplicate_fp", "empty_outputs")}
    clean_gates.update({k: a["clean"][k] >= c["clean"][k]
                       for k in ("returned_endpoints", "pairs_within_5px", "pairs_within_10px")})
    equal(clean_gates, summary["comparisons"][b]["clean_nonregression"], "clean gates " + b)
    changes = {}
    for field in ("matched", "pair_available", "pair_within_5px", "pair_within_10px"):
        changes[field] = {
            "gained": sorted(k for k in a["objects"] if a["objects"][k][field] and not c["objects"][k][field]),
            "lost": sorted(k for k in a["objects"] if not a["objects"][k][field] and c["objects"][k][field])}
        for label in ("gained", "lost"):
            equal(changes[field][label], sorted(summary["comparisons"][b]["clean_identity_changes"][field][label]),
                  "clean changed identities " + b + "/" + field + "/" + label)
    covered = {r: sum(t[t["condition"]]["within_10px"] for t in derived[r]["targets"].values()
                      if t["condition"] in ("left", "right")) for r in ("candidate", b)}
    support = []
    for key, t in a["targets"].items():
        side = t["condition"]
        if side not in ("left", "right"):
            continue
        old, new = c["targets"][key][side], t[side]
        if (new["within_10px"] and not old["within_10px"] and old["available"]
                and old["error_px"] - new["error_px"] >= 2):
            support.append({"case_id": t["case_id"], "object": f"{t['image_id']}:{t['row']}",
                            "error_before_px": old["error_px"], "error_after_px": new["error_px"]})
    equal(covered, summary["comparisons"][b]["covered_10px_counts"], "covered counts " + b)
    equal(support, summary["comparisons"][b]["supporting_gains"], "supporting gains " + b)
    gates = {"additional_covered_10px": covered["candidate"] - covered[b] >= 2,
             "two_objects_improve_at_least_2px": len({x["object"] for x in support}) >= 2}
    for cond in ("intact", "left", "right", "center"):
        ca, cb = a["probe"][cond], c["probe"][cond]
        fields = ["matched", "pair_available"]
        if cond in ("left", "right"):
            fields += [cond + "_within_5px", cond + "_within_10px",
                       ("right" if cond == "left" else "left") + "_within_10px"]
        if cond == "center":
            fields += ["pair_within_5px", "pair_within_10px"]
        gates.update({cond + "/" + k: ca[k] >= cb[k] for k in fields})
    equal(gates, summary["comparisons"][b]["probe_gates"], "probe gates " + b)
    numeric = all(clean_gates.values()) and all(gates.values())
    equal(numeric, summary["comparisons"][b]["numeric_gates_pass"], "numeric pass " + b)
    comparisons[b] = {"clean_nonregression": clean_gates, "probe_gates": gates, "covered_10px_counts": covered,
                       "supporting_gains": support, "clean_identity_changes": changes, "numeric_gates_pass": numeric}

clean_equal = raw["current"]["clean"] == raw["control"]["clean"]
probe_equal = all(a["predictions"] == b["predictions"] for a, b in zip(raw["current"]["probe"], raw["control"]["probe"]))
check(clean_equal, "current/control exact clean arrays")
check(probe_equal, "current/control exact probe arrays")
report = {
    "status": "pass" if not failures else "failed",
    "reviewed_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "implementation": "Independent standard-library label parser, direct rectangle IoU, confidence-ordered greedy matching, endpoint filtering, Euclidean errors, pair scoring and gate calculation. No project scoring helpers imported; no inference performed.",
    "checker_source_sha256": digest(pathlib.Path(__file__)),
    "input_files_sha256": {n: digest(p / n) for n in status["files"]},
    "checks": checks,
    "check_count_meaning": "Arithmetic, structure, binding and identity checks on reused records. This is not a count of independent images, examples, experiments or statistical trials.",
    "captured_image_scope": {"clean_development_images": len(inputs["clean_references"]),
                             "synthetic_probe_source_images": len(inputs["probe_references"]),
                             "probe_images_are_subset_of_clean_development_images": set(inputs["probe_references"]).issubset(inputs["clean_references"]),
                             "newly_captured_images": 0,
                             "independent_test_images": 0},
    "failures": failures,
    "cases_checked": {"clean_image_model_cases": 60, "probe_image_model_cases": 282,
                      "clean_object_model_states": 1989, "probe_target_condition_model_states": 360,
                      "probe_endpoint_states": 720},
    "current_control_raw_arrays_exactly_equal": {"clean": clean_equal, "probe": probe_equal},
    "clean": {r: derived[r]["clean"] for r in derived},
    "probe_target_counts": {r: derived[r]["probe"] for r in derived},
    "comparisons": comparisons,
    "candidate_empty_predictions": derived["candidate"]["empty_predictions"],
    "decision": "retain_PR35",
    "decision_scope": "Candidate fails predefined clean nonregression against both comparators; independent arithmetic review does not certify visual identity or natural hidden-point truth. Images and checkpoints are not rerun here."}
args.output.write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n")
print(json.dumps({"status": report["status"], "checks": checks, "failures": failures[:20],
                  "raw_arrays_equal": report["current_control_raw_arrays_exactly_equal"],
                  "captured_image_scope": report["captured_image_scope"],
                  "numeric_gates_pass_against_both": all(x["numeric_gates_pass"] for x in comparisons.values())}, indent=2))
raise SystemExit(1 if failures else 0)
