Cassette folder inference: two-image functional demonstration.
Tested published source revision: df9254ac16f61eb6f5f858dfd4737459d4133a7e
Run python scripts/predict_pose_folder.py --input /path/to/input --output /path/to/new-results --device cpu from that repository revision.
The repository code, pinned inference environment and separately downloaded original epoch173 weights are required.
input/ contains two original development-validation PNGs. output/ contains label-free predictions and overlays.
reference/ is the existing labeled evaluator on the same originals; verification/ preserves commands and exact prediction parity.
This is a functional comparison, not an independent test. Predictions are not approved annotations or physical-visibility measurements.
